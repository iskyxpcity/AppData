.class public final Lcom/chuanyi/voyage/ui/docreader/DocReadAloudService;
.super Landroidx/media3/session/MediaSessionService;
.source "S"


# static fields
.field public static volatile Io:Lgz70;

.field public static volatile Ol:Ljava/lang/String;


# instance fields
.field public IO:Le9y;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Landroidx/media3/session/MediaSessionService;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public final OO()V
    .locals 5

    .line 1
    sget-object v0, Lcom/chuanyi/voyage/ui/docreader/DocReadAloudService;->Io:Lgz70;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    invoke-virtual {p0}, Landroid/app/Service;->stopSelf()V

    .line 6
    .line 7
    .line 8
    return-void

    .line 9
    :cond_0
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/docreader/DocReadAloudService;->IO:Le9y;

    .line 10
    .line 11
    const/4 v2, 0x0

    .line 12
    if-eqz v1, :cond_1

    .line 13
    .line 14
    invoke-virtual {v1}, Le9y;->l()Lgz70;

    .line 15
    .line 16
    .line 17
    move-result-object v1

    .line 18
    goto :goto_0

    .line 19
    :cond_1
    move-object v1, v2

    .line 20
    :goto_0
    if-ne v1, v0, :cond_2

    .line 21
    .line 22
    return-void

    .line 23
    :cond_2
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/docreader/DocReadAloudService;->IO:Le9y;

    .line 24
    .line 25
    if-eqz v1, :cond_4

    .line 26
    .line 27
    invoke-virtual {p0, v1}, Landroidx/media3/session/MediaSessionService;->lI(Le9y;)Z

    .line 28
    .line 29
    .line 30
    move-result v3

    .line 31
    if-eqz v3, :cond_3

    .line 32
    .line 33
    invoke-virtual {p0, v1}, Landroidx/media3/session/MediaSessionService;->IO(Le9y;)V

    .line 34
    .line 35
    .line 36
    :cond_3
    invoke-virtual {v1}, Le9y;->I()V

    .line 37
    .line 38
    .line 39
    :cond_4
    :try_start_0
    new-instance v1, Lx8y;

    .line 40
    .line 41
    invoke-direct {v1, p0, v0}, Lx8y;-><init>(Landroid/content/Context;Lgz70;)V

    .line 42
    .line 43
    .line 44
    const-wide v3, -0x8798a9a0c56e39L    # -1.0710521257597999E306

    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    invoke-static {v3, v4}, Li6t0;->lO(J)Ljava/lang/String;

    .line 50
    .line 51
    .line 52
    move-result-object v0

    .line 53
    iput-object v0, v1, Lx8y;->O:Ljava/lang/String;

    .line 54
    .line 55
    new-instance v0, Landroid/content/Intent;

    .line 56
    .line 57
    const-class v3, Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;

    .line 58
    .line 59
    invoke-direct {v0, p0, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 60
    .line 61
    .line 62
    const-wide v3, -0x8798bda0c56e39L    # -1.07103873190221E306

    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    invoke-static {v3, v4}, Li6t0;->lO(J)Ljava/lang/String;

    .line 68
    .line 69
    .line 70
    move-result-object v3

    .line 71
    sget-object v4, Lcom/chuanyi/voyage/ui/docreader/DocReadAloudService;->Ol:Ljava/lang/String;

    .line 72
    .line 73
    invoke-virtual {v0, v3, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 74
    .line 75
    .line 76
    move-result-object v0

    .line 77
    const/high16 v3, 0x20000000

    .line 78
    .line 79
    invoke-virtual {v0, v3}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 80
    .line 81
    .line 82
    move-result-object v0

    .line 83
    const-wide v3, -0x8798e1a0c56e39L

    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    invoke-static {v3, v4}, Li6t0;->lO(J)Ljava/lang/String;

    .line 89
    .line 90
    .line 91
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 92
    .line 93
    .line 94
    const/4 v3, 0x0

    .line 95
    const/high16 v4, 0xc000000

    .line 96
    .line 97
    invoke-static {p0, v3, v0, v4}, Landroid/app/PendingIntent;->getActivity(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    .line 98
    .line 99
    .line 100
    move-result-object v0

    .line 101
    const-wide v3, -0x8798efa0c56e39L

    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    invoke-static {v3, v4}, Li6t0;->lO(J)Ljava/lang/String;

    .line 107
    .line 108
    .line 109
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 110
    .line 111
    .line 112
    invoke-virtual {v1, v0}, Lx8y;->I(Landroid/app/PendingIntent;)V

    .line 113
    .line 114
    .line 115
    invoke-virtual {v1}, Lx8y;->l()Le9y;

    .line 116
    .line 117
    .line 118
    move-result-object v0

    .line 119
    invoke-virtual {p0, v0}, Landroidx/media3/session/MediaSessionService;->l(Le9y;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 120
    .line 121
    .line 122
    goto :goto_1

    .line 123
    :catchall_0
    move-exception v0

    .line 124
    new-instance v1, Lvqb0;

    .line 125
    .line 126
    invoke-direct {v1, v0}, Lvqb0;-><init>(Ljava/lang/Throwable;)V

    .line 127
    .line 128
    .line 129
    move-object v0, v1

    .line 130
    :goto_1
    invoke-static {v0}, Lxqb0;->l(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 131
    .line 132
    .line 133
    move-result-object v1

    .line 134
    if-eqz v1, :cond_5

    .line 135
    .line 136
    sget-object v1, Lsmj0;->l:Lqmj0;

    .line 137
    .line 138
    const-wide v3, -0x8798b4a0c56e39L

    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    invoke-static {v3, v4}, Li6t0;->lO(J)Ljava/lang/String;

    .line 144
    .line 145
    .line 146
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 147
    .line 148
    .line 149
    :cond_5
    instance-of v1, v0, Lvqb0;

    .line 150
    .line 151
    if-eqz v1, :cond_6

    .line 152
    .line 153
    goto :goto_2

    .line 154
    :cond_6
    move-object v2, v0

    .line 155
    :goto_2
    check-cast v2, Le9y;

    .line 156
    .line 157
    iput-object v2, p0, Lcom/chuanyi/voyage/ui/docreader/DocReadAloudService;->IO:Le9y;

    .line 158
    .line 159
    return-void
.end method

.method public final lo(Lc9y;)Le9y;
    .locals 2

    .line 1
    const-wide v0, -0x879900a0c56e39L

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/docreader/DocReadAloudService;->IO:Le9y;

    .line 10
    .line 11
    return-object p0
.end method

.method public final onCreate()V
    .locals 0

    .line 1
    invoke-super {p0}, Landroidx/media3/session/MediaSessionService;->onCreate()V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Landroidx/media3/session/MediaSessionService;->Ol()V

    .line 5
    .line 6
    .line 7
    invoke-virtual {p0}, Lcom/chuanyi/voyage/ui/docreader/DocReadAloudService;->OO()V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public final onDestroy()V
    .locals 2

    .line 1
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/docreader/DocReadAloudService;->IO:Le9y;

    .line 2
    .line 3
    if-eqz v0, :cond_1

    .line 4
    .line 5
    invoke-virtual {p0, v0}, Landroidx/media3/session/MediaSessionService;->lI(Le9y;)Z

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    if-eqz v1, :cond_0

    .line 10
    .line 11
    invoke-virtual {p0, v0}, Landroidx/media3/session/MediaSessionService;->IO(Le9y;)V

    .line 12
    .line 13
    .line 14
    :cond_0
    invoke-virtual {v0}, Le9y;->I()V

    .line 15
    .line 16
    .line 17
    :cond_1
    const/4 v0, 0x0

    .line 18
    iput-object v0, p0, Lcom/chuanyi/voyage/ui/docreader/DocReadAloudService;->IO:Le9y;

    .line 19
    .line 20
    invoke-super {p0}, Landroidx/media3/session/MediaSessionService;->onDestroy()V

    .line 21
    .line 22
    .line 23
    return-void
.end method

.method public final onStartCommand(Landroid/content/Intent;II)I
    .locals 0

    .line 1
    invoke-virtual {p0}, Lcom/chuanyi/voyage/ui/docreader/DocReadAloudService;->OO()V

    .line 2
    .line 3
    .line 4
    invoke-super {p0, p1, p2, p3}, Landroidx/media3/session/MediaSessionService;->onStartCommand(Landroid/content/Intent;II)I

    .line 5
    .line 6
    .line 7
    const/4 p0, 0x1

    .line 8
    return p0
.end method

.method public final onTaskRemoved(Landroid/content/Intent;)V
    .locals 1

    .line 1
    iget-object p1, p0, Lcom/chuanyi/voyage/ui/docreader/DocReadAloudService;->IO:Le9y;

    .line 2
    .line 3
    if-eqz p1, :cond_0

    .line 4
    .line 5
    invoke-virtual {p1}, Le9y;->l()Lgz70;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    goto :goto_0

    .line 10
    :cond_0
    const/4 p1, 0x0

    .line 11
    :goto_0
    if-eqz p1, :cond_2

    .line 12
    .line 13
    invoke-interface {p1}, Lgz70;->getPlayWhenReady()Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    if-nez v0, :cond_1

    .line 18
    .line 19
    goto :goto_1

    .line 20
    :cond_1
    return-void

    .line 21
    :cond_2
    :goto_1
    if-eqz p1, :cond_3

    .line 22
    .line 23
    invoke-interface {p1}, Lgz70;->pause()V

    .line 24
    .line 25
    .line 26
    :cond_3
    invoke-virtual {p0}, Landroid/app/Service;->stopSelf()V

    .line 27
    .line 28
    .line 29
    return-void
.end method
