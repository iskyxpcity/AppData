.class public final Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;
.super Lyfp;
.source "S"


# static fields
.field public static final Ol:Lod8;


# instance fields
.field public final II:Llxh;

.field public final IO:Lpxh;

.field public Il:Landroidx/fragment/app/FragmentContainerView;

.field public final Io:Lnxh;

.field public lI:Lhzh;

.field public lO:Lp9g0;

.field public ll:Ljava/lang/String;

.field public lo:Lkzh;

.field public final o:Lo2n0;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    const-wide v0, -0x87a1eca0c56e39L

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    const-wide v0, -0x87a210a0c56e39L

    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 15
    .line 16
    .line 17
    const-wide v0, -0x87a217a0c56e39L

    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    new-instance v0, Lod8;

    .line 26
    .line 27
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 28
    .line 29
    .line 30
    sput-object v0, Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;->Ol:Lod8;

    .line 31
    .line 32
    return-void
.end method

.method public constructor <init>()V
    .locals 6

    .line 1
    invoke-direct {p0}, Lyfp;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Loxh;

    .line 5
    .line 6
    const/4 v1, 0x0

    .line 7
    invoke-direct {v0, p0, v1}, Loxh;-><init>(Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;B)V

    .line 8
    .line 9
    .line 10
    new-instance v1, Lo2n0;

    .line 11
    .line 12
    const-class v2, Lt0i;

    .line 13
    .line 14
    invoke-static {v2}, Lkotlin/jvm/internal/Reflection;->getOrCreateKotlinClass(Ljava/lang/Class;)Lkotlin/reflect/KClass;

    .line 15
    .line 16
    .line 17
    move-result-object v2

    .line 18
    new-instance v3, Loxh;

    .line 19
    .line 20
    const/4 v4, 0x1

    .line 21
    invoke-direct {v3, p0, v4}, Loxh;-><init>(Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;B)V

    .line 22
    .line 23
    .line 24
    new-instance v4, Loxh;

    .line 25
    .line 26
    const/4 v5, 0x2

    .line 27
    invoke-direct {v4, p0, v5}, Loxh;-><init>(Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;B)V

    .line 28
    .line 29
    .line 30
    invoke-direct {v1, v2, v3, v0, v4}, Lo2n0;-><init>(Lkotlin/reflect/KClass;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;)V

    .line 31
    .line 32
    .line 33
    iput-object v1, p0, Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;->o:Lo2n0;

    .line 34
    .line 35
    new-instance v0, Lkzh;

    .line 36
    .line 37
    const/4 v1, 0x0

    .line 38
    const/16 v2, 0xf

    .line 39
    .line 40
    invoke-direct {v0, v2, v1}, Lkzh;-><init>(ILjava/util/Map;)V

    .line 41
    .line 42
    .line 43
    iput-object v0, p0, Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;->lo:Lkzh;

    .line 44
    .line 45
    new-instance v0, Llxh;

    .line 46
    .line 47
    invoke-direct {v0, p0}, Llxh;-><init>(Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;)V

    .line 48
    .line 49
    .line 50
    iput-object v0, p0, Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;->II:Llxh;

    .line 51
    .line 52
    new-instance v0, Lpxh;

    .line 53
    .line 54
    invoke-direct {v0, p0}, Lpxh;-><init>(Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;)V

    .line 55
    .line 56
    .line 57
    iput-object v0, p0, Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;->IO:Lpxh;

    .line 58
    .line 59
    new-instance v0, Lnxh;

    .line 60
    .line 61
    invoke-direct {v0, p0}, Lnxh;-><init>(Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;)V

    .line 62
    .line 63
    .line 64
    iput-object v0, p0, Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;->Io:Lnxh;

    .line 65
    .line 66
    return-void
.end method

.method public static Oo(Landroid/content/Intent;)Landroid/net/Uri;
    .locals 5

    .line 1
    const/4 v0, 0x0

    .line 2
    if-nez p0, :cond_0

    .line 3
    .line 4
    goto :goto_3

    .line 5
    :cond_0
    invoke-virtual {p0}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    const-class v2, Landroid/net/Uri;

    .line 10
    .line 11
    if-eqz v1, :cond_2

    .line 12
    .line 13
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    .line 14
    .line 15
    .line 16
    move-result v3

    .line 17
    const v4, -0x45ee9a33

    .line 18
    .line 19
    .line 20
    if-eq v3, v4, :cond_1

    .line 21
    .line 22
    goto :goto_0

    .line 23
    :cond_1
    const-wide v3, -0x879f82a0c56e39L

    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    invoke-static {v3, v4}, Li6t0;->lO(J)Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    move-result-object v3

    .line 32
    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 33
    .line 34
    .line 35
    move-result v1

    .line 36
    if-eqz v1, :cond_2

    .line 37
    .line 38
    const-wide v3, -0x879f9da0c56e39L

    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    invoke-static {v3, v4}, Li6t0;->lO(J)Ljava/lang/String;

    .line 44
    .line 45
    .line 46
    move-result-object v1

    .line 47
    invoke-static {p0, v1, v2}, Landroidx/core/content/IntentCompat;->getParcelableExtra(Landroid/content/Intent;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    move-result-object v1

    .line 51
    check-cast v1, Landroid/net/Uri;

    .line 52
    .line 53
    if-nez v1, :cond_3

    .line 54
    .line 55
    invoke-virtual {p0}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    .line 56
    .line 57
    .line 58
    move-result-object v1

    .line 59
    goto :goto_1

    .line 60
    :cond_2
    :goto_0
    invoke-virtual {p0}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    .line 61
    .line 62
    .line 63
    move-result-object v1

    .line 64
    if-nez v1, :cond_3

    .line 65
    .line 66
    const-wide v3, -0x879fb9a0c56e39L

    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    invoke-static {v3, v4}, Li6t0;->lO(J)Ljava/lang/String;

    .line 72
    .line 73
    .line 74
    move-result-object v1

    .line 75
    invoke-static {p0, v1, v2}, Landroidx/core/content/IntentCompat;->getParcelableExtra(Landroid/content/Intent;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 76
    .line 77
    .line 78
    move-result-object v1

    .line 79
    check-cast v1, Landroid/net/Uri;

    .line 80
    .line 81
    :cond_3
    :goto_1
    if-nez v1, :cond_6

    .line 82
    .line 83
    invoke-virtual {p0}, Landroid/content/Intent;->getClipData()Landroid/content/ClipData;

    .line 84
    .line 85
    .line 86
    move-result-object p0

    .line 87
    if-eqz p0, :cond_5

    .line 88
    .line 89
    invoke-virtual {p0}, Landroid/content/ClipData;->getItemCount()I

    .line 90
    .line 91
    .line 92
    move-result v1

    .line 93
    if-lez v1, :cond_4

    .line 94
    .line 95
    goto :goto_2

    .line 96
    :cond_4
    move-object p0, v0

    .line 97
    :goto_2
    if-eqz p0, :cond_5

    .line 98
    .line 99
    const/4 v1, 0x0

    .line 100
    invoke-virtual {p0, v1}, Landroid/content/ClipData;->getItemAt(I)Landroid/content/ClipData$Item;

    .line 101
    .line 102
    .line 103
    move-result-object p0

    .line 104
    if-eqz p0, :cond_5

    .line 105
    .line 106
    invoke-virtual {p0}, Landroid/content/ClipData$Item;->getUri()Landroid/net/Uri;

    .line 107
    .line 108
    .line 109
    move-result-object p0

    .line 110
    return-object p0

    .line 111
    :cond_5
    :goto_3
    return-object v0

    .line 112
    :cond_6
    return-object v1
.end method


# virtual methods
.method public final Io(ILkud;)V
    .locals 7

    .line 1
    move-object v5, p2

    .line 2
    check-cast v5, Ltgn;

    .line 3
    .line 4
    const p2, -0x224c0dec

    .line 5
    .line 6
    .line 7
    invoke-virtual {v5, p2}, Ltgn;->OOl(I)Ltgn;

    .line 8
    .line 9
    .line 10
    const-wide v0, -0x879c61a0c56e39L

    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    invoke-virtual {v5, p0}, Ltgn;->Il(Ljava/lang/Object;)Z

    .line 19
    .line 20
    .line 21
    move-result p2

    .line 22
    const/4 v0, 0x2

    .line 23
    if-eqz p2, :cond_0

    .line 24
    .line 25
    const/4 p2, 0x4

    .line 26
    goto :goto_0

    .line 27
    :cond_0
    move p2, v0

    .line 28
    :goto_0
    or-int/2addr p2, p1

    .line 29
    and-int/lit8 v1, p2, 0x3

    .line 30
    .line 31
    const/4 v6, 0x1

    .line 32
    if-eq v1, v0, :cond_1

    .line 33
    .line 34
    move v0, v6

    .line 35
    goto :goto_1

    .line 36
    :cond_1
    const/4 v0, 0x0

    .line 37
    :goto_1
    and-int/2addr p2, v6

    .line 38
    invoke-virtual {v5, p2, v0}, Ltgn;->Iol(IZ)Z

    .line 39
    .line 40
    .line 41
    move-result p2

    .line 42
    if-eqz p2, :cond_3

    .line 43
    .line 44
    const-wide v0, -0x879d1aa0c56e39L

    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 50
    .line 51
    .line 52
    invoke-static {v5}, Lxuv;->l(Lkud;)Lu2n0;

    .line 53
    .line 54
    .line 55
    move-result-object v1

    .line 56
    if-eqz v1, :cond_2

    .line 57
    .line 58
    const-wide v2, -0x879dbea0c56e39L

    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    invoke-static {v1, v5, v2, v3}, Lscp;->Il(Lu2n0;Ltgn;J)Lq2n0;

    .line 64
    .line 65
    .line 66
    move-result-object v3

    .line 67
    invoke-static {v1}, Lvrh0;->lIl(Lu2n0;)Ltze;

    .line 68
    .line 69
    .line 70
    move-result-object v4

    .line 71
    const-class p2, Lyce0;

    .line 72
    .line 73
    invoke-static {p2}, Lkotlin/jvm/internal/Reflection;->getOrCreateKotlinClass(Ljava/lang/Class;)Lkotlin/reflect/KClass;

    .line 74
    .line 75
    .line 76
    move-result-object v0

    .line 77
    const/4 v2, 0x0

    .line 78
    invoke-static/range {v0 .. v5}, Lijh0;->Ol(Lkotlin/reflect/KClass;Lu2n0;Ljava/lang/String;Lq2n0;Ltze;Lkud;)Ll2n0;

    .line 79
    .line 80
    .line 81
    move-result-object p2

    .line 82
    check-cast p2, Lyce0;

    .line 83
    .line 84
    iget-object p2, p2, Lyce0;->I:Ldpa0;

    .line 85
    .line 86
    invoke-static {p2, v5}, Ldl8;->Io(Lwbg0;Lkud;)Lkc10;

    .line 87
    .line 88
    .line 89
    move-result-object p2

    .line 90
    invoke-interface {p2}, Lubg0;->getValue()Ljava/lang/Object;

    .line 91
    .line 92
    .line 93
    move-result-object p2

    .line 94
    check-cast p2, Loce0;

    .line 95
    .line 96
    new-instance v0, Lgxh;

    .line 97
    .line 98
    invoke-direct {v0, p0, v6}, Lgxh;-><init>(Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;B)V

    .line 99
    .line 100
    .line 101
    const v1, 0x31915772    # 4.229997E-9f

    .line 102
    .line 103
    .line 104
    invoke-static {v1, v0, v5}, Lbe9;->IlI(ILu6n;Lkud;)Lggd;

    .line 105
    .line 106
    .line 107
    move-result-object v0

    .line 108
    const/16 v1, 0x38

    .line 109
    .line 110
    invoke-static {p2, v0, v5, v1}, Lccj0;->O(Loce0;Lggd;Lkud;I)V

    .line 111
    .line 112
    .line 113
    goto :goto_2

    .line 114
    :cond_2
    const-wide p0, -0x879d7da0c56e39L

    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    invoke-static {p0, p1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 120
    .line 121
    .line 122
    move-result-object p0

    .line 123
    invoke-static {p0}, Lvv70;->II(Ljava/lang/Object;)V

    .line 124
    .line 125
    .line 126
    return-void

    .line 127
    :cond_3
    invoke-virtual {v5}, Ltgn;->Ioo()V

    .line 128
    .line 129
    .line 130
    :goto_2
    invoke-virtual {v5}, Ltgn;->llI()Ldya0;

    .line 131
    .line 132
    .line 133
    move-result-object p2

    .line 134
    if-eqz p2, :cond_4

    .line 135
    .line 136
    new-instance v0, Lgxh;

    .line 137
    .line 138
    invoke-direct {v0, p0, p1}, Lgxh;-><init>(Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;I)V

    .line 139
    .line 140
    .line 141
    iput-object v0, p2, Ldya0;->o:Lkotlin/jvm/functions/Function2;

    .line 142
    .line 143
    :cond_4
    return-void
.end method

.method public final OI()Lt0i;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;->o:Lo2n0;

    .line 2
    .line 3
    invoke-virtual {p0}, Lo2n0;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Lt0i;

    .line 8
    .line 9
    return-object p0
.end method

.method public final OO(Lhzh;)V
    .locals 6

    .line 1
    iget-object v0, p1, Lhzh;->l:Lruh;

    .line 2
    .line 3
    iget-object v0, v0, Lruh;->l:Ljava/lang/String;

    .line 4
    .line 5
    iput-object v0, p0, Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;->ll:Ljava/lang/String;

    .line 6
    .line 7
    invoke-virtual {p0}, Landroidx/fragment/app/lOO;->getSupportFragmentManager()Landroidx/fragment/app/IIO;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    const-wide v1, -0x879e58a0c56e39L

    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object v1

    .line 20
    invoke-virtual {v0, v1}, Landroidx/fragment/app/IIO;->lOO(Ljava/lang/String;)Landroidx/fragment/app/lIl;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    const/4 v1, 0x1

    .line 25
    if-eqz v0, :cond_0

    .line 26
    .line 27
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 28
    .line 29
    .line 30
    move-result-object v2

    .line 31
    iget-object v3, p1, Lhzh;->lO:Ljava/lang/Class;

    .line 32
    .line 33
    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 34
    .line 35
    .line 36
    move-result v2

    .line 37
    if-eqz v2, :cond_0

    .line 38
    .line 39
    iget-object v2, p0, Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;->lI:Lhzh;

    .line 40
    .line 41
    if-eqz v2, :cond_2

    .line 42
    .line 43
    if-ne v2, p1, :cond_0

    .line 44
    .line 45
    goto :goto_0

    .line 46
    :cond_0
    invoke-virtual {p0}, Landroidx/fragment/app/lOO;->getSupportFragmentManager()Landroidx/fragment/app/IIO;

    .line 47
    .line 48
    .line 49
    move-result-object v2

    .line 50
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 51
    .line 52
    .line 53
    new-instance v3, Landroidx/fragment/app/l;

    .line 54
    .line 55
    invoke-direct {v3, v2}, Landroidx/fragment/app/l;-><init>(Landroidx/fragment/app/IIO;)V

    .line 56
    .line 57
    .line 58
    const-wide v4, -0x879e66a0c56e39L

    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    invoke-static {v4, v5}, Li6t0;->lO(J)Ljava/lang/String;

    .line 64
    .line 65
    .line 66
    if-eqz v0, :cond_1

    .line 67
    .line 68
    invoke-virtual {v3, v0}, Landroidx/fragment/app/l;->lo(Landroidx/fragment/app/lIl;)Landroidx/fragment/app/l;

    .line 69
    .line 70
    .line 71
    :cond_1
    iget-object v0, p1, Lhzh;->lO:Ljava/lang/Class;

    .line 72
    .line 73
    const-wide v4, -0x879e7ca0c56e39L

    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    invoke-static {v4, v5}, Li6t0;->lO(J)Ljava/lang/String;

    .line 79
    .line 80
    .line 81
    move-result-object v2

    .line 82
    iget-object v4, v3, Loxm;->l:Ltwm;

    .line 83
    .line 84
    if-eqz v4, :cond_c

    .line 85
    .line 86
    iget-object v5, v3, Loxm;->I:Ljava/lang/ClassLoader;

    .line 87
    .line 88
    if-eqz v5, :cond_b

    .line 89
    .line 90
    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 91
    .line 92
    .line 93
    move-result-object v0

    .line 94
    invoke-virtual {v4, v5, v0}, Ltwm;->instantiate(Ljava/lang/ClassLoader;Ljava/lang/String;)Landroidx/fragment/app/lIl;

    .line 95
    .line 96
    .line 97
    move-result-object v0

    .line 98
    const v4, 0x7f090245

    .line 99
    .line 100
    .line 101
    invoke-virtual {v3, v4, v0, v2, v1}, Landroidx/fragment/app/l;->lI(ILandroidx/fragment/app/lIl;Ljava/lang/String;I)V

    .line 102
    .line 103
    .line 104
    invoke-virtual {v3}, Landroidx/fragment/app/l;->O()V

    .line 105
    .line 106
    .line 107
    :cond_2
    :goto_0
    invoke-virtual {p0}, Landroidx/fragment/app/lOO;->getSupportFragmentManager()Landroidx/fragment/app/IIO;

    .line 108
    .line 109
    .line 110
    move-result-object v0

    .line 111
    const-wide v2, -0x879e8aa0c56e39L

    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    invoke-static {v2, v3}, Li6t0;->lO(J)Ljava/lang/String;

    .line 117
    .line 118
    .line 119
    move-result-object v2

    .line 120
    invoke-virtual {v0, v2}, Landroidx/fragment/app/IIO;->lOO(Ljava/lang/String;)Landroidx/fragment/app/lIl;

    .line 121
    .line 122
    .line 123
    move-result-object v0

    .line 124
    if-nez v0, :cond_3

    .line 125
    .line 126
    goto :goto_4

    .line 127
    :cond_3
    iput-object p1, p0, Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;->lI:Lhzh;

    .line 128
    .line 129
    iget-object p1, p1, Lhzh;->ll:Ltwh;

    .line 130
    .line 131
    iput-object p0, p1, Ltwh;->l:Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;

    .line 132
    .line 133
    instance-of p1, v0, Lorg/readium/r2/navigator/VisualNavigator;

    .line 134
    .line 135
    const/4 v2, 0x0

    .line 136
    if-eqz p1, :cond_4

    .line 137
    .line 138
    move-object p1, v0

    .line 139
    check-cast p1, Lorg/readium/r2/navigator/VisualNavigator;

    .line 140
    .line 141
    goto :goto_1

    .line 142
    :cond_4
    move-object p1, v2

    .line 143
    :goto_1
    if-eqz p1, :cond_5

    .line 144
    .line 145
    iget-object v3, p0, Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;->IO:Lpxh;

    .line 146
    .line 147
    invoke-interface {p1, v3}, Lorg/readium/r2/navigator/VisualNavigator;->removeInputListener(Lorg/readium/r2/navigator/input/InputListener;)V

    .line 148
    .line 149
    .line 150
    iget-object v3, p0, Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;->IO:Lpxh;

    .line 151
    .line 152
    invoke-interface {p1, v3}, Lorg/readium/r2/navigator/VisualNavigator;->addInputListener(Lorg/readium/r2/navigator/input/InputListener;)V

    .line 153
    .line 154
    .line 155
    :cond_5
    instance-of p1, v0, Lorg/readium/r2/navigator/DecorableNavigator;

    .line 156
    .line 157
    if-eqz p1, :cond_6

    .line 158
    .line 159
    move-object p1, v0

    .line 160
    check-cast p1, Lorg/readium/r2/navigator/DecorableNavigator;

    .line 161
    .line 162
    goto :goto_2

    .line 163
    :cond_6
    move-object p1, v2

    .line 164
    :goto_2
    if-eqz p1, :cond_7

    .line 165
    .line 166
    iget-object v3, p0, Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;->II:Llxh;

    .line 167
    .line 168
    invoke-interface {p1, v3}, Lorg/readium/r2/navigator/DecorableNavigator;->removeDecorationListener(Lorg/readium/r2/navigator/DecorableNavigator$Listener;)V

    .line 169
    .line 170
    .line 171
    const-wide v3, -0x879e98a0c56e39L

    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    invoke-static {v3, v4}, Li6t0;->lO(J)Ljava/lang/String;

    .line 177
    .line 178
    .line 179
    move-result-object v3

    .line 180
    iget-object v4, p0, Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;->II:Llxh;

    .line 181
    .line 182
    invoke-interface {p1, v3, v4}, Lorg/readium/r2/navigator/DecorableNavigator;->addDecorationListener(Ljava/lang/String;Lorg/readium/r2/navigator/DecorableNavigator$Listener;)V

    .line 183
    .line 184
    .line 185
    :cond_7
    iget-object p1, p0, Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;->lO:Lp9g0;

    .line 186
    .line 187
    if-eqz p1, :cond_8

    .line 188
    .line 189
    invoke-virtual {p1, v2}, Lups;->OO(Ljava/util/concurrent/CancellationException;)V

    .line 190
    .line 191
    .line 192
    :cond_8
    instance-of p1, v0, Lorg/readium/r2/navigator/Navigator;

    .line 193
    .line 194
    if-eqz p1, :cond_9

    .line 195
    .line 196
    check-cast v0, Lorg/readium/r2/navigator/Navigator;

    .line 197
    .line 198
    goto :goto_3

    .line 199
    :cond_9
    move-object v0, v2

    .line 200
    :goto_3
    if-nez v0, :cond_a

    .line 201
    .line 202
    :goto_4
    return-void

    .line 203
    :cond_a
    invoke-static {p0}, Lavv0;->OO(Lkwu;)Lbwu;

    .line 204
    .line 205
    .line 206
    move-result-object p1

    .line 207
    new-instance v3, Lkxh;

    .line 208
    .line 209
    invoke-direct {v3, p0, v0, v2}, Lkxh;-><init>(Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;Lorg/readium/r2/navigator/Navigator;Lvce;)V

    .line 210
    .line 211
    .line 212
    const/4 v0, 0x3

    .line 213
    invoke-static {p1, v2, v2, v3, v0}, Lw19;->loI(Lqoe;Lhoe;Ltoe;Lkotlin/jvm/functions/Function2;I)Lp9g0;

    .line 214
    .line 215
    .line 216
    move-result-object p1

    .line 217
    iput-object p1, p0, Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;->lO:Lp9g0;

    .line 218
    .line 219
    invoke-virtual {p0}, Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;->OI()Lt0i;

    .line 220
    .line 221
    .line 222
    move-result-object p1

    .line 223
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;->Io:Lnxh;

    .line 224
    .line 225
    const-wide v3, -0x887ac0a0c56e39L

    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    invoke-static {v3, v4}, Li6t0;->lO(J)Ljava/lang/String;

    .line 231
    .line 232
    .line 233
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 234
    .line 235
    .line 236
    iput-object p0, p1, Lt0i;->Ol:Luwh;

    .line 237
    .line 238
    iget-object v3, p1, Lt0i;->lo:Lybg0;

    .line 239
    .line 240
    invoke-virtual {v3}, Lybg0;->getValue()Ljava/lang/Object;

    .line 241
    .line 242
    .line 243
    move-result-object v4

    .line 244
    check-cast v4, Lc0i;

    .line 245
    .line 246
    iget-object v4, v4, Lc0i;->Oo:Lkzh;

    .line 247
    .line 248
    invoke-virtual {v3}, Lybg0;->getValue()Ljava/lang/Object;

    .line 249
    .line 250
    .line 251
    move-result-object v3

    .line 252
    check-cast v3, Lc0i;

    .line 253
    .line 254
    iget-boolean v3, v3, Lc0i;->ol:Z

    .line 255
    .line 256
    invoke-virtual {p0, v4, v3}, Lnxh;->lI(Lkzh;Z)V

    .line 257
    .line 258
    .line 259
    invoke-static {p1}, Lb6h;->loI(Ll2n0;)Ltac;

    .line 260
    .line 261
    .line 262
    move-result-object p0

    .line 263
    new-instance v3, Le0i;

    .line 264
    .line 265
    invoke-direct {v3, p1, v2, v1}, Le0i;-><init>(Lt0i;Lvce;B)V

    .line 266
    .line 267
    .line 268
    invoke-static {p0, v2, v2, v3, v0}, Lw19;->loI(Lqoe;Lhoe;Ltoe;Lkotlin/jvm/functions/Function2;I)Lp9g0;

    .line 269
    .line 270
    .line 271
    return-void

    .line 272
    :cond_b
    const-string p0, "The FragmentManager must be attached to itshost to create a Fragment"

    .line 273
    .line 274
    invoke-static {p0}, Lvv70;->llI(Ljava/lang/String;)V

    .line 275
    .line 276
    .line 277
    return-void

    .line 278
    :cond_c
    const-string p0, "Creating a Fragment requires that this FragmentTransaction was built with FragmentManager.beginTransaction()"

    .line 279
    .line 280
    invoke-static {p0}, Lvv70;->llI(Ljava/lang/String;)V

    .line 281
    .line 282
    .line 283
    return-void
.end method

.method public final Ol()Lorg/readium/r2/navigator/Navigator;
    .locals 2

    .line 1
    invoke-virtual {p0}, Landroidx/fragment/app/lOO;->getSupportFragmentManager()Landroidx/fragment/app/IIO;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    const-wide v0, -0x879c12a0c56e39L

    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    invoke-virtual {p0, v0}, Landroidx/fragment/app/IIO;->lOO(Ljava/lang/String;)Landroidx/fragment/app/lIl;

    .line 15
    .line 16
    .line 17
    move-result-object p0

    .line 18
    instance-of v0, p0, Lorg/readium/r2/navigator/Navigator;

    .line 19
    .line 20
    if-eqz v0, :cond_0

    .line 21
    .line 22
    check-cast p0, Lorg/readium/r2/navigator/Navigator;

    .line 23
    .line 24
    return-object p0

    .line 25
    :cond_0
    const/4 p0, 0x0

    .line 26
    return-object p0
.end method

.method public final attachBaseContext(Landroid/content/Context;)V
    .locals 2

    .line 1
    const-wide v0, -0x879c20a0c56e39L

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    invoke-super {p0, p1}, Landroid/content/ContextWrapper;->attachBaseContext(Landroid/content/Context;)V

    .line 13
    .line 14
    .line 15
    sget-object p1, Lh15;->l:Lh15;

    .line 16
    .line 17
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 18
    .line 19
    .line 20
    invoke-static {p0}, Lh15;->I(Landroid/view/ContextThemeWrapper;)V

    .line 21
    .line 22
    .line 23
    return-void
.end method

.method public final dispatchKeyEvent(Landroid/view/KeyEvent;)Z
    .locals 3

    .line 1
    const-wide v0, -0x879ed3a0c56e39L    # -1.0699953503959624E306

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    invoke-virtual {p0}, Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;->OI()Lt0i;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    iget-object v0, v0, Lt0i;->Il:Ldpa0;

    .line 17
    .line 18
    iget-object v0, v0, Ldpa0;->l:Lwbg0;

    .line 19
    .line 20
    invoke-interface {v0}, Lwbg0;->getValue()Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    check-cast v0, Lc0i;

    .line 25
    .line 26
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;->lo:Lkzh;

    .line 27
    .line 28
    iget-boolean v1, v1, Lkzh;->lIO:Z

    .line 29
    .line 30
    if-eqz v1, :cond_4

    .line 31
    .line 32
    iget-object v1, v0, Lc0i;->l:Lb0i;

    .line 33
    .line 34
    sget-object v2, La0i;->l:La0i;

    .line 35
    .line 36
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 37
    .line 38
    .line 39
    move-result v1

    .line 40
    if-eqz v1, :cond_4

    .line 41
    .line 42
    iget-object v1, v0, Lc0i;->OO:Ljyh;

    .line 43
    .line 44
    if-nez v1, :cond_4

    .line 45
    .line 46
    iget-object v0, v0, Lc0i;->oo:Li6i;

    .line 47
    .line 48
    iget-boolean v0, v0, Li6i;->I:Z

    .line 49
    .line 50
    if-nez v0, :cond_4

    .line 51
    .line 52
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    .line 53
    .line 54
    .line 55
    move-result v0

    .line 56
    const/16 v1, 0x19

    .line 57
    .line 58
    if-eq v0, v1, :cond_0

    .line 59
    .line 60
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    .line 61
    .line 62
    .line 63
    move-result v0

    .line 64
    const/16 v2, 0x18

    .line 65
    .line 66
    if-ne v0, v2, :cond_4

    .line 67
    .line 68
    :cond_0
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getAction()I

    .line 69
    .line 70
    .line 71
    move-result v0

    .line 72
    if-nez v0, :cond_3

    .line 73
    .line 74
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    .line 75
    .line 76
    .line 77
    move-result p1

    .line 78
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;->Io:Lnxh;

    .line 79
    .line 80
    if-ne p1, v1, :cond_1

    .line 81
    .line 82
    invoke-virtual {p0}, Lnxh;->O()V

    .line 83
    .line 84
    .line 85
    goto :goto_1

    .line 86
    :cond_1
    iget-object p0, p0, Lnxh;->l:Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;

    .line 87
    .line 88
    invoke-virtual {p0}, Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;->Ol()Lorg/readium/r2/navigator/Navigator;

    .line 89
    .line 90
    .line 91
    move-result-object p1

    .line 92
    instance-of v0, p1, Lorg/readium/r2/navigator/OverflowableNavigator;

    .line 93
    .line 94
    if-eqz v0, :cond_2

    .line 95
    .line 96
    check-cast p1, Lorg/readium/r2/navigator/OverflowableNavigator;

    .line 97
    .line 98
    goto :goto_0

    .line 99
    :cond_2
    const/4 p1, 0x0

    .line 100
    :goto_0
    if-eqz p1, :cond_3

    .line 101
    .line 102
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;->lo:Lkzh;

    .line 103
    .line 104
    iget-boolean p0, p0, Lkzh;->lOO:Z

    .line 105
    .line 106
    invoke-interface {p1, p0}, Lorg/readium/r2/navigator/OverflowableNavigator;->goBackward(Z)Z

    .line 107
    .line 108
    .line 109
    :cond_3
    :goto_1
    const/4 p0, 0x1

    .line 110
    return p0

    .line 111
    :cond_4
    invoke-super {p0, p1}, Landroidx/core/app/ComponentActivity;->dispatchKeyEvent(Landroid/view/KeyEvent;)Z

    .line 112
    .line 113
    .line 114
    move-result p0

    .line 115
    return p0
.end method

.method public final onCreate(Landroid/os/Bundle;)V
    .locals 12

    .line 1
    if-eqz p1, :cond_0

    .line 2
    .line 3
    const-wide v0, -0x879c28a0c56e39L

    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    invoke-virtual {p1, v0}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    if-nez v0, :cond_1

    .line 17
    .line 18
    :cond_0
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    const-wide v1, -0x879c2fa0c56e39L

    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object v1

    .line 31
    invoke-virtual {v0, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    :cond_1
    iput-object v0, p0, Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;->ll:Ljava/lang/String;

    .line 36
    .line 37
    invoke-virtual {p0}, Landroidx/fragment/app/lOO;->getSupportFragmentManager()Landroidx/fragment/app/IIO;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    new-instance v1, Lxuh;

    .line 42
    .line 43
    new-instance v2, Lhne;

    .line 44
    .line 45
    const/16 v3, 0x15

    .line 46
    .line 47
    invoke-direct {v2, p0, v3}, Lhne;-><init>(Ljava/lang/Object;B)V

    .line 48
    .line 49
    .line 50
    invoke-direct {v1, v2}, Lxuh;-><init>(Lhne;)V

    .line 51
    .line 52
    .line 53
    iput-object v1, v0, Landroidx/fragment/app/IIO;->lIo:Ltwm;

    .line 54
    .line 55
    invoke-super {p0, p1}, Lyfp;->onCreate(Landroid/os/Bundle;)V

    .line 56
    .line 57
    .line 58
    invoke-static {p0}, Ljgj;->I(Lcfd;)V

    .line 59
    .line 60
    .line 61
    invoke-virtual {p0}, Landroidx/fragment/app/lOO;->getSupportFragmentManager()Landroidx/fragment/app/IIO;

    .line 62
    .line 63
    .line 64
    move-result-object p1

    .line 65
    const-wide v0, -0x879c53a0c56e39L

    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 71
    .line 72
    .line 73
    move-result-object v0

    .line 74
    invoke-virtual {p1, v0}, Landroidx/fragment/app/IIO;->lOO(Ljava/lang/String;)Landroidx/fragment/app/lIl;

    .line 75
    .line 76
    .line 77
    move-result-object p1

    .line 78
    const/4 v0, 0x0

    .line 79
    if-eqz p1, :cond_3

    .line 80
    .line 81
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;->ll:Ljava/lang/String;

    .line 82
    .line 83
    if-eqz v1, :cond_2

    .line 84
    .line 85
    invoke-static {v1}, La6i;->I(Ljava/lang/String;)Lhzh;

    .line 86
    .line 87
    .line 88
    move-result-object v1

    .line 89
    goto :goto_0

    .line 90
    :cond_2
    move-object v1, v0

    .line 91
    :goto_0
    if-nez v1, :cond_3

    .line 92
    .line 93
    invoke-virtual {p0}, Landroidx/fragment/app/lOO;->getSupportFragmentManager()Landroidx/fragment/app/IIO;

    .line 94
    .line 95
    .line 96
    move-result-object v1

    .line 97
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 98
    .line 99
    .line 100
    new-instance v2, Landroidx/fragment/app/l;

    .line 101
    .line 102
    invoke-direct {v2, v1}, Landroidx/fragment/app/l;-><init>(Landroidx/fragment/app/IIO;)V

    .line 103
    .line 104
    .line 105
    invoke-virtual {v2, p1}, Landroidx/fragment/app/l;->lo(Landroidx/fragment/app/lIl;)Landroidx/fragment/app/l;

    .line 106
    .line 107
    .line 108
    invoke-virtual {v2}, Landroidx/fragment/app/l;->O()V

    .line 109
    .line 110
    .line 111
    :cond_3
    new-instance p1, Landroid/widget/FrameLayout;

    .line 112
    .line 113
    invoke-direct {p1, p0}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    .line 114
    .line 115
    .line 116
    new-instance v1, Landroidx/fragment/app/FragmentContainerView;

    .line 117
    .line 118
    invoke-direct {v1, p0}, Landroidx/fragment/app/FragmentContainerView;-><init>(Landroid/content/Context;)V

    .line 119
    .line 120
    .line 121
    const v2, 0x7f090245

    .line 122
    .line 123
    .line 124
    invoke-virtual {v1, v2}, Landroid/view/View;->setId(I)V

    .line 125
    .line 126
    .line 127
    new-instance v2, Lb3f;

    .line 128
    .line 129
    const/4 v3, 0x4

    .line 130
    invoke-direct {v2, p0, v3}, Lb3f;-><init>(Ljava/lang/Object;B)V

    .line 131
    .line 132
    .line 133
    invoke-static {v1, v2}, Landroidx/core/view/ViewCompat;->setOnApplyWindowInsetsListener(Landroid/view/View;Landroidx/core/view/OnApplyWindowInsetsListener;)V

    .line 134
    .line 135
    .line 136
    iput-object v1, p0, Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;->Il:Landroidx/fragment/app/FragmentContainerView;

    .line 137
    .line 138
    new-instance v2, Landroid/widget/FrameLayout$LayoutParams;

    .line 139
    .line 140
    const/4 v4, -0x1

    .line 141
    invoke-direct {v2, v4, v4}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    .line 142
    .line 143
    .line 144
    invoke-virtual {p1, v1, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 145
    .line 146
    .line 147
    new-instance v1, Laud;

    .line 148
    .line 149
    invoke-direct {v1, p0}, Laud;-><init>(Landroid/content/Context;)V

    .line 150
    .line 151
    .line 152
    sget-object v2, Lbwv0;->oI:Lbwv0;

    .line 153
    .line 154
    invoke-virtual {v1, v2}, Ll6;->setViewCompositionStrategy(Lo1n0;)V

    .line 155
    .line 156
    .line 157
    new-instance v2, Lgxh;

    .line 158
    .line 159
    const/4 v5, 0x0

    .line 160
    invoke-direct {v2, p0, v5}, Lgxh;-><init>(Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;B)V

    .line 161
    .line 162
    .line 163
    new-instance v5, Lggd;

    .line 164
    .line 165
    const v6, -0x595b040c

    .line 166
    .line 167
    .line 168
    const/4 v7, 0x1

    .line 169
    invoke-direct {v5, v2, v6, v7}, Lggd;-><init>(Ljava/lang/Object;IZ)V

    .line 170
    .line 171
    .line 172
    invoke-virtual {v1, v5}, Laud;->setContent(Lkotlin/jvm/functions/Function2;)V

    .line 173
    .line 174
    .line 175
    new-instance v2, Landroid/widget/FrameLayout$LayoutParams;

    .line 176
    .line 177
    invoke-direct {v2, v4, v4}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    .line 178
    .line 179
    .line 180
    invoke-virtual {p1, v1, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 181
    .line 182
    .line 183
    invoke-virtual {p0, p1}, Lcfd;->setContentView(Landroid/view/View;)V

    .line 184
    .line 185
    .line 186
    invoke-virtual {p0}, Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;->OI()Lt0i;

    .line 187
    .line 188
    .line 189
    move-result-object p1

    .line 190
    new-instance v4, Ll0h;

    .line 191
    .line 192
    const-wide v1, -0x879aaea0c56e39L

    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 198
    .line 199
    .line 200
    move-result-object v8

    .line 201
    const-wide v1, -0x879abaa0c56e39L

    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 207
    .line 208
    .line 209
    move-result-object v9

    .line 210
    const/4 v10, 0x0

    .line 211
    const/16 v11, 0x15

    .line 212
    .line 213
    const/4 v5, 0x1

    .line 214
    const-class v7, Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;

    .line 215
    .line 216
    move-object v6, p0

    .line 217
    invoke-direct/range {v4 .. v11}, Ll0h;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 218
    .line 219
    .line 220
    iput-object v4, p1, Lt0i;->llO:Ll0h;

    .line 221
    .line 222
    invoke-static {v6}, Lavv0;->OO(Lkwu;)Lbwu;

    .line 223
    .line 224
    .line 225
    move-result-object p0

    .line 226
    new-instance p1, Lhxh;

    .line 227
    .line 228
    const/4 v1, 0x2

    .line 229
    invoke-direct {p1, v6, v0, v1}, Lhxh;-><init>(Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;Lvce;B)V

    .line 230
    .line 231
    .line 232
    const/4 v1, 0x3

    .line 233
    invoke-static {p0, v0, v0, p1, v1}, Lw19;->loI(Lqoe;Lhoe;Ltoe;Lkotlin/jvm/functions/Function2;I)Lp9g0;

    .line 234
    .line 235
    .line 236
    invoke-static {v6}, Lavv0;->OO(Lkwu;)Lbwu;

    .line 237
    .line 238
    .line 239
    move-result-object p0

    .line 240
    new-instance p1, Lhxh;

    .line 241
    .line 242
    invoke-direct {p1, v6, v0, v3}, Lhxh;-><init>(Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;Lvce;B)V

    .line 243
    .line 244
    .line 245
    invoke-static {p0, v0, v0, p1, v1}, Lw19;->loI(Lqoe;Lhoe;Ltoe;Lkotlin/jvm/functions/Function2;I)Lp9g0;

    .line 246
    .line 247
    .line 248
    invoke-virtual {v6}, Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;->OI()Lt0i;

    .line 249
    .line 250
    .line 251
    move-result-object p0

    .line 252
    iget-object p0, p0, Lt0i;->Io:Lhzh;

    .line 253
    .line 254
    if-eqz p0, :cond_4

    .line 255
    .line 256
    invoke-virtual {v6, p0}, Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;->OO(Lhzh;)V

    .line 257
    .line 258
    .line 259
    :cond_4
    return-void
.end method

.method public final onDestroy()V
    .locals 5

    .line 1
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;->lI:Lhzh;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_0

    .line 5
    .line 6
    iget-object v0, v0, Lhzh;->ll:Ltwh;

    .line 7
    .line 8
    iput-object v1, v0, Ltwh;->l:Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;

    .line 9
    .line 10
    :cond_0
    invoke-virtual {p0}, Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;->OI()Lt0i;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    iget-object v2, p0, Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;->Io:Lnxh;

    .line 15
    .line 16
    const-wide v3, -0x887ac7a0c56e39L

    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    invoke-static {v3, v4}, Li6t0;->lO(J)Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 25
    .line 26
    .line 27
    iget-object v3, v0, Lt0i;->Ol:Luwh;

    .line 28
    .line 29
    if-ne v3, v2, :cond_1

    .line 30
    .line 31
    iput-object v1, v0, Lt0i;->Ol:Luwh;

    .line 32
    .line 33
    :cond_1
    invoke-virtual {p0}, Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;->OI()Lt0i;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    iput-object v1, v0, Lt0i;->llO:Ll0h;

    .line 38
    .line 39
    invoke-super {p0}, Lyfp;->onDestroy()V

    .line 40
    .line 41
    .line 42
    return-void
.end method

.method public final onNewIntent(Landroid/content/Intent;)V
    .locals 5

    .line 1
    const-wide v0, -0x879e1da0c56e39L    # -1.0701172345000299E306

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    invoke-super {p0, p1}, Lcfd;->onNewIntent(Landroid/content/Intent;)V

    .line 13
    .line 14
    .line 15
    const-wide v0, -0x879e24a0c56e39L

    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    invoke-virtual {p1, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    const/4 v1, 0x0

    .line 29
    if-nez v0, :cond_0

    .line 30
    .line 31
    invoke-static {p1}, Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;->Oo(Landroid/content/Intent;)Landroid/net/Uri;

    .line 32
    .line 33
    .line 34
    move-result-object v2

    .line 35
    goto :goto_0

    .line 36
    :cond_0
    move-object v2, v1

    .line 37
    :goto_0
    if-eqz v0, :cond_1

    .line 38
    .line 39
    iget-object v3, p0, Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;->ll:Ljava/lang/String;

    .line 40
    .line 41
    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 42
    .line 43
    .line 44
    move-result v3

    .line 45
    if-eqz v3, :cond_1

    .line 46
    .line 47
    goto :goto_1

    .line 48
    :cond_1
    if-nez v0, :cond_2

    .line 49
    .line 50
    if-nez v2, :cond_2

    .line 51
    .line 52
    :goto_1
    return-void

    .line 53
    :cond_2
    invoke-virtual {p0, p1}, Landroid/app/Activity;->setIntent(Landroid/content/Intent;)V

    .line 54
    .line 55
    .line 56
    invoke-virtual {p0}, Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;->OI()Lt0i;

    .line 57
    .line 58
    .line 59
    move-result-object p1

    .line 60
    invoke-virtual {p1}, Lt0i;->lII()V

    .line 61
    .line 62
    .line 63
    iget-object v3, p1, Lt0i;->Io:Lhzh;

    .line 64
    .line 65
    if-eqz v3, :cond_3

    .line 66
    .line 67
    sget-object v4, La6i;->l:Ljava/util/concurrent/ConcurrentHashMap;

    .line 68
    .line 69
    iget-object v3, v3, Lhzh;->l:Lruh;

    .line 70
    .line 71
    iget-object v3, v3, Lruh;->l:Ljava/lang/String;

    .line 72
    .line 73
    invoke-static {v3}, La6i;->l(Ljava/lang/String;)V

    .line 74
    .line 75
    .line 76
    :cond_3
    iput-object v1, p1, Lt0i;->Io:Lhzh;

    .line 77
    .line 78
    iput-object v0, p0, Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;->ll:Ljava/lang/String;

    .line 79
    .line 80
    invoke-virtual {p0}, Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;->OI()Lt0i;

    .line 81
    .line 82
    .line 83
    move-result-object p0

    .line 84
    invoke-virtual {p0, v2, v0}, Lt0i;->Oo(Landroid/net/Uri;Ljava/lang/String;)V

    .line 85
    .line 86
    .line 87
    return-void
.end method

.method public final onPause()V
    .locals 7

    .line 1
    invoke-virtual {p0}, Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;->OI()Lt0i;

    .line 2
    .line 3
    .line 4
    move-result-object v3

    .line 5
    iget-wide v1, v3, Lt0i;->oO:J

    .line 6
    .line 7
    const-wide/16 v4, 0x0

    .line 8
    .line 9
    iput-wide v4, v3, Lt0i;->oO:J

    .line 10
    .line 11
    iget-object v0, v3, Lt0i;->Io:Lhzh;

    .line 12
    .line 13
    if-eqz v0, :cond_1

    .line 14
    .line 15
    iget-object v0, v0, Lhzh;->l:Lruh;

    .line 16
    .line 17
    if-eqz v0, :cond_1

    .line 18
    .line 19
    iget-object v4, v0, Lruh;->l:Ljava/lang/String;

    .line 20
    .line 21
    if-nez v4, :cond_0

    .line 22
    .line 23
    goto :goto_0

    .line 24
    :cond_0
    invoke-static {v3}, Lb6h;->loI(Ll2n0;)Ltac;

    .line 25
    .line 26
    .line 27
    move-result-object v6

    .line 28
    new-instance v0, Lrk0;

    .line 29
    .line 30
    const/4 v5, 0x0

    .line 31
    invoke-direct/range {v0 .. v5}, Lrk0;-><init>(JLt0i;Ljava/lang/String;Lvce;)V

    .line 32
    .line 33
    .line 34
    const/4 v1, 0x3

    .line 35
    const/4 v2, 0x0

    .line 36
    invoke-static {v6, v2, v2, v0, v1}, Lw19;->loI(Lqoe;Lhoe;Ltoe;Lkotlin/jvm/functions/Function2;I)Lp9g0;

    .line 37
    .line 38
    .line 39
    :cond_1
    :goto_0
    invoke-super {p0}, Landroidx/fragment/app/lOO;->onPause()V

    .line 40
    .line 41
    .line 42
    return-void
.end method

.method public final onResume()V
    .locals 2

    .line 1
    invoke-super {p0}, Landroidx/fragment/app/lOO;->onResume()V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;->OI()Lt0i;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 9
    .line 10
    .line 11
    move-result-wide v0

    .line 12
    iput-wide v0, p0, Lt0i;->oO:J

    .line 13
    .line 14
    return-void
.end method

.method public final onSaveInstanceState(Landroid/os/Bundle;)V
    .locals 2

    .line 1
    const-wide v0, -0x879e48a0c56e39L

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    invoke-super {p0, p1}, Lcfd;->onSaveInstanceState(Landroid/os/Bundle;)V

    .line 13
    .line 14
    .line 15
    const-wide v0, -0x879e51a0c56e39L

    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/docreader/DocReaderActivity;->ll:Ljava/lang/String;

    .line 25
    .line 26
    invoke-virtual {p1, v0, p0}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 27
    .line 28
    .line 29
    return-void
.end method
