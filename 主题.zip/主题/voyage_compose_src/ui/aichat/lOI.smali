.class public final Lcom/chuanyi/voyage/ui/aichat/lOI;
.super Li0i0;
.source "S"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic I:Lza1;

.field public final synthetic O:Ljava/lang/String;

.field public final synthetic l:Lv41;

.field public final synthetic ll:Lkc10;

.field public final synthetic o:Ljava/lang/String;


# direct methods
.method public constructor <init>(Lv41;Lza1;Ljava/lang/String;Ljava/lang/String;Lkc10;Lvce;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lcom/chuanyi/voyage/ui/aichat/lOI;->l:Lv41;

    .line 2
    .line 3
    iput-object p2, p0, Lcom/chuanyi/voyage/ui/aichat/lOI;->I:Lza1;

    .line 4
    .line 5
    iput-object p3, p0, Lcom/chuanyi/voyage/ui/aichat/lOI;->O:Ljava/lang/String;

    .line 6
    .line 7
    iput-object p4, p0, Lcom/chuanyi/voyage/ui/aichat/lOI;->o:Ljava/lang/String;

    .line 8
    .line 9
    iput-object p5, p0, Lcom/chuanyi/voyage/ui/aichat/lOI;->ll:Lkc10;

    .line 10
    .line 11
    const/4 p1, 0x2

    .line 12
    invoke-direct {p0, p1, p6}, Li0i0;-><init>(ILvce;)V

    .line 13
    .line 14
    .line 15
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lvce;)Lvce;
    .locals 7

    .line 1
    new-instance v0, Lcom/chuanyi/voyage/ui/aichat/lOI;

    .line 2
    .line 3
    iget-object v4, p0, Lcom/chuanyi/voyage/ui/aichat/lOI;->o:Ljava/lang/String;

    .line 4
    .line 5
    iget-object v5, p0, Lcom/chuanyi/voyage/ui/aichat/lOI;->ll:Lkc10;

    .line 6
    .line 7
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/aichat/lOI;->l:Lv41;

    .line 8
    .line 9
    iget-object v2, p0, Lcom/chuanyi/voyage/ui/aichat/lOI;->I:Lza1;

    .line 10
    .line 11
    iget-object v3, p0, Lcom/chuanyi/voyage/ui/aichat/lOI;->O:Ljava/lang/String;

    .line 12
    .line 13
    move-object v6, p2

    .line 14
    invoke-direct/range {v0 .. v6}, Lcom/chuanyi/voyage/ui/aichat/lOI;-><init>(Lv41;Lza1;Ljava/lang/String;Ljava/lang/String;Lkc10;Lvce;)V

    .line 15
    .line 16
    .line 17
    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lqoe;

    .line 2
    .line 3
    check-cast p2, Lvce;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, Lcom/chuanyi/voyage/ui/aichat/lOI;->create(Ljava/lang/Object;Lvce;)Lvce;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    check-cast p0, Lcom/chuanyi/voyage/ui/aichat/lOI;

    .line 10
    .line 11
    sget-object p1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 12
    .line 13
    invoke-virtual {p0, p1}, Lcom/chuanyi/voyage/ui/aichat/lOI;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 8

    .line 1
    sget-object v0, Lroe;->l:Lroe;

    .line 2
    .line 3
    invoke-static {p1}, Lcp30;->IoO(Ljava/lang/Object;)V

    .line 4
    .line 5
    .line 6
    sget-object p1, Lcom/chuanyi/voyage/ui/aichat/Ill;->l:Lzus;

    .line 7
    .line 8
    iget-object p1, p0, Lcom/chuanyi/voyage/ui/aichat/lOI;->ll:Lkc10;

    .line 9
    .line 10
    invoke-interface {p1}, Lubg0;->getValue()Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    check-cast p1, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 15
    .line 16
    if-nez p1, :cond_0

    .line 17
    .line 18
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 19
    .line 20
    return-object p0

    .line 21
    :cond_0
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/aichat/lOI;->l:Lv41;

    .line 22
    .line 23
    if-eqz v0, :cond_1

    .line 24
    .line 25
    invoke-virtual {p1}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->getKey()Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    invoke-static {v0}, Ligh0;->isBlank(Ljava/lang/CharSequence;)Z

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    if-nez v0, :cond_1

    .line 34
    .line 35
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/aichat/lOI;->O:Ljava/lang/String;

    .line 36
    .line 37
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/aichat/lOI;->o:Ljava/lang/String;

    .line 38
    .line 39
    invoke-virtual {p1, v0, v1}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->provider(Ljava/lang/String;Ljava/lang/String;)Lxw1;

    .line 40
    .line 41
    .line 42
    move-result-object v3

    .line 43
    invoke-virtual {p1}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->getKey()Ljava/lang/String;

    .line 44
    .line 45
    .line 46
    move-result-object v4

    .line 47
    invoke-virtual {p1}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->getHeaders()Ljava/lang/String;

    .line 48
    .line 49
    .line 50
    move-result-object p1

    .line 51
    invoke-static {p1}, Lcom/chuanyi/voyage/ui/aichat/Ill;->lIO(Ljava/lang/String;)Ljava/util/Map;

    .line 52
    .line 53
    .line 54
    move-result-object v5

    .line 55
    const-wide/32 v6, 0xea60

    .line 56
    .line 57
    .line 58
    iget-object v2, p0, Lcom/chuanyi/voyage/ui/aichat/lOI;->I:Lza1;

    .line 59
    .line 60
    invoke-virtual/range {v2 .. v7}, Lza1;->Io(Lxw1;Ljava/lang/String;Ljava/util/Map;J)V

    .line 61
    .line 62
    .line 63
    :cond_1
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 64
    .line 65
    return-object p0
.end method
