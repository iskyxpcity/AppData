.class public final synthetic Lcom/chuanyi/voyage/ui/aichat/OI;
.super Ljava/lang/Object;
.source "S"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic I:Ljava/lang/Object;

.field public final synthetic O:Ljava/lang/Object;

.field public final synthetic l:B


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;B)V
    .locals 0

    .line 1
    iput-byte p3, p0, Lcom/chuanyi/voyage/ui/aichat/OI;->l:B

    .line 2
    .line 3
    iput-object p1, p0, Lcom/chuanyi/voyage/ui/aichat/OI;->I:Ljava/lang/Object;

    .line 4
    .line 5
    iput-object p2, p0, Lcom/chuanyi/voyage/ui/aichat/OI;->O:Ljava/lang/Object;

    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 18

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lcom/chuanyi/voyage/ui/aichat/OI;->l:B

    .line 4
    .line 5
    iget-object v2, v0, Lcom/chuanyi/voyage/ui/aichat/OI;->O:Ljava/lang/Object;

    .line 6
    .line 7
    iget-object v0, v0, Lcom/chuanyi/voyage/ui/aichat/OI;->I:Ljava/lang/Object;

    .line 8
    .line 9
    packed-switch v1, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    check-cast v0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 13
    .line 14
    check-cast v2, Lkc10;

    .line 15
    .line 16
    invoke-interface {v2}, Lubg0;->getValue()Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object v1

    .line 20
    check-cast v1, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 21
    .line 22
    if-nez v1, :cond_0

    .line 23
    .line 24
    goto :goto_0

    .line 25
    :cond_0
    move-object v0, v1

    .line 26
    :goto_0
    invoke-static {v0}, Landroidx/compose/runtime/lI;->lI(Ljava/lang/Object;)Lkc10;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    return-object v0

    .line 31
    :pswitch_0
    check-cast v0, Lxw1;

    .line 32
    .line 33
    check-cast v2, Lza1;

    .line 34
    .line 35
    iget-object v1, v2, Lza1;->O:Lty1;

    .line 36
    .line 37
    if-eqz v0, :cond_1

    .line 38
    .line 39
    sget-object v2, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->Companion:Lyw1;

    .line 40
    .line 41
    const-wide v3, -0x1e329a0c56e39L

    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    invoke-static {v3, v4}, Li6t0;->lO(J)Ljava/lang/String;

    .line 47
    .line 48
    .line 49
    iget-object v3, v0, Lxw1;->ll:Ljava/lang/String;

    .line 50
    .line 51
    invoke-virtual {v1, v3}, Lty1;->O(Ljava/lang/String;)Ljava/lang/String;

    .line 52
    .line 53
    .line 54
    move-result-object v8

    .line 55
    iget-object v3, v0, Lxw1;->lI:Ljava/lang/String;

    .line 56
    .line 57
    const-wide v4, -0x1e332a0c56e39L

    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    invoke-static {v4, v5}, Li6t0;->lO(J)Ljava/lang/String;

    .line 63
    .line 64
    .line 65
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 66
    .line 67
    .line 68
    invoke-virtual {v1, v3}, Lty1;->o(Ljava/lang/String;)Ljava/util/Map;

    .line 69
    .line 70
    .line 71
    move-result-object v1

    .line 72
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 73
    .line 74
    .line 75
    const-wide v2, -0x527358a0c56e39L

    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    invoke-static {v2, v3}, Li6t0;->lO(J)Ljava/lang/String;

    .line 81
    .line 82
    .line 83
    const-wide v2, -0x527361a0c56e39L

    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    invoke-static {v2, v3}, Li6t0;->lO(J)Ljava/lang/String;

    .line 89
    .line 90
    .line 91
    const-wide v2, -0x527365a0c56e39L

    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    invoke-static {v2, v3}, Li6t0;->lO(J)Ljava/lang/String;

    .line 97
    .line 98
    .line 99
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 100
    .line 101
    .line 102
    new-instance v4, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 103
    .line 104
    iget-object v5, v0, Lxw1;->I:Ljava/lang/String;

    .line 105
    .line 106
    invoke-virtual {v0}, Lxw1;->getType()Ldx1;

    .line 107
    .line 108
    .line 109
    move-result-object v6

    .line 110
    iget-object v7, v0, Lxw1;->o:Ljava/lang/String;

    .line 111
    .line 112
    invoke-interface {v1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    .line 113
    .line 114
    .line 115
    move-result-object v1

    .line 116
    move-object v9, v1

    .line 117
    check-cast v9, Ljava/lang/Iterable;

    .line 118
    .line 119
    const-wide v1, -0x51410aa0c56e39L

    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 125
    .line 126
    .line 127
    move-result-object v10

    .line 128
    new-instance v15, Ln71;

    .line 129
    .line 130
    const/16 v1, 0x1a

    .line 131
    .line 132
    invoke-direct {v15, v1}, Ln71;-><init>(B)V

    .line 133
    .line 134
    .line 135
    const/16 v16, 0x1e

    .line 136
    .line 137
    const/16 v17, 0x0

    .line 138
    .line 139
    const/4 v11, 0x0

    .line 140
    const/4 v12, 0x0

    .line 141
    const/4 v13, 0x0

    .line 142
    const/4 v14, 0x0

    .line 143
    invoke-static/range {v9 .. v17}, Lyqc;->joinToString$default(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/String;

    .line 144
    .line 145
    .line 146
    move-result-object v9

    .line 147
    iget-boolean v10, v0, Lxw1;->lO:Z

    .line 148
    .line 149
    iget-boolean v11, v0, Lxw1;->Il:Z

    .line 150
    .line 151
    iget-object v12, v0, Lxw1;->lo:Ljava/util/List;

    .line 152
    .line 153
    invoke-direct/range {v4 .. v12}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;-><init>(Ljava/lang/String;Ldx1;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZLjava/util/List;)V

    .line 154
    .line 155
    .line 156
    goto :goto_1

    .line 157
    :cond_1
    const/4 v4, 0x0

    .line 158
    :goto_1
    invoke-static {v4}, Landroidx/compose/runtime/lI;->lI(Ljava/lang/Object;)Lkc10;

    .line 159
    .line 160
    .line 161
    move-result-object v0

    .line 162
    return-object v0

    .line 163
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
