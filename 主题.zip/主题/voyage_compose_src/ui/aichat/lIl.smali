.class public final Lcom/chuanyi/voyage/ui/aichat/lIl;
.super Li0i0;
.source "S"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic I:Lza1;

.field public final synthetic O:Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

.field public l:Z

.field public final synthetic lI:Lkc10;

.field public final synthetic ll:Ljava/lang/String;

.field public final synthetic o:Ljava/lang/String;


# direct methods
.method public constructor <init>(Lza1;Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;Ljava/lang/String;Ljava/lang/String;Lkc10;Lvce;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lcom/chuanyi/voyage/ui/aichat/lIl;->I:Lza1;

    .line 2
    .line 3
    iput-object p2, p0, Lcom/chuanyi/voyage/ui/aichat/lIl;->O:Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 4
    .line 5
    iput-object p3, p0, Lcom/chuanyi/voyage/ui/aichat/lIl;->o:Ljava/lang/String;

    .line 6
    .line 7
    iput-object p4, p0, Lcom/chuanyi/voyage/ui/aichat/lIl;->ll:Ljava/lang/String;

    .line 8
    .line 9
    iput-object p5, p0, Lcom/chuanyi/voyage/ui/aichat/lIl;->lI:Lkc10;

    .line 10
    .line 11
    const/4 p1, 0x2

    .line 12
    invoke-direct {p0, p1, p6}, Li0i0;-><init>(ILvce;)V

    .line 13
    .line 14
    .line 15
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lvce;)Lvce;
    .locals 7

    .line 1
    new-instance v0, Lcom/chuanyi/voyage/ui/aichat/lIl;

    .line 2
    .line 3
    iget-object v4, p0, Lcom/chuanyi/voyage/ui/aichat/lIl;->ll:Ljava/lang/String;

    .line 4
    .line 5
    iget-object v5, p0, Lcom/chuanyi/voyage/ui/aichat/lIl;->lI:Lkc10;

    .line 6
    .line 7
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/aichat/lIl;->I:Lza1;

    .line 8
    .line 9
    iget-object v2, p0, Lcom/chuanyi/voyage/ui/aichat/lIl;->O:Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 10
    .line 11
    iget-object v3, p0, Lcom/chuanyi/voyage/ui/aichat/lIl;->o:Ljava/lang/String;

    .line 12
    .line 13
    move-object v6, p2

    .line 14
    invoke-direct/range {v0 .. v6}, Lcom/chuanyi/voyage/ui/aichat/lIl;-><init>(Lza1;Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;Ljava/lang/String;Ljava/lang/String;Lkc10;Lvce;)V

    .line 15
    .line 16
    .line 17
    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lqoe;

    .line 2
    .line 3
    check-cast p2, Lvce;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, Lcom/chuanyi/voyage/ui/aichat/lIl;->create(Ljava/lang/Object;Lvce;)Lvce;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    check-cast p0, Lcom/chuanyi/voyage/ui/aichat/lIl;

    .line 10
    .line 11
    sget-object p1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 12
    .line 13
    invoke-virtual {p0, p1}, Lcom/chuanyi/voyage/ui/aichat/lIl;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    .line 1
    sget-object v0, Lroe;->l:Lroe;

    .line 2
    .line 3
    iget-boolean v1, p0, Lcom/chuanyi/voyage/ui/aichat/lIl;->l:Z

    .line 4
    .line 5
    const/4 v2, 0x1

    .line 6
    if-eqz v1, :cond_1

    .line 7
    .line 8
    if-ne v1, v2, :cond_0

    .line 9
    .line 10
    invoke-static {p1}, Lcp30;->IoO(Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    goto :goto_0

    .line 14
    :cond_0
    const-wide p0, -0x512fa1a0c56e39L

    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    invoke-static {p0, p1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object p0

    .line 23
    invoke-static {p0}, Lvv70;->llI(Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    const/4 p0, 0x0

    .line 27
    return-object p0

    .line 28
    :cond_1
    invoke-static {p1}, Lcp30;->IoO(Ljava/lang/Object;)V

    .line 29
    .line 30
    .line 31
    iget-object p1, p0, Lcom/chuanyi/voyage/ui/aichat/lIl;->o:Ljava/lang/String;

    .line 32
    .line 33
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/aichat/lIl;->ll:Ljava/lang/String;

    .line 34
    .line 35
    iget-object v3, p0, Lcom/chuanyi/voyage/ui/aichat/lIl;->O:Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 36
    .line 37
    invoke-virtual {v3, p1, v1}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->provider(Ljava/lang/String;Ljava/lang/String;)Lxw1;

    .line 38
    .line 39
    .line 40
    move-result-object p1

    .line 41
    invoke-virtual {v3}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->getModels()Ljava/util/List;

    .line 42
    .line 43
    .line 44
    move-result-object v1

    .line 45
    iput-boolean v2, p0, Lcom/chuanyi/voyage/ui/aichat/lIl;->l:Z

    .line 46
    .line 47
    iget-object v3, p0, Lcom/chuanyi/voyage/ui/aichat/lIl;->I:Lza1;

    .line 48
    .line 49
    invoke-virtual {v3, p1, v1, v2, p0}, Lza1;->lI(Lxw1;Ljava/util/List;ZLxce;)Ljava/lang/Object;

    .line 50
    .line 51
    .line 52
    move-result-object p1

    .line 53
    if-ne p1, v0, :cond_2

    .line 54
    .line 55
    return-object v0

    .line 56
    :cond_2
    :goto_0
    check-cast p1, Ljava/util/List;

    .line 57
    .line 58
    new-instance v0, Lcom/chuanyi/voyage/ui/aichat/lI;

    .line 59
    .line 60
    invoke-direct {v0, p1, v2}, Lcom/chuanyi/voyage/ui/aichat/lI;-><init>(Ljava/util/List;B)V

    .line 61
    .line 62
    .line 63
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/aichat/lIl;->lI:Lkc10;

    .line 64
    .line 65
    invoke-static {p0, v0}, Lcom/chuanyi/voyage/ui/aichat/Ill;->oO(Lkc10;Lkotlin/jvm/functions/Function1;)V

    .line 66
    .line 67
    .line 68
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 69
    .line 70
    return-object p0
.end method
