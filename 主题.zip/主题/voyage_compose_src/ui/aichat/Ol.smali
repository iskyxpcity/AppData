.class public final synthetic Lcom/chuanyi/voyage/ui/aichat/Ol;
.super Ljava/lang/Object;
.source "S"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic I:Ljava/io/Serializable;

.field public final synthetic l:B


# direct methods
.method public synthetic constructor <init>(Ljava/io/Serializable;B)V
    .locals 0

    .line 1
    iput-byte p2, p0, Lcom/chuanyi/voyage/ui/aichat/Ol;->l:B

    .line 2
    .line 3
    iput-object p1, p0, Lcom/chuanyi/voyage/ui/aichat/Ol;->I:Ljava/io/Serializable;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 11

    .line 1
    iget-byte v0, p0, Lcom/chuanyi/voyage/ui/aichat/Ol;->l:B

    .line 2
    .line 3
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/aichat/Ol;->I:Ljava/io/Serializable;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    check-cast p0, Ljava/util/ArrayList;

    .line 9
    .line 10
    move-object v0, p1

    .line 11
    check-cast v0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 12
    .line 13
    const-wide v1, -0x518204a0c56e39L

    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 19
    .line 20
    .line 21
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    .line 23
    .line 24
    invoke-virtual {v0}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->getModels()Ljava/util/List;

    .line 25
    .line 26
    .line 27
    move-result-object p1

    .line 28
    check-cast p1, Ljava/util/Collection;

    .line 29
    .line 30
    new-instance v1, Ljava/util/ArrayList;

    .line 31
    .line 32
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 33
    .line 34
    .line 35
    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 36
    .line 37
    .line 38
    move-result-object p0

    .line 39
    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 40
    .line 41
    .line 42
    move-result v2

    .line 43
    if-eqz v2, :cond_3

    .line 44
    .line 45
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 46
    .line 47
    .line 48
    move-result-object v2

    .line 49
    move-object v3, v2

    .line 50
    check-cast v3, Lgt1;

    .line 51
    .line 52
    invoke-virtual {v0}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->getModels()Ljava/util/List;

    .line 53
    .line 54
    .line 55
    move-result-object v4

    .line 56
    check-cast v4, Ljava/lang/Iterable;

    .line 57
    .line 58
    instance-of v5, v4, Ljava/util/Collection;

    .line 59
    .line 60
    if-eqz v5, :cond_0

    .line 61
    .line 62
    move-object v5, v4

    .line 63
    check-cast v5, Ljava/util/Collection;

    .line 64
    .line 65
    invoke-interface {v5}, Ljava/util/Collection;->isEmpty()Z

    .line 66
    .line 67
    .line 68
    move-result v5

    .line 69
    if-eqz v5, :cond_0

    .line 70
    .line 71
    goto :goto_1

    .line 72
    :cond_0
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 73
    .line 74
    .line 75
    move-result-object v4

    .line 76
    :cond_1
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 77
    .line 78
    .line 79
    move-result v5

    .line 80
    if-eqz v5, :cond_2

    .line 81
    .line 82
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 83
    .line 84
    .line 85
    move-result-object v5

    .line 86
    check-cast v5, Lgt1;

    .line 87
    .line 88
    iget-object v5, v5, Lgt1;->l:Ljava/lang/String;

    .line 89
    .line 90
    iget-object v6, v3, Lgt1;->l:Ljava/lang/String;

    .line 91
    .line 92
    invoke-static {v5, v6}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 93
    .line 94
    .line 95
    move-result v5

    .line 96
    if-eqz v5, :cond_1

    .line 97
    .line 98
    goto :goto_0

    .line 99
    :cond_2
    :goto_1
    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 100
    .line 101
    .line 102
    goto :goto_0

    .line 103
    :cond_3
    invoke-static {p1, v1}, Lyqc;->plus(Ljava/util/Collection;Ljava/lang/Iterable;)Ljava/util/List;

    .line 104
    .line 105
    .line 106
    move-result-object v8

    .line 107
    const/16 v9, 0x7f

    .line 108
    .line 109
    const/4 v10, 0x0

    .line 110
    const/4 v1, 0x0

    .line 111
    const/4 v2, 0x0

    .line 112
    const/4 v3, 0x0

    .line 113
    const/4 v4, 0x0

    .line 114
    const/4 v5, 0x0

    .line 115
    const/4 v6, 0x0

    .line 116
    const/4 v7, 0x0

    .line 117
    invoke-static/range {v0 .. v10}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->copy$default(Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;Ljava/lang/String;Ldx1;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZLjava/util/List;ILjava/lang/Object;)Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 118
    .line 119
    .line 120
    move-result-object p0

    .line 121
    return-object p0

    .line 122
    :pswitch_0
    move-object v2, p0

    .line 123
    check-cast v2, Ldx1;

    .line 124
    .line 125
    move-object v0, p1

    .line 126
    check-cast v0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 127
    .line 128
    const-wide p0, -0x51b1aea0c56e39L

    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    invoke-static {p0, p1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 134
    .line 135
    .line 136
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 137
    .line 138
    .line 139
    invoke-virtual {v0}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->getBaseUrl()Ljava/lang/String;

    .line 140
    .line 141
    .line 142
    move-result-object p0

    .line 143
    invoke-static {p0}, Ligh0;->isBlank(Ljava/lang/CharSequence;)Z

    .line 144
    .line 145
    .line 146
    move-result p0

    .line 147
    if-nez p0, :cond_5

    .line 148
    .line 149
    invoke-virtual {v0}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->getBaseUrl()Ljava/lang/String;

    .line 150
    .line 151
    .line 152
    move-result-object p0

    .line 153
    invoke-virtual {v0}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->getType()Ldx1;

    .line 154
    .line 155
    .line 156
    move-result-object p1

    .line 157
    iget-object p1, p1, Ldx1;->I:Ljava/lang/String;

    .line 158
    .line 159
    invoke-static {p0, p1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 160
    .line 161
    .line 162
    move-result p0

    .line 163
    if-eqz p0, :cond_4

    .line 164
    .line 165
    goto :goto_3

    .line 166
    :cond_4
    invoke-virtual {v0}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->getBaseUrl()Ljava/lang/String;

    .line 167
    .line 168
    .line 169
    move-result-object p0

    .line 170
    :goto_2
    move-object v3, p0

    .line 171
    goto :goto_4

    .line 172
    :cond_5
    :goto_3
    iget-object p0, v2, Ldx1;->I:Ljava/lang/String;

    .line 173
    .line 174
    goto :goto_2

    .line 175
    :goto_4
    const/16 v9, 0xf9

    .line 176
    .line 177
    const/4 v10, 0x0

    .line 178
    const/4 v1, 0x0

    .line 179
    const/4 v4, 0x0

    .line 180
    const/4 v5, 0x0

    .line 181
    const/4 v6, 0x0

    .line 182
    const/4 v7, 0x0

    .line 183
    const/4 v8, 0x0

    .line 184
    invoke-static/range {v0 .. v10}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->copy$default(Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;Ljava/lang/String;Ldx1;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZLjava/util/List;ILjava/lang/Object;)Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 185
    .line 186
    .line 187
    move-result-object p0

    .line 188
    return-object p0

    .line 189
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
