.class public final Lcom/chuanyi/voyage/ui/aichat/lOO;
.super Ljava/lang/Object;
.source "S"

# interfaces
.implements Ltrh;


# instance fields
.field public final synthetic I:Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

.field public final synthetic Il:Landroid/content/Context;

.field public final synthetic O:Lkc10;

.field public final synthetic l:Landroid/app/Activity;

.field public final synthetic lI:Lza1;

.field public final synthetic lO:Ljava/lang/String;

.field public final synthetic ll:Lkc10;

.field public final synthetic lo:Ljava/lang/String;

.field public final synthetic o:Lkc10;


# direct methods
.method public constructor <init>(Landroid/app/Activity;Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;Lkc10;Lkc10;Lkc10;Lza1;Ljava/lang/String;Ljava/lang/String;Landroid/content/Context;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lcom/chuanyi/voyage/ui/aichat/lOO;->l:Landroid/app/Activity;

    .line 5
    .line 6
    iput-object p2, p0, Lcom/chuanyi/voyage/ui/aichat/lOO;->I:Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 7
    .line 8
    iput-object p3, p0, Lcom/chuanyi/voyage/ui/aichat/lOO;->O:Lkc10;

    .line 9
    .line 10
    iput-object p4, p0, Lcom/chuanyi/voyage/ui/aichat/lOO;->o:Lkc10;

    .line 11
    .line 12
    iput-object p5, p0, Lcom/chuanyi/voyage/ui/aichat/lOO;->ll:Lkc10;

    .line 13
    .line 14
    iput-object p6, p0, Lcom/chuanyi/voyage/ui/aichat/lOO;->lI:Lza1;

    .line 15
    .line 16
    iput-object p7, p0, Lcom/chuanyi/voyage/ui/aichat/lOO;->lO:Ljava/lang/String;

    .line 17
    .line 18
    iput-object p8, p0, Lcom/chuanyi/voyage/ui/aichat/lOO;->lo:Ljava/lang/String;

    .line 19
    .line 20
    iput-object p9, p0, Lcom/chuanyi/voyage/ui/aichat/lOO;->Il:Landroid/content/Context;

    .line 21
    .line 22
    return-void
.end method


# virtual methods
.method public final I()V
    .locals 10

    .line 1
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/aichat/lOO;->O:Lkc10;

    .line 2
    .line 3
    invoke-interface {v0}, Lubg0;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Ljava/lang/Boolean;

    .line 8
    .line 9
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    if-nez v0, :cond_2

    .line 14
    .line 15
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/aichat/lOO;->l:Landroid/app/Activity;

    .line 16
    .line 17
    if-eqz v0, :cond_0

    .line 18
    .line 19
    invoke-virtual {v0}, Landroid/app/Activity;->isChangingConfigurations()Z

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    const/4 v1, 0x1

    .line 24
    if-ne v0, v1, :cond_0

    .line 25
    .line 26
    goto :goto_0

    .line 27
    :cond_0
    iget-object v4, p0, Lcom/chuanyi/voyage/ui/aichat/lOO;->o:Lkc10;

    .line 28
    .line 29
    invoke-interface {v4}, Lubg0;->getValue()Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    check-cast v0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 34
    .line 35
    iget-object v5, p0, Lcom/chuanyi/voyage/ui/aichat/lOO;->lo:Ljava/lang/String;

    .line 36
    .line 37
    iget-object v2, p0, Lcom/chuanyi/voyage/ui/aichat/lOO;->lI:Lza1;

    .line 38
    .line 39
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/aichat/lOO;->ll:Lkc10;

    .line 40
    .line 41
    if-eqz v0, :cond_1

    .line 42
    .line 43
    invoke-interface {v1}, Lubg0;->getValue()Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    move-result-object v3

    .line 47
    check-cast v3, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 48
    .line 49
    invoke-static {v3, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 50
    .line 51
    .line 52
    move-result v0

    .line 53
    if-nez v0, :cond_2

    .line 54
    .line 55
    invoke-interface {v1}, Lubg0;->getValue()Ljava/lang/Object;

    .line 56
    .line 57
    .line 58
    move-result-object v0

    .line 59
    move-object v7, v0

    .line 60
    check-cast v7, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 61
    .line 62
    const/4 v8, 0x0

    .line 63
    const/4 v9, 0x0

    .line 64
    iget-object v3, p0, Lcom/chuanyi/voyage/ui/aichat/lOO;->lO:Ljava/lang/String;

    .line 65
    .line 66
    iget-object v6, p0, Lcom/chuanyi/voyage/ui/aichat/lOO;->Il:Landroid/content/Context;

    .line 67
    .line 68
    invoke-static/range {v2 .. v9}, Lcom/chuanyi/voyage/ui/aichat/Ill;->OO(Lza1;Ljava/lang/String;Lkc10;Ljava/lang/String;Landroid/content/Context;Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;ZZ)V

    .line 69
    .line 70
    .line 71
    return-void

    .line 72
    :cond_1
    invoke-interface {v1}, Lubg0;->getValue()Ljava/lang/Object;

    .line 73
    .line 74
    .line 75
    move-result-object v0

    .line 76
    check-cast v0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 77
    .line 78
    iget-object v3, p0, Lcom/chuanyi/voyage/ui/aichat/lOO;->I:Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 79
    .line 80
    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 81
    .line 82
    .line 83
    move-result v0

    .line 84
    if-nez v0, :cond_2

    .line 85
    .line 86
    invoke-interface {v1}, Lubg0;->getValue()Ljava/lang/Object;

    .line 87
    .line 88
    .line 89
    move-result-object v0

    .line 90
    check-cast v0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 91
    .line 92
    invoke-virtual {v0}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->getValid()Z

    .line 93
    .line 94
    .line 95
    move-result v0

    .line 96
    if-eqz v0, :cond_2

    .line 97
    .line 98
    invoke-interface {v1}, Lubg0;->getValue()Ljava/lang/Object;

    .line 99
    .line 100
    .line 101
    move-result-object v0

    .line 102
    move-object v7, v0

    .line 103
    check-cast v7, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 104
    .line 105
    const/4 v8, 0x1

    .line 106
    const/4 v9, 0x1

    .line 107
    iget-object v3, p0, Lcom/chuanyi/voyage/ui/aichat/lOO;->lO:Ljava/lang/String;

    .line 108
    .line 109
    iget-object v6, p0, Lcom/chuanyi/voyage/ui/aichat/lOO;->Il:Landroid/content/Context;

    .line 110
    .line 111
    invoke-static/range {v2 .. v9}, Lcom/chuanyi/voyage/ui/aichat/Ill;->OO(Lza1;Ljava/lang/String;Lkc10;Ljava/lang/String;Landroid/content/Context;Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;ZZ)V

    .line 112
    .line 113
    .line 114
    :cond_2
    :goto_0
    return-void
.end method
