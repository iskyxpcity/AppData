.class public final synthetic Lcom/chuanyi/voyage/ui/aichat/IO;
.super Ljava/lang/Object;
.source "S"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic I:Ljava/lang/String;

.field public final synthetic O:Lkc10;

.field public final synthetic l:Z


# direct methods
.method public synthetic constructor <init>(ZLjava/lang/String;Lkc10;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-boolean p1, p0, Lcom/chuanyi/voyage/ui/aichat/IO;->l:Z

    .line 5
    .line 6
    iput-object p2, p0, Lcom/chuanyi/voyage/ui/aichat/IO;->I:Ljava/lang/String;

    .line 7
    .line 8
    iput-object p3, p0, Lcom/chuanyi/voyage/ui/aichat/IO;->O:Lkc10;

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 33

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    check-cast v1, Lkud;

    .line 6
    .line 7
    move-object/from16 v2, p2

    .line 8
    .line 9
    check-cast v2, Ljava/lang/Integer;

    .line 10
    .line 11
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 12
    .line 13
    .line 14
    move-result v2

    .line 15
    const-wide v3, -0x517189a0c56e39L

    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    invoke-static {v3, v4}, Li6t0;->lO(J)Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    and-int/lit8 v3, v2, 0x3

    .line 24
    .line 25
    const/4 v4, 0x2

    .line 26
    const/4 v5, 0x1

    .line 27
    const/4 v6, 0x0

    .line 28
    if-eq v3, v4, :cond_0

    .line 29
    .line 30
    move v3, v5

    .line 31
    goto :goto_0

    .line 32
    :cond_0
    move v3, v6

    .line 33
    :goto_0
    and-int/2addr v2, v5

    .line 34
    check-cast v1, Ltgn;

    .line 35
    .line 36
    invoke-virtual {v1, v2, v3}, Ltgn;->Iol(IZ)Z

    .line 37
    .line 38
    .line 39
    move-result v2

    .line 40
    if-eqz v2, :cond_3

    .line 41
    .line 42
    iget-object v2, v0, Lcom/chuanyi/voyage/ui/aichat/IO;->O:Lkc10;

    .line 43
    .line 44
    invoke-interface {v2}, Lubg0;->getValue()Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    move-result-object v2

    .line 48
    check-cast v2, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 49
    .line 50
    invoke-virtual {v2}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->getUrlInvalid()Z

    .line 51
    .line 52
    .line 53
    move-result v2

    .line 54
    if-eqz v2, :cond_1

    .line 55
    .line 56
    const v0, -0x244715c

    .line 57
    .line 58
    .line 59
    invoke-virtual {v1, v0}, Ltgn;->OIO(I)V

    .line 60
    .line 61
    .line 62
    const-wide v2, -0x517205a0c56e39L

    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    const v0, 0x7f120152

    .line 68
    .line 69
    .line 70
    :goto_1
    invoke-static {v0, v2, v3, v1, v6}, Lfm7;->Il(IJLtgn;Z)Ljava/lang/String;

    .line 71
    .line 72
    .line 73
    move-result-object v0

    .line 74
    :goto_2
    move-object v7, v0

    .line 75
    goto :goto_3

    .line 76
    :cond_1
    iget-boolean v2, v0, Lcom/chuanyi/voyage/ui/aichat/IO;->l:Z

    .line 77
    .line 78
    if-eqz v2, :cond_2

    .line 79
    .line 80
    const v0, -0x24467df

    .line 81
    .line 82
    .line 83
    invoke-virtual {v1, v0}, Ltgn;->OIO(I)V

    .line 84
    .line 85
    .line 86
    const-wide v2, -0x517212a0c56e39L

    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    const v0, 0x7f120209

    .line 92
    .line 93
    .line 94
    goto :goto_1

    .line 95
    :cond_2
    const v2, -0x2445f35

    .line 96
    .line 97
    .line 98
    invoke-virtual {v1, v2}, Ltgn;->OIO(I)V

    .line 99
    .line 100
    .line 101
    const-wide v2, -0x51721fa0c56e39L

    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    invoke-static {v2, v3}, Li6t0;->lO(J)Ljava/lang/String;

    .line 107
    .line 108
    .line 109
    const v2, 0x7f120116

    .line 110
    .line 111
    .line 112
    iget-object v0, v0, Lcom/chuanyi/voyage/ui/aichat/IO;->I:Ljava/lang/String;

    .line 113
    .line 114
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 115
    .line 116
    .line 117
    move-result-object v0

    .line 118
    invoke-static {v2, v0, v1}, Lkz30;->Ill(I[Ljava/lang/Object;Lkud;)Ljava/lang/String;

    .line 119
    .line 120
    .line 121
    move-result-object v0

    .line 122
    invoke-virtual {v1, v6}, Ltgn;->oI(Z)V

    .line 123
    .line 124
    .line 125
    goto :goto_2

    .line 126
    :goto_3
    const/16 v31, 0x6180

    .line 127
    .line 128
    const v32, 0x3affe

    .line 129
    .line 130
    .line 131
    const/4 v8, 0x0

    .line 132
    const-wide/16 v9, 0x0

    .line 133
    .line 134
    const/4 v11, 0x0

    .line 135
    const-wide/16 v12, 0x0

    .line 136
    .line 137
    const/4 v14, 0x0

    .line 138
    const/4 v15, 0x0

    .line 139
    const/16 v16, 0x0

    .line 140
    .line 141
    const-wide/16 v17, 0x0

    .line 142
    .line 143
    const/16 v19, 0x0

    .line 144
    .line 145
    const/16 v20, 0x0

    .line 146
    .line 147
    const-wide/16 v21, 0x0

    .line 148
    .line 149
    const/16 v23, 0x2

    .line 150
    .line 151
    const/16 v24, 0x0

    .line 152
    .line 153
    const/16 v25, 0x2

    .line 154
    .line 155
    const/16 v26, 0x0

    .line 156
    .line 157
    const/16 v27, 0x0

    .line 158
    .line 159
    const/16 v28, 0x0

    .line 160
    .line 161
    const/16 v30, 0x0

    .line 162
    .line 163
    move-object/from16 v29, v1

    .line 164
    .line 165
    invoke-static/range {v7 .. v32}, Lm7j0;->I(Ljava/lang/String;Lzgz;JLa1j0;JLunm;Ldom;Lgmm;JLk2j0;Lj0j0;JIZIILkotlin/jvm/functions/Function1;Lhaj0;Lkud;III)V

    .line 166
    .line 167
    .line 168
    goto :goto_4

    .line 169
    :cond_3
    move-object/from16 v29, v1

    .line 170
    .line 171
    invoke-virtual/range {v29 .. v29}, Ltgn;->Ioo()V

    .line 172
    .line 173
    .line 174
    :goto_4
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 175
    .line 176
    return-object v0
.end method
