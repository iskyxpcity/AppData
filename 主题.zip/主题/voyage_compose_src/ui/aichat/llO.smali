.class public final synthetic Lcom/chuanyi/voyage/ui/aichat/llO;
.super Ljava/lang/Object;
.source "S"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic I:Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

.field public final synthetic Il:Landroid/content/Context;

.field public final synthetic O:Lkc10;

.field public final synthetic l:Landroid/app/Activity;

.field public final synthetic lI:Lza1;

.field public final synthetic lO:Ljava/lang/String;

.field public final synthetic ll:Lkc10;

.field public final synthetic lo:Ljava/lang/String;

.field public final synthetic o:Lkc10;


# direct methods
.method public synthetic constructor <init>(Landroid/app/Activity;Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;Lkc10;Lkc10;Lkc10;Lza1;Ljava/lang/String;Ljava/lang/String;Landroid/content/Context;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lcom/chuanyi/voyage/ui/aichat/llO;->l:Landroid/app/Activity;

    .line 5
    .line 6
    iput-object p2, p0, Lcom/chuanyi/voyage/ui/aichat/llO;->I:Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 7
    .line 8
    iput-object p3, p0, Lcom/chuanyi/voyage/ui/aichat/llO;->O:Lkc10;

    .line 9
    .line 10
    iput-object p4, p0, Lcom/chuanyi/voyage/ui/aichat/llO;->o:Lkc10;

    .line 11
    .line 12
    iput-object p5, p0, Lcom/chuanyi/voyage/ui/aichat/llO;->ll:Lkc10;

    .line 13
    .line 14
    iput-object p6, p0, Lcom/chuanyi/voyage/ui/aichat/llO;->lI:Lza1;

    .line 15
    .line 16
    iput-object p7, p0, Lcom/chuanyi/voyage/ui/aichat/llO;->lO:Ljava/lang/String;

    .line 17
    .line 18
    iput-object p8, p0, Lcom/chuanyi/voyage/ui/aichat/llO;->lo:Ljava/lang/String;

    .line 19
    .line 20
    iput-object p9, p0, Lcom/chuanyi/voyage/ui/aichat/llO;->Il:Landroid/content/Context;

    .line 21
    .line 22
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 12

    .line 1
    check-cast p1, Lurh;

    .line 2
    .line 3
    const-wide v0, -0x516ef8a0c56e39L

    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    new-instance v2, Lcom/chuanyi/voyage/ui/aichat/lOO;

    .line 15
    .line 16
    iget-object v3, p0, Lcom/chuanyi/voyage/ui/aichat/llO;->l:Landroid/app/Activity;

    .line 17
    .line 18
    iget-object v4, p0, Lcom/chuanyi/voyage/ui/aichat/llO;->I:Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 19
    .line 20
    iget-object v5, p0, Lcom/chuanyi/voyage/ui/aichat/llO;->O:Lkc10;

    .line 21
    .line 22
    iget-object v6, p0, Lcom/chuanyi/voyage/ui/aichat/llO;->o:Lkc10;

    .line 23
    .line 24
    iget-object v7, p0, Lcom/chuanyi/voyage/ui/aichat/llO;->ll:Lkc10;

    .line 25
    .line 26
    iget-object v8, p0, Lcom/chuanyi/voyage/ui/aichat/llO;->lI:Lza1;

    .line 27
    .line 28
    iget-object v9, p0, Lcom/chuanyi/voyage/ui/aichat/llO;->lO:Ljava/lang/String;

    .line 29
    .line 30
    iget-object v10, p0, Lcom/chuanyi/voyage/ui/aichat/llO;->lo:Ljava/lang/String;

    .line 31
    .line 32
    iget-object v11, p0, Lcom/chuanyi/voyage/ui/aichat/llO;->Il:Landroid/content/Context;

    .line 33
    .line 34
    invoke-direct/range {v2 .. v11}, Lcom/chuanyi/voyage/ui/aichat/lOO;-><init>(Landroid/app/Activity;Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;Lkc10;Lkc10;Lkc10;Lza1;Ljava/lang/String;Ljava/lang/String;Landroid/content/Context;)V

    .line 35
    .line 36
    .line 37
    return-object v2
.end method
