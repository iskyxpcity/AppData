.class public final synthetic Lcom/chuanyi/voyage/ui/aichat/O;
.super Ljava/lang/Object;
.source "S"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic I:Lkc10;

.field public final synthetic O:Ljava/lang/Object;

.field public final synthetic l:B

.field public final synthetic o:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Landroid/content/Context;Ljava/lang/String;Lkc10;)V
    .locals 1

    .line 14
    const/4 v0, 0x1

    iput-byte v0, p0, Lcom/chuanyi/voyage/ui/aichat/O;->l:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p3, p0, Lcom/chuanyi/voyage/ui/aichat/O;->I:Lkc10;

    iput-object p2, p0, Lcom/chuanyi/voyage/ui/aichat/O;->O:Ljava/lang/Object;

    iput-object p1, p0, Lcom/chuanyi/voyage/ui/aichat/O;->o:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Ldx1;Lkc10;Lkc10;)V
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-byte v0, p0, Lcom/chuanyi/voyage/ui/aichat/O;->l:B

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/chuanyi/voyage/ui/aichat/O;->O:Ljava/lang/Object;

    .line 8
    .line 9
    iput-object p2, p0, Lcom/chuanyi/voyage/ui/aichat/O;->I:Lkc10;

    .line 10
    .line 11
    iput-object p3, p0, Lcom/chuanyi/voyage/ui/aichat/O;->o:Ljava/lang/Object;

    .line 12
    .line 13
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 32

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lcom/chuanyi/voyage/ui/aichat/O;->l:B

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    const/4 v3, 0x2

    .line 7
    iget-object v4, v0, Lcom/chuanyi/voyage/ui/aichat/O;->o:Ljava/lang/Object;

    .line 8
    .line 9
    iget-object v5, v0, Lcom/chuanyi/voyage/ui/aichat/O;->O:Ljava/lang/Object;

    .line 10
    .line 11
    iget-object v0, v0, Lcom/chuanyi/voyage/ui/aichat/O;->I:Lkc10;

    .line 12
    .line 13
    const/4 v6, 0x1

    .line 14
    packed-switch v1, :pswitch_data_0

    .line 15
    .line 16
    .line 17
    check-cast v5, Ljava/lang/String;

    .line 18
    .line 19
    check-cast v4, Landroid/content/Context;

    .line 20
    .line 21
    move-object/from16 v1, p1

    .line 22
    .line 23
    check-cast v1, Lkud;

    .line 24
    .line 25
    move-object/from16 v7, p2

    .line 26
    .line 27
    check-cast v7, Ljava/lang/Integer;

    .line 28
    .line 29
    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    .line 30
    .line 31
    .line 32
    move-result v7

    .line 33
    const-wide v8, -0x517077a0c56e39L

    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    invoke-static {v8, v9}, Li6t0;->lO(J)Ljava/lang/String;

    .line 39
    .line 40
    .line 41
    and-int/lit8 v8, v7, 0x3

    .line 42
    .line 43
    if-eq v8, v3, :cond_0

    .line 44
    .line 45
    move v2, v6

    .line 46
    :cond_0
    and-int/lit8 v3, v7, 0x1

    .line 47
    .line 48
    check-cast v1, Ltgn;

    .line 49
    .line 50
    invoke-virtual {v1, v3, v2}, Ltgn;->Iol(IZ)Z

    .line 51
    .line 52
    .line 53
    move-result v2

    .line 54
    if-eqz v2, :cond_1

    .line 55
    .line 56
    invoke-interface {v0}, Lubg0;->getValue()Ljava/lang/Object;

    .line 57
    .line 58
    .line 59
    move-result-object v0

    .line 60
    check-cast v0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 61
    .line 62
    invoke-static {v5, v4, v0}, Lcom/chuanyi/voyage/ui/aichat/Ill;->ol(Ljava/lang/String;Landroid/content/Context;Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;)Ljava/lang/String;

    .line 63
    .line 64
    .line 65
    move-result-object v6

    .line 66
    const/16 v30, 0x0

    .line 67
    .line 68
    const v31, 0x3fffe

    .line 69
    .line 70
    .line 71
    const/4 v7, 0x0

    .line 72
    const-wide/16 v8, 0x0

    .line 73
    .line 74
    const/4 v10, 0x0

    .line 75
    const-wide/16 v11, 0x0

    .line 76
    .line 77
    const/4 v13, 0x0

    .line 78
    const/4 v14, 0x0

    .line 79
    const/4 v15, 0x0

    .line 80
    const-wide/16 v16, 0x0

    .line 81
    .line 82
    const/16 v18, 0x0

    .line 83
    .line 84
    const/16 v19, 0x0

    .line 85
    .line 86
    const-wide/16 v20, 0x0

    .line 87
    .line 88
    const/16 v22, 0x0

    .line 89
    .line 90
    const/16 v23, 0x0

    .line 91
    .line 92
    const/16 v24, 0x0

    .line 93
    .line 94
    const/16 v25, 0x0

    .line 95
    .line 96
    const/16 v26, 0x0

    .line 97
    .line 98
    const/16 v27, 0x0

    .line 99
    .line 100
    const/16 v29, 0x0

    .line 101
    .line 102
    move-object/from16 v28, v1

    .line 103
    .line 104
    invoke-static/range {v6 .. v31}, Lm7j0;->I(Ljava/lang/String;Lzgz;JLa1j0;JLunm;Ldom;Lgmm;JLk2j0;Lj0j0;JIZIILkotlin/jvm/functions/Function1;Lhaj0;Lkud;III)V

    .line 105
    .line 106
    .line 107
    goto :goto_0

    .line 108
    :cond_1
    move-object/from16 v28, v1

    .line 109
    .line 110
    invoke-virtual/range {v28 .. v28}, Ltgn;->Ioo()V

    .line 111
    .line 112
    .line 113
    :goto_0
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 114
    .line 115
    return-object v0

    .line 116
    :pswitch_0
    check-cast v5, Ldx1;

    .line 117
    .line 118
    check-cast v4, Lkc10;

    .line 119
    .line 120
    move-object/from16 v1, p1

    .line 121
    .line 122
    check-cast v1, Lkud;

    .line 123
    .line 124
    move-object/from16 v7, p2

    .line 125
    .line 126
    check-cast v7, Ljava/lang/Integer;

    .line 127
    .line 128
    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    .line 129
    .line 130
    .line 131
    move-result v7

    .line 132
    const-wide v8, -0x518067a0c56e39L

    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    invoke-static {v8, v9}, Li6t0;->lO(J)Ljava/lang/String;

    .line 138
    .line 139
    .line 140
    and-int/lit8 v8, v7, 0x3

    .line 141
    .line 142
    if-eq v8, v3, :cond_2

    .line 143
    .line 144
    move v3, v6

    .line 145
    goto :goto_1

    .line 146
    :cond_2
    move v3, v2

    .line 147
    :goto_1
    and-int/2addr v7, v6

    .line 148
    move-object v13, v1

    .line 149
    check-cast v13, Ltgn;

    .line 150
    .line 151
    invoke-virtual {v13, v7, v3}, Ltgn;->Iol(IZ)Z

    .line 152
    .line 153
    .line 154
    move-result v1

    .line 155
    if-eqz v1, :cond_6

    .line 156
    .line 157
    invoke-interface {v0}, Lubg0;->getValue()Ljava/lang/Object;

    .line 158
    .line 159
    .line 160
    move-result-object v1

    .line 161
    check-cast v1, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 162
    .line 163
    invoke-virtual {v1}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->getType()Ldx1;

    .line 164
    .line 165
    .line 166
    move-result-object v1

    .line 167
    if-ne v5, v1, :cond_3

    .line 168
    .line 169
    move v8, v6

    .line 170
    goto :goto_2

    .line 171
    :cond_3
    move v8, v2

    .line 172
    :goto_2
    const-wide v1, -0x5180fba0c56e39L

    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 178
    .line 179
    .line 180
    invoke-virtual {v13, v0}, Ltgn;->lO(Ljava/lang/Object;)Z

    .line 181
    .line 182
    .line 183
    move-result v1

    .line 184
    invoke-virtual {v13, v4}, Ltgn;->lO(Ljava/lang/Object;)Z

    .line 185
    .line 186
    .line 187
    move-result v2

    .line 188
    or-int/2addr v1, v2

    .line 189
    invoke-virtual {v5}, Ljava/lang/Enum;->ordinal()I

    .line 190
    .line 191
    .line 192
    move-result v2

    .line 193
    invoke-virtual {v13, v2}, Ltgn;->ll(I)Z

    .line 194
    .line 195
    .line 196
    move-result v2

    .line 197
    or-int/2addr v1, v2

    .line 198
    invoke-virtual {v13}, Ltgn;->IIo()Ljava/lang/Object;

    .line 199
    .line 200
    .line 201
    move-result-object v2

    .line 202
    if-nez v1, :cond_4

    .line 203
    .line 204
    sget-object v1, Lhud;->l:Ljac;

    .line 205
    .line 206
    if-ne v2, v1, :cond_5

    .line 207
    .line 208
    :cond_4
    new-instance v2, Lff1;

    .line 209
    .line 210
    invoke-direct {v2, v5, v0, v4, v6}, Lff1;-><init>(Ldx1;Lkc10;Lkc10;B)V

    .line 211
    .line 212
    .line 213
    invoke-virtual {v13, v2}, Ltgn;->oll(Ljava/lang/Object;)V

    .line 214
    .line 215
    .line 216
    :cond_5
    move-object v9, v2

    .line 217
    check-cast v9, Lkotlin/jvm/functions/Function0;

    .line 218
    .line 219
    const/4 v14, 0x0

    .line 220
    const/16 v15, 0x3c

    .line 221
    .line 222
    const/4 v10, 0x0

    .line 223
    const/4 v11, 0x0

    .line 224
    const/4 v12, 0x0

    .line 225
    invoke-static/range {v8 .. v15}, Le7w0;->l(ZLkotlin/jvm/functions/Function0;Lzgz;ZLlw90;Lkud;II)V

    .line 226
    .line 227
    .line 228
    goto :goto_3

    .line 229
    :cond_6
    invoke-virtual {v13}, Ltgn;->Ioo()V

    .line 230
    .line 231
    .line 232
    :goto_3
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 233
    .line 234
    return-object v0

    .line 235
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
