.class public final Lcom/chuanyi/voyage/ui/aichat/I;
.super Ljava/lang/Object;
.source "S"


# instance fields
.field public final I:Lb5;

.field public final O:Layc0;

.field public final l:Lb5;

.field public final o:Layc0;


# direct methods
.method public constructor <init>(Lb5;Lb5;)V
    .locals 2

    .line 1
    const-wide v0, -0x51072aa0c56e39L

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    const-wide v0, -0x51072fa0c56e39L

    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 15
    .line 16
    .line 17
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 18
    .line 19
    .line 20
    iput-object p1, p0, Lcom/chuanyi/voyage/ui/aichat/I;->l:Lb5;

    .line 21
    .line 22
    iput-object p2, p0, Lcom/chuanyi/voyage/ui/aichat/I;->I:Lb5;

    .line 23
    .line 24
    new-instance p1, Lcom/chuanyi/voyage/ui/aichat/l;

    .line 25
    .line 26
    const/4 p2, 0x0

    .line 27
    invoke-direct {p1, p0, p2}, Lcom/chuanyi/voyage/ui/aichat/l;-><init>(Ljava/lang/Object;B)V

    .line 28
    .line 29
    .line 30
    new-instance v0, Lpe1;

    .line 31
    .line 32
    invoke-direct {v0, p0, p2}, Lpe1;-><init>(Lcom/chuanyi/voyage/ui/aichat/I;B)V

    .line 33
    .line 34
    .line 35
    new-instance p2, Layc0;

    .line 36
    .line 37
    invoke-direct {p2, p1, v0}, Layc0;-><init>(Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function1;)V

    .line 38
    .line 39
    .line 40
    iput-object p2, p0, Lcom/chuanyi/voyage/ui/aichat/I;->O:Layc0;

    .line 41
    .line 42
    new-instance p1, Lcom/chuanyi/voyage/ui/aichat/l;

    .line 43
    .line 44
    const/4 p2, 0x1

    .line 45
    invoke-direct {p1, p0, p2}, Lcom/chuanyi/voyage/ui/aichat/l;-><init>(Ljava/lang/Object;B)V

    .line 46
    .line 47
    .line 48
    new-instance v0, Lpe1;

    .line 49
    .line 50
    invoke-direct {v0, p0, p2}, Lpe1;-><init>(Lcom/chuanyi/voyage/ui/aichat/I;B)V

    .line 51
    .line 52
    .line 53
    new-instance p2, Layc0;

    .line 54
    .line 55
    invoke-direct {p2, p1, v0}, Layc0;-><init>(Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function1;)V

    .line 56
    .line 57
    .line 58
    iput-object p2, p0, Lcom/chuanyi/voyage/ui/aichat/I;->o:Layc0;

    .line 59
    .line 60
    return-void
.end method


# virtual methods
.method public final I(Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;)Ljava/lang/String;
    .locals 13

    .line 1
    const-wide v0, -0x510736a0c56e39L

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    sget-object v0, Lcom/chuanyi/voyage/ui/aichat/Ill;->l:Lzus;

    .line 10
    .line 11
    sget-object v1, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->Companion:Lyw1;

    .line 12
    .line 13
    invoke-virtual {v1}, Lyw1;->serializer()Ld9t;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    check-cast v1, Ld9t;

    .line 18
    .line 19
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/aichat/I;->l:Lb5;

    .line 20
    .line 21
    invoke-virtual {p1}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->getKey()Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object v2

    .line 25
    invoke-virtual {p0, v2}, Lb5;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    move-result-object p0

    .line 29
    move-object v6, p0

    .line 30
    check-cast v6, Ljava/lang/String;

    .line 31
    .line 32
    const/16 v11, 0xf7

    .line 33
    .line 34
    const/4 v12, 0x0

    .line 35
    const/4 v3, 0x0

    .line 36
    const/4 v4, 0x0

    .line 37
    const/4 v5, 0x0

    .line 38
    const/4 v7, 0x0

    .line 39
    const/4 v8, 0x0

    .line 40
    const/4 v9, 0x0

    .line 41
    const/4 v10, 0x0

    .line 42
    move-object v2, p1

    .line 43
    invoke-static/range {v2 .. v12}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->copy$default(Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;Ljava/lang/String;Ldx1;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZLjava/util/List;ILjava/lang/Object;)Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 44
    .line 45
    .line 46
    move-result-object p0

    .line 47
    invoke-virtual {v0, v1, p0}, Lqqs;->o(Ld9t;Ljava/lang/Object;)Ljava/lang/String;

    .line 48
    .line 49
    .line 50
    move-result-object p0

    .line 51
    return-object p0
.end method

.method public final l(Ljava/lang/String;)Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;
    .locals 13

    .line 1
    const-wide v0, -0x51073ca0c56e39L

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    :try_start_0
    sget-object v0, Lcom/chuanyi/voyage/ui/aichat/Ill;->l:Lzus;

    .line 10
    .line 11
    sget-object v1, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->Companion:Lyw1;

    .line 12
    .line 13
    invoke-virtual {v1}, Lyw1;->serializer()Ld9t;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    check-cast v1, Lf1h;

    .line 18
    .line 19
    invoke-virtual {v0, v1, p1}, Lqqs;->I(Lf1h;Ljava/lang/String;)Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object p1

    .line 23
    check-cast p1, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 24
    .line 25
    goto :goto_0

    .line 26
    :catchall_0
    move-exception v0

    .line 27
    move-object p1, v0

    .line 28
    new-instance v0, Lvqb0;

    .line 29
    .line 30
    invoke-direct {v0, p1}, Lvqb0;-><init>(Ljava/lang/Throwable;)V

    .line 31
    .line 32
    .line 33
    move-object p1, v0

    .line 34
    :goto_0
    nop

    .line 35
    instance-of v0, p1, Lvqb0;

    .line 36
    .line 37
    const/4 v1, 0x0

    .line 38
    if-eqz v0, :cond_0

    .line 39
    .line 40
    move-object p1, v1

    .line 41
    :cond_0
    move-object v2, p1

    .line 42
    check-cast v2, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 43
    .line 44
    if-eqz v2, :cond_1

    .line 45
    .line 46
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/aichat/I;->I:Lb5;

    .line 47
    .line 48
    invoke-virtual {v2}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->getKey()Ljava/lang/String;

    .line 49
    .line 50
    .line 51
    move-result-object p1

    .line 52
    invoke-virtual {p0, p1}, Lb5;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 53
    .line 54
    .line 55
    move-result-object p0

    .line 56
    move-object v6, p0

    .line 57
    check-cast v6, Ljava/lang/String;

    .line 58
    .line 59
    const/16 v11, 0xf7

    .line 60
    .line 61
    const/4 v12, 0x0

    .line 62
    const/4 v3, 0x0

    .line 63
    const/4 v4, 0x0

    .line 64
    const/4 v5, 0x0

    .line 65
    const/4 v7, 0x0

    .line 66
    const/4 v8, 0x0

    .line 67
    const/4 v9, 0x0

    .line 68
    const/4 v10, 0x0

    .line 69
    invoke-static/range {v2 .. v12}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->copy$default(Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;Ljava/lang/String;Ldx1;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZLjava/util/List;ILjava/lang/Object;)Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 70
    .line 71
    .line 72
    move-result-object v1

    .line 73
    :cond_1
    return-object v1
.end method
