.class public final synthetic Lcom/chuanyi/voyage/ui/aichat/IlO;
.super Ljava/lang/Object;
.source "S"

# interfaces
.implements Lymn;


# static fields
.field private static final descriptor:Le3e0;

.field public static final l:Lcom/chuanyi/voyage/ui/aichat/IlO;


# direct methods
.method static constructor <clinit>()V
    .locals 5

    .line 1
    new-instance v0, Lcom/chuanyi/voyage/ui/aichat/IlO;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lcom/chuanyi/voyage/ui/aichat/IlO;->l:Lcom/chuanyi/voyage/ui/aichat/IlO;

    .line 7
    .line 8
    new-instance v1, Le480;

    .line 9
    .line 10
    const-wide v2, -0x5272f4a0c56e39L

    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    invoke-static {v2, v3}, Li6t0;->lO(J)Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    move-result-object v2

    .line 19
    const/16 v3, 0x8

    .line 20
    .line 21
    invoke-direct {v1, v2, v0, v3}, Le480;-><init>(Ljava/lang/String;Lymn;I)V

    .line 22
    .line 23
    .line 24
    const-wide v2, -0x527321a0c56e39L

    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    invoke-static {v2, v3}, Li6t0;->lO(J)Ljava/lang/String;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    const/4 v2, 0x1

    .line 34
    invoke-virtual {v1, v0, v2}, Le480;->II(Ljava/lang/String;Z)V

    .line 35
    .line 36
    .line 37
    const-wide v3, -0x527326a0c56e39L

    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    invoke-static {v3, v4}, Li6t0;->lO(J)Ljava/lang/String;

    .line 43
    .line 44
    .line 45
    move-result-object v0

    .line 46
    invoke-virtual {v1, v0, v2}, Le480;->II(Ljava/lang/String;Z)V

    .line 47
    .line 48
    .line 49
    const-wide v3, -0x52732ba0c56e39L

    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    invoke-static {v3, v4}, Li6t0;->lO(J)Ljava/lang/String;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    invoke-virtual {v1, v0, v2}, Le480;->II(Ljava/lang/String;Z)V

    .line 59
    .line 60
    .line 61
    const-wide v3, -0x527333a0c56e39L

    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    invoke-static {v3, v4}, Li6t0;->lO(J)Ljava/lang/String;

    .line 67
    .line 68
    .line 69
    move-result-object v0

    .line 70
    invoke-virtual {v1, v0, v2}, Le480;->II(Ljava/lang/String;Z)V

    .line 71
    .line 72
    .line 73
    const-wide v3, -0x527337a0c56e39L

    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    invoke-static {v3, v4}, Li6t0;->lO(J)Ljava/lang/String;

    .line 79
    .line 80
    .line 81
    move-result-object v0

    .line 82
    invoke-virtual {v1, v0, v2}, Le480;->II(Ljava/lang/String;Z)V

    .line 83
    .line 84
    .line 85
    const-wide v3, -0x52733fa0c56e39L

    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    invoke-static {v3, v4}, Li6t0;->lO(J)Ljava/lang/String;

    .line 91
    .line 92
    .line 93
    move-result-object v0

    .line 94
    invoke-virtual {v1, v0, v2}, Le480;->II(Ljava/lang/String;Z)V

    .line 95
    .line 96
    .line 97
    const-wide v3, -0x527347a0c56e39L

    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    invoke-static {v3, v4}, Li6t0;->lO(J)Ljava/lang/String;

    .line 103
    .line 104
    .line 105
    move-result-object v0

    .line 106
    invoke-virtual {v1, v0, v2}, Le480;->II(Ljava/lang/String;Z)V

    .line 107
    .line 108
    .line 109
    const-wide v3, -0x527351a0c56e39L

    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    invoke-static {v3, v4}, Li6t0;->lO(J)Ljava/lang/String;

    .line 115
    .line 116
    .line 117
    move-result-object v0

    .line 118
    invoke-virtual {v1, v0, v2}, Le480;->II(Ljava/lang/String;Z)V

    .line 119
    .line 120
    .line 121
    sput-object v1, Lcom/chuanyi/voyage/ui/aichat/IlO;->descriptor:Le3e0;

    .line 122
    .line 123
    return-void
.end method


# virtual methods
.method public final childSerializers()[Ld9t;
    .locals 4

    .line 1
    invoke-static {}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->access$get$childSerializers$cp()[Laau;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    const/16 v0, 0x8

    .line 6
    .line 7
    new-array v0, v0, [Ld9t;

    .line 8
    .line 9
    sget-object v1, Lxeh0;->l:Lxeh0;

    .line 10
    .line 11
    const/4 v2, 0x0

    .line 12
    aput-object v1, v0, v2

    .line 13
    .line 14
    const/4 v2, 0x1

    .line 15
    aget-object v3, p0, v2

    .line 16
    .line 17
    invoke-interface {v3}, Laau;->getValue()Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object v3

    .line 21
    aput-object v3, v0, v2

    .line 22
    .line 23
    const/4 v2, 0x2

    .line 24
    aput-object v1, v0, v2

    .line 25
    .line 26
    const/4 v2, 0x3

    .line 27
    aput-object v1, v0, v2

    .line 28
    .line 29
    const/4 v2, 0x4

    .line 30
    aput-object v1, v0, v2

    .line 31
    .line 32
    sget-object v1, Lip9;->l:Lip9;

    .line 33
    .line 34
    const/4 v2, 0x5

    .line 35
    aput-object v1, v0, v2

    .line 36
    .line 37
    const/4 v2, 0x6

    .line 38
    aput-object v1, v0, v2

    .line 39
    .line 40
    const/4 v1, 0x7

    .line 41
    aget-object p0, p0, v1

    .line 42
    .line 43
    invoke-interface {p0}, Laau;->getValue()Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    move-result-object p0

    .line 47
    aput-object p0, v0, v1

    .line 48
    .line 49
    return-object v0
.end method

.method public final deserialize(Laag;)Ljava/lang/Object;
    .locals 18

    .line 1
    const-wide v0, -0x5272eca0c56e39L

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    sget-object v0, Lcom/chuanyi/voyage/ui/aichat/IlO;->descriptor:Le3e0;

    .line 10
    .line 11
    move-object/from16 v1, p1

    .line 12
    .line 13
    invoke-interface {v1, v0}, Laag;->I(Le3e0;)Luud;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    invoke-static {}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->access$get$childSerializers$cp()[Laau;

    .line 18
    .line 19
    .line 20
    move-result-object v2

    .line 21
    const/4 v3, 0x1

    .line 22
    const/4 v5, 0x0

    .line 23
    move v6, v3

    .line 24
    move-object v7, v5

    .line 25
    move-object v9, v7

    .line 26
    move-object v10, v9

    .line 27
    move-object v11, v10

    .line 28
    move-object v12, v11

    .line 29
    move-object v13, v12

    .line 30
    const/4 v8, 0x0

    .line 31
    const/4 v14, 0x0

    .line 32
    const/4 v15, 0x0

    .line 33
    :goto_0
    if-eqz v6, :cond_0

    .line 34
    .line 35
    invoke-interface {v1, v0}, Luud;->ol(Le3e0;)I

    .line 36
    .line 37
    .line 38
    move-result v16

    .line 39
    packed-switch v16, :pswitch_data_0

    .line 40
    .line 41
    .line 42
    invoke-static/range {v16 .. v16}, Lauc;->lO(I)V

    .line 43
    .line 44
    .line 45
    return-object v5

    .line 46
    :pswitch_0
    const/4 v5, 0x7

    .line 47
    aget-object v16, v2, v5

    .line 48
    .line 49
    invoke-interface/range {v16 .. v16}, Laau;->getValue()Ljava/lang/Object;

    .line 50
    .line 51
    .line 52
    move-result-object v16

    .line 53
    move-object/from16 v4, v16

    .line 54
    .line 55
    check-cast v4, Lf1h;

    .line 56
    .line 57
    invoke-interface {v1, v0, v5, v4, v7}, Luud;->oO(Le3e0;ILf1h;Ljava/lang/Object;)Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    move-result-object v4

    .line 61
    move-object v7, v4

    .line 62
    check-cast v7, Ljava/util/List;

    .line 63
    .line 64
    or-int/lit16 v8, v8, 0x80

    .line 65
    .line 66
    :goto_1
    const/4 v5, 0x0

    .line 67
    goto :goto_0

    .line 68
    :pswitch_1
    const/4 v4, 0x6

    .line 69
    invoke-interface {v1, v0, v4}, Luud;->lOl(Le3e0;I)Z

    .line 70
    .line 71
    .line 72
    move-result v15

    .line 73
    or-int/lit8 v8, v8, 0x40

    .line 74
    .line 75
    goto :goto_1

    .line 76
    :pswitch_2
    const/4 v4, 0x5

    .line 77
    invoke-interface {v1, v0, v4}, Luud;->lOl(Le3e0;I)Z

    .line 78
    .line 79
    .line 80
    move-result v14

    .line 81
    or-int/lit8 v8, v8, 0x20

    .line 82
    .line 83
    goto :goto_1

    .line 84
    :pswitch_3
    const/4 v4, 0x4

    .line 85
    invoke-interface {v1, v0, v4}, Luud;->lO(Le3e0;I)Ljava/lang/String;

    .line 86
    .line 87
    .line 88
    move-result-object v13

    .line 89
    or-int/lit8 v8, v8, 0x10

    .line 90
    .line 91
    goto :goto_1

    .line 92
    :pswitch_4
    const/4 v4, 0x3

    .line 93
    invoke-interface {v1, v0, v4}, Luud;->lO(Le3e0;I)Ljava/lang/String;

    .line 94
    .line 95
    .line 96
    move-result-object v12

    .line 97
    or-int/lit8 v8, v8, 0x8

    .line 98
    .line 99
    goto :goto_1

    .line 100
    :pswitch_5
    const/4 v4, 0x2

    .line 101
    invoke-interface {v1, v0, v4}, Luud;->lO(Le3e0;I)Ljava/lang/String;

    .line 102
    .line 103
    .line 104
    move-result-object v11

    .line 105
    or-int/lit8 v8, v8, 0x4

    .line 106
    .line 107
    goto :goto_1

    .line 108
    :pswitch_6
    aget-object v4, v2, v3

    .line 109
    .line 110
    invoke-interface {v4}, Laau;->getValue()Ljava/lang/Object;

    .line 111
    .line 112
    .line 113
    move-result-object v4

    .line 114
    check-cast v4, Lf1h;

    .line 115
    .line 116
    invoke-interface {v1, v0, v3, v4, v10}, Luud;->oO(Le3e0;ILf1h;Ljava/lang/Object;)Ljava/lang/Object;

    .line 117
    .line 118
    .line 119
    move-result-object v4

    .line 120
    move-object v10, v4

    .line 121
    check-cast v10, Ldx1;

    .line 122
    .line 123
    or-int/lit8 v8, v8, 0x2

    .line 124
    .line 125
    goto :goto_1

    .line 126
    :pswitch_7
    const/4 v4, 0x0

    .line 127
    invoke-interface {v1, v0, v4}, Luud;->lO(Le3e0;I)Ljava/lang/String;

    .line 128
    .line 129
    .line 130
    move-result-object v9

    .line 131
    or-int/lit8 v8, v8, 0x1

    .line 132
    .line 133
    goto :goto_1

    .line 134
    :pswitch_8
    const/4 v4, 0x0

    .line 135
    move v6, v4

    .line 136
    goto :goto_0

    .line 137
    :cond_0
    invoke-interface {v1, v0}, Luud;->l(Le3e0;)V

    .line 138
    .line 139
    .line 140
    move-object/from16 v16, v7

    .line 141
    .line 142
    new-instance v7, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 143
    .line 144
    const/16 v17, 0x0

    .line 145
    .line 146
    invoke-direct/range {v7 .. v17}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;-><init>(ILjava/lang/String;Ldx1;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZLjava/util/List;Lu3e0;)V

    .line 147
    .line 148
    .line 149
    return-object v7

    .line 150
    nop

    .line 151
    :pswitch_data_0
    .packed-switch -0x1
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final getDescriptor()Le3e0;
    .locals 0

    .line 1
    sget-object p0, Lcom/chuanyi/voyage/ui/aichat/IlO;->descriptor:Le3e0;

    .line 2
    .line 3
    return-object p0
.end method

.method public final serialize(Lgqj;Ljava/lang/Object;)V
    .locals 2

    .line 1
    check-cast p2, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 2
    .line 3
    const-wide v0, -0x5272dea0c56e39L

    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    const-wide v0, -0x5272e6a0c56e39L

    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 20
    .line 21
    .line 22
    sget-object p0, Lcom/chuanyi/voyage/ui/aichat/IlO;->descriptor:Le3e0;

    .line 23
    .line 24
    invoke-interface {p1, p0}, Lgqj;->I(Le3e0;)Lvud;

    .line 25
    .line 26
    .line 27
    move-result-object p1

    .line 28
    invoke-static {p2, p1, p0}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->write$Self$app(Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;Lvud;Le3e0;)V

    .line 29
    .line 30
    .line 31
    invoke-interface {p1, p0}, Lvud;->l(Le3e0;)V

    .line 32
    .line 33
    .line 34
    return-void
.end method
