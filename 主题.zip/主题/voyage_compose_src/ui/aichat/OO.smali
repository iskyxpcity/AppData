.class public final synthetic Lcom/chuanyi/voyage/ui/aichat/OO;
.super Ljava/lang/Object;
.source "S"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# instance fields
.field public final synthetic I:Lkc10;

.field public final synthetic II:Z

.field public final synthetic IO:Lkotlin/jvm/functions/Function0;

.field public final synthetic Il:Lkc10;

.field public final synthetic Io:Lkc10;

.field public final synthetic O:Lkc10;

.field public final synthetic l:Z

.field public final synthetic lI:Ljava/lang/String;

.field public final synthetic lO:Landroid/content/Context;

.field public final synthetic ll:Ljava/lang/String;

.field public final synthetic lo:Lkc10;

.field public final synthetic o:Lza1;


# direct methods
.method public synthetic constructor <init>(ZLkc10;Lkc10;Lza1;Ljava/lang/String;Ljava/lang/String;Landroid/content/Context;Lkc10;Lkc10;ZLkotlin/jvm/functions/Function0;Lkc10;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-boolean p1, p0, Lcom/chuanyi/voyage/ui/aichat/OO;->l:Z

    .line 5
    .line 6
    iput-object p2, p0, Lcom/chuanyi/voyage/ui/aichat/OO;->I:Lkc10;

    .line 7
    .line 8
    iput-object p3, p0, Lcom/chuanyi/voyage/ui/aichat/OO;->O:Lkc10;

    .line 9
    .line 10
    iput-object p4, p0, Lcom/chuanyi/voyage/ui/aichat/OO;->o:Lza1;

    .line 11
    .line 12
    iput-object p5, p0, Lcom/chuanyi/voyage/ui/aichat/OO;->ll:Ljava/lang/String;

    .line 13
    .line 14
    iput-object p6, p0, Lcom/chuanyi/voyage/ui/aichat/OO;->lI:Ljava/lang/String;

    .line 15
    .line 16
    iput-object p7, p0, Lcom/chuanyi/voyage/ui/aichat/OO;->lO:Landroid/content/Context;

    .line 17
    .line 18
    iput-object p8, p0, Lcom/chuanyi/voyage/ui/aichat/OO;->lo:Lkc10;

    .line 19
    .line 20
    iput-object p9, p0, Lcom/chuanyi/voyage/ui/aichat/OO;->Il:Lkc10;

    .line 21
    .line 22
    iput-boolean p10, p0, Lcom/chuanyi/voyage/ui/aichat/OO;->II:Z

    .line 23
    .line 24
    iput-object p11, p0, Lcom/chuanyi/voyage/ui/aichat/OO;->IO:Lkotlin/jvm/functions/Function0;

    .line 25
    .line 26
    iput-object p12, p0, Lcom/chuanyi/voyage/ui/aichat/OO;->Io:Lkc10;

    .line 27
    .line 28
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 22

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    check-cast v1, Lofc0;

    .line 6
    .line 7
    move-object/from16 v2, p2

    .line 8
    .line 9
    check-cast v2, Lkud;

    .line 10
    .line 11
    move-object/from16 v3, p3

    .line 12
    .line 13
    check-cast v3, Ljava/lang/Integer;

    .line 14
    .line 15
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 16
    .line 17
    .line 18
    move-result v3

    .line 19
    const-wide v4, -0x516f0fa0c56e39L

    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    const-wide v6, -0x516f26a0c56e39L

    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    invoke-static {v4, v5, v1, v6, v7}, Lnk00;->llI(JLofc0;J)V

    .line 30
    .line 31
    .line 32
    and-int/lit8 v1, v3, 0x11

    .line 33
    .line 34
    const/16 v4, 0x10

    .line 35
    .line 36
    const/4 v5, 0x1

    .line 37
    const/4 v6, 0x0

    .line 38
    if-eq v1, v4, :cond_0

    .line 39
    .line 40
    move v1, v5

    .line 41
    goto :goto_0

    .line 42
    :cond_0
    move v1, v6

    .line 43
    :goto_0
    and-int/2addr v3, v5

    .line 44
    check-cast v2, Ltgn;

    .line 45
    .line 46
    invoke-virtual {v2, v3, v1}, Ltgn;->Iol(IZ)Z

    .line 47
    .line 48
    .line 49
    move-result v1

    .line 50
    if-eqz v1, :cond_a

    .line 51
    .line 52
    iget-boolean v1, v0, Lcom/chuanyi/voyage/ui/aichat/OO;->l:Z

    .line 53
    .line 54
    iget-object v13, v0, Lcom/chuanyi/voyage/ui/aichat/OO;->I:Lkc10;

    .line 55
    .line 56
    iget-object v9, v0, Lcom/chuanyi/voyage/ui/aichat/OO;->O:Lkc10;

    .line 57
    .line 58
    iget-object v8, v0, Lcom/chuanyi/voyage/ui/aichat/OO;->o:Lza1;

    .line 59
    .line 60
    iget-object v12, v0, Lcom/chuanyi/voyage/ui/aichat/OO;->ll:Ljava/lang/String;

    .line 61
    .line 62
    iget-object v14, v0, Lcom/chuanyi/voyage/ui/aichat/OO;->lI:Ljava/lang/String;

    .line 63
    .line 64
    iget-object v15, v0, Lcom/chuanyi/voyage/ui/aichat/OO;->lO:Landroid/content/Context;

    .line 65
    .line 66
    sget-object v3, Lhud;->l:Ljac;

    .line 67
    .line 68
    if-eqz v1, :cond_7

    .line 69
    .line 70
    const v1, 0x701077c7

    .line 71
    .line 72
    .line 73
    const-wide v4, -0x516f89a0c56e39L

    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    invoke-static {v2, v1, v4, v5, v9}, Lnk00;->Io(Ltgn;IJLkc10;)Ljava/lang/Object;

    .line 79
    .line 80
    .line 81
    move-result-object v1

    .line 82
    check-cast v1, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 83
    .line 84
    invoke-interface {v13}, Lubg0;->getValue()Ljava/lang/Object;

    .line 85
    .line 86
    .line 87
    move-result-object v4

    .line 88
    check-cast v4, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 89
    .line 90
    invoke-static {v1, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 91
    .line 92
    .line 93
    move-result v1

    .line 94
    if-nez v1, :cond_1

    .line 95
    .line 96
    sget-object v4, Lri1;->IIo:Lf4r;

    .line 97
    .line 98
    goto :goto_1

    .line 99
    :cond_1
    sget-object v4, Lri1;->IIO:Lf4r;

    .line 100
    .line 101
    :goto_1
    if-nez v1, :cond_2

    .line 102
    .line 103
    const v1, 0x7f120215

    .line 104
    .line 105
    .line 106
    goto :goto_2

    .line 107
    :cond_2
    const v1, 0x7f120214

    .line 108
    .line 109
    .line 110
    :goto_2
    invoke-static {v1, v2}, Lkz30;->loo(ILkud;)Ljava/lang/String;

    .line 111
    .line 112
    .line 113
    move-result-object v1

    .line 114
    const-wide v10, -0x516fd9a0c56e39L

    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    invoke-static {v10, v11}, Li6t0;->lO(J)Ljava/lang/String;

    .line 120
    .line 121
    .line 122
    invoke-virtual {v2, v13}, Ltgn;->lO(Ljava/lang/Object;)Z

    .line 123
    .line 124
    .line 125
    move-result v5

    .line 126
    invoke-virtual {v2, v9}, Ltgn;->lO(Ljava/lang/Object;)Z

    .line 127
    .line 128
    .line 129
    move-result v7

    .line 130
    or-int/2addr v5, v7

    .line 131
    invoke-virtual {v2, v8}, Ltgn;->Il(Ljava/lang/Object;)Z

    .line 132
    .line 133
    .line 134
    move-result v7

    .line 135
    or-int/2addr v5, v7

    .line 136
    invoke-virtual {v2, v12}, Ltgn;->lO(Ljava/lang/Object;)Z

    .line 137
    .line 138
    .line 139
    move-result v7

    .line 140
    or-int/2addr v5, v7

    .line 141
    invoke-virtual {v2, v14}, Ltgn;->lO(Ljava/lang/Object;)Z

    .line 142
    .line 143
    .line 144
    move-result v7

    .line 145
    or-int/2addr v5, v7

    .line 146
    invoke-virtual {v2, v15}, Ltgn;->Il(Ljava/lang/Object;)Z

    .line 147
    .line 148
    .line 149
    move-result v7

    .line 150
    or-int/2addr v5, v7

    .line 151
    invoke-virtual {v2}, Ltgn;->IIo()Ljava/lang/Object;

    .line 152
    .line 153
    .line 154
    move-result-object v7

    .line 155
    if-nez v5, :cond_3

    .line 156
    .line 157
    if-ne v7, v3, :cond_4

    .line 158
    .line 159
    :cond_3
    new-instance v7, Lna0;

    .line 160
    .line 161
    move-object v10, v9

    .line 162
    move-object v11, v12

    .line 163
    move-object v9, v13

    .line 164
    move-object v12, v14

    .line 165
    move-object v13, v15

    .line 166
    invoke-direct/range {v7 .. v13}, Lna0;-><init>(Lza1;Lkc10;Lkc10;Ljava/lang/String;Ljava/lang/String;Landroid/content/Context;)V

    .line 167
    .line 168
    .line 169
    invoke-virtual {v2, v7}, Ltgn;->oll(Ljava/lang/Object;)V

    .line 170
    .line 171
    .line 172
    :cond_4
    move-object v9, v7

    .line 173
    check-cast v9, Lkotlin/jvm/functions/Function0;

    .line 174
    .line 175
    const/16 v20, 0x0

    .line 176
    .line 177
    const/16 v21, 0x3f8

    .line 178
    .line 179
    const/4 v10, 0x0

    .line 180
    const/4 v11, 0x0

    .line 181
    const/4 v12, 0x0

    .line 182
    const-wide/16 v13, 0x0

    .line 183
    .line 184
    const-wide/16 v15, 0x0

    .line 185
    .line 186
    const/16 v17, 0x0

    .line 187
    .line 188
    const/16 v18, 0x0

    .line 189
    .line 190
    move-object v8, v1

    .line 191
    move-object/from16 v19, v2

    .line 192
    .line 193
    move-object v7, v4

    .line 194
    invoke-static/range {v7 .. v21}, Lkc1;->lI(Lf4r;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lzgz;ZZJJLree0;FLkud;II)V

    .line 195
    .line 196
    .line 197
    sget-object v7, Lri1;->lIo:Lf4r;

    .line 198
    .line 199
    const v1, 0x7f1200f7

    .line 200
    .line 201
    .line 202
    invoke-static {v1, v2}, Lkz30;->loo(ILkud;)Ljava/lang/String;

    .line 203
    .line 204
    .line 205
    move-result-object v8

    .line 206
    const-wide v4, -0x516ffaa0c56e39L    # -1.07308874592144E307

    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    invoke-static {v4, v5}, Li6t0;->lO(J)Ljava/lang/String;

    .line 212
    .line 213
    .line 214
    iget-object v0, v0, Lcom/chuanyi/voyage/ui/aichat/OO;->lo:Lkc10;

    .line 215
    .line 216
    invoke-virtual {v2, v0}, Ltgn;->lO(Ljava/lang/Object;)Z

    .line 217
    .line 218
    .line 219
    move-result v1

    .line 220
    invoke-virtual {v2}, Ltgn;->IIo()Ljava/lang/Object;

    .line 221
    .line 222
    .line 223
    move-result-object v4

    .line 224
    if-nez v1, :cond_5

    .line 225
    .line 226
    if-ne v4, v3, :cond_6

    .line 227
    .line 228
    :cond_5
    new-instance v4, Lyf1;

    .line 229
    .line 230
    const/16 v1, 0x1c

    .line 231
    .line 232
    invoke-direct {v4, v0, v1}, Lyf1;-><init>(Lkc10;B)V

    .line 233
    .line 234
    .line 235
    invoke-virtual {v2, v4}, Ltgn;->oll(Ljava/lang/Object;)V

    .line 236
    .line 237
    .line 238
    :cond_6
    move-object v9, v4

    .line 239
    check-cast v9, Lkotlin/jvm/functions/Function0;

    .line 240
    .line 241
    const/16 v20, 0x0

    .line 242
    .line 243
    const/16 v21, 0x3f8

    .line 244
    .line 245
    const/4 v10, 0x0

    .line 246
    const/4 v11, 0x0

    .line 247
    const/4 v12, 0x0

    .line 248
    const-wide/16 v13, 0x0

    .line 249
    .line 250
    const-wide/16 v15, 0x0

    .line 251
    .line 252
    const/16 v17, 0x0

    .line 253
    .line 254
    const/16 v18, 0x0

    .line 255
    .line 256
    move-object/from16 v19, v2

    .line 257
    .line 258
    invoke-static/range {v7 .. v21}, Lkc1;->lI(Lf4r;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lzgz;ZZJJLree0;FLkud;II)V

    .line 259
    .line 260
    .line 261
    invoke-virtual {v2, v6}, Ltgn;->oI(Z)V

    .line 262
    .line 263
    .line 264
    goto/16 :goto_3

    .line 265
    .line 266
    :cond_7
    const v1, 0x701789e3

    .line 267
    .line 268
    .line 269
    invoke-virtual {v2, v1}, Ltgn;->OIO(I)V

    .line 270
    .line 271
    .line 272
    const-wide v4, -0x51701ba0c56e39L

    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    invoke-static {v4, v5}, Li6t0;->lO(J)Ljava/lang/String;

    .line 278
    .line 279
    .line 280
    sget-object v1, Lri1;->IlI:Lf4r;

    .line 281
    .line 282
    const v4, 0x7f120213

    .line 283
    .line 284
    .line 285
    invoke-static {v4, v2}, Lkz30;->loo(ILkud;)Ljava/lang/String;

    .line 286
    .line 287
    .line 288
    move-result-object v4

    .line 289
    const-wide v10, -0x517043a0c56e39L

    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    invoke-static {v10, v11}, Li6t0;->lO(J)Ljava/lang/String;

    .line 295
    .line 296
    .line 297
    invoke-virtual {v2, v9}, Ltgn;->lO(Ljava/lang/Object;)Z

    .line 298
    .line 299
    .line 300
    move-result v5

    .line 301
    iget-object v10, v0, Lcom/chuanyi/voyage/ui/aichat/OO;->Il:Lkc10;

    .line 302
    .line 303
    invoke-virtual {v2, v10}, Ltgn;->lO(Ljava/lang/Object;)Z

    .line 304
    .line 305
    .line 306
    move-result v7

    .line 307
    or-int/2addr v5, v7

    .line 308
    invoke-virtual {v2, v13}, Ltgn;->lO(Ljava/lang/Object;)Z

    .line 309
    .line 310
    .line 311
    move-result v7

    .line 312
    or-int/2addr v5, v7

    .line 313
    invoke-virtual {v2, v8}, Ltgn;->Il(Ljava/lang/Object;)Z

    .line 314
    .line 315
    .line 316
    move-result v7

    .line 317
    or-int/2addr v5, v7

    .line 318
    invoke-virtual {v2, v12}, Ltgn;->lO(Ljava/lang/Object;)Z

    .line 319
    .line 320
    .line 321
    move-result v7

    .line 322
    or-int/2addr v5, v7

    .line 323
    invoke-virtual {v2, v14}, Ltgn;->lO(Ljava/lang/Object;)Z

    .line 324
    .line 325
    .line 326
    move-result v7

    .line 327
    or-int/2addr v5, v7

    .line 328
    invoke-virtual {v2, v15}, Ltgn;->Il(Ljava/lang/Object;)Z

    .line 329
    .line 330
    .line 331
    move-result v7

    .line 332
    or-int/2addr v5, v7

    .line 333
    move-object v11, v8

    .line 334
    iget-boolean v8, v0, Lcom/chuanyi/voyage/ui/aichat/OO;->II:Z

    .line 335
    .line 336
    invoke-virtual {v2, v8}, Ltgn;->lo(Z)Z

    .line 337
    .line 338
    .line 339
    move-result v7

    .line 340
    or-int/2addr v5, v7

    .line 341
    iget-object v7, v0, Lcom/chuanyi/voyage/ui/aichat/OO;->IO:Lkotlin/jvm/functions/Function0;

    .line 342
    .line 343
    invoke-virtual {v2, v7}, Ltgn;->lO(Ljava/lang/Object;)Z

    .line 344
    .line 345
    .line 346
    move-result v16

    .line 347
    or-int v5, v5, v16

    .line 348
    .line 349
    invoke-virtual {v2}, Ltgn;->IIo()Ljava/lang/Object;

    .line 350
    .line 351
    .line 352
    move-result-object v6

    .line 353
    if-nez v5, :cond_8

    .line 354
    .line 355
    if-ne v6, v3, :cond_9

    .line 356
    .line 357
    :cond_8
    move-object/from16 v16, v7

    .line 358
    .line 359
    new-instance v7, Lmf1;

    .line 360
    .line 361
    const/16 v18, 0x1

    .line 362
    .line 363
    iget-object v0, v0, Lcom/chuanyi/voyage/ui/aichat/OO;->Io:Lkc10;

    .line 364
    .line 365
    move-object/from16 v17, v0

    .line 366
    .line 367
    invoke-direct/range {v7 .. v18}, Lmf1;-><init>(ZLkc10;Lkc10;Lza1;Ljava/lang/String;Lkc10;Ljava/lang/String;Landroid/content/Context;Lkotlin/jvm/functions/Function0;Lkc10;B)V

    .line 368
    .line 369
    .line 370
    invoke-virtual {v2, v7}, Ltgn;->oll(Ljava/lang/Object;)V

    .line 371
    .line 372
    .line 373
    move-object v6, v7

    .line 374
    :cond_9
    move-object v9, v6

    .line 375
    check-cast v9, Lkotlin/jvm/functions/Function0;

    .line 376
    .line 377
    const/16 v20, 0x0

    .line 378
    .line 379
    const/16 v21, 0x3f8

    .line 380
    .line 381
    const/4 v10, 0x0

    .line 382
    const/4 v11, 0x0

    .line 383
    const/4 v12, 0x0

    .line 384
    const-wide/16 v13, 0x0

    .line 385
    .line 386
    const-wide/16 v15, 0x0

    .line 387
    .line 388
    const/16 v17, 0x0

    .line 389
    .line 390
    const/16 v18, 0x0

    .line 391
    .line 392
    move-object v7, v1

    .line 393
    move-object/from16 v19, v2

    .line 394
    .line 395
    move-object v8, v4

    .line 396
    invoke-static/range {v7 .. v21}, Lkc1;->lI(Lf4r;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lzgz;ZZJJLree0;FLkud;II)V

    .line 397
    .line 398
    .line 399
    const/4 v0, 0x0

    .line 400
    invoke-virtual {v2, v0}, Ltgn;->oI(Z)V

    .line 401
    .line 402
    .line 403
    goto :goto_3

    .line 404
    :cond_a
    invoke-virtual {v2}, Ltgn;->Ioo()V

    .line 405
    .line 406
    .line 407
    :goto_3
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 408
    .line 409
    return-object v0
.end method
