.class public final Lcom/chuanyi/voyage/ui/aichat/lII;
.super Li0i0;
.source "S"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public I:Z

.field public final synthetic O:Lza1;

.field public final synthetic l:B

.field public final synthetic lI:Ljava/lang/String;

.field public final synthetic lO:Lkc10;

.field public final synthetic ll:Ljava/lang/String;

.field public final synthetic lo:Ljava/lang/Object;

.field public synthetic o:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Lkc10;Lza1;Ljava/lang/String;Ljava/lang/String;Landroid/content/Context;Lvce;)V
    .locals 1

    const/4 v0, 0x2

    iput-byte v0, p0, Lcom/chuanyi/voyage/ui/aichat/lII;->l:B

    .line 22
    iput-object p1, p0, Lcom/chuanyi/voyage/ui/aichat/lII;->lO:Lkc10;

    iput-object p2, p0, Lcom/chuanyi/voyage/ui/aichat/lII;->O:Lza1;

    iput-object p3, p0, Lcom/chuanyi/voyage/ui/aichat/lII;->ll:Ljava/lang/String;

    iput-object p4, p0, Lcom/chuanyi/voyage/ui/aichat/lII;->lI:Ljava/lang/String;

    iput-object p5, p0, Lcom/chuanyi/voyage/ui/aichat/lII;->lo:Ljava/lang/Object;

    invoke-direct {p0, v0, p6}, Li0i0;-><init>(ILvce;)V

    return-void
.end method

.method public constructor <init>(Lza1;Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;Lkc10;Lvce;)V
    .locals 1

    const/4 v0, 0x1

    iput-byte v0, p0, Lcom/chuanyi/voyage/ui/aichat/lII;->l:B

    .line 21
    iput-object p1, p0, Lcom/chuanyi/voyage/ui/aichat/lII;->O:Lza1;

    iput-object p2, p0, Lcom/chuanyi/voyage/ui/aichat/lII;->o:Ljava/lang/Object;

    iput-object p3, p0, Lcom/chuanyi/voyage/ui/aichat/lII;->ll:Ljava/lang/String;

    iput-object p4, p0, Lcom/chuanyi/voyage/ui/aichat/lII;->lI:Ljava/lang/String;

    iput-object p5, p0, Lcom/chuanyi/voyage/ui/aichat/lII;->lo:Ljava/lang/Object;

    iput-object p6, p0, Lcom/chuanyi/voyage/ui/aichat/lII;->lO:Lkc10;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p7}, Li0i0;-><init>(ILvce;)V

    return-void
.end method

.method public constructor <init>(Lza1;Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;Ljava/lang/String;Ljava/lang/String;Lkc10;Lkc10;Lvce;)V
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-byte v0, p0, Lcom/chuanyi/voyage/ui/aichat/lII;->l:B

    .line 3
    .line 4
    iput-object p1, p0, Lcom/chuanyi/voyage/ui/aichat/lII;->O:Lza1;

    .line 5
    .line 6
    iput-object p2, p0, Lcom/chuanyi/voyage/ui/aichat/lII;->o:Ljava/lang/Object;

    .line 7
    .line 8
    iput-object p3, p0, Lcom/chuanyi/voyage/ui/aichat/lII;->ll:Ljava/lang/String;

    .line 9
    .line 10
    iput-object p4, p0, Lcom/chuanyi/voyage/ui/aichat/lII;->lI:Ljava/lang/String;

    .line 11
    .line 12
    iput-object p5, p0, Lcom/chuanyi/voyage/ui/aichat/lII;->lO:Lkc10;

    .line 13
    .line 14
    iput-object p6, p0, Lcom/chuanyi/voyage/ui/aichat/lII;->lo:Ljava/lang/Object;

    .line 15
    .line 16
    const/4 p1, 0x2

    .line 17
    invoke-direct {p0, p1, p7}, Li0i0;-><init>(ILvce;)V

    .line 18
    .line 19
    .line 20
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lvce;)Lvce;
    .locals 11

    .line 1
    iget-byte v0, p0, Lcom/chuanyi/voyage/ui/aichat/lII;->l:B

    .line 2
    .line 3
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/aichat/lII;->lo:Ljava/lang/Object;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    new-instance v2, Lcom/chuanyi/voyage/ui/aichat/lII;

    .line 9
    .line 10
    iget-object v6, p0, Lcom/chuanyi/voyage/ui/aichat/lII;->lI:Ljava/lang/String;

    .line 11
    .line 12
    move-object v7, v1

    .line 13
    check-cast v7, Landroid/content/Context;

    .line 14
    .line 15
    iget-object v3, p0, Lcom/chuanyi/voyage/ui/aichat/lII;->lO:Lkc10;

    .line 16
    .line 17
    iget-object v4, p0, Lcom/chuanyi/voyage/ui/aichat/lII;->O:Lza1;

    .line 18
    .line 19
    iget-object v5, p0, Lcom/chuanyi/voyage/ui/aichat/lII;->ll:Ljava/lang/String;

    .line 20
    .line 21
    move-object v8, p2

    .line 22
    invoke-direct/range {v2 .. v8}, Lcom/chuanyi/voyage/ui/aichat/lII;-><init>(Lkc10;Lza1;Ljava/lang/String;Ljava/lang/String;Landroid/content/Context;Lvce;)V

    .line 23
    .line 24
    .line 25
    iput-object p1, v2, Lcom/chuanyi/voyage/ui/aichat/lII;->o:Ljava/lang/Object;

    .line 26
    .line 27
    return-object v2

    .line 28
    :pswitch_0
    move-object v10, p2

    .line 29
    new-instance v3, Lcom/chuanyi/voyage/ui/aichat/lII;

    .line 30
    .line 31
    iget-object p1, p0, Lcom/chuanyi/voyage/ui/aichat/lII;->o:Ljava/lang/Object;

    .line 32
    .line 33
    move-object v5, p1

    .line 34
    check-cast v5, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 35
    .line 36
    move-object v8, v1

    .line 37
    check-cast v8, Ljava/util/ArrayList;

    .line 38
    .line 39
    iget-object v9, p0, Lcom/chuanyi/voyage/ui/aichat/lII;->lO:Lkc10;

    .line 40
    .line 41
    iget-object v4, p0, Lcom/chuanyi/voyage/ui/aichat/lII;->O:Lza1;

    .line 42
    .line 43
    iget-object v6, p0, Lcom/chuanyi/voyage/ui/aichat/lII;->ll:Ljava/lang/String;

    .line 44
    .line 45
    iget-object v7, p0, Lcom/chuanyi/voyage/ui/aichat/lII;->lI:Ljava/lang/String;

    .line 46
    .line 47
    invoke-direct/range {v3 .. v10}, Lcom/chuanyi/voyage/ui/aichat/lII;-><init>(Lza1;Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;Lkc10;Lvce;)V

    .line 48
    .line 49
    .line 50
    return-object v3

    .line 51
    :pswitch_1
    move-object v10, p2

    .line 52
    new-instance v3, Lcom/chuanyi/voyage/ui/aichat/lII;

    .line 53
    .line 54
    iget-object p1, p0, Lcom/chuanyi/voyage/ui/aichat/lII;->o:Ljava/lang/Object;

    .line 55
    .line 56
    move-object v5, p1

    .line 57
    check-cast v5, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 58
    .line 59
    iget-object v8, p0, Lcom/chuanyi/voyage/ui/aichat/lII;->lO:Lkc10;

    .line 60
    .line 61
    move-object v9, v1

    .line 62
    check-cast v9, Lkc10;

    .line 63
    .line 64
    iget-object v4, p0, Lcom/chuanyi/voyage/ui/aichat/lII;->O:Lza1;

    .line 65
    .line 66
    iget-object v6, p0, Lcom/chuanyi/voyage/ui/aichat/lII;->ll:Ljava/lang/String;

    .line 67
    .line 68
    iget-object v7, p0, Lcom/chuanyi/voyage/ui/aichat/lII;->lI:Ljava/lang/String;

    .line 69
    .line 70
    invoke-direct/range {v3 .. v10}, Lcom/chuanyi/voyage/ui/aichat/lII;-><init>(Lza1;Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;Ljava/lang/String;Ljava/lang/String;Lkc10;Lkc10;Lvce;)V

    .line 71
    .line 72
    .line 73
    return-object v3

    .line 74
    nop

    .line 75
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iget-byte v0, p0, Lcom/chuanyi/voyage/ui/aichat/lII;->l:B

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 7
    .line 8
    check-cast p2, Lvce;

    .line 9
    .line 10
    invoke-virtual {p0, p1, p2}, Lcom/chuanyi/voyage/ui/aichat/lII;->create(Ljava/lang/Object;Lvce;)Lvce;

    .line 11
    .line 12
    .line 13
    move-result-object p0

    .line 14
    check-cast p0, Lcom/chuanyi/voyage/ui/aichat/lII;

    .line 15
    .line 16
    sget-object p1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 17
    .line 18
    invoke-virtual {p0, p1}, Lcom/chuanyi/voyage/ui/aichat/lII;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object p0

    .line 22
    return-object p0

    .line 23
    :pswitch_0
    check-cast p1, Lqoe;

    .line 24
    .line 25
    check-cast p2, Lvce;

    .line 26
    .line 27
    invoke-virtual {p0, p1, p2}, Lcom/chuanyi/voyage/ui/aichat/lII;->create(Ljava/lang/Object;Lvce;)Lvce;

    .line 28
    .line 29
    .line 30
    move-result-object p0

    .line 31
    check-cast p0, Lcom/chuanyi/voyage/ui/aichat/lII;

    .line 32
    .line 33
    sget-object p1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 34
    .line 35
    invoke-virtual {p0, p1}, Lcom/chuanyi/voyage/ui/aichat/lII;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object p0

    .line 39
    return-object p0

    .line 40
    :pswitch_1
    check-cast p1, Lqoe;

    .line 41
    .line 42
    check-cast p2, Lvce;

    .line 43
    .line 44
    invoke-virtual {p0, p1, p2}, Lcom/chuanyi/voyage/ui/aichat/lII;->create(Ljava/lang/Object;Lvce;)Lvce;

    .line 45
    .line 46
    .line 47
    move-result-object p0

    .line 48
    check-cast p0, Lcom/chuanyi/voyage/ui/aichat/lII;

    .line 49
    .line 50
    sget-object p1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 51
    .line 52
    invoke-virtual {p0, p1}, Lcom/chuanyi/voyage/ui/aichat/lII;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 53
    .line 54
    .line 55
    move-result-object p0

    .line 56
    return-object p0

    .line 57
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 17

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lcom/chuanyi/voyage/ui/aichat/lII;->l:B

    .line 4
    .line 5
    iget-object v2, v0, Lcom/chuanyi/voyage/ui/aichat/lII;->lO:Lkc10;

    .line 6
    .line 7
    iget-object v3, v0, Lcom/chuanyi/voyage/ui/aichat/lII;->lI:Ljava/lang/String;

    .line 8
    .line 9
    iget-object v4, v0, Lcom/chuanyi/voyage/ui/aichat/lII;->ll:Ljava/lang/String;

    .line 10
    .line 11
    iget-object v5, v0, Lcom/chuanyi/voyage/ui/aichat/lII;->O:Lza1;

    .line 12
    .line 13
    iget-object v6, v0, Lcom/chuanyi/voyage/ui/aichat/lII;->lo:Ljava/lang/Object;

    .line 14
    .line 15
    const/4 v7, 0x0

    .line 16
    const/4 v8, 0x1

    .line 17
    packed-switch v1, :pswitch_data_0

    .line 18
    .line 19
    .line 20
    iget-object v1, v0, Lcom/chuanyi/voyage/ui/aichat/lII;->o:Ljava/lang/Object;

    .line 21
    .line 22
    move-object v14, v1

    .line 23
    check-cast v14, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 24
    .line 25
    sget-object v1, Lroe;->l:Lroe;

    .line 26
    .line 27
    iget-boolean v2, v0, Lcom/chuanyi/voyage/ui/aichat/lII;->I:Z

    .line 28
    .line 29
    if-eqz v2, :cond_1

    .line 30
    .line 31
    if-ne v2, v8, :cond_0

    .line 32
    .line 33
    invoke-static/range {p1 .. p1}, Lcp30;->IoO(Ljava/lang/Object;)V

    .line 34
    .line 35
    .line 36
    goto :goto_0

    .line 37
    :cond_0
    const-wide v0, -0x513060a0c56e39L

    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 43
    .line 44
    .line 45
    move-result-object v0

    .line 46
    invoke-static {v0}, Lvv70;->llI(Ljava/lang/String;)V

    .line 47
    .line 48
    .line 49
    goto :goto_1

    .line 50
    :cond_1
    invoke-static/range {p1 .. p1}, Lcp30;->IoO(Ljava/lang/Object;)V

    .line 51
    .line 52
    .line 53
    iput-object v14, v0, Lcom/chuanyi/voyage/ui/aichat/lII;->o:Ljava/lang/Object;

    .line 54
    .line 55
    iput-boolean v8, v0, Lcom/chuanyi/voyage/ui/aichat/lII;->I:Z

    .line 56
    .line 57
    const-wide/16 v2, 0x1f4

    .line 58
    .line 59
    invoke-static {v2, v3, v0}, Lpt8;->lll(JLvce;)Ljava/lang/Object;

    .line 60
    .line 61
    .line 62
    move-result-object v2

    .line 63
    if-ne v2, v1, :cond_2

    .line 64
    .line 65
    move-object v7, v1

    .line 66
    goto :goto_1

    .line 67
    :cond_2
    :goto_0
    sget-object v1, Lcom/chuanyi/voyage/ui/aichat/Ill;->l:Lzus;

    .line 68
    .line 69
    iget-object v11, v0, Lcom/chuanyi/voyage/ui/aichat/lII;->lO:Lkc10;

    .line 70
    .line 71
    invoke-interface {v11}, Lubg0;->getValue()Ljava/lang/Object;

    .line 72
    .line 73
    .line 74
    move-result-object v1

    .line 75
    check-cast v1, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 76
    .line 77
    if-eqz v1, :cond_3

    .line 78
    .line 79
    invoke-static {v14, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 80
    .line 81
    .line 82
    move-result v1

    .line 83
    if-nez v1, :cond_3

    .line 84
    .line 85
    move-object v13, v6

    .line 86
    check-cast v13, Landroid/content/Context;

    .line 87
    .line 88
    const/4 v15, 0x0

    .line 89
    const/16 v16, 0x0

    .line 90
    .line 91
    iget-object v9, v0, Lcom/chuanyi/voyage/ui/aichat/lII;->O:Lza1;

    .line 92
    .line 93
    iget-object v10, v0, Lcom/chuanyi/voyage/ui/aichat/lII;->ll:Ljava/lang/String;

    .line 94
    .line 95
    iget-object v12, v0, Lcom/chuanyi/voyage/ui/aichat/lII;->lI:Ljava/lang/String;

    .line 96
    .line 97
    invoke-static/range {v9 .. v16}, Lcom/chuanyi/voyage/ui/aichat/Ill;->OO(Lza1;Ljava/lang/String;Lkc10;Ljava/lang/String;Landroid/content/Context;Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;ZZ)V

    .line 98
    .line 99
    .line 100
    :cond_3
    sget-object v7, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 101
    .line 102
    :goto_1
    return-object v7

    .line 103
    :pswitch_0
    sget-object v1, Lroe;->l:Lroe;

    .line 104
    .line 105
    iget-boolean v9, v0, Lcom/chuanyi/voyage/ui/aichat/lII;->I:Z

    .line 106
    .line 107
    if-eqz v9, :cond_5

    .line 108
    .line 109
    if-ne v9, v8, :cond_4

    .line 110
    .line 111
    invoke-static/range {p1 .. p1}, Lcp30;->IoO(Ljava/lang/Object;)V

    .line 112
    .line 113
    .line 114
    move-object/from16 v0, p1

    .line 115
    .line 116
    goto :goto_2

    .line 117
    :cond_4
    const-wide v0, -0x513030a0c56e39L

    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 123
    .line 124
    .line 125
    move-result-object v0

    .line 126
    invoke-static {v0}, Lvv70;->llI(Ljava/lang/String;)V

    .line 127
    .line 128
    .line 129
    goto :goto_3

    .line 130
    :cond_5
    invoke-static/range {p1 .. p1}, Lcp30;->IoO(Ljava/lang/Object;)V

    .line 131
    .line 132
    .line 133
    iget-object v7, v0, Lcom/chuanyi/voyage/ui/aichat/lII;->o:Ljava/lang/Object;

    .line 134
    .line 135
    check-cast v7, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 136
    .line 137
    invoke-virtual {v7, v4, v3}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->provider(Ljava/lang/String;Ljava/lang/String;)Lxw1;

    .line 138
    .line 139
    .line 140
    move-result-object v3

    .line 141
    check-cast v6, Ljava/util/ArrayList;

    .line 142
    .line 143
    iput-boolean v8, v0, Lcom/chuanyi/voyage/ui/aichat/lII;->I:Z

    .line 144
    .line 145
    const/4 v4, 0x0

    .line 146
    invoke-virtual {v5, v3, v6, v4, v0}, Lza1;->lI(Lxw1;Ljava/util/List;ZLxce;)Ljava/lang/Object;

    .line 147
    .line 148
    .line 149
    move-result-object v0

    .line 150
    if-ne v0, v1, :cond_6

    .line 151
    .line 152
    move-object v7, v1

    .line 153
    goto :goto_3

    .line 154
    :cond_6
    :goto_2
    check-cast v0, Ljava/util/List;

    .line 155
    .line 156
    new-instance v1, Lcom/chuanyi/voyage/ui/aichat/lI;

    .line 157
    .line 158
    const/4 v3, 0x2

    .line 159
    invoke-direct {v1, v0, v3}, Lcom/chuanyi/voyage/ui/aichat/lI;-><init>(Ljava/util/List;B)V

    .line 160
    .line 161
    .line 162
    invoke-static {v2, v1}, Lcom/chuanyi/voyage/ui/aichat/Ill;->oO(Lkc10;Lkotlin/jvm/functions/Function1;)V

    .line 163
    .line 164
    .line 165
    sget-object v7, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 166
    .line 167
    :goto_3
    return-object v7

    .line 168
    :pswitch_1
    iget-object v1, v0, Lcom/chuanyi/voyage/ui/aichat/lII;->o:Ljava/lang/Object;

    .line 169
    .line 170
    check-cast v1, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 171
    .line 172
    sget-object v9, Lroe;->l:Lroe;

    .line 173
    .line 174
    iget-boolean v10, v0, Lcom/chuanyi/voyage/ui/aichat/lII;->I:Z

    .line 175
    .line 176
    if-eqz v10, :cond_8

    .line 177
    .line 178
    if-ne v10, v8, :cond_7

    .line 179
    .line 180
    invoke-static/range {p1 .. p1}, Lcp30;->IoO(Ljava/lang/Object;)V

    .line 181
    .line 182
    .line 183
    move-object/from16 v0, p1

    .line 184
    .line 185
    check-cast v0, Lxqb0;

    .line 186
    .line 187
    iget-object v0, v0, Lxqb0;->l:Ljava/lang/Object;

    .line 188
    .line 189
    goto :goto_4

    .line 190
    :cond_7
    const-wide v0, -0x512fd1a0c56e39L

    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 196
    .line 197
    .line 198
    move-result-object v0

    .line 199
    invoke-static {v0}, Lvv70;->llI(Ljava/lang/String;)V

    .line 200
    .line 201
    .line 202
    goto :goto_5

    .line 203
    :cond_8
    invoke-static/range {p1 .. p1}, Lcp30;->IoO(Ljava/lang/Object;)V

    .line 204
    .line 205
    .line 206
    invoke-virtual {v1, v4, v3}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->provider(Ljava/lang/String;Ljava/lang/String;)Lxw1;

    .line 207
    .line 208
    .line 209
    move-result-object v3

    .line 210
    invoke-virtual {v1}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->getKey()Ljava/lang/String;

    .line 211
    .line 212
    .line 213
    move-result-object v4

    .line 214
    invoke-virtual {v1}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->getHeaders()Ljava/lang/String;

    .line 215
    .line 216
    .line 217
    move-result-object v1

    .line 218
    invoke-static {v1}, Lcom/chuanyi/voyage/ui/aichat/Ill;->lIO(Ljava/lang/String;)Ljava/util/Map;

    .line 219
    .line 220
    .line 221
    move-result-object v1

    .line 222
    iput-boolean v8, v0, Lcom/chuanyi/voyage/ui/aichat/lII;->I:Z

    .line 223
    .line 224
    invoke-virtual {v5, v3, v4, v1, v0}, Lza1;->lO(Lxw1;Ljava/lang/String;Ljava/util/Map;Lxce;)Ljava/lang/Object;

    .line 225
    .line 226
    .line 227
    move-result-object v0

    .line 228
    if-ne v0, v9, :cond_9

    .line 229
    .line 230
    move-object v7, v9

    .line 231
    goto :goto_5

    .line 232
    :cond_9
    :goto_4
    check-cast v6, Lkc10;

    .line 233
    .line 234
    instance-of v1, v0, Lvqb0;

    .line 235
    .line 236
    if-nez v1, :cond_a

    .line 237
    .line 238
    check-cast v0, Ljava/util/List;

    .line 239
    .line 240
    sget-object v1, Lcom/chuanyi/voyage/ui/aichat/Ill;->l:Lzus;

    .line 241
    .line 242
    invoke-interface {v2, v0}, Lkc10;->setValue(Ljava/lang/Object;)V

    .line 243
    .line 244
    .line 245
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 246
    .line 247
    invoke-interface {v6, v0}, Lkc10;->setValue(Ljava/lang/Object;)V

    .line 248
    .line 249
    .line 250
    :cond_a
    sget-object v7, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 251
    .line 252
    :goto_5
    return-object v7

    .line 253
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
