.class public final synthetic Lcom/chuanyi/voyage/ui/aichat/IlI;
.super Ljava/lang/Object;
.source "S"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic l:B


# direct methods
.method public synthetic constructor <init>(B)V
    .locals 0

    .line 1
    iput-byte p1, p0, Lcom/chuanyi/voyage/ui/aichat/IlI;->l:B

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 0

    .line 1
    iget-byte p0, p0, Lcom/chuanyi/voyage/ui/aichat/IlI;->l:B

    .line 2
    .line 3
    packed-switch p0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    invoke-static {}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->l()Ld9t;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    return-object p0

    .line 11
    :pswitch_0
    invoke-static {}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->I()Ld9t;

    .line 12
    .line 13
    .line 14
    move-result-object p0

    .line 15
    return-object p0

    .line 16
    nop

    .line 17
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
