.class public final synthetic Lcom/chuanyi/voyage/ui/aichat/II;
.super Ljava/lang/Object;
.source "S"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic I:Lkc10;

.field public final synthetic O:Lkc10;

.field public final synthetic l:Lqoe;

.field public final synthetic lI:Ljava/lang/String;

.field public final synthetic lO:Lkc10;

.field public final synthetic ll:Ljava/lang/String;

.field public final synthetic lo:Lkc10;

.field public final synthetic o:Lza1;


# direct methods
.method public synthetic constructor <init>(Lqoe;Lkc10;Lkc10;Lza1;Ljava/lang/String;Ljava/lang/String;Lkc10;Lkc10;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lcom/chuanyi/voyage/ui/aichat/II;->l:Lqoe;

    .line 5
    .line 6
    iput-object p2, p0, Lcom/chuanyi/voyage/ui/aichat/II;->I:Lkc10;

    .line 7
    .line 8
    iput-object p3, p0, Lcom/chuanyi/voyage/ui/aichat/II;->O:Lkc10;

    .line 9
    .line 10
    iput-object p4, p0, Lcom/chuanyi/voyage/ui/aichat/II;->o:Lza1;

    .line 11
    .line 12
    iput-object p5, p0, Lcom/chuanyi/voyage/ui/aichat/II;->ll:Ljava/lang/String;

    .line 13
    .line 14
    iput-object p6, p0, Lcom/chuanyi/voyage/ui/aichat/II;->lI:Ljava/lang/String;

    .line 15
    .line 16
    iput-object p7, p0, Lcom/chuanyi/voyage/ui/aichat/II;->lO:Lkc10;

    .line 17
    .line 18
    iput-object p8, p0, Lcom/chuanyi/voyage/ui/aichat/II;->lo:Lkc10;

    .line 19
    .line 20
    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 9

    .line 1
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/aichat/II;->I:Lkc10;

    .line 2
    .line 3
    invoke-interface {v0}, Lubg0;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    move-object v3, v0

    .line 8
    check-cast v3, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 9
    .line 10
    invoke-virtual {v3}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->getValid()Z

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    if-nez v0, :cond_0

    .line 15
    .line 16
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 17
    .line 18
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/aichat/II;->O:Lkc10;

    .line 19
    .line 20
    invoke-interface {p0, v0}, Lkc10;->setValue(Ljava/lang/Object;)V

    .line 21
    .line 22
    .line 23
    goto :goto_0

    .line 24
    :cond_0
    new-instance v1, Lcom/chuanyi/voyage/ui/aichat/lII;

    .line 25
    .line 26
    const/4 v8, 0x0

    .line 27
    iget-object v2, p0, Lcom/chuanyi/voyage/ui/aichat/II;->o:Lza1;

    .line 28
    .line 29
    iget-object v4, p0, Lcom/chuanyi/voyage/ui/aichat/II;->ll:Ljava/lang/String;

    .line 30
    .line 31
    iget-object v5, p0, Lcom/chuanyi/voyage/ui/aichat/II;->lI:Ljava/lang/String;

    .line 32
    .line 33
    iget-object v6, p0, Lcom/chuanyi/voyage/ui/aichat/II;->lO:Lkc10;

    .line 34
    .line 35
    iget-object v7, p0, Lcom/chuanyi/voyage/ui/aichat/II;->lo:Lkc10;

    .line 36
    .line 37
    invoke-direct/range {v1 .. v8}, Lcom/chuanyi/voyage/ui/aichat/lII;-><init>(Lza1;Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;Ljava/lang/String;Ljava/lang/String;Lkc10;Lkc10;Lvce;)V

    .line 38
    .line 39
    .line 40
    const/4 v0, 0x3

    .line 41
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/aichat/II;->l:Lqoe;

    .line 42
    .line 43
    const/4 v2, 0x0

    .line 44
    invoke-static {p0, v2, v2, v1, v0}, Lw19;->loI(Lqoe;Lhoe;Ltoe;Lkotlin/jvm/functions/Function2;I)Lp9g0;

    .line 45
    .line 46
    .line 47
    :goto_0
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 48
    .line 49
    return-object p0
.end method
