.class public final synthetic Lcom/chuanyi/voyage/ui/aichat/lll;
.super Ljava/lang/Object;
.source "S"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# instance fields
.field public final synthetic I:Lkc10;

.field public final synthetic II:Ljava/util/List;

.field public final synthetic IO:Z

.field public final synthetic Il:Lkc10;

.field public final synthetic Io:Lkc10;

.field public final synthetic O:Ljava/lang/String;

.field public final synthetic Ol:Ljava/lang/String;

.field public final synthetic Oo:Landroid/content/Context;

.field public final synthetic f:Ljava/lang/String;

.field public final synthetic g:Lubg0;

.field public final synthetic h:Lqoe;

.field public final synthetic i:Lubg0;

.field public final synthetic j:Lkc10;

.field public final synthetic k:Lkc10;

.field public final synthetic l:Lkc10;

.field public final synthetic lI:Llw1;

.field public final synthetic lO:Lv41;

.field public final synthetic ll:Z

.field public final synthetic lo:Ljava/lang/String;

.field public final synthetic m:Lkc10;

.field public final synthetic n:Lkc10;

.field public final synthetic o:Lza1;

.field public final synthetic oI:Lkotlin/jvm/functions/Function0;

.field public final synthetic oO:Z

.field public final synthetic ol:Z

.field public final synthetic oo:Lkc10;

.field public final synthetic p:Lkc10;

.field public final synthetic q:Lkc10;


# direct methods
.method public synthetic constructor <init>(Lkc10;Lkc10;Ljava/lang/String;Lza1;ZLlw1;Lv41;Ljava/lang/String;Lkc10;Ljava/util/List;ZLkc10;Ljava/lang/String;Landroid/content/Context;ZLkotlin/jvm/functions/Function0;ZLkc10;Ljava/lang/String;Lkc10;Lqoe;Lkc10;Lkc10;Lkc10;Lkc10;Lkc10;Lkc10;Lkc10;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lcom/chuanyi/voyage/ui/aichat/lll;->l:Lkc10;

    .line 5
    .line 6
    iput-object p2, p0, Lcom/chuanyi/voyage/ui/aichat/lll;->I:Lkc10;

    .line 7
    .line 8
    iput-object p3, p0, Lcom/chuanyi/voyage/ui/aichat/lll;->O:Ljava/lang/String;

    .line 9
    .line 10
    iput-object p4, p0, Lcom/chuanyi/voyage/ui/aichat/lll;->o:Lza1;

    .line 11
    .line 12
    iput-boolean p5, p0, Lcom/chuanyi/voyage/ui/aichat/lll;->ll:Z

    .line 13
    .line 14
    iput-object p6, p0, Lcom/chuanyi/voyage/ui/aichat/lll;->lI:Llw1;

    .line 15
    .line 16
    iput-object p7, p0, Lcom/chuanyi/voyage/ui/aichat/lll;->lO:Lv41;

    .line 17
    .line 18
    iput-object p8, p0, Lcom/chuanyi/voyage/ui/aichat/lll;->lo:Ljava/lang/String;

    .line 19
    .line 20
    iput-object p9, p0, Lcom/chuanyi/voyage/ui/aichat/lll;->Il:Lkc10;

    .line 21
    .line 22
    iput-object p10, p0, Lcom/chuanyi/voyage/ui/aichat/lll;->II:Ljava/util/List;

    .line 23
    .line 24
    iput-boolean p11, p0, Lcom/chuanyi/voyage/ui/aichat/lll;->IO:Z

    .line 25
    .line 26
    iput-object p12, p0, Lcom/chuanyi/voyage/ui/aichat/lll;->Io:Lkc10;

    .line 27
    .line 28
    iput-object p13, p0, Lcom/chuanyi/voyage/ui/aichat/lll;->Ol:Ljava/lang/String;

    .line 29
    .line 30
    iput-object p14, p0, Lcom/chuanyi/voyage/ui/aichat/lll;->Oo:Landroid/content/Context;

    .line 31
    .line 32
    iput-boolean p15, p0, Lcom/chuanyi/voyage/ui/aichat/lll;->ol:Z

    .line 33
    .line 34
    move-object/from16 p1, p16

    .line 35
    .line 36
    iput-object p1, p0, Lcom/chuanyi/voyage/ui/aichat/lll;->oI:Lkotlin/jvm/functions/Function0;

    .line 37
    .line 38
    move/from16 p1, p17

    .line 39
    .line 40
    iput-boolean p1, p0, Lcom/chuanyi/voyage/ui/aichat/lll;->oO:Z

    .line 41
    .line 42
    move-object/from16 p1, p18

    .line 43
    .line 44
    iput-object p1, p0, Lcom/chuanyi/voyage/ui/aichat/lll;->oo:Lkc10;

    .line 45
    .line 46
    move-object/from16 p1, p19

    .line 47
    .line 48
    iput-object p1, p0, Lcom/chuanyi/voyage/ui/aichat/lll;->f:Ljava/lang/String;

    .line 49
    .line 50
    move-object/from16 p1, p20

    .line 51
    .line 52
    iput-object p1, p0, Lcom/chuanyi/voyage/ui/aichat/lll;->g:Lubg0;

    .line 53
    .line 54
    move-object/from16 p1, p21

    .line 55
    .line 56
    iput-object p1, p0, Lcom/chuanyi/voyage/ui/aichat/lll;->h:Lqoe;

    .line 57
    .line 58
    move-object/from16 p1, p22

    .line 59
    .line 60
    iput-object p1, p0, Lcom/chuanyi/voyage/ui/aichat/lll;->i:Lubg0;

    .line 61
    .line 62
    move-object/from16 p1, p23

    .line 63
    .line 64
    iput-object p1, p0, Lcom/chuanyi/voyage/ui/aichat/lll;->j:Lkc10;

    .line 65
    .line 66
    move-object/from16 p1, p24

    .line 67
    .line 68
    iput-object p1, p0, Lcom/chuanyi/voyage/ui/aichat/lll;->k:Lkc10;

    .line 69
    .line 70
    move-object/from16 p1, p25

    .line 71
    .line 72
    iput-object p1, p0, Lcom/chuanyi/voyage/ui/aichat/lll;->m:Lkc10;

    .line 73
    .line 74
    move-object/from16 p1, p26

    .line 75
    .line 76
    iput-object p1, p0, Lcom/chuanyi/voyage/ui/aichat/lll;->n:Lkc10;

    .line 77
    .line 78
    move-object/from16 p1, p27

    .line 79
    .line 80
    iput-object p1, p0, Lcom/chuanyi/voyage/ui/aichat/lll;->p:Lkc10;

    .line 81
    .line 82
    move-object/from16 p1, p28

    .line 83
    .line 84
    iput-object p1, p0, Lcom/chuanyi/voyage/ui/aichat/lll;->q:Lkc10;

    .line 85
    .line 86
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 77

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    sget-object v1, Ljac;->f:Leqd;

    .line 4
    .line 5
    sget-object v2, Ljac;->i:Leqd;

    .line 6
    .line 7
    sget-object v3, Ljac;->g:Leqd;

    .line 8
    .line 9
    sget-object v4, Ljac;->h:Leqd;

    .line 10
    .line 11
    move-object/from16 v5, p1

    .line 12
    .line 13
    check-cast v5, Lqxc;

    .line 14
    .line 15
    move-object/from16 v6, p2

    .line 16
    .line 17
    check-cast v6, Lkud;

    .line 18
    .line 19
    move-object/from16 v7, p3

    .line 20
    .line 21
    check-cast v7, Ljava/lang/Integer;

    .line 22
    .line 23
    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    .line 24
    .line 25
    .line 26
    move-result v7

    .line 27
    const-wide v8, -0x5176f4a0c56e39L

    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    const-wide v10, -0x51770ba0c56e39L    # -1.07211956638624E307

    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    invoke-static {v8, v9, v5, v10, v11}, LIO;->lll(JLqxc;J)V

    .line 38
    .line 39
    .line 40
    and-int/lit8 v5, v7, 0x11

    .line 41
    .line 42
    const/16 v8, 0x10

    .line 43
    .line 44
    const/4 v9, 0x0

    .line 45
    const/4 v10, 0x1

    .line 46
    if-eq v5, v8, :cond_0

    .line 47
    .line 48
    move v5, v10

    .line 49
    goto :goto_0

    .line 50
    :cond_0
    move v5, v9

    .line 51
    :goto_0
    and-int/2addr v7, v10

    .line 52
    move-object v13, v6

    .line 53
    check-cast v13, Ltgn;

    .line 54
    .line 55
    invoke-virtual {v13, v7, v5}, Ltgn;->Iol(IZ)Z

    .line 56
    .line 57
    .line 58
    move-result v5

    .line 59
    if-eqz v5, :cond_41

    .line 60
    .line 61
    iget-object v5, v0, Lcom/chuanyi/voyage/ui/aichat/lll;->l:Lkc10;

    .line 62
    .line 63
    invoke-interface {v5}, Lubg0;->getValue()Ljava/lang/Object;

    .line 64
    .line 65
    .line 66
    move-result-object v6

    .line 67
    check-cast v6, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 68
    .line 69
    invoke-virtual {v6}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->getName()Ljava/lang/String;

    .line 70
    .line 71
    .line 72
    move-result-object v11

    .line 73
    sget v6, Lzee0;->l:I

    .line 74
    .line 75
    invoke-static {v13}, Lzee0;->Io(Lkud;)Lvne;

    .line 76
    .line 77
    .line 78
    move-result-object v31

    .line 79
    sget-object v6, Lwgz;->l:Lwgz;

    .line 80
    .line 81
    const/high16 v7, 0x3f800000    # 1.0f

    .line 82
    .line 83
    invoke-static {v6, v7}, Lj2f0;->lO(Lzgz;F)Lzgz;

    .line 84
    .line 85
    .line 86
    move-result-object v8

    .line 87
    const-wide v14, -0x5178c7a0c56e39L

    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    invoke-static {v14, v15}, Li6t0;->lO(J)Ljava/lang/String;

    .line 93
    .line 94
    .line 95
    invoke-virtual {v13, v5}, Ltgn;->lO(Ljava/lang/Object;)Z

    .line 96
    .line 97
    .line 98
    move-result v12

    .line 99
    invoke-virtual {v13}, Ltgn;->IIo()Ljava/lang/Object;

    .line 100
    .line 101
    .line 102
    move-result-object v14

    .line 103
    sget-object v15, Lhud;->l:Ljac;

    .line 104
    .line 105
    if-nez v12, :cond_1

    .line 106
    .line 107
    if-ne v14, v15, :cond_2

    .line 108
    .line 109
    :cond_1
    new-instance v14, Lcom/chuanyi/voyage/ui/aichat/lO;

    .line 110
    .line 111
    invoke-direct {v14, v5, v9}, Lcom/chuanyi/voyage/ui/aichat/lO;-><init>(Lkc10;B)V

    .line 112
    .line 113
    .line 114
    invoke-virtual {v13, v14}, Ltgn;->oll(Ljava/lang/Object;)V

    .line 115
    .line 116
    .line 117
    :cond_2
    move-object v12, v14

    .line 118
    check-cast v12, Lkotlin/jvm/functions/Function1;

    .line 119
    .line 120
    sget-object v17, Lrfs0;->I:Lggd;

    .line 121
    .line 122
    new-instance v14, Lcom/chuanyi/voyage/ui/aichat/O;

    .line 123
    .line 124
    iget-object v10, v0, Lcom/chuanyi/voyage/ui/aichat/lll;->Oo:Landroid/content/Context;

    .line 125
    .line 126
    iget-object v9, v0, Lcom/chuanyi/voyage/ui/aichat/lll;->Ol:Ljava/lang/String;

    .line 127
    .line 128
    invoke-direct {v14, v10, v9, v5}, Lcom/chuanyi/voyage/ui/aichat/O;-><init>(Landroid/content/Context;Ljava/lang/String;Lkc10;)V

    .line 129
    .line 130
    .line 131
    const v7, 0x2f8fcc02

    .line 132
    .line 133
    .line 134
    invoke-static {v7, v14, v13}, Lbe9;->IlI(ILu6n;Lkud;)Lggd;

    .line 135
    .line 136
    .line 137
    move-result-object v18

    .line 138
    const/high16 v35, 0xc00000

    .line 139
    .line 140
    const v36, 0x5dff38

    .line 141
    .line 142
    .line 143
    const/4 v14, 0x0

    .line 144
    move-object v7, v15

    .line 145
    const/4 v15, 0x0

    .line 146
    const/16 v16, 0x0

    .line 147
    .line 148
    const/16 v19, 0x0

    .line 149
    .line 150
    const/16 v20, 0x0

    .line 151
    .line 152
    const/16 v21, 0x0

    .line 153
    .line 154
    const/16 v22, 0x0

    .line 155
    .line 156
    const/16 v23, 0x0

    .line 157
    .line 158
    const/16 v24, 0x0

    .line 159
    .line 160
    const/16 v25, 0x0

    .line 161
    .line 162
    const/16 v26, 0x0

    .line 163
    .line 164
    const/16 v27, 0x0

    .line 165
    .line 166
    const/16 v28, 0x1

    .line 167
    .line 168
    const/16 v29, 0x0

    .line 169
    .line 170
    const/16 v30, 0x0

    .line 171
    .line 172
    const/16 v32, 0x0

    .line 173
    .line 174
    const v34, 0xd80180

    .line 175
    .line 176
    .line 177
    move-object/from16 v33, v13

    .line 178
    .line 179
    move-object v13, v8

    .line 180
    invoke-static/range {v11 .. v36}, Lc2t0;->O(Ljava/lang/String;Lkotlin/jvm/functions/Function1;Lzgz;ZZLhaj0;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;ZLq6n0;Lxdt;Lodt;ZIILree0;Lc3j0;Lkud;III)V

    .line 181
    .line 182
    .line 183
    move-object/from16 v13, v33

    .line 184
    .line 185
    const v8, 0x7f1201bd

    .line 186
    .line 187
    .line 188
    invoke-static {v8, v13}, Lkz30;->loo(ILkud;)Ljava/lang/String;

    .line 189
    .line 190
    .line 191
    move-result-object v8

    .line 192
    sget-object v11, Lri1;->l:Lri1;

    .line 193
    .line 194
    invoke-interface {v5}, Lubg0;->getValue()Ljava/lang/Object;

    .line 195
    .line 196
    .line 197
    move-result-object v11

    .line 198
    check-cast v11, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 199
    .line 200
    invoke-virtual {v11}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->getType()Ldx1;

    .line 201
    .line 202
    .line 203
    move-result-object v11

    .line 204
    invoke-static {v11}, Lri1;->O(Ldx1;)Lf4r;

    .line 205
    .line 206
    .line 207
    move-result-object v16

    .line 208
    sget-object v17, Lri1;->oIl:Lf4r;

    .line 209
    .line 210
    const/high16 v11, 0x3f800000    # 1.0f

    .line 211
    .line 212
    invoke-static {v6, v11}, Lj2f0;->lO(Lzgz;F)Lzgz;

    .line 213
    .line 214
    .line 215
    move-result-object v34

    .line 216
    const-wide v11, -0x5178e8a0c56e39L

    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    invoke-static {v11, v12}, Li6t0;->lO(J)Ljava/lang/String;

    .line 222
    .line 223
    .line 224
    iget-object v11, v0, Lcom/chuanyi/voyage/ui/aichat/lll;->I:Lkc10;

    .line 225
    .line 226
    invoke-virtual {v13, v11}, Ltgn;->lO(Ljava/lang/Object;)Z

    .line 227
    .line 228
    .line 229
    move-result v12

    .line 230
    invoke-virtual {v13}, Ltgn;->IIo()Ljava/lang/Object;

    .line 231
    .line 232
    .line 233
    move-result-object v14

    .line 234
    if-nez v12, :cond_3

    .line 235
    .line 236
    if-ne v14, v7, :cond_4

    .line 237
    .line 238
    :cond_3
    new-instance v14, Lyk0;

    .line 239
    .line 240
    const/16 v12, 0x1a

    .line 241
    .line 242
    invoke-direct {v14, v11, v12}, Lyk0;-><init>(Lkc10;B)V

    .line 243
    .line 244
    .line 245
    invoke-virtual {v13, v14}, Ltgn;->oll(Ljava/lang/Object;)V

    .line 246
    .line 247
    .line 248
    :cond_4
    move-object v11, v14

    .line 249
    check-cast v11, Lkotlin/jvm/functions/Function0;

    .line 250
    .line 251
    const/16 v38, 0x30

    .line 252
    .line 253
    const v39, 0x1fff8a

    .line 254
    .line 255
    .line 256
    const/4 v12, 0x0

    .line 257
    const/4 v14, 0x0

    .line 258
    iget-object v15, v0, Lcom/chuanyi/voyage/ui/aichat/lll;->O:Ljava/lang/String;

    .line 259
    .line 260
    const/16 v18, 0x0

    .line 261
    .line 262
    const/16 v19, 0x0

    .line 263
    .line 264
    const/16 v20, 0x0

    .line 265
    .line 266
    const-wide/16 v21, 0x0

    .line 267
    .line 268
    const-wide/16 v23, 0x0

    .line 269
    .line 270
    const/16 v25, 0x0

    .line 271
    .line 272
    const/16 v26, 0x0

    .line 273
    .line 274
    const/16 v27, 0x0

    .line 275
    .line 276
    const/16 v28, 0x0

    .line 277
    .line 278
    const/16 v29, 0x0

    .line 279
    .line 280
    const/16 v30, 0x0

    .line 281
    .line 282
    const/16 v31, 0x0

    .line 283
    .line 284
    const/16 v32, 0x0

    .line 285
    .line 286
    const/16 v33, 0x0

    .line 287
    .line 288
    const/16 v36, 0x0

    .line 289
    .line 290
    const/16 v37, 0x0

    .line 291
    .line 292
    move-object/from16 v35, v13

    .line 293
    .line 294
    move-object v13, v8

    .line 295
    invoke-static/range {v11 .. v39}, Lbhu0;->l(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Ljava/lang/String;ZLjava/lang/String;Lf4r;Lf4r;FLree0;Lree0;JJZZLhaj0;Lhaj0;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;ZLkotlin/jvm/functions/Function2;Lzgz;Lkud;IIII)V

    .line 296
    .line 297
    .line 298
    move-object v8, v15

    .line 299
    move-object/from16 v13, v35

    .line 300
    .line 301
    invoke-interface {v5}, Lubg0;->getValue()Ljava/lang/Object;

    .line 302
    .line 303
    .line 304
    move-result-object v11

    .line 305
    check-cast v11, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 306
    .line 307
    invoke-virtual {v11}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->getUrlInvalid()Z

    .line 308
    .line 309
    .line 310
    move-result v11

    .line 311
    iget-object v12, v0, Lcom/chuanyi/voyage/ui/aichat/lll;->Il:Lkc10;

    .line 312
    .line 313
    if-nez v11, :cond_6

    .line 314
    .line 315
    invoke-interface {v12}, Lubg0;->getValue()Ljava/lang/Object;

    .line 316
    .line 317
    .line 318
    move-result-object v11

    .line 319
    check-cast v11, Ljava/lang/Boolean;

    .line 320
    .line 321
    invoke-virtual {v11}, Ljava/lang/Boolean;->booleanValue()Z

    .line 322
    .line 323
    .line 324
    move-result v11

    .line 325
    if-eqz v11, :cond_5

    .line 326
    .line 327
    invoke-interface {v5}, Lubg0;->getValue()Ljava/lang/Object;

    .line 328
    .line 329
    .line 330
    move-result-object v11

    .line 331
    check-cast v11, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 332
    .line 333
    invoke-virtual {v11}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->getUrlMissing()Z

    .line 334
    .line 335
    .line 336
    move-result v11

    .line 337
    if-eqz v11, :cond_5

    .line 338
    .line 339
    goto :goto_1

    .line 340
    :cond_5
    const/4 v11, 0x0

    .line 341
    goto :goto_2

    .line 342
    :cond_6
    :goto_1
    const/4 v11, 0x1

    .line 343
    :goto_2
    invoke-interface {v5}, Lubg0;->getValue()Ljava/lang/Object;

    .line 344
    .line 345
    .line 346
    move-result-object v14

    .line 347
    check-cast v14, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 348
    .line 349
    invoke-virtual {v14}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->getBaseUrl()Ljava/lang/String;

    .line 350
    .line 351
    .line 352
    move-result-object v14

    .line 353
    new-instance v15, Lxdt;

    .line 354
    .line 355
    const/16 v19, 0x6

    .line 356
    .line 357
    const/16 v20, 0x73

    .line 358
    .line 359
    const/16 v16, 0x0

    .line 360
    .line 361
    const/16 v17, 0x0

    .line 362
    .line 363
    const/16 v18, 0x5

    .line 364
    .line 365
    invoke-direct/range {v15 .. v20}, Lxdt;-><init>(ILjava/lang/Boolean;III)V

    .line 366
    .line 367
    .line 368
    invoke-static {v13}, Lzee0;->Io(Lkud;)Lvne;

    .line 369
    .line 370
    .line 371
    move-result-object v31

    .line 372
    move-object/from16 v16, v12

    .line 373
    .line 374
    const/high16 v12, 0x3f800000    # 1.0f

    .line 375
    .line 376
    invoke-static {v6, v12}, Lj2f0;->lO(Lzgz;F)Lzgz;

    .line 377
    .line 378
    .line 379
    move-result-object v17

    .line 380
    const-wide v18, -0x517909a0c56e39L

    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    invoke-static/range {v18 .. v19}, Li6t0;->lO(J)Ljava/lang/String;

    .line 386
    .line 387
    .line 388
    invoke-virtual {v13, v5}, Ltgn;->lO(Ljava/lang/Object;)Z

    .line 389
    .line 390
    .line 391
    move-result v12

    .line 392
    move/from16 v18, v12

    .line 393
    .line 394
    invoke-virtual {v13}, Ltgn;->IIo()Ljava/lang/Object;

    .line 395
    .line 396
    .line 397
    move-result-object v12

    .line 398
    move-object/from16 v19, v14

    .line 399
    .line 400
    const/4 v14, 0x2

    .line 401
    if-nez v18, :cond_7

    .line 402
    .line 403
    if-ne v12, v7, :cond_8

    .line 404
    .line 405
    :cond_7
    new-instance v12, Lcom/chuanyi/voyage/ui/aichat/lO;

    .line 406
    .line 407
    invoke-direct {v12, v5, v14}, Lcom/chuanyi/voyage/ui/aichat/lO;-><init>(Lkc10;B)V

    .line 408
    .line 409
    .line 410
    invoke-virtual {v13, v12}, Ltgn;->oll(Ljava/lang/Object;)V

    .line 411
    .line 412
    .line 413
    :cond_8
    check-cast v12, Lkotlin/jvm/functions/Function1;

    .line 414
    .line 415
    move-object/from16 v18, v17

    .line 416
    .line 417
    sget-object v17, Lrfs0;->O:Lggd;

    .line 418
    .line 419
    move-object/from16 v20, v12

    .line 420
    .line 421
    new-instance v12, Lcom/chuanyi/voyage/ui/aichat/l;

    .line 422
    .line 423
    invoke-direct {v12, v5, v14}, Lcom/chuanyi/voyage/ui/aichat/l;-><init>(Ljava/lang/Object;B)V

    .line 424
    .line 425
    .line 426
    const v14, -0x392d1d5

    .line 427
    .line 428
    .line 429
    invoke-static {v14, v12, v13}, Lbe9;->IlI(ILu6n;Lkud;)Lggd;

    .line 430
    .line 431
    .line 432
    move-result-object v12

    .line 433
    move-object/from16 v14, v19

    .line 434
    .line 435
    sget-object v19, Lrfs0;->o:Lggd;

    .line 436
    .line 437
    move-object/from16 v21, v12

    .line 438
    .line 439
    new-instance v12, Lcom/chuanyi/voyage/ui/aichat/IO;

    .line 440
    .line 441
    move-object/from16 v22, v14

    .line 442
    .line 443
    iget-object v14, v0, Lcom/chuanyi/voyage/ui/aichat/lll;->f:Ljava/lang/String;

    .line 444
    .line 445
    invoke-direct {v12, v11, v14, v5}, Lcom/chuanyi/voyage/ui/aichat/IO;-><init>(ZLjava/lang/String;Lkc10;)V

    .line 446
    .line 447
    .line 448
    const v14, 0x613accfd

    .line 449
    .line 450
    .line 451
    invoke-static {v14, v12, v13}, Lbe9;->IlI(ILu6n;Lkud;)Lggd;

    .line 452
    .line 453
    .line 454
    move-result-object v23

    .line 455
    const v35, 0xc30180

    .line 456
    .line 457
    .line 458
    const v36, 0x5d4e38

    .line 459
    .line 460
    .line 461
    const/4 v14, 0x0

    .line 462
    move-object/from16 v26, v15

    .line 463
    .line 464
    const/4 v15, 0x0

    .line 465
    move-object/from16 v12, v16

    .line 466
    .line 467
    const/16 v16, 0x0

    .line 468
    .line 469
    move-object/from16 v24, v12

    .line 470
    .line 471
    move-object/from16 v12, v20

    .line 472
    .line 473
    const/16 v20, 0x0

    .line 474
    .line 475
    move-object/from16 v33, v13

    .line 476
    .line 477
    move-object/from16 v13, v18

    .line 478
    .line 479
    move-object/from16 v18, v21

    .line 480
    .line 481
    const/16 v21, 0x0

    .line 482
    .line 483
    move-object/from16 v25, v24

    .line 484
    .line 485
    move/from16 v24, v11

    .line 486
    .line 487
    move-object/from16 v11, v22

    .line 488
    .line 489
    const/16 v22, 0x0

    .line 490
    .line 491
    move-object/from16 v27, v25

    .line 492
    .line 493
    const/16 v25, 0x0

    .line 494
    .line 495
    move-object/from16 v28, v27

    .line 496
    .line 497
    const/16 v27, 0x0

    .line 498
    .line 499
    move-object/from16 v29, v28

    .line 500
    .line 501
    const/16 v28, 0x1

    .line 502
    .line 503
    move-object/from16 v30, v29

    .line 504
    .line 505
    const/16 v29, 0x0

    .line 506
    .line 507
    move-object/from16 v32, v30

    .line 508
    .line 509
    const/16 v30, 0x0

    .line 510
    .line 511
    move-object/from16 v34, v32

    .line 512
    .line 513
    const/16 v32, 0x0

    .line 514
    .line 515
    move-object/from16 v37, v34

    .line 516
    .line 517
    const v34, 0x6d80180

    .line 518
    .line 519
    .line 520
    move-object/from16 v38, v37

    .line 521
    .line 522
    invoke-static/range {v11 .. v36}, Lc2t0;->O(Ljava/lang/String;Lkotlin/jvm/functions/Function1;Lzgz;ZZLhaj0;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;ZLq6n0;Lxdt;Lodt;ZIILree0;Lc3j0;Lkud;III)V

    .line 523
    .line 524
    .line 525
    move-object/from16 v13, v33

    .line 526
    .line 527
    invoke-interface/range {v38 .. v38}, Lubg0;->getValue()Ljava/lang/Object;

    .line 528
    .line 529
    .line 530
    move-result-object v11

    .line 531
    check-cast v11, Ljava/lang/Boolean;

    .line 532
    .line 533
    invoke-virtual {v11}, Ljava/lang/Boolean;->booleanValue()Z

    .line 534
    .line 535
    .line 536
    move-result v11

    .line 537
    if-eqz v11, :cond_9

    .line 538
    .line 539
    invoke-interface {v5}, Lubg0;->getValue()Ljava/lang/Object;

    .line 540
    .line 541
    .line 542
    move-result-object v11

    .line 543
    check-cast v11, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 544
    .line 545
    invoke-virtual {v11}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->getKeyMissing()Z

    .line 546
    .line 547
    .line 548
    move-result v11

    .line 549
    if-eqz v11, :cond_9

    .line 550
    .line 551
    const/4 v14, 0x1

    .line 552
    goto :goto_3

    .line 553
    :cond_9
    const/4 v14, 0x0

    .line 554
    :goto_3
    invoke-interface {v5}, Lubg0;->getValue()Ljava/lang/Object;

    .line 555
    .line 556
    .line 557
    move-result-object v11

    .line 558
    check-cast v11, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 559
    .line 560
    invoke-virtual {v11}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->getKey()Ljava/lang/String;

    .line 561
    .line 562
    .line 563
    move-result-object v11

    .line 564
    const-wide v15, -0x51792aa0c56e39L

    .line 565
    .line 566
    .line 567
    .line 568
    .line 569
    invoke-static/range {v15 .. v16}, Li6t0;->lO(J)Ljava/lang/String;

    .line 570
    .line 571
    .line 572
    invoke-virtual {v13, v5}, Ltgn;->lO(Ljava/lang/Object;)Z

    .line 573
    .line 574
    .line 575
    move-result v12

    .line 576
    invoke-virtual {v13}, Ltgn;->IIo()Ljava/lang/Object;

    .line 577
    .line 578
    .line 579
    move-result-object v15

    .line 580
    move-object/from16 v16, v11

    .line 581
    .line 582
    const/4 v11, 0x3

    .line 583
    if-nez v12, :cond_a

    .line 584
    .line 585
    if-ne v15, v7, :cond_b

    .line 586
    .line 587
    :cond_a
    new-instance v15, Lcom/chuanyi/voyage/ui/aichat/lO;

    .line 588
    .line 589
    invoke-direct {v15, v5, v11}, Lcom/chuanyi/voyage/ui/aichat/lO;-><init>(Lkc10;B)V

    .line 590
    .line 591
    .line 592
    invoke-virtual {v13, v15}, Ltgn;->oll(Ljava/lang/Object;)V

    .line 593
    .line 594
    .line 595
    :cond_b
    move-object v12, v15

    .line 596
    check-cast v12, Lkotlin/jvm/functions/Function1;

    .line 597
    .line 598
    invoke-interface {v5}, Lubg0;->getValue()Ljava/lang/Object;

    .line 599
    .line 600
    .line 601
    move-result-object v15

    .line 602
    check-cast v15, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 603
    .line 604
    invoke-virtual {v15}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->getType()Ldx1;

    .line 605
    .line 606
    .line 607
    move-result-object v15

    .line 608
    iget-boolean v15, v15, Ldx1;->O:Z

    .line 609
    .line 610
    if-eqz v15, :cond_c

    .line 611
    .line 612
    const v15, 0x7f120093

    .line 613
    .line 614
    .line 615
    goto :goto_4

    .line 616
    :cond_c
    const v15, 0x7f120092

    .line 617
    .line 618
    .line 619
    :goto_4
    invoke-static {v15, v13}, Lkz30;->loo(ILkud;)Ljava/lang/String;

    .line 620
    .line 621
    .line 622
    move-result-object v15

    .line 623
    if-eqz v14, :cond_d

    .line 624
    .line 625
    const v11, -0x340474c1    # -3.2970366E7f

    .line 626
    .line 627
    .line 628
    invoke-virtual {v13, v11}, Ltgn;->OIO(I)V

    .line 629
    .line 630
    .line 631
    move-object/from16 v19, v12

    .line 632
    .line 633
    const-wide v11, -0x51794ba0c56e39L

    .line 634
    .line 635
    .line 636
    .line 637
    .line 638
    move/from16 v20, v14

    .line 639
    .line 640
    const v14, 0x7f120209

    .line 641
    .line 642
    .line 643
    move-object/from16 v21, v15

    .line 644
    .line 645
    const/4 v15, 0x0

    .line 646
    invoke-static {v14, v11, v12, v13, v15}, Lfm7;->Il(IJLtgn;Z)Ljava/lang/String;

    .line 647
    .line 648
    .line 649
    move-result-object v11

    .line 650
    move-object v15, v11

    .line 651
    goto :goto_5

    .line 652
    :cond_d
    move-object/from16 v19, v12

    .line 653
    .line 654
    move/from16 v20, v14

    .line 655
    .line 656
    move-object/from16 v21, v15

    .line 657
    .line 658
    const/4 v15, 0x0

    .line 659
    const v11, -0x4c89847e

    .line 660
    .line 661
    .line 662
    invoke-virtual {v13, v11}, Ltgn;->OIO(I)V

    .line 663
    .line 664
    .line 665
    invoke-virtual {v13, v15}, Ltgn;->oI(Z)V

    .line 666
    .line 667
    .line 668
    const/4 v15, 0x0

    .line 669
    :goto_5
    const-wide v11, -0x517958a0c56e39L

    .line 670
    .line 671
    .line 672
    .line 673
    .line 674
    invoke-static {v11, v12}, Li6t0;->lO(J)Ljava/lang/String;

    .line 675
    .line 676
    .line 677
    iget-object v11, v0, Lcom/chuanyi/voyage/ui/aichat/lll;->o:Lza1;

    .line 678
    .line 679
    invoke-virtual {v13, v11}, Ltgn;->Il(Ljava/lang/Object;)Z

    .line 680
    .line 681
    .line 682
    move-result v12

    .line 683
    invoke-virtual {v13}, Ltgn;->IIo()Ljava/lang/Object;

    .line 684
    .line 685
    .line 686
    move-result-object v14

    .line 687
    if-nez v12, :cond_e

    .line 688
    .line 689
    if-ne v14, v7, :cond_f

    .line 690
    .line 691
    :cond_e
    new-instance v14, Li71;

    .line 692
    .line 693
    const/4 v12, 0x3

    .line 694
    invoke-direct {v14, v11, v12}, Li71;-><init>(Lza1;B)V

    .line 695
    .line 696
    .line 697
    invoke-virtual {v13, v14}, Ltgn;->oll(Ljava/lang/Object;)V

    .line 698
    .line 699
    .line 700
    :cond_f
    check-cast v14, Lkotlin/jvm/functions/Function1;

    .line 701
    .line 702
    const/16 v17, 0x0

    .line 703
    .line 704
    move-object/from16 v12, v19

    .line 705
    .line 706
    const/16 v19, 0x0

    .line 707
    .line 708
    move-object/from16 v42, v10

    .line 709
    .line 710
    move-object v10, v11

    .line 711
    move-object/from16 v18, v13

    .line 712
    .line 713
    move-object/from16 v11, v16

    .line 714
    .line 715
    move-object/from16 v13, v21

    .line 716
    .line 717
    move-object/from16 v16, v14

    .line 718
    .line 719
    move/from16 v14, v20

    .line 720
    .line 721
    invoke-static/range {v11 .. v19}, Lrn1;->l(Ljava/lang/String;Lkotlin/jvm/functions/Function1;Ljava/lang/String;ZLjava/lang/String;Lkotlin/jvm/functions/Function1;Lzgz;Lkud;I)V

    .line 722
    .line 723
    .line 724
    move-object/from16 v13, v18

    .line 725
    .line 726
    iget-boolean v11, v0, Lcom/chuanyi/voyage/ui/aichat/lll;->ll:Z

    .line 727
    .line 728
    if-eqz v11, :cond_12

    .line 729
    .line 730
    iget-object v11, v0, Lcom/chuanyi/voyage/ui/aichat/lll;->lI:Llw1;

    .line 731
    .line 732
    iget-object v12, v11, Llw1;->o:Lu770;

    .line 733
    .line 734
    invoke-virtual {v12}, Lu770;->I()Z

    .line 735
    .line 736
    .line 737
    move-result v12

    .line 738
    if-nez v12, :cond_12

    .line 739
    .line 740
    const v12, -0x4c86f3eb

    .line 741
    .line 742
    .line 743
    invoke-virtual {v13, v12}, Ltgn;->OIO(I)V

    .line 744
    .line 745
    .line 746
    const-wide v14, -0x517979a0c56e39L

    .line 747
    .line 748
    .line 749
    .line 750
    .line 751
    invoke-static {v14, v15}, Li6t0;->lO(J)Ljava/lang/String;

    .line 752
    .line 753
    .line 754
    const v12, 0x7f12015d

    .line 755
    .line 756
    .line 757
    invoke-static {v12, v13}, Lkz30;->loo(ILkud;)Ljava/lang/String;

    .line 758
    .line 759
    .line 760
    move-result-object v12

    .line 761
    iget-object v11, v11, Llw1;->o:Lu770;

    .line 762
    .line 763
    const-wide v14, -0x5179a1a0c56e39L

    .line 764
    .line 765
    .line 766
    .line 767
    .line 768
    invoke-static {v14, v15}, Li6t0;->lO(J)Ljava/lang/String;

    .line 769
    .line 770
    .line 771
    invoke-virtual {v13, v11}, Ltgn;->lO(Ljava/lang/Object;)Z

    .line 772
    .line 773
    .line 774
    move-result v14

    .line 775
    invoke-virtual {v13}, Ltgn;->IIo()Ljava/lang/Object;

    .line 776
    .line 777
    .line 778
    move-result-object v15

    .line 779
    if-nez v14, :cond_10

    .line 780
    .line 781
    if-ne v15, v7, :cond_11

    .line 782
    .line 783
    :cond_10
    new-instance v14, Lvg1;

    .line 784
    .line 785
    const-wide v15, -0x513001a0c56e39L

    .line 786
    .line 787
    .line 788
    .line 789
    .line 790
    invoke-static/range {v15 .. v16}, Li6t0;->lO(J)Ljava/lang/String;

    .line 791
    .line 792
    .line 793
    move-result-object v18

    .line 794
    const-wide v15, -0x513017a0c56e39L

    .line 795
    .line 796
    .line 797
    .line 798
    .line 799
    invoke-static/range {v15 .. v16}, Li6t0;->lO(J)Ljava/lang/String;

    .line 800
    .line 801
    .line 802
    move-result-object v19

    .line 803
    const/16 v20, 0x0

    .line 804
    .line 805
    const/16 v21, 0x1

    .line 806
    .line 807
    const/4 v15, 0x0

    .line 808
    const-class v17, Lu770;

    .line 809
    .line 810
    move-object/from16 v16, v11

    .line 811
    .line 812
    invoke-direct/range {v14 .. v21}, Lvg1;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;IB)V

    .line 813
    .line 814
    .line 815
    invoke-virtual {v13, v14}, Ltgn;->oll(Ljava/lang/Object;)V

    .line 816
    .line 817
    .line 818
    move-object v15, v14

    .line 819
    :cond_11
    check-cast v15, Lkotlin/reflect/KFunction;

    .line 820
    .line 821
    check-cast v15, Lkotlin/jvm/functions/Function0;

    .line 822
    .line 823
    const/4 v11, 0x0

    .line 824
    invoke-static {v12, v15, v13, v11}, Lcom/chuanyi/voyage/ui/aichat/Ill;->Io(Ljava/lang/String;Lkotlin/jvm/functions/Function0;Lkud;I)V

    .line 825
    .line 826
    .line 827
    invoke-virtual {v13, v11}, Ltgn;->oI(Z)V

    .line 828
    .line 829
    .line 830
    goto :goto_6

    .line 831
    :cond_12
    const/4 v11, 0x0

    .line 832
    const v12, -0x4c84cfd9

    .line 833
    .line 834
    .line 835
    invoke-virtual {v13, v12}, Ltgn;->OIO(I)V

    .line 836
    .line 837
    .line 838
    invoke-virtual {v13, v11}, Ltgn;->oI(Z)V

    .line 839
    .line 840
    .line 841
    :goto_6
    const v11, 0x7f120115

    .line 842
    .line 843
    .line 844
    invoke-static {v11, v13}, Lkz30;->loo(ILkud;)Ljava/lang/String;

    .line 845
    .line 846
    .line 847
    move-result-object v12

    .line 848
    invoke-interface {v5}, Lubg0;->getValue()Ljava/lang/Object;

    .line 849
    .line 850
    .line 851
    move-result-object v11

    .line 852
    check-cast v11, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 853
    .line 854
    invoke-virtual {v11}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->getEnabled()Z

    .line 855
    .line 856
    .line 857
    move-result v16

    .line 858
    sget-object v22, Lri1;->IlI:Lf4r;

    .line 859
    .line 860
    invoke-interface {v5}, Lubg0;->getValue()Ljava/lang/Object;

    .line 861
    .line 862
    .line 863
    move-result-object v11

    .line 864
    check-cast v11, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 865
    .line 866
    invoke-virtual {v11}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->getType()Ldx1;

    .line 867
    .line 868
    .line 869
    move-result-object v11

    .line 870
    sget-object v14, Ldx1;->ll:Ldx1;

    .line 871
    .line 872
    if-ne v11, v14, :cond_13

    .line 873
    .line 874
    const v11, -0x34042b02    # -3.3008124E7f

    .line 875
    .line 876
    .line 877
    invoke-virtual {v13, v11}, Ltgn;->OIO(I)V

    .line 878
    .line 879
    .line 880
    const-wide v17, -0x5179c2a0c56e39L

    .line 881
    .line 882
    .line 883
    .line 884
    .line 885
    invoke-static/range {v17 .. v18}, Li6t0;->lO(J)Ljava/lang/String;

    .line 886
    .line 887
    .line 888
    invoke-static {v13}, Lzee0;->ol(Lkud;)Lvne;

    .line 889
    .line 890
    .line 891
    move-result-object v11

    .line 892
    const/4 v15, 0x0

    .line 893
    :goto_7
    invoke-virtual {v13, v15}, Ltgn;->oI(Z)V

    .line 894
    .line 895
    .line 896
    move-object/from16 v21, v11

    .line 897
    .line 898
    const/high16 v11, 0x3f800000    # 1.0f

    .line 899
    .line 900
    goto :goto_8

    .line 901
    :cond_13
    const/4 v15, 0x0

    .line 902
    const v11, -0x3404281e    # -3.3009604E7f

    .line 903
    .line 904
    .line 905
    invoke-virtual {v13, v11}, Ltgn;->OIO(I)V

    .line 906
    .line 907
    .line 908
    const-wide v17, -0x5179cea0c56e39L

    .line 909
    .line 910
    .line 911
    .line 912
    .line 913
    invoke-static/range {v17 .. v18}, Li6t0;->lO(J)Ljava/lang/String;

    .line 914
    .line 915
    .line 916
    invoke-static {v13}, Lzee0;->lO(Lkud;)Lvne;

    .line 917
    .line 918
    .line 919
    move-result-object v11

    .line 920
    goto :goto_7

    .line 921
    :goto_8
    invoke-static {v6, v11}, Lj2f0;->lO(Lzgz;F)Lzgz;

    .line 922
    .line 923
    .line 924
    move-result-object v15

    .line 925
    const-wide v17, -0x5179daa0c56e39L

    .line 926
    .line 927
    .line 928
    .line 929
    .line 930
    invoke-static/range {v17 .. v18}, Li6t0;->lO(J)Ljava/lang/String;

    .line 931
    .line 932
    .line 933
    invoke-virtual {v13, v5}, Ltgn;->lO(Ljava/lang/Object;)Z

    .line 934
    .line 935
    .line 936
    move-result v11

    .line 937
    move/from16 v17, v11

    .line 938
    .line 939
    invoke-virtual {v13}, Ltgn;->IIo()Ljava/lang/Object;

    .line 940
    .line 941
    .line 942
    move-result-object v11

    .line 943
    move-object/from16 v18, v14

    .line 944
    .line 945
    const/4 v14, 0x4

    .line 946
    if-nez v17, :cond_14

    .line 947
    .line 948
    if-ne v11, v7, :cond_15

    .line 949
    .line 950
    :cond_14
    new-instance v11, Lcom/chuanyi/voyage/ui/aichat/lO;

    .line 951
    .line 952
    invoke-direct {v11, v5, v14}, Lcom/chuanyi/voyage/ui/aichat/lO;-><init>(Lkc10;B)V

    .line 953
    .line 954
    .line 955
    invoke-virtual {v13, v11}, Ltgn;->oll(Ljava/lang/Object;)V

    .line 956
    .line 957
    .line 958
    :cond_15
    move-object/from16 v23, v11

    .line 959
    .line 960
    check-cast v23, Lkotlin/jvm/functions/Function1;

    .line 961
    .line 962
    const/16 v31, 0x0

    .line 963
    .line 964
    const v32, 0x3e3dc

    .line 965
    .line 966
    .line 967
    move-object/from16 v33, v13

    .line 968
    .line 969
    const/4 v13, 0x0

    .line 970
    move v11, v14

    .line 971
    const/4 v14, 0x0

    .line 972
    move/from16 v17, v11

    .line 973
    .line 974
    move-object v11, v15

    .line 975
    const/4 v15, 0x0

    .line 976
    move/from16 v20, v17

    .line 977
    .line 978
    move-object/from16 v19, v18

    .line 979
    .line 980
    const-wide/16 v17, 0x0

    .line 981
    .line 982
    move-object/from16 v24, v19

    .line 983
    .line 984
    const/16 v19, 0x0

    .line 985
    .line 986
    move/from16 v25, v20

    .line 987
    .line 988
    const/16 v20, 0x0

    .line 989
    .line 990
    move-object/from16 v26, v24

    .line 991
    .line 992
    const/16 v24, 0x0

    .line 993
    .line 994
    move/from16 v27, v25

    .line 995
    .line 996
    const/16 v25, 0x0

    .line 997
    .line 998
    move-object/from16 v28, v26

    .line 999
    .line 1000
    const/16 v26, 0x0

    .line 1001
    .line 1002
    move/from16 v29, v27

    .line 1003
    .line 1004
    const/16 v27, 0x0

    .line 1005
    .line 1006
    move-object/from16 v30, v28

    .line 1007
    .line 1008
    const/16 v28, 0x0

    .line 1009
    .line 1010
    move-object/from16 v34, v30

    .line 1011
    .line 1012
    const/16 v30, 0x6

    .line 1013
    .line 1014
    move-object/from16 v44, v9

    .line 1015
    .line 1016
    move-object/from16 v29, v33

    .line 1017
    .line 1018
    move-object/from16 v9, v34

    .line 1019
    .line 1020
    invoke-static/range {v11 .. v32}, Ld6v0;->O(Lzgz;Ljava/lang/String;ZLjava/lang/String;FZJLkotlin/jvm/functions/Function0;ZLree0;Lf4r;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function2;ZLzgz;Lkotlin/jvm/functions/Function2;Lhaj0;Lkud;III)V

    .line 1021
    .line 1022
    .line 1023
    move-object/from16 v13, v29

    .line 1024
    .line 1025
    invoke-interface {v5}, Lubg0;->getValue()Ljava/lang/Object;

    .line 1026
    .line 1027
    .line 1028
    move-result-object v11

    .line 1029
    check-cast v11, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 1030
    .line 1031
    invoke-virtual {v11}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->getType()Ldx1;

    .line 1032
    .line 1033
    .line 1034
    move-result-object v11

    .line 1035
    if-ne v11, v9, :cond_18

    .line 1036
    .line 1037
    const v9, -0x4c7dbc2a

    .line 1038
    .line 1039
    .line 1040
    invoke-virtual {v13, v9}, Ltgn;->OIO(I)V

    .line 1041
    .line 1042
    .line 1043
    const-wide v14, -0x5179fba0c56e39L

    .line 1044
    .line 1045
    .line 1046
    .line 1047
    .line 1048
    invoke-static {v14, v15}, Li6t0;->lO(J)Ljava/lang/String;

    .line 1049
    .line 1050
    .line 1051
    const v9, 0x7f12020c

    .line 1052
    .line 1053
    .line 1054
    invoke-static {v9, v13}, Lkz30;->loo(ILkud;)Ljava/lang/String;

    .line 1055
    .line 1056
    .line 1057
    move-result-object v9

    .line 1058
    const v11, 0x7f12020d

    .line 1059
    .line 1060
    .line 1061
    invoke-static {v11, v13}, Lkz30;->loo(ILkud;)Ljava/lang/String;

    .line 1062
    .line 1063
    .line 1064
    move-result-object v14

    .line 1065
    invoke-interface {v5}, Lubg0;->getValue()Ljava/lang/Object;

    .line 1066
    .line 1067
    .line 1068
    move-result-object v11

    .line 1069
    check-cast v11, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 1070
    .line 1071
    invoke-virtual {v11}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->getResponses()Z

    .line 1072
    .line 1073
    .line 1074
    move-result v16

    .line 1075
    sget-object v22, Lri1;->lll:Lf4r;

    .line 1076
    .line 1077
    invoke-static {v13}, Lzee0;->o(Lkud;)Lvne;

    .line 1078
    .line 1079
    .line 1080
    move-result-object v21

    .line 1081
    const/high16 v11, 0x3f800000    # 1.0f

    .line 1082
    .line 1083
    invoke-static {v6, v11}, Lj2f0;->lO(Lzgz;F)Lzgz;

    .line 1084
    .line 1085
    .line 1086
    move-result-object v15

    .line 1087
    const-wide v17, -0x517a3ca0c56e39L

    .line 1088
    .line 1089
    .line 1090
    .line 1091
    .line 1092
    invoke-static/range {v17 .. v18}, Li6t0;->lO(J)Ljava/lang/String;

    .line 1093
    .line 1094
    .line 1095
    invoke-virtual {v13, v5}, Ltgn;->lO(Ljava/lang/Object;)Z

    .line 1096
    .line 1097
    .line 1098
    move-result v11

    .line 1099
    invoke-virtual {v13}, Ltgn;->IIo()Ljava/lang/Object;

    .line 1100
    .line 1101
    .line 1102
    move-result-object v12

    .line 1103
    if-nez v11, :cond_17

    .line 1104
    .line 1105
    if-ne v12, v7, :cond_16

    .line 1106
    .line 1107
    goto :goto_9

    .line 1108
    :cond_16
    const/4 v11, 0x5

    .line 1109
    goto :goto_a

    .line 1110
    :cond_17
    :goto_9
    new-instance v12, Lcom/chuanyi/voyage/ui/aichat/lO;

    .line 1111
    .line 1112
    const/4 v11, 0x5

    .line 1113
    invoke-direct {v12, v5, v11}, Lcom/chuanyi/voyage/ui/aichat/lO;-><init>(Lkc10;B)V

    .line 1114
    .line 1115
    .line 1116
    invoke-virtual {v13, v12}, Ltgn;->oll(Ljava/lang/Object;)V

    .line 1117
    .line 1118
    .line 1119
    :goto_a
    move-object/from16 v23, v12

    .line 1120
    .line 1121
    check-cast v23, Lkotlin/jvm/functions/Function1;

    .line 1122
    .line 1123
    const/16 v31, 0x0

    .line 1124
    .line 1125
    const v32, 0x3e3d4

    .line 1126
    .line 1127
    .line 1128
    move-object/from16 v33, v13

    .line 1129
    .line 1130
    const/4 v13, 0x0

    .line 1131
    move/from16 v17, v11

    .line 1132
    .line 1133
    move-object v11, v15

    .line 1134
    const/4 v15, 0x0

    .line 1135
    move/from16 v12, v17

    .line 1136
    .line 1137
    const-wide/16 v17, 0x0

    .line 1138
    .line 1139
    const/16 v19, 0x0

    .line 1140
    .line 1141
    const/16 v20, 0x0

    .line 1142
    .line 1143
    const/16 v24, 0x0

    .line 1144
    .line 1145
    const/16 v25, 0x0

    .line 1146
    .line 1147
    const/16 v26, 0x0

    .line 1148
    .line 1149
    const/16 v27, 0x0

    .line 1150
    .line 1151
    const/16 v28, 0x0

    .line 1152
    .line 1153
    const/16 v30, 0x6

    .line 1154
    .line 1155
    move/from16 v29, v12

    .line 1156
    .line 1157
    move-object v12, v9

    .line 1158
    move/from16 v9, v29

    .line 1159
    .line 1160
    move-object/from16 v29, v33

    .line 1161
    .line 1162
    invoke-static/range {v11 .. v32}, Ld6v0;->O(Lzgz;Ljava/lang/String;ZLjava/lang/String;FZJLkotlin/jvm/functions/Function0;ZLree0;Lf4r;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function2;ZLzgz;Lkotlin/jvm/functions/Function2;Lhaj0;Lkud;III)V

    .line 1163
    .line 1164
    .line 1165
    move-object/from16 v13, v29

    .line 1166
    .line 1167
    const/4 v15, 0x0

    .line 1168
    invoke-virtual {v13, v15}, Ltgn;->oI(Z)V

    .line 1169
    .line 1170
    .line 1171
    goto :goto_b

    .line 1172
    :cond_18
    const/4 v9, 0x5

    .line 1173
    const/4 v15, 0x0

    .line 1174
    const v11, -0x4c773bf9

    .line 1175
    .line 1176
    .line 1177
    invoke-virtual {v13, v11}, Ltgn;->OIO(I)V

    .line 1178
    .line 1179
    .line 1180
    invoke-virtual {v13, v15}, Ltgn;->oI(Z)V

    .line 1181
    .line 1182
    .line 1183
    :goto_b
    invoke-interface {v5}, Lubg0;->getValue()Ljava/lang/Object;

    .line 1184
    .line 1185
    .line 1186
    move-result-object v11

    .line 1187
    check-cast v11, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 1188
    .line 1189
    invoke-virtual {v11}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->getHeaders()Ljava/lang/String;

    .line 1190
    .line 1191
    .line 1192
    move-result-object v11

    .line 1193
    invoke-static {v13}, Ljac;->Il(Lkud;)Ldal0;

    .line 1194
    .line 1195
    .line 1196
    move-result-object v12

    .line 1197
    iget-object v12, v12, Ldal0;->IO:Lhaj0;

    .line 1198
    .line 1199
    const/16 v68, 0x0

    .line 1200
    .line 1201
    const v69, 0xffffdf

    .line 1202
    .line 1203
    .line 1204
    const-wide/16 v46, 0x0

    .line 1205
    .line 1206
    const-wide/16 v48, 0x0

    .line 1207
    .line 1208
    const/16 v50, 0x0

    .line 1209
    .line 1210
    const/16 v51, 0x0

    .line 1211
    .line 1212
    sget-object v52, Lgmm;->o:Llnn;

    .line 1213
    .line 1214
    const/16 v53, 0x0

    .line 1215
    .line 1216
    const-wide/16 v54, 0x0

    .line 1217
    .line 1218
    const-wide/16 v56, 0x0

    .line 1219
    .line 1220
    const/16 v58, 0x0

    .line 1221
    .line 1222
    const/16 v59, 0x0

    .line 1223
    .line 1224
    const/16 v60, 0x0

    .line 1225
    .line 1226
    const/16 v61, 0x0

    .line 1227
    .line 1228
    const-wide/16 v62, 0x0

    .line 1229
    .line 1230
    const/16 v64, 0x0

    .line 1231
    .line 1232
    const/16 v65, 0x0

    .line 1233
    .line 1234
    const/16 v66, 0x0

    .line 1235
    .line 1236
    const/16 v67, 0x0

    .line 1237
    .line 1238
    move-object/from16 v45, v12

    .line 1239
    .line 1240
    invoke-static/range {v45 .. v69}, Lhaj0;->l(Lhaj0;JJLdom;Lunm;Lgmm;Ljava/lang/String;JJLk2j0;Lhee0;Lj1j;IJLz6j0;Lgx70;Lb4v;ILf8j0;I)Lhaj0;

    .line 1241
    .line 1242
    .line 1243
    move-result-object v16

    .line 1244
    invoke-static {v13}, Lzee0;->Io(Lkud;)Lvne;

    .line 1245
    .line 1246
    .line 1247
    move-result-object v31

    .line 1248
    const/high16 v12, 0x3f800000    # 1.0f

    .line 1249
    .line 1250
    invoke-static {v6, v12}, Lj2f0;->lO(Lzgz;F)Lzgz;

    .line 1251
    .line 1252
    .line 1253
    move-result-object v14

    .line 1254
    const-wide v17, -0x517a5da0c56e39L

    .line 1255
    .line 1256
    .line 1257
    .line 1258
    .line 1259
    invoke-static/range {v17 .. v18}, Li6t0;->lO(J)Ljava/lang/String;

    .line 1260
    .line 1261
    .line 1262
    invoke-virtual {v13, v5}, Ltgn;->lO(Ljava/lang/Object;)Z

    .line 1263
    .line 1264
    .line 1265
    move-result v12

    .line 1266
    invoke-virtual {v13}, Ltgn;->IIo()Ljava/lang/Object;

    .line 1267
    .line 1268
    .line 1269
    move-result-object v15

    .line 1270
    if-nez v12, :cond_19

    .line 1271
    .line 1272
    if-ne v15, v7, :cond_1a

    .line 1273
    .line 1274
    :cond_19
    new-instance v15, Lcom/chuanyi/voyage/ui/aichat/lO;

    .line 1275
    .line 1276
    const/4 v12, 0x1

    .line 1277
    invoke-direct {v15, v5, v12}, Lcom/chuanyi/voyage/ui/aichat/lO;-><init>(Lkc10;B)V

    .line 1278
    .line 1279
    .line 1280
    invoke-virtual {v13, v15}, Ltgn;->oll(Ljava/lang/Object;)V

    .line 1281
    .line 1282
    .line 1283
    :cond_1a
    move-object v12, v15

    .line 1284
    check-cast v12, Lkotlin/jvm/functions/Function1;

    .line 1285
    .line 1286
    sget-object v17, Lrfs0;->ll:Lggd;

    .line 1287
    .line 1288
    sget-object v18, Lrfs0;->lI:Lggd;

    .line 1289
    .line 1290
    sget-object v23, Lrfs0;->lO:Lggd;

    .line 1291
    .line 1292
    const v35, 0x36000180

    .line 1293
    .line 1294
    .line 1295
    const v36, 0x53ef18

    .line 1296
    .line 1297
    .line 1298
    move-object/from16 v33, v13

    .line 1299
    .line 1300
    move-object v13, v14

    .line 1301
    const/4 v14, 0x0

    .line 1302
    const/4 v15, 0x0

    .line 1303
    const/16 v19, 0x0

    .line 1304
    .line 1305
    const/16 v20, 0x0

    .line 1306
    .line 1307
    const/16 v21, 0x0

    .line 1308
    .line 1309
    const/16 v22, 0x0

    .line 1310
    .line 1311
    const/16 v24, 0x0

    .line 1312
    .line 1313
    const/16 v25, 0x0

    .line 1314
    .line 1315
    const/16 v26, 0x0

    .line 1316
    .line 1317
    const/16 v27, 0x0

    .line 1318
    .line 1319
    const/16 v28, 0x0

    .line 1320
    .line 1321
    const/16 v29, 0x6

    .line 1322
    .line 1323
    const/16 v30, 0x2

    .line 1324
    .line 1325
    const/16 v32, 0x0

    .line 1326
    .line 1327
    const v34, 0xd80180

    .line 1328
    .line 1329
    .line 1330
    invoke-static/range {v11 .. v36}, Lc2t0;->O(Ljava/lang/String;Lkotlin/jvm/functions/Function1;Lzgz;ZZLhaj0;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;ZLq6n0;Lxdt;Lodt;ZIILree0;Lc3j0;Lkud;III)V

    .line 1331
    .line 1332
    .line 1333
    move-object/from16 v13, v33

    .line 1334
    .line 1335
    iget-object v11, v0, Lcom/chuanyi/voyage/ui/aichat/lll;->lO:Lv41;

    .line 1336
    .line 1337
    iget-object v12, v0, Lcom/chuanyi/voyage/ui/aichat/lll;->lo:Ljava/lang/String;

    .line 1338
    .line 1339
    if-eqz v11, :cond_1d

    .line 1340
    .line 1341
    const v11, -0x4c6cac8e

    .line 1342
    .line 1343
    .line 1344
    invoke-virtual {v13, v11}, Ltgn;->OIO(I)V

    .line 1345
    .line 1346
    .line 1347
    const-wide v14, -0x517a7ea0c56e39L

    .line 1348
    .line 1349
    .line 1350
    .line 1351
    .line 1352
    invoke-static {v14, v15}, Li6t0;->lO(J)Ljava/lang/String;

    .line 1353
    .line 1354
    .line 1355
    sget-object v11, Lri1;->m:Lf4r;

    .line 1356
    .line 1357
    const v14, 0x7f1200ae

    .line 1358
    .line 1359
    .line 1360
    invoke-static {v14, v13}, Lkz30;->loo(ILkud;)Ljava/lang/String;

    .line 1361
    .line 1362
    .line 1363
    move-result-object v20

    .line 1364
    const/16 v18, 0x0

    .line 1365
    .line 1366
    const/16 v19, 0xd

    .line 1367
    .line 1368
    const/4 v15, 0x0

    .line 1369
    const/high16 v16, 0x41000000    # 8.0f

    .line 1370
    .line 1371
    const/16 v17, 0x0

    .line 1372
    .line 1373
    move-object v14, v6

    .line 1374
    invoke-static/range {v14 .. v19}, Lfqr;->loo(Lzgz;FFFFI)Lzgz;

    .line 1375
    .line 1376
    .line 1377
    move-result-object v15

    .line 1378
    move-object v14, v11

    .line 1379
    const/16 v11, 0x180

    .line 1380
    .line 1381
    move-object/from16 v18, v12

    .line 1382
    .line 1383
    const/16 v12, 0x8

    .line 1384
    .line 1385
    const/16 v17, 0x0

    .line 1386
    .line 1387
    move-object/from16 v9, v18

    .line 1388
    .line 1389
    move-object/from16 v16, v20

    .line 1390
    .line 1391
    invoke-static/range {v11 .. v17}, Lkc1;->ll(IILkud;Lf4r;Lzgz;Ljava/lang/String;Lkotlin/jvm/functions/Function3;)V

    .line 1392
    .line 1393
    .line 1394
    iget-object v11, v0, Lcom/chuanyi/voyage/ui/aichat/lll;->g:Lubg0;

    .line 1395
    .line 1396
    invoke-interface {v11}, Lubg0;->getValue()Ljava/lang/Object;

    .line 1397
    .line 1398
    .line 1399
    move-result-object v11

    .line 1400
    check-cast v11, Ljava/util/Map;

    .line 1401
    .line 1402
    invoke-interface {v11, v9}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1403
    .line 1404
    .line 1405
    move-result-object v11

    .line 1406
    check-cast v11, Lz41;

    .line 1407
    .line 1408
    const-wide v14, -0x517ab5a0c56e39L

    .line 1409
    .line 1410
    .line 1411
    .line 1412
    .line 1413
    invoke-static {v14, v15}, Li6t0;->lO(J)Ljava/lang/String;

    .line 1414
    .line 1415
    .line 1416
    invoke-virtual {v13, v5}, Ltgn;->lO(Ljava/lang/Object;)Z

    .line 1417
    .line 1418
    .line 1419
    move-result v12

    .line 1420
    move-object/from16 v14, v38

    .line 1421
    .line 1422
    invoke-virtual {v13, v14}, Ltgn;->lO(Ljava/lang/Object;)Z

    .line 1423
    .line 1424
    .line 1425
    move-result v15

    .line 1426
    or-int/2addr v12, v15

    .line 1427
    invoke-virtual {v13, v10}, Ltgn;->Il(Ljava/lang/Object;)Z

    .line 1428
    .line 1429
    .line 1430
    move-result v15

    .line 1431
    or-int/2addr v12, v15

    .line 1432
    invoke-virtual {v13, v9}, Ltgn;->lO(Ljava/lang/Object;)Z

    .line 1433
    .line 1434
    .line 1435
    move-result v15

    .line 1436
    or-int/2addr v12, v15

    .line 1437
    invoke-virtual {v13, v8}, Ltgn;->lO(Ljava/lang/Object;)Z

    .line 1438
    .line 1439
    .line 1440
    move-result v15

    .line 1441
    or-int/2addr v12, v15

    .line 1442
    invoke-virtual {v13}, Ltgn;->IIo()Ljava/lang/Object;

    .line 1443
    .line 1444
    .line 1445
    move-result-object v15

    .line 1446
    if-nez v12, :cond_1b

    .line 1447
    .line 1448
    if-ne v15, v7, :cond_1c

    .line 1449
    .line 1450
    :cond_1b
    move-object/from16 v16, v14

    .line 1451
    .line 1452
    goto :goto_c

    .line 1453
    :cond_1c
    move-object/from16 v20, v8

    .line 1454
    .line 1455
    move-object v8, v14

    .line 1456
    goto :goto_d

    .line 1457
    :goto_c
    new-instance v14, Lcom/chuanyi/voyage/ui/aichat/Il;

    .line 1458
    .line 1459
    move-object v15, v5

    .line 1460
    move-object/from16 v19, v8

    .line 1461
    .line 1462
    move-object/from16 v18, v9

    .line 1463
    .line 1464
    move-object/from16 v17, v10

    .line 1465
    .line 1466
    invoke-direct/range {v14 .. v19}, Lcom/chuanyi/voyage/ui/aichat/Il;-><init>(Lkc10;Lkc10;Lza1;Ljava/lang/String;Ljava/lang/String;)V

    .line 1467
    .line 1468
    .line 1469
    move-object/from16 v8, v16

    .line 1470
    .line 1471
    move-object/from16 v20, v19

    .line 1472
    .line 1473
    invoke-virtual {v13, v14}, Ltgn;->oll(Ljava/lang/Object;)V

    .line 1474
    .line 1475
    .line 1476
    move-object v15, v14

    .line 1477
    :goto_d
    check-cast v15, Lkotlin/jvm/functions/Function0;

    .line 1478
    .line 1479
    const/4 v12, 0x0

    .line 1480
    const/4 v14, 0x0

    .line 1481
    invoke-static {v11, v15, v12, v13, v14}, Lvyv0;->l(Lz41;Lkotlin/jvm/functions/Function0;Lzgz;Lkud;I)V

    .line 1482
    .line 1483
    .line 1484
    invoke-virtual {v13, v14}, Ltgn;->oI(Z)V

    .line 1485
    .line 1486
    .line 1487
    goto :goto_e

    .line 1488
    :cond_1d
    move-object/from16 v20, v8

    .line 1489
    .line 1490
    move-object v9, v12

    .line 1491
    move-object/from16 v8, v38

    .line 1492
    .line 1493
    const/4 v12, 0x0

    .line 1494
    const/4 v14, 0x0

    .line 1495
    const v11, -0x4c673459

    .line 1496
    .line 1497
    .line 1498
    invoke-virtual {v13, v11}, Ltgn;->OIO(I)V

    .line 1499
    .line 1500
    .line 1501
    invoke-virtual {v13, v14}, Ltgn;->oI(Z)V

    .line 1502
    .line 1503
    .line 1504
    :goto_e
    sget-object v11, Lri1;->loo:Lf4r;

    .line 1505
    .line 1506
    iget-object v15, v0, Lcom/chuanyi/voyage/ui/aichat/lll;->II:Ljava/util/List;

    .line 1507
    .line 1508
    invoke-interface {v15}, Ljava/util/List;->isEmpty()Z

    .line 1509
    .line 1510
    .line 1511
    move-result v16

    .line 1512
    if-eqz v16, :cond_1e

    .line 1513
    .line 1514
    const v12, -0x34034583    # -3.3125626E7f

    .line 1515
    .line 1516
    .line 1517
    invoke-virtual {v13, v12}, Ltgn;->OIO(I)V

    .line 1518
    .line 1519
    .line 1520
    move-object/from16 v21, v5

    .line 1521
    .line 1522
    move-object v12, v6

    .line 1523
    const-wide v5, -0x517ad6a0c56e39L

    .line 1524
    .line 1525
    .line 1526
    .line 1527
    .line 1528
    move-object/from16 v22, v9

    .line 1529
    .line 1530
    const v9, 0x7f12016d

    .line 1531
    .line 1532
    .line 1533
    invoke-static {v9, v5, v6, v13, v14}, Lfm7;->Il(IJLtgn;Z)Ljava/lang/String;

    .line 1534
    .line 1535
    .line 1536
    move-result-object v5

    .line 1537
    move-object v6, v10

    .line 1538
    goto :goto_f

    .line 1539
    :cond_1e
    move-object/from16 v21, v5

    .line 1540
    .line 1541
    move-object v12, v6

    .line 1542
    move-object/from16 v22, v9

    .line 1543
    .line 1544
    const v5, -0x3403405d    # -3.3128262E7f

    .line 1545
    .line 1546
    .line 1547
    move-object v6, v10

    .line 1548
    const-wide v9, -0x517ae3a0c56e39L

    .line 1549
    .line 1550
    .line 1551
    .line 1552
    .line 1553
    invoke-static {v13, v5, v9, v10, v15}, Lcbj0;->ll(Ltgn;IJLjava/util/List;)I

    .line 1554
    .line 1555
    .line 1556
    move-result v5

    .line 1557
    invoke-interface {v15}, Ljava/util/List;->size()I

    .line 1558
    .line 1559
    .line 1560
    move-result v9

    .line 1561
    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1562
    .line 1563
    .line 1564
    move-result-object v9

    .line 1565
    filled-new-array {v9}, [Ljava/lang/Object;

    .line 1566
    .line 1567
    .line 1568
    move-result-object v9

    .line 1569
    const v10, 0x7f100003

    .line 1570
    .line 1571
    .line 1572
    invoke-static {v10, v5, v9, v13}, Lkz30;->llO(II[Ljava/lang/Object;Lkud;)Ljava/lang/String;

    .line 1573
    .line 1574
    .line 1575
    move-result-object v5

    .line 1576
    invoke-virtual {v13, v14}, Ltgn;->oI(Z)V

    .line 1577
    .line 1578
    .line 1579
    :goto_f
    const/16 v18, 0x0

    .line 1580
    .line 1581
    const/16 v19, 0xd

    .line 1582
    .line 1583
    move-object v9, v15

    .line 1584
    const/4 v15, 0x0

    .line 1585
    const/high16 v16, 0x41000000    # 8.0f

    .line 1586
    .line 1587
    const/16 v17, 0x0

    .line 1588
    .line 1589
    move-object v14, v12

    .line 1590
    invoke-static/range {v14 .. v19}, Lfqr;->loo(Lzgz;FFFFI)Lzgz;

    .line 1591
    .line 1592
    .line 1593
    move-result-object v10

    .line 1594
    invoke-interface {v9}, Ljava/util/List;->isEmpty()Z

    .line 1595
    .line 1596
    .line 1597
    move-result v14

    .line 1598
    iget-object v15, v0, Lcom/chuanyi/voyage/ui/aichat/lll;->h:Lqoe;

    .line 1599
    .line 1600
    if-eqz v14, :cond_1f

    .line 1601
    .line 1602
    const v14, -0x4c6148be

    .line 1603
    .line 1604
    .line 1605
    invoke-virtual {v13, v14}, Ltgn;->OIO(I)V

    .line 1606
    .line 1607
    .line 1608
    const/4 v14, 0x0

    .line 1609
    invoke-virtual {v13, v14}, Ltgn;->oI(Z)V

    .line 1610
    .line 1611
    .line 1612
    move-object/from16 v16, v5

    .line 1613
    .line 1614
    move-object/from16 v72, v6

    .line 1615
    .line 1616
    move-object/from16 v74, v15

    .line 1617
    .line 1618
    move-object/from16 v71, v20

    .line 1619
    .line 1620
    move-object/from16 v15, v21

    .line 1621
    .line 1622
    move-object/from16 v73, v22

    .line 1623
    .line 1624
    const/16 v17, 0x0

    .line 1625
    .line 1626
    :goto_10
    move-object v14, v11

    .line 1627
    goto :goto_11

    .line 1628
    :cond_1f
    const v14, -0x34031fa9    # -3.3145006E7f

    .line 1629
    .line 1630
    .line 1631
    invoke-virtual {v13, v14}, Ltgn;->OIO(I)V

    .line 1632
    .line 1633
    .line 1634
    const-wide v17, -0x517af0a0c56e39L

    .line 1635
    .line 1636
    .line 1637
    .line 1638
    .line 1639
    invoke-static/range {v17 .. v18}, Li6t0;->lO(J)Ljava/lang/String;

    .line 1640
    .line 1641
    .line 1642
    new-instance v14, Lxf;

    .line 1643
    .line 1644
    move-object/from16 v19, v20

    .line 1645
    .line 1646
    const/16 v20, 0x9

    .line 1647
    .line 1648
    move-object/from16 v17, v6

    .line 1649
    .line 1650
    move-object/from16 v16, v15

    .line 1651
    .line 1652
    move-object/from16 v15, v21

    .line 1653
    .line 1654
    move-object/from16 v18, v22

    .line 1655
    .line 1656
    const/4 v6, 0x0

    .line 1657
    invoke-direct/range {v14 .. v20}, Lxf;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 1658
    .line 1659
    .line 1660
    move-object/from16 v74, v16

    .line 1661
    .line 1662
    move-object/from16 v72, v17

    .line 1663
    .line 1664
    move-object/from16 v73, v18

    .line 1665
    .line 1666
    move-object/from16 v71, v19

    .line 1667
    .line 1668
    move-object/from16 v16, v5

    .line 1669
    .line 1670
    const v5, 0x49cd1b6b

    .line 1671
    .line 1672
    .line 1673
    invoke-static {v5, v14, v13}, Lbe9;->IlI(ILu6n;Lkud;)Lggd;

    .line 1674
    .line 1675
    .line 1676
    move-result-object v5

    .line 1677
    invoke-virtual {v13, v6}, Ltgn;->oI(Z)V

    .line 1678
    .line 1679
    .line 1680
    move-object/from16 v17, v5

    .line 1681
    .line 1682
    goto :goto_10

    .line 1683
    :goto_11
    const/16 v11, 0x180

    .line 1684
    .line 1685
    move-object v6, v12

    .line 1686
    const/4 v12, 0x0

    .line 1687
    move-object v5, v15

    .line 1688
    const/16 v43, 0x0

    .line 1689
    .line 1690
    move-object v15, v10

    .line 1691
    invoke-static/range {v11 .. v17}, Lkc1;->ll(IILkud;Lf4r;Lzgz;Ljava/lang/String;Lkotlin/jvm/functions/Function3;)V

    .line 1692
    .line 1693
    .line 1694
    iget-object v10, v0, Lcom/chuanyi/voyage/ui/aichat/lll;->i:Lubg0;

    .line 1695
    .line 1696
    invoke-interface {v10}, Lubg0;->getValue()Ljava/lang/Object;

    .line 1697
    .line 1698
    .line 1699
    move-result-object v11

    .line 1700
    check-cast v11, Ljava/util/Map;

    .line 1701
    .line 1702
    new-instance v12, Ljava/lang/StringBuilder;

    .line 1703
    .line 1704
    const-wide v14, -0x517afea0c56e39L

    .line 1705
    .line 1706
    .line 1707
    .line 1708
    .line 1709
    invoke-static {v14, v15}, Li6t0;->lO(J)Ljava/lang/String;

    .line 1710
    .line 1711
    .line 1712
    move-result-object v14

    .line 1713
    invoke-direct {v12, v14}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1714
    .line 1715
    .line 1716
    move-object/from16 v14, v73

    .line 1717
    .line 1718
    invoke-virtual {v12, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1719
    .line 1720
    .line 1721
    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1722
    .line 1723
    .line 1724
    move-result-object v12

    .line 1725
    invoke-interface {v11, v12}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1726
    .line 1727
    .line 1728
    move-result-object v11

    .line 1729
    check-cast v11, Ltw1;

    .line 1730
    .line 1731
    new-instance v12, Lhx5;

    .line 1732
    .line 1733
    new-instance v15, Lho2;

    .line 1734
    .line 1735
    move-object/from16 v46, v9

    .line 1736
    .line 1737
    const/16 v9, 0x12

    .line 1738
    .line 1739
    invoke-direct {v15, v9}, Lho2;-><init>(B)V

    .line 1740
    .line 1741
    .line 1742
    move-object/from16 v48, v10

    .line 1743
    .line 1744
    const/4 v9, 0x1

    .line 1745
    const/high16 v10, 0x41000000    # 8.0f

    .line 1746
    .line 1747
    invoke-direct {v12, v10, v9, v15}, Lhx5;-><init>(FZLix5;)V

    .line 1748
    .line 1749
    .line 1750
    const/high16 v9, 0x3f800000    # 1.0f

    .line 1751
    .line 1752
    invoke-static {v6, v9}, Lj2f0;->lO(Lzgz;F)Lzgz;

    .line 1753
    .line 1754
    .line 1755
    move-result-object v15

    .line 1756
    const-wide v16, -0x517b06a0c56e39L

    .line 1757
    .line 1758
    .line 1759
    .line 1760
    .line 1761
    invoke-static/range {v16 .. v17}, Li6t0;->lO(J)Ljava/lang/String;

    .line 1762
    .line 1763
    .line 1764
    sget-object v9, Ljac;->IO:Ld29;

    .line 1765
    .line 1766
    const/4 v10, 0x6

    .line 1767
    invoke-static {v12, v9, v13, v10}, Ldfc0;->l(Lgx5;Lha2;Lkud;I)Lffc0;

    .line 1768
    .line 1769
    .line 1770
    move-result-object v9

    .line 1771
    const-wide v16, -0x517b6ea0c56e39L

    .line 1772
    .line 1773
    .line 1774
    .line 1775
    .line 1776
    invoke-static/range {v16 .. v17}, Li6t0;->lO(J)Ljava/lang/String;

    .line 1777
    .line 1778
    .line 1779
    move-object/from16 v49, v6

    .line 1780
    .line 1781
    move-object v10, v7

    .line 1782
    iget-wide v6, v13, Ltgn;->IOI:J

    .line 1783
    .line 1784
    invoke-static {v6, v7}, Ljava/lang/Long;->hashCode(J)I

    .line 1785
    .line 1786
    .line 1787
    move-result v6

    .line 1788
    invoke-virtual {v13}, Ltgn;->Ol()Lec70;

    .line 1789
    .line 1790
    .line 1791
    move-result-object v7

    .line 1792
    invoke-static {v13, v15}, Ld19;->lIo(Lkud;Lzgz;)Lzgz;

    .line 1793
    .line 1794
    .line 1795
    move-result-object v12

    .line 1796
    sget-object v15, Lztd;->Ill:Ljac;

    .line 1797
    .line 1798
    move-object/from16 v16, v10

    .line 1799
    .line 1800
    move-object/from16 v23, v11

    .line 1801
    .line 1802
    const-wide v10, -0x517bc1a0c56e39L

    .line 1803
    .line 1804
    .line 1805
    .line 1806
    .line 1807
    invoke-static {v15, v10, v11, v13}, Lti6;->oI(Ljac;JLtgn;)V

    .line 1808
    .line 1809
    .line 1810
    iget-boolean v10, v13, Ltgn;->IOl:Z

    .line 1811
    .line 1812
    sget-object v11, La8u;->J:Lvqp;

    .line 1813
    .line 1814
    if-eqz v10, :cond_20

    .line 1815
    .line 1816
    invoke-virtual {v13, v11}, Ltgn;->Io(Lkotlin/jvm/functions/Function0;)V

    .line 1817
    .line 1818
    .line 1819
    goto :goto_12

    .line 1820
    :cond_20
    invoke-virtual {v13}, Ltgn;->olo()V

    .line 1821
    .line 1822
    .line 1823
    :goto_12
    invoke-static {v13, v9, v4}, Lvrh0;->lOI(Lkud;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1824
    .line 1825
    .line 1826
    invoke-static {v13, v7, v3}, Lvrh0;->lOI(Lkud;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1827
    .line 1828
    .line 1829
    invoke-static {v6, v13, v2, v13}, Lxbe;->oo(ILtgn;Leqd;Ltgn;)V

    .line 1830
    .line 1831
    .line 1832
    invoke-static {v13, v12, v1}, Lvrh0;->lOI(Lkud;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1833
    .line 1834
    .line 1835
    const-wide v6, -0x517c13a0c56e39L

    .line 1836
    .line 1837
    .line 1838
    .line 1839
    .line 1840
    invoke-static {v6, v7}, Li6t0;->lO(J)Ljava/lang/String;

    .line 1841
    .line 1842
    .line 1843
    const-wide v6, -0x517c2da0c56e39L

    .line 1844
    .line 1845
    .line 1846
    .line 1847
    .line 1848
    invoke-static {v6, v7}, Li6t0;->lO(J)Ljava/lang/String;

    .line 1849
    .line 1850
    .line 1851
    sget-object v6, Lrw1;->l:Lrw1;

    .line 1852
    .line 1853
    move-object/from16 v7, v23

    .line 1854
    .line 1855
    invoke-static {v7, v6}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1856
    .line 1857
    .line 1858
    move-result v9

    .line 1859
    const/4 v12, 0x1

    .line 1860
    xor-int/2addr v9, v12

    .line 1861
    invoke-static {v13}, Ljac;->ll(Lkud;)Ljtc;

    .line 1862
    .line 1863
    .line 1864
    move-result-object v10

    .line 1865
    move v12, v9

    .line 1866
    iget-wide v9, v10, Ljtc;->lo:J

    .line 1867
    .line 1868
    move-wide/from16 v23, v9

    .line 1869
    .line 1870
    const/high16 v15, 0x3f800000    # 1.0f

    .line 1871
    .line 1872
    float-to-double v9, v15

    .line 1873
    const-wide/16 v25, 0x0

    .line 1874
    .line 1875
    cmpl-double v9, v9, v25

    .line 1876
    .line 1877
    const-string v10, "invalid weight; must be greater than zero"

    .line 1878
    .line 1879
    if-lez v9, :cond_21

    .line 1880
    .line 1881
    :goto_13
    move v9, v12

    .line 1882
    goto :goto_14

    .line 1883
    :cond_21
    invoke-static {v10}, Ljer;->l(Ljava/lang/String;)V

    .line 1884
    .line 1885
    .line 1886
    goto :goto_13

    .line 1887
    :goto_14
    new-instance v12, Lx9u;

    .line 1888
    .line 1889
    const v27, 0x7f7fffff    # Float.MAX_VALUE

    .line 1890
    .line 1891
    .line 1892
    cmpl-float v17, v15, v27

    .line 1893
    .line 1894
    if-lez v17, :cond_22

    .line 1895
    .line 1896
    move/from16 v15, v27

    .line 1897
    .line 1898
    :goto_15
    move/from16 v28, v9

    .line 1899
    .line 1900
    const/4 v9, 0x1

    .line 1901
    goto :goto_16

    .line 1902
    :cond_22
    const/high16 v15, 0x3f800000    # 1.0f

    .line 1903
    .line 1904
    goto :goto_15

    .line 1905
    :goto_16
    invoke-direct {v12, v15, v9}, Lx9u;-><init>(FZ)V

    .line 1906
    .line 1907
    .line 1908
    const-wide v17, -0x517ca2a0c56e39L

    .line 1909
    .line 1910
    .line 1911
    .line 1912
    .line 1913
    invoke-static/range {v17 .. v18}, Li6t0;->lO(J)Ljava/lang/String;

    .line 1914
    .line 1915
    .line 1916
    invoke-virtual {v13, v5}, Ltgn;->lO(Ljava/lang/Object;)Z

    .line 1917
    .line 1918
    .line 1919
    move-result v9

    .line 1920
    invoke-virtual {v13, v8}, Ltgn;->lO(Ljava/lang/Object;)Z

    .line 1921
    .line 1922
    .line 1923
    move-result v15

    .line 1924
    or-int/2addr v9, v15

    .line 1925
    move-object/from16 v15, v74

    .line 1926
    .line 1927
    invoke-virtual {v13, v15}, Ltgn;->Il(Ljava/lang/Object;)Z

    .line 1928
    .line 1929
    .line 1930
    move-result v17

    .line 1931
    or-int v9, v9, v17

    .line 1932
    .line 1933
    move-object/from16 v21, v5

    .line 1934
    .line 1935
    move-object/from16 v5, v72

    .line 1936
    .line 1937
    invoke-virtual {v13, v5}, Ltgn;->Il(Ljava/lang/Object;)Z

    .line 1938
    .line 1939
    .line 1940
    move-result v17

    .line 1941
    or-int v9, v9, v17

    .line 1942
    .line 1943
    invoke-virtual {v13, v14}, Ltgn;->lO(Ljava/lang/Object;)Z

    .line 1944
    .line 1945
    .line 1946
    move-result v17

    .line 1947
    or-int v9, v9, v17

    .line 1948
    .line 1949
    move-object/from16 v17, v5

    .line 1950
    .line 1951
    move-object/from16 v5, v71

    .line 1952
    .line 1953
    invoke-virtual {v13, v5}, Ltgn;->lO(Ljava/lang/Object;)Z

    .line 1954
    .line 1955
    .line 1956
    move-result v18

    .line 1957
    or-int v9, v9, v18

    .line 1958
    .line 1959
    move-object/from16 v19, v5

    .line 1960
    .line 1961
    invoke-virtual {v13}, Ltgn;->IIo()Ljava/lang/Object;

    .line 1962
    .line 1963
    .line 1964
    move-result-object v5

    .line 1965
    if-nez v9, :cond_24

    .line 1966
    .line 1967
    move-object/from16 v9, v16

    .line 1968
    .line 1969
    if-ne v5, v9, :cond_23

    .line 1970
    .line 1971
    :goto_17
    move-object/from16 v18, v14

    .line 1972
    .line 1973
    goto :goto_18

    .line 1974
    :cond_23
    move-object/from16 v16, v8

    .line 1975
    .line 1976
    move-object/from16 v18, v14

    .line 1977
    .line 1978
    move-object/from16 v8, v19

    .line 1979
    .line 1980
    move-object v14, v5

    .line 1981
    move-object/from16 v5, v21

    .line 1982
    .line 1983
    goto :goto_19

    .line 1984
    :cond_24
    move-object/from16 v9, v16

    .line 1985
    .line 1986
    goto :goto_17

    .line 1987
    :goto_18
    new-instance v14, Lcom/chuanyi/voyage/ui/aichat/II;

    .line 1988
    .line 1989
    iget-object v5, v0, Lcom/chuanyi/voyage/ui/aichat/lll;->k:Lkc10;

    .line 1990
    .line 1991
    move-object/from16 v16, v5

    .line 1992
    .line 1993
    iget-object v5, v0, Lcom/chuanyi/voyage/ui/aichat/lll;->m:Lkc10;

    .line 1994
    .line 1995
    move-object/from16 v20, v21

    .line 1996
    .line 1997
    move-object/from16 v21, v16

    .line 1998
    .line 1999
    move-object/from16 v16, v20

    .line 2000
    .line 2001
    move-object/from16 v22, v5

    .line 2002
    .line 2003
    move-object/from16 v20, v19

    .line 2004
    .line 2005
    move-object/from16 v19, v18

    .line 2006
    .line 2007
    move-object/from16 v18, v17

    .line 2008
    .line 2009
    move-object/from16 v17, v8

    .line 2010
    .line 2011
    invoke-direct/range {v14 .. v22}, Lcom/chuanyi/voyage/ui/aichat/II;-><init>(Lqoe;Lkc10;Lkc10;Lza1;Ljava/lang/String;Ljava/lang/String;Lkc10;Lkc10;)V

    .line 2012
    .line 2013
    .line 2014
    move-object/from16 v5, v16

    .line 2015
    .line 2016
    move-object/from16 v16, v17

    .line 2017
    .line 2018
    move-object/from16 v17, v18

    .line 2019
    .line 2020
    move-object/from16 v18, v19

    .line 2021
    .line 2022
    move-object/from16 v8, v20

    .line 2023
    .line 2024
    invoke-virtual {v13, v14}, Ltgn;->oll(Ljava/lang/Object;)V

    .line 2025
    .line 2026
    .line 2027
    :goto_19
    check-cast v14, Lkotlin/jvm/functions/Function0;

    .line 2028
    .line 2029
    new-instance v15, Lyf;

    .line 2030
    .line 2031
    move-object/from16 v21, v10

    .line 2032
    .line 2033
    const/16 v10, 0x8

    .line 2034
    .line 2035
    invoke-direct {v15, v7, v10}, Lyf;-><init>(Ljava/lang/Object;B)V

    .line 2036
    .line 2037
    .line 2038
    const v10, -0x24258c90

    .line 2039
    .line 2040
    .line 2041
    invoke-static {v10, v15, v13}, Lbe9;->IlI(ILu6n;Lkud;)Lggd;

    .line 2042
    .line 2043
    .line 2044
    move-result-object v10

    .line 2045
    const/high16 v19, 0x30000

    .line 2046
    .line 2047
    const/16 v20, 0x10

    .line 2048
    .line 2049
    move-object/from16 v29, v16

    .line 2050
    .line 2051
    const/16 v16, 0x0

    .line 2052
    .line 2053
    move-object/from16 v15, v17

    .line 2054
    .line 2055
    move-object/from16 v17, v10

    .line 2056
    .line 2057
    move-object v10, v15

    .line 2058
    move-object/from16 v50, v1

    .line 2059
    .line 2060
    move-object/from16 v51, v2

    .line 2061
    .line 2062
    move-object/from16 v52, v3

    .line 2063
    .line 2064
    move-object v3, v11

    .line 2065
    move-object v11, v14

    .line 2066
    move-object/from16 v1, v18

    .line 2067
    .line 2068
    move-wide/from16 v14, v23

    .line 2069
    .line 2070
    move-object/from16 v2, v29

    .line 2071
    .line 2072
    move-object/from16 v18, v13

    .line 2073
    .line 2074
    move/from16 v13, v28

    .line 2075
    .line 2076
    invoke-static/range {v11 .. v20}, Lkc1;->lo(Lkotlin/jvm/functions/Function0;Lzgz;ZJLf4r;Lkotlin/jvm/functions/Function3;Lkud;II)V

    .line 2077
    .line 2078
    .line 2079
    move-object/from16 v13, v18

    .line 2080
    .line 2081
    invoke-static {v13}, Ljac;->ll(Lkud;)Ljtc;

    .line 2082
    .line 2083
    .line 2084
    move-result-object v11

    .line 2085
    iget-wide v14, v11, Ljtc;->loI:J

    .line 2086
    .line 2087
    sget-object v16, Lri1;->Ol:Lf4r;

    .line 2088
    .line 2089
    move-wide/from16 v17, v14

    .line 2090
    .line 2091
    const/high16 v11, 0x3f800000    # 1.0f

    .line 2092
    .line 2093
    float-to-double v14, v11

    .line 2094
    cmpl-double v12, v14, v25

    .line 2095
    .line 2096
    if-lez v12, :cond_25

    .line 2097
    .line 2098
    goto :goto_1a

    .line 2099
    :cond_25
    invoke-static/range {v21 .. v21}, Ljer;->l(Ljava/lang/String;)V

    .line 2100
    .line 2101
    .line 2102
    :goto_1a
    new-instance v12, Lx9u;

    .line 2103
    .line 2104
    cmpl-float v14, v11, v27

    .line 2105
    .line 2106
    if-lez v14, :cond_26

    .line 2107
    .line 2108
    move/from16 v11, v27

    .line 2109
    .line 2110
    :goto_1b
    const/4 v14, 0x1

    .line 2111
    goto :goto_1c

    .line 2112
    :cond_26
    const/high16 v11, 0x3f800000    # 1.0f

    .line 2113
    .line 2114
    goto :goto_1b

    .line 2115
    :goto_1c
    invoke-direct {v12, v11, v14}, Lx9u;-><init>(FZ)V

    .line 2116
    .line 2117
    .line 2118
    const-wide v14, -0x517cc3a0c56e39L

    .line 2119
    .line 2120
    .line 2121
    .line 2122
    .line 2123
    invoke-static {v14, v15}, Li6t0;->lO(J)Ljava/lang/String;

    .line 2124
    .line 2125
    .line 2126
    iget-object v11, v0, Lcom/chuanyi/voyage/ui/aichat/lll;->j:Lkc10;

    .line 2127
    .line 2128
    invoke-virtual {v13, v11}, Ltgn;->lO(Ljava/lang/Object;)Z

    .line 2129
    .line 2130
    .line 2131
    move-result v14

    .line 2132
    invoke-virtual {v13}, Ltgn;->IIo()Ljava/lang/Object;

    .line 2133
    .line 2134
    .line 2135
    move-result-object v15

    .line 2136
    if-nez v14, :cond_27

    .line 2137
    .line 2138
    if-ne v15, v9, :cond_28

    .line 2139
    .line 2140
    :cond_27
    new-instance v15, Lyk0;

    .line 2141
    .line 2142
    const/16 v14, 0x19

    .line 2143
    .line 2144
    invoke-direct {v15, v11, v14}, Lyk0;-><init>(Lkc10;B)V

    .line 2145
    .line 2146
    .line 2147
    invoke-virtual {v13, v15}, Ltgn;->oll(Ljava/lang/Object;)V

    .line 2148
    .line 2149
    .line 2150
    :cond_28
    move-object v11, v15

    .line 2151
    check-cast v11, Lkotlin/jvm/functions/Function0;

    .line 2152
    .line 2153
    move-wide/from16 v14, v17

    .line 2154
    .line 2155
    sget-object v17, Lrfs0;->lo:Lggd;

    .line 2156
    .line 2157
    const/high16 v19, 0x30000

    .line 2158
    .line 2159
    const/16 v20, 0x4

    .line 2160
    .line 2161
    move-object/from16 v33, v13

    .line 2162
    .line 2163
    const/4 v13, 0x0

    .line 2164
    move-object/from16 v18, v33

    .line 2165
    .line 2166
    invoke-static/range {v11 .. v20}, Lkc1;->lo(Lkotlin/jvm/functions/Function0;Lzgz;ZJLf4r;Lkotlin/jvm/functions/Function3;Lkud;II)V

    .line 2167
    .line 2168
    .line 2169
    move-object/from16 v13, v18

    .line 2170
    .line 2171
    const/4 v12, 0x1

    .line 2172
    invoke-virtual {v13, v12}, Ltgn;->oI(Z)V

    .line 2173
    .line 2174
    .line 2175
    instance-of v11, v7, Lqw1;

    .line 2176
    .line 2177
    if-eqz v11, :cond_2d

    .line 2178
    .line 2179
    const-wide v11, -0x517ce4a0c56e39L

    .line 2180
    .line 2181
    .line 2182
    .line 2183
    .line 2184
    const v14, -0x3401eb91    # -3.330275E7f

    .line 2185
    .line 2186
    .line 2187
    const v15, -0x4c3d3e3e

    .line 2188
    .line 2189
    .line 2190
    invoke-static {v13, v15, v11, v12, v14}, Lfm7;->llO(Ltgn;IJI)V

    .line 2191
    .line 2192
    .line 2193
    const-wide v11, -0x517d0ca0c56e39L

    .line 2194
    .line 2195
    .line 2196
    .line 2197
    .line 2198
    invoke-static {v11, v12}, Li6t0;->lO(J)Ljava/lang/String;

    .line 2199
    .line 2200
    .line 2201
    move-object v11, v7

    .line 2202
    check-cast v11, Lqw1;

    .line 2203
    .line 2204
    iget-object v7, v11, Lqw1;->l:Ljava/lang/String;

    .line 2205
    .line 2206
    invoke-static {v7}, Ligh0;->lineSequence(Ljava/lang/CharSequence;)Ly1e0;

    .line 2207
    .line 2208
    .line 2209
    move-result-object v7

    .line 2210
    invoke-interface {v7}, Ly1e0;->iterator()Ljava/util/Iterator;

    .line 2211
    .line 2212
    .line 2213
    move-result-object v7

    .line 2214
    :cond_29
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    .line 2215
    .line 2216
    .line 2217
    move-result v11

    .line 2218
    if-eqz v11, :cond_2a

    .line 2219
    .line 2220
    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 2221
    .line 2222
    .line 2223
    move-result-object v11

    .line 2224
    move-object v12, v11

    .line 2225
    check-cast v12, Ljava/lang/String;

    .line 2226
    .line 2227
    invoke-static {v12}, Ligh0;->isBlank(Ljava/lang/CharSequence;)Z

    .line 2228
    .line 2229
    .line 2230
    move-result v12

    .line 2231
    if-nez v12, :cond_29

    .line 2232
    .line 2233
    goto :goto_1d

    .line 2234
    :cond_2a
    move-object/from16 v11, v43

    .line 2235
    .line 2236
    :goto_1d
    check-cast v11, Ljava/lang/String;

    .line 2237
    .line 2238
    if-nez v11, :cond_2b

    .line 2239
    .line 2240
    const-wide v11, -0x517d1aa0c56e39L

    .line 2241
    .line 2242
    .line 2243
    .line 2244
    .line 2245
    invoke-static {v11, v12}, Li6t0;->lO(J)Ljava/lang/String;

    .line 2246
    .line 2247
    .line 2248
    move-result-object v11

    .line 2249
    :cond_2b
    invoke-static {v11}, Ligh0;->isBlank(Ljava/lang/CharSequence;)Z

    .line 2250
    .line 2251
    .line 2252
    move-result v7

    .line 2253
    if-eqz v7, :cond_2c

    .line 2254
    .line 2255
    const v7, 0x7f120129

    .line 2256
    .line 2257
    .line 2258
    invoke-static {v7, v13}, Lkz30;->loo(ILkud;)Ljava/lang/String;

    .line 2259
    .line 2260
    .line 2261
    move-result-object v11

    .line 2262
    :cond_2c
    move-object/from16 v20, v11

    .line 2263
    .line 2264
    const/4 v7, 0x0

    .line 2265
    invoke-virtual {v13, v7}, Ltgn;->oI(Z)V

    .line 2266
    .line 2267
    .line 2268
    sget-object v18, Lri1;->IlO:Lf4r;

    .line 2269
    .line 2270
    invoke-static {v13}, Ljac;->ll(Lkud;)Ljtc;

    .line 2271
    .line 2272
    .line 2273
    move-result-object v11

    .line 2274
    iget-wide v11, v11, Ljtc;->lIl:J

    .line 2275
    .line 2276
    invoke-static {v13}, Ljac;->ll(Lkud;)Ljtc;

    .line 2277
    .line 2278
    .line 2279
    move-result-object v14

    .line 2280
    iget-wide v14, v14, Ljtc;->lII:J

    .line 2281
    .line 2282
    move-object/from16 v33, v13

    .line 2283
    .line 2284
    move-wide v15, v14

    .line 2285
    move-wide v13, v11

    .line 2286
    const/4 v11, 0x0

    .line 2287
    const/4 v12, 0x2

    .line 2288
    const/16 v19, 0x0

    .line 2289
    .line 2290
    move-object/from16 v17, v33

    .line 2291
    .line 2292
    invoke-static/range {v11 .. v20}, Lkc1;->O(IIJJLkud;Lf4r;Lzgz;Ljava/lang/String;)V

    .line 2293
    .line 2294
    .line 2295
    move-object/from16 v13, v17

    .line 2296
    .line 2297
    invoke-virtual {v13, v7}, Ltgn;->oI(Z)V

    .line 2298
    .line 2299
    .line 2300
    goto :goto_1e

    .line 2301
    :cond_2d
    const/4 v7, 0x0

    .line 2302
    const v11, -0x4c3789f9

    .line 2303
    .line 2304
    .line 2305
    invoke-virtual {v13, v11}, Ltgn;->OIO(I)V

    .line 2306
    .line 2307
    .line 2308
    invoke-virtual {v13, v7}, Ltgn;->oI(Z)V

    .line 2309
    .line 2310
    .line 2311
    :goto_1e
    invoke-interface/range {v46 .. v46}, Ljava/util/List;->isEmpty()Z

    .line 2312
    .line 2313
    .line 2314
    move-result v7

    .line 2315
    if-eqz v7, :cond_2e

    .line 2316
    .line 2317
    const v7, -0x4c36bbfe

    .line 2318
    .line 2319
    .line 2320
    invoke-virtual {v13, v7}, Ltgn;->OIO(I)V

    .line 2321
    .line 2322
    .line 2323
    const-wide v11, -0x517d1ba0c56e39L

    .line 2324
    .line 2325
    .line 2326
    .line 2327
    .line 2328
    invoke-static {v11, v12}, Li6t0;->lO(J)Ljava/lang/String;

    .line 2329
    .line 2330
    .line 2331
    const v7, 0x7f120179

    .line 2332
    .line 2333
    .line 2334
    invoke-static {v7, v13}, Lkz30;->loo(ILkud;)Ljava/lang/String;

    .line 2335
    .line 2336
    .line 2337
    move-result-object v11

    .line 2338
    invoke-static {v13}, Ljac;->Il(Lkud;)Ldal0;

    .line 2339
    .line 2340
    .line 2341
    move-result-object v7

    .line 2342
    iget-object v7, v7, Ldal0;->IO:Lhaj0;

    .line 2343
    .line 2344
    invoke-static {v13}, Ljac;->ll(Lkud;)Ljtc;

    .line 2345
    .line 2346
    .line 2347
    move-result-object v12

    .line 2348
    iget-wide v14, v12, Ljtc;->oO:J

    .line 2349
    .line 2350
    move-wide/from16 v16, v14

    .line 2351
    .line 2352
    move-object/from16 v12, v49

    .line 2353
    .line 2354
    const/high16 v15, 0x41000000    # 8.0f

    .line 2355
    .line 2356
    invoke-static {v12, v15}, Lfqr;->lOo(Lzgz;F)Lzgz;

    .line 2357
    .line 2358
    .line 2359
    move-result-object v14

    .line 2360
    const/16 v35, 0x0

    .line 2361
    .line 2362
    const v36, 0x1fff8

    .line 2363
    .line 2364
    .line 2365
    move/from16 v70, v15

    .line 2366
    .line 2367
    const/4 v15, 0x0

    .line 2368
    move-object/from16 v33, v13

    .line 2369
    .line 2370
    move-object v12, v14

    .line 2371
    move-wide/from16 v13, v16

    .line 2372
    .line 2373
    const-wide/16 v16, 0x0

    .line 2374
    .line 2375
    const/16 v18, 0x0

    .line 2376
    .line 2377
    const/16 v19, 0x0

    .line 2378
    .line 2379
    const/16 v20, 0x0

    .line 2380
    .line 2381
    const-wide/16 v21, 0x0

    .line 2382
    .line 2383
    const/16 v23, 0x0

    .line 2384
    .line 2385
    const/16 v24, 0x0

    .line 2386
    .line 2387
    const-wide/16 v25, 0x0

    .line 2388
    .line 2389
    const/16 v27, 0x0

    .line 2390
    .line 2391
    const/16 v28, 0x0

    .line 2392
    .line 2393
    const/16 v29, 0x0

    .line 2394
    .line 2395
    const/16 v30, 0x0

    .line 2396
    .line 2397
    const/16 v31, 0x0

    .line 2398
    .line 2399
    const/16 v34, 0x30

    .line 2400
    .line 2401
    move-object/from16 v32, v7

    .line 2402
    .line 2403
    move-object/from16 v7, v49

    .line 2404
    .line 2405
    invoke-static/range {v11 .. v36}, Lm7j0;->I(Ljava/lang/String;Lzgz;JLa1j0;JLunm;Ldom;Lgmm;JLk2j0;Lj0j0;JIZIILkotlin/jvm/functions/Function1;Lhaj0;Lkud;III)V

    .line 2406
    .line 2407
    .line 2408
    move-object/from16 v13, v33

    .line 2409
    .line 2410
    const/4 v15, 0x0

    .line 2411
    invoke-virtual {v13, v15}, Ltgn;->oI(Z)V

    .line 2412
    .line 2413
    .line 2414
    goto :goto_1f

    .line 2415
    :cond_2e
    move-object/from16 v7, v49

    .line 2416
    .line 2417
    const/4 v15, 0x0

    .line 2418
    const/high16 v70, 0x41000000    # 8.0f

    .line 2419
    .line 2420
    const v11, -0x4c32c179

    .line 2421
    .line 2422
    .line 2423
    invoke-virtual {v13, v11}, Ltgn;->OIO(I)V

    .line 2424
    .line 2425
    .line 2426
    invoke-virtual {v13, v15}, Ltgn;->oI(Z)V

    .line 2427
    .line 2428
    .line 2429
    :goto_1f
    const v11, -0x34019b79    # -3.3343758E7f

    .line 2430
    .line 2431
    .line 2432
    invoke-virtual {v13, v11}, Ltgn;->OIO(I)V

    .line 2433
    .line 2434
    .line 2435
    const-wide v11, -0x517d50a0c56e39L

    .line 2436
    .line 2437
    .line 2438
    .line 2439
    .line 2440
    invoke-static {v11, v12}, Li6t0;->lO(J)Ljava/lang/String;

    .line 2441
    .line 2442
    .line 2443
    move-object/from16 v15, v46

    .line 2444
    .line 2445
    check-cast v15, Ljava/lang/Iterable;

    .line 2446
    .line 2447
    invoke-interface {v15}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 2448
    .line 2449
    .line 2450
    move-result-object v49

    .line 2451
    const/4 v11, 0x0

    .line 2452
    :goto_20
    invoke-interface/range {v49 .. v49}, Ljava/util/Iterator;->hasNext()Z

    .line 2453
    .line 2454
    .line 2455
    move-result v12

    .line 2456
    if-eqz v12, :cond_33

    .line 2457
    .line 2458
    invoke-interface/range {v49 .. v49}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 2459
    .line 2460
    .line 2461
    move-result-object v12

    .line 2462
    add-int/lit8 v53, v11, 0x1

    .line 2463
    .line 2464
    if-gez v11, :cond_2f

    .line 2465
    .line 2466
    invoke-static {}, Loqc;->throwIndexOverflow()V

    .line 2467
    .line 2468
    .line 2469
    :cond_2f
    check-cast v12, Lgt1;

    .line 2470
    .line 2471
    const v14, 0x76bdf8a

    .line 2472
    .line 2473
    .line 2474
    iget-object v15, v12, Lgt1;->l:Ljava/lang/String;

    .line 2475
    .line 2476
    invoke-virtual {v13, v14, v15}, Ltgn;->Olo(ILjava/lang/Object;)V

    .line 2477
    .line 2478
    .line 2479
    const-wide v14, -0x517d51a0c56e39L

    .line 2480
    .line 2481
    .line 2482
    .line 2483
    .line 2484
    invoke-static {v14, v15}, Li6t0;->lO(J)Ljava/lang/String;

    .line 2485
    .line 2486
    .line 2487
    invoke-virtual {v12}, Lgt1;->O()Ljava/lang/String;

    .line 2488
    .line 2489
    .line 2490
    move-result-object v18

    .line 2491
    iget-object v14, v12, Lgt1;->I:Ljava/lang/String;

    .line 2492
    .line 2493
    invoke-static {v14}, Ligh0;->isBlank(Ljava/lang/CharSequence;)Z

    .line 2494
    .line 2495
    .line 2496
    move-result v14

    .line 2497
    if-nez v14, :cond_30

    .line 2498
    .line 2499
    iget-object v14, v12, Lgt1;->l:Ljava/lang/String;

    .line 2500
    .line 2501
    move-object/from16 v19, v14

    .line 2502
    .line 2503
    goto :goto_21

    .line 2504
    :cond_30
    move-object/from16 v19, v43

    .line 2505
    .line 2506
    :goto_21
    sget v14, Lzee0;->l:I

    .line 2507
    .line 2508
    move-object v14, v12

    .line 2509
    invoke-interface/range {v46 .. v46}, Ljava/util/List;->size()I

    .line 2510
    .line 2511
    .line 2512
    move-result v12

    .line 2513
    const/4 v15, 0x0

    .line 2514
    const/16 v17, 0x3c

    .line 2515
    .line 2516
    move-object/from16 v33, v13

    .line 2517
    .line 2518
    const/4 v13, 0x0

    .line 2519
    move-object/from16 v16, v14

    .line 2520
    .line 2521
    const/4 v14, 0x0

    .line 2522
    move-object/from16 v54, v4

    .line 2523
    .line 2524
    move-object/from16 v4, v16

    .line 2525
    .line 2526
    move-object/from16 v16, v33

    .line 2527
    .line 2528
    invoke-static/range {v11 .. v17}, Lzee0;->O(IIZFFLkud;I)Lvne;

    .line 2529
    .line 2530
    .line 2531
    move-result-object v21

    .line 2532
    move-object/from16 v13, v16

    .line 2533
    .line 2534
    const/high16 v11, 0x3f800000    # 1.0f

    .line 2535
    .line 2536
    invoke-static {v7, v11}, Lj2f0;->lO(Lzgz;F)Lzgz;

    .line 2537
    .line 2538
    .line 2539
    move-result-object v29

    .line 2540
    const-wide v11, -0x517d89a0c56e39L

    .line 2541
    .line 2542
    .line 2543
    .line 2544
    .line 2545
    invoke-static {v11, v12}, Li6t0;->lO(J)Ljava/lang/String;

    .line 2546
    .line 2547
    .line 2548
    invoke-virtual {v13, v4}, Ltgn;->Il(Ljava/lang/Object;)Z

    .line 2549
    .line 2550
    .line 2551
    move-result v11

    .line 2552
    invoke-virtual {v13}, Ltgn;->IIo()Ljava/lang/Object;

    .line 2553
    .line 2554
    .line 2555
    move-result-object v12

    .line 2556
    if-nez v11, :cond_31

    .line 2557
    .line 2558
    if-ne v12, v9, :cond_32

    .line 2559
    .line 2560
    :cond_31
    new-instance v12, Lfj;

    .line 2561
    .line 2562
    const/16 v11, 0x18

    .line 2563
    .line 2564
    iget-object v14, v0, Lcom/chuanyi/voyage/ui/aichat/lll;->n:Lkc10;

    .line 2565
    .line 2566
    iget-object v15, v0, Lcom/chuanyi/voyage/ui/aichat/lll;->p:Lkc10;

    .line 2567
    .line 2568
    invoke-direct {v12, v4, v14, v15, v11}, Lfj;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 2569
    .line 2570
    .line 2571
    invoke-virtual {v13, v12}, Ltgn;->oll(Ljava/lang/Object;)V

    .line 2572
    .line 2573
    .line 2574
    :cond_32
    move-object v11, v12

    .line 2575
    check-cast v11, Lkotlin/jvm/functions/Function0;

    .line 2576
    .line 2577
    sget-object v17, Lrfs0;->Il:Lggd;

    .line 2578
    .line 2579
    new-instance v12, Lj4;

    .line 2580
    .line 2581
    const/4 v14, 0x5

    .line 2582
    invoke-direct {v12, v4, v5, v14}, Lj4;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 2583
    .line 2584
    .line 2585
    const v4, 0x2102780c

    .line 2586
    .line 2587
    .line 2588
    invoke-static {v4, v12, v13}, Lbe9;->IlI(ILu6n;Lkud;)Lggd;

    .line 2589
    .line 2590
    .line 2591
    move-result-object v4

    .line 2592
    const/16 v40, 0x0

    .line 2593
    .line 2594
    const v41, 0xfefb2a

    .line 2595
    .line 2596
    .line 2597
    const/4 v12, 0x0

    .line 2598
    move/from16 v45, v14

    .line 2599
    .line 2600
    const/4 v14, 0x0

    .line 2601
    const/16 v16, 0x0

    .line 2602
    .line 2603
    move-object/from16 v15, v19

    .line 2604
    .line 2605
    const/16 v19, 0x0

    .line 2606
    .line 2607
    const/16 v20, 0x0

    .line 2608
    .line 2609
    const/16 v22, 0x0

    .line 2610
    .line 2611
    const-wide/16 v23, 0x0

    .line 2612
    .line 2613
    const-wide/16 v25, 0x0

    .line 2614
    .line 2615
    const/16 v27, 0x0

    .line 2616
    .line 2617
    const/16 v28, 0x0

    .line 2618
    .line 2619
    const/16 v30, 0x0

    .line 2620
    .line 2621
    const/16 v31, 0x0

    .line 2622
    .line 2623
    const/16 v32, 0x0

    .line 2624
    .line 2625
    const/16 v33, 0x0

    .line 2626
    .line 2627
    const/16 v34, 0x0

    .line 2628
    .line 2629
    const/16 v35, 0x0

    .line 2630
    .line 2631
    const/16 v36, 0x0

    .line 2632
    .line 2633
    const/high16 v38, 0xd80000

    .line 2634
    .line 2635
    const/high16 v39, 0x180000

    .line 2636
    .line 2637
    move-object/from16 v37, v13

    .line 2638
    .line 2639
    move-object/from16 v13, v18

    .line 2640
    .line 2641
    move-object/from16 v18, v4

    .line 2642
    .line 2643
    invoke-static/range {v11 .. v41}, Ln5v0;->I(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Ljava/lang/String;ZLjava/lang/String;FLkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function3;Lha2;Lree0;Lree0;JJZLzgz;Lzgz;Lhaj0;Lhaj0;Lkotlin/jvm/functions/Function0;ZLua10;ZLkotlin/jvm/functions/Function2;Lkud;IIII)V

    .line 2644
    .line 2645
    .line 2646
    move-object/from16 v13, v37

    .line 2647
    .line 2648
    const/4 v15, 0x0

    .line 2649
    invoke-virtual {v13, v15}, Ltgn;->oI(Z)V

    .line 2650
    .line 2651
    .line 2652
    move/from16 v11, v53

    .line 2653
    .line 2654
    move-object/from16 v4, v54

    .line 2655
    .line 2656
    goto/16 :goto_20

    .line 2657
    .line 2658
    :cond_33
    move-object/from16 v54, v4

    .line 2659
    .line 2660
    const/4 v15, 0x0

    .line 2661
    invoke-virtual {v13, v15}, Ltgn;->oI(Z)V

    .line 2662
    .line 2663
    .line 2664
    move-object/from16 v15, v46

    .line 2665
    .line 2666
    check-cast v15, Ljava/util/Collection;

    .line 2667
    .line 2668
    invoke-interface {v15}, Ljava/util/Collection;->isEmpty()Z

    .line 2669
    .line 2670
    .line 2671
    move-result v4

    .line 2672
    if-nez v4, :cond_3a

    .line 2673
    .line 2674
    const v4, -0x4c1adf54

    .line 2675
    .line 2676
    .line 2677
    const-wide v11, -0x517daaa0c56e39L

    .line 2678
    .line 2679
    .line 2680
    .line 2681
    .line 2682
    move-object/from16 v14, v48

    .line 2683
    .line 2684
    invoke-static {v13, v4, v11, v12, v14}, Lns;->ll(Ltgn;IJLubg0;)Ljava/lang/Object;

    .line 2685
    .line 2686
    .line 2687
    move-result-object v4

    .line 2688
    check-cast v4, Ljava/util/Map;

    .line 2689
    .line 2690
    new-instance v11, Ljava/lang/StringBuilder;

    .line 2691
    .line 2692
    const-wide v14, -0x517de1a0c56e39L

    .line 2693
    .line 2694
    .line 2695
    .line 2696
    .line 2697
    invoke-static {v14, v15}, Li6t0;->lO(J)Ljava/lang/String;

    .line 2698
    .line 2699
    .line 2700
    move-result-object v12

    .line 2701
    invoke-direct {v11, v12}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 2702
    .line 2703
    .line 2704
    invoke-virtual {v11, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2705
    .line 2706
    .line 2707
    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 2708
    .line 2709
    .line 2710
    move-result-object v11

    .line 2711
    invoke-interface {v4, v11}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 2712
    .line 2713
    .line 2714
    move-result-object v4

    .line 2715
    check-cast v4, Ltw1;

    .line 2716
    .line 2717
    invoke-static {v4, v6}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 2718
    .line 2719
    .line 2720
    move-result v11

    .line 2721
    const/4 v12, 0x1

    .line 2722
    xor-int/2addr v11, v12

    .line 2723
    sget-object v12, Lhpx;->I:Lzaj;

    .line 2724
    .line 2725
    invoke-virtual {v13, v12}, Ltgn;->IO(Landroidx/compose/runtime/ll;)Ljava/lang/Object;

    .line 2726
    .line 2727
    .line 2728
    move-result-object v14

    .line 2729
    check-cast v14, Ldpx;

    .line 2730
    .line 2731
    iget-object v14, v14, Ldpx;->l:Ljtc;

    .line 2732
    .line 2733
    iget-wide v14, v14, Ljtc;->Io:J

    .line 2734
    .line 2735
    sget-object v20, Lri1;->OOI:Lf4r;

    .line 2736
    .line 2737
    move/from16 v21, v11

    .line 2738
    .line 2739
    const/high16 v11, 0x3f800000    # 1.0f

    .line 2740
    .line 2741
    invoke-static {v7, v11}, Lj2f0;->lO(Lzgz;F)Lzgz;

    .line 2742
    .line 2743
    .line 2744
    move-result-object v23

    .line 2745
    const/16 v27, 0x0

    .line 2746
    .line 2747
    const/16 v28, 0xd

    .line 2748
    .line 2749
    const/16 v24, 0x0

    .line 2750
    .line 2751
    const/16 v26, 0x0

    .line 2752
    .line 2753
    move/from16 v25, v70

    .line 2754
    .line 2755
    invoke-static/range {v23 .. v28}, Lfqr;->loo(Lzgz;FFFFI)Lzgz;

    .line 2756
    .line 2757
    .line 2758
    move-result-object v11

    .line 2759
    move/from16 v0, v25

    .line 2760
    .line 2761
    const-wide v16, -0x517de7a0c56e39L

    .line 2762
    .line 2763
    .line 2764
    .line 2765
    .line 2766
    invoke-static/range {v16 .. v17}, Li6t0;->lO(J)Ljava/lang/String;

    .line 2767
    .line 2768
    .line 2769
    invoke-virtual {v13, v5}, Ltgn;->lO(Ljava/lang/Object;)Z

    .line 2770
    .line 2771
    .line 2772
    move-result v16

    .line 2773
    invoke-virtual {v13, v2}, Ltgn;->lO(Ljava/lang/Object;)Z

    .line 2774
    .line 2775
    .line 2776
    move-result v17

    .line 2777
    or-int v16, v16, v17

    .line 2778
    .line 2779
    invoke-virtual {v13, v10}, Ltgn;->Il(Ljava/lang/Object;)Z

    .line 2780
    .line 2781
    .line 2782
    move-result v17

    .line 2783
    or-int v16, v16, v17

    .line 2784
    .line 2785
    invoke-virtual {v13, v1}, Ltgn;->lO(Ljava/lang/Object;)Z

    .line 2786
    .line 2787
    .line 2788
    move-result v17

    .line 2789
    or-int v16, v16, v17

    .line 2790
    .line 2791
    invoke-virtual {v13, v8}, Ltgn;->lO(Ljava/lang/Object;)Z

    .line 2792
    .line 2793
    .line 2794
    move-result v17

    .line 2795
    or-int v16, v16, v17

    .line 2796
    .line 2797
    invoke-virtual {v13}, Ltgn;->IIo()Ljava/lang/Object;

    .line 2798
    .line 2799
    .line 2800
    move-result-object v0

    .line 2801
    if-nez v16, :cond_34

    .line 2802
    .line 2803
    if-ne v0, v9, :cond_35

    .line 2804
    .line 2805
    :cond_34
    move-wide v15, v14

    .line 2806
    goto :goto_22

    .line 2807
    :cond_35
    move-object v8, v2

    .line 2808
    move-object v2, v1

    .line 2809
    move-wide/from16 v75, v14

    .line 2810
    .line 2811
    move-object v14, v0

    .line 2812
    move-wide/from16 v0, v75

    .line 2813
    .line 2814
    goto :goto_23

    .line 2815
    :goto_22
    new-instance v14, Lcom/chuanyi/voyage/ui/aichat/Il;

    .line 2816
    .line 2817
    move-wide/from16 v17, v15

    .line 2818
    .line 2819
    move-object/from16 v16, v1

    .line 2820
    .line 2821
    move-wide/from16 v0, v17

    .line 2822
    .line 2823
    move-object/from16 v19, v2

    .line 2824
    .line 2825
    move-object/from16 v18, v5

    .line 2826
    .line 2827
    move-object/from16 v17, v8

    .line 2828
    .line 2829
    move-object v15, v10

    .line 2830
    invoke-direct/range {v14 .. v19}, Lcom/chuanyi/voyage/ui/aichat/Il;-><init>(Lza1;Ljava/lang/String;Ljava/lang/String;Lkc10;Lkc10;)V

    .line 2831
    .line 2832
    .line 2833
    move-object/from16 v2, v16

    .line 2834
    .line 2835
    move-object/from16 v8, v19

    .line 2836
    .line 2837
    invoke-virtual {v13, v14}, Ltgn;->oll(Ljava/lang/Object;)V

    .line 2838
    .line 2839
    .line 2840
    :goto_23
    check-cast v14, Lkotlin/jvm/functions/Function0;

    .line 2841
    .line 2842
    new-instance v15, Ldg;

    .line 2843
    .line 2844
    move-wide/from16 v16, v0

    .line 2845
    .line 2846
    move-object/from16 v1, v46

    .line 2847
    .line 2848
    const/4 v0, 0x4

    .line 2849
    invoke-direct {v15, v1, v0}, Ldg;-><init>(Ljava/util/List;B)V

    .line 2850
    .line 2851
    .line 2852
    const v0, -0x6ac9d302

    .line 2853
    .line 2854
    .line 2855
    invoke-static {v0, v15, v13}, Lbe9;->IlI(ILu6n;Lkud;)Lggd;

    .line 2856
    .line 2857
    .line 2858
    move-result-object v0

    .line 2859
    const v19, 0x30030

    .line 2860
    .line 2861
    .line 2862
    move-object v1, v12

    .line 2863
    move-object v12, v11

    .line 2864
    move-object v11, v14

    .line 2865
    move-wide/from16 v14, v16

    .line 2866
    .line 2867
    move-object/from16 v16, v20

    .line 2868
    .line 2869
    const/16 v20, 0x0

    .line 2870
    .line 2871
    move-object/from16 v17, v0

    .line 2872
    .line 2873
    move-object/from16 v18, v13

    .line 2874
    .line 2875
    move/from16 v13, v21

    .line 2876
    .line 2877
    invoke-static/range {v11 .. v20}, Lkc1;->lo(Lkotlin/jvm/functions/Function0;Lzgz;ZJLf4r;Lkotlin/jvm/functions/Function3;Lkud;II)V

    .line 2878
    .line 2879
    .line 2880
    move-object/from16 v13, v18

    .line 2881
    .line 2882
    invoke-static {v4, v6}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 2883
    .line 2884
    .line 2885
    move-result v0

    .line 2886
    const/high16 v6, 0x41400000    # 12.0f

    .line 2887
    .line 2888
    if-eqz v0, :cond_37

    .line 2889
    .line 2890
    const v0, -0x4c0dcc6b

    .line 2891
    .line 2892
    .line 2893
    invoke-virtual {v13, v0}, Ltgn;->OIO(I)V

    .line 2894
    .line 2895
    .line 2896
    const-wide v11, -0x517e08a0c56e39L

    .line 2897
    .line 2898
    .line 2899
    .line 2900
    .line 2901
    invoke-static {v11, v12}, Li6t0;->lO(J)Ljava/lang/String;

    .line 2902
    .line 2903
    .line 2904
    sget-object v0, Ljac;->Io:Ld29;

    .line 2905
    .line 2906
    new-instance v4, Lhx5;

    .line 2907
    .line 2908
    new-instance v11, Lho2;

    .line 2909
    .line 2910
    const/16 v12, 0x12

    .line 2911
    .line 2912
    invoke-direct {v11, v12}, Lho2;-><init>(B)V

    .line 2913
    .line 2914
    .line 2915
    const/4 v12, 0x1

    .line 2916
    invoke-direct {v4, v6, v12, v11}, Lhx5;-><init>(FZLix5;)V

    .line 2917
    .line 2918
    .line 2919
    const-wide v11, -0x517e16a0c56e39L

    .line 2920
    .line 2921
    .line 2922
    .line 2923
    .line 2924
    invoke-static {v11, v12}, Li6t0;->lO(J)Ljava/lang/String;

    .line 2925
    .line 2926
    .line 2927
    const/16 v6, 0x36

    .line 2928
    .line 2929
    invoke-static {v4, v0, v13, v6}, Ldfc0;->l(Lgx5;Lha2;Lkud;I)Lffc0;

    .line 2930
    .line 2931
    .line 2932
    move-result-object v0

    .line 2933
    const-wide v11, -0x517e7ea0c56e39L

    .line 2934
    .line 2935
    .line 2936
    .line 2937
    .line 2938
    invoke-static {v11, v12}, Li6t0;->lO(J)Ljava/lang/String;

    .line 2939
    .line 2940
    .line 2941
    iget-wide v11, v13, Ltgn;->IOI:J

    .line 2942
    .line 2943
    invoke-static {v11, v12}, Ljava/lang/Long;->hashCode(J)I

    .line 2944
    .line 2945
    .line 2946
    move-result v4

    .line 2947
    invoke-virtual {v13}, Ltgn;->Ol()Lec70;

    .line 2948
    .line 2949
    .line 2950
    move-result-object v6

    .line 2951
    invoke-static {v13, v7}, Ld19;->lIo(Lkud;Lzgz;)Lzgz;

    .line 2952
    .line 2953
    .line 2954
    move-result-object v11

    .line 2955
    sget-object v12, Lztd;->Ill:Ljac;

    .line 2956
    .line 2957
    const-wide v14, -0x517ed1a0c56e39L

    .line 2958
    .line 2959
    .line 2960
    .line 2961
    .line 2962
    invoke-static {v12, v14, v15, v13}, Lti6;->oI(Ljac;JLtgn;)V

    .line 2963
    .line 2964
    .line 2965
    iget-boolean v12, v13, Ltgn;->IOl:Z

    .line 2966
    .line 2967
    if-eqz v12, :cond_36

    .line 2968
    .line 2969
    invoke-virtual {v13, v3}, Ltgn;->Io(Lkotlin/jvm/functions/Function0;)V

    .line 2970
    .line 2971
    .line 2972
    :goto_24
    move-object/from16 v3, v54

    .line 2973
    .line 2974
    goto :goto_25

    .line 2975
    :cond_36
    invoke-virtual {v13}, Ltgn;->olo()V

    .line 2976
    .line 2977
    .line 2978
    goto :goto_24

    .line 2979
    :goto_25
    invoke-static {v13, v0, v3}, Lvrh0;->lOI(Lkud;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 2980
    .line 2981
    .line 2982
    move-object/from16 v0, v52

    .line 2983
    .line 2984
    invoke-static {v13, v6, v0}, Lvrh0;->lOI(Lkud;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 2985
    .line 2986
    .line 2987
    move-object/from16 v0, v51

    .line 2988
    .line 2989
    invoke-static {v4, v13, v0, v13}, Lxbe;->oo(ILtgn;Leqd;Ltgn;)V

    .line 2990
    .line 2991
    .line 2992
    move-object/from16 v0, v50

    .line 2993
    .line 2994
    invoke-static {v13, v11, v0}, Lvrh0;->lOI(Lkud;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 2995
    .line 2996
    .line 2997
    const-wide v3, -0x517f23a0c56e39L

    .line 2998
    .line 2999
    .line 3000
    .line 3001
    .line 3002
    invoke-static {v3, v4}, Li6t0;->lO(J)Ljava/lang/String;

    .line 3003
    .line 3004
    .line 3005
    const-wide v3, -0x517f3da0c56e39L

    .line 3006
    .line 3007
    .line 3008
    .line 3009
    .line 3010
    invoke-static {v3, v4}, Li6t0;->lO(J)Ljava/lang/String;

    .line 3011
    .line 3012
    .line 3013
    const/high16 v0, 0x41c00000    # 24.0f

    .line 3014
    .line 3015
    invoke-static {v7, v0}, Lj2f0;->ol(Lzgz;F)Lzgz;

    .line 3016
    .line 3017
    .line 3018
    move-result-object v11

    .line 3019
    const/16 v21, 0x186

    .line 3020
    .line 3021
    const/16 v22, 0x7a

    .line 3022
    .line 3023
    move-object/from16 v33, v13

    .line 3024
    .line 3025
    const-wide/16 v12, 0x0

    .line 3026
    .line 3027
    const/high16 v14, 0x40400000    # 3.0f

    .line 3028
    .line 3029
    const-wide/16 v15, 0x0

    .line 3030
    .line 3031
    const/16 v17, 0x0

    .line 3032
    .line 3033
    const/16 v18, 0x0

    .line 3034
    .line 3035
    const/16 v19, 0x0

    .line 3036
    .line 3037
    move-object/from16 v20, v33

    .line 3038
    .line 3039
    invoke-static/range {v11 .. v22}, La7w0;->o(Lzgz;JFJIFLc7w0;Lkud;II)V

    .line 3040
    .line 3041
    .line 3042
    move-object/from16 v13, v20

    .line 3043
    .line 3044
    const v0, 0x7f120260

    .line 3045
    .line 3046
    .line 3047
    invoke-static {v0, v13}, Lkz30;->loo(ILkud;)Ljava/lang/String;

    .line 3048
    .line 3049
    .line 3050
    move-result-object v11

    .line 3051
    invoke-virtual {v13, v1}, Ltgn;->IO(Landroidx/compose/runtime/ll;)Ljava/lang/Object;

    .line 3052
    .line 3053
    .line 3054
    move-result-object v0

    .line 3055
    check-cast v0, Ldpx;

    .line 3056
    .line 3057
    iget-object v0, v0, Ldpx;->I:Ldal0;

    .line 3058
    .line 3059
    iget-object v0, v0, Ldal0;->IO:Lhaj0;

    .line 3060
    .line 3061
    const/16 v35, 0x0

    .line 3062
    .line 3063
    const v36, 0x1fffe

    .line 3064
    .line 3065
    .line 3066
    const/4 v12, 0x0

    .line 3067
    move-object/from16 v33, v13

    .line 3068
    .line 3069
    const-wide/16 v13, 0x0

    .line 3070
    .line 3071
    const/4 v15, 0x0

    .line 3072
    const-wide/16 v16, 0x0

    .line 3073
    .line 3074
    const/16 v18, 0x0

    .line 3075
    .line 3076
    const/16 v20, 0x0

    .line 3077
    .line 3078
    const-wide/16 v21, 0x0

    .line 3079
    .line 3080
    const/16 v23, 0x0

    .line 3081
    .line 3082
    const/16 v24, 0x0

    .line 3083
    .line 3084
    const-wide/16 v25, 0x0

    .line 3085
    .line 3086
    const/16 v27, 0x0

    .line 3087
    .line 3088
    const/16 v28, 0x0

    .line 3089
    .line 3090
    const/16 v29, 0x0

    .line 3091
    .line 3092
    const/16 v30, 0x0

    .line 3093
    .line 3094
    const/16 v31, 0x0

    .line 3095
    .line 3096
    const/16 v34, 0x0

    .line 3097
    .line 3098
    move-object/from16 v32, v0

    .line 3099
    .line 3100
    invoke-static/range {v11 .. v36}, Lm7j0;->I(Ljava/lang/String;Lzgz;JLa1j0;JLunm;Ldom;Lgmm;JLk2j0;Lj0j0;JIZIILkotlin/jvm/functions/Function1;Lhaj0;Lkud;III)V

    .line 3101
    .line 3102
    .line 3103
    move-object/from16 v13, v33

    .line 3104
    .line 3105
    const/4 v12, 0x1

    .line 3106
    invoke-virtual {v13, v12}, Ltgn;->oI(Z)V

    .line 3107
    .line 3108
    .line 3109
    const/4 v15, 0x0

    .line 3110
    invoke-virtual {v13, v15}, Ltgn;->oI(Z)V

    .line 3111
    .line 3112
    .line 3113
    goto/16 :goto_26

    .line 3114
    .line 3115
    :cond_37
    instance-of v0, v4, Lsw1;

    .line 3116
    .line 3117
    if-eqz v0, :cond_38

    .line 3118
    .line 3119
    const v0, -0x340043cb    # -3.3519722E7f

    .line 3120
    .line 3121
    .line 3122
    invoke-virtual {v13, v0}, Ltgn;->OIO(I)V

    .line 3123
    .line 3124
    .line 3125
    const-wide v0, -0x517f86a0c56e39L

    .line 3126
    .line 3127
    .line 3128
    .line 3129
    .line 3130
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 3131
    .line 3132
    .line 3133
    check-cast v4, Lsw1;

    .line 3134
    .line 3135
    iget-object v0, v4, Lsw1;->l:Ljava/lang/String;

    .line 3136
    .line 3137
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 3138
    .line 3139
    .line 3140
    move-result-object v0

    .line 3141
    const v1, 0x7f12025e

    .line 3142
    .line 3143
    .line 3144
    invoke-static {v1, v0, v13}, Lkz30;->Ill(I[Ljava/lang/Object;Lkud;)Ljava/lang/String;

    .line 3145
    .line 3146
    .line 3147
    move-result-object v20

    .line 3148
    sget-object v18, Lri1;->IlI:Lf4r;

    .line 3149
    .line 3150
    const/4 v11, 0x0

    .line 3151
    const/16 v12, 0x1a

    .line 3152
    .line 3153
    move-object/from16 v33, v13

    .line 3154
    .line 3155
    const-wide/16 v13, 0x0

    .line 3156
    .line 3157
    const-wide/16 v15, 0x0

    .line 3158
    .line 3159
    const/16 v19, 0x0

    .line 3160
    .line 3161
    move-object/from16 v17, v33

    .line 3162
    .line 3163
    invoke-static/range {v11 .. v20}, Lkc1;->O(IIJJLkud;Lf4r;Lzgz;Ljava/lang/String;)V

    .line 3164
    .line 3165
    .line 3166
    move-object/from16 v13, v17

    .line 3167
    .line 3168
    const/4 v15, 0x0

    .line 3169
    invoke-virtual {v13, v15}, Ltgn;->oI(Z)V

    .line 3170
    .line 3171
    .line 3172
    goto/16 :goto_26

    .line 3173
    .line 3174
    :cond_38
    instance-of v0, v4, Lqw1;

    .line 3175
    .line 3176
    if-eqz v0, :cond_39

    .line 3177
    .line 3178
    const v0, -0x4c061333

    .line 3179
    .line 3180
    .line 3181
    invoke-virtual {v13, v0}, Ltgn;->OIO(I)V

    .line 3182
    .line 3183
    .line 3184
    const-wide v11, -0x517fa0a0c56e39L

    .line 3185
    .line 3186
    .line 3187
    .line 3188
    .line 3189
    invoke-static {v11, v12}, Li6t0;->lO(J)Ljava/lang/String;

    .line 3190
    .line 3191
    .line 3192
    check-cast v4, Lqw1;

    .line 3193
    .line 3194
    iget-object v0, v4, Lqw1;->l:Ljava/lang/String;

    .line 3195
    .line 3196
    invoke-virtual {v13, v1}, Ltgn;->IO(Landroidx/compose/runtime/ll;)Ljava/lang/Object;

    .line 3197
    .line 3198
    .line 3199
    move-result-object v3

    .line 3200
    check-cast v3, Ldpx;

    .line 3201
    .line 3202
    iget-object v3, v3, Ldpx;->I:Ldal0;

    .line 3203
    .line 3204
    iget-object v3, v3, Ldal0;->Io:Lhaj0;

    .line 3205
    .line 3206
    invoke-virtual {v13, v1}, Ltgn;->IO(Landroidx/compose/runtime/ll;)Ljava/lang/Object;

    .line 3207
    .line 3208
    .line 3209
    move-result-object v4

    .line 3210
    check-cast v4, Ldpx;

    .line 3211
    .line 3212
    iget-object v4, v4, Ldpx;->l:Ljtc;

    .line 3213
    .line 3214
    iget-wide v11, v4, Ljtc;->llO:J

    .line 3215
    .line 3216
    move-wide/from16 v16, v11

    .line 3217
    .line 3218
    const/high16 v15, 0x3f800000    # 1.0f

    .line 3219
    .line 3220
    invoke-static {v7, v15}, Lj2f0;->lO(Lzgz;F)Lzgz;

    .line 3221
    .line 3222
    .line 3223
    move-result-object v11

    .line 3224
    sget v4, Lzee0;->l:I

    .line 3225
    .line 3226
    invoke-static {v13}, Lzee0;->Io(Lkud;)Lvne;

    .line 3227
    .line 3228
    .line 3229
    move-result-object v12

    .line 3230
    invoke-virtual {v13, v1}, Ltgn;->IO(Landroidx/compose/runtime/ll;)Ljava/lang/Object;

    .line 3231
    .line 3232
    .line 3233
    move-result-object v1

    .line 3234
    check-cast v1, Ldpx;

    .line 3235
    .line 3236
    iget-object v1, v1, Ldpx;->l:Ljtc;

    .line 3237
    .line 3238
    iget-wide v14, v1, Ljtc;->lIl:J

    .line 3239
    .line 3240
    const/16 v22, 0x0

    .line 3241
    .line 3242
    const/16 v23, 0x7d8

    .line 3243
    .line 3244
    move-object/from16 v33, v13

    .line 3245
    .line 3246
    move-wide v13, v14

    .line 3247
    const/4 v15, 0x0

    .line 3248
    move-wide/from16 v17, v16

    .line 3249
    .line 3250
    const/16 v16, 0x0

    .line 3251
    .line 3252
    move-wide/from16 v18, v17

    .line 3253
    .line 3254
    const/16 v17, 0x0

    .line 3255
    .line 3256
    move-wide/from16 v20, v18

    .line 3257
    .line 3258
    const/16 v19, 0x0

    .line 3259
    .line 3260
    move-wide/from16 v24, v20

    .line 3261
    .line 3262
    const v21, 0x180c06

    .line 3263
    .line 3264
    .line 3265
    move/from16 v18, v15

    .line 3266
    .line 3267
    move-object/from16 v20, v33

    .line 3268
    .line 3269
    invoke-static/range {v11 .. v23}, Lot8;->Io(Lzgz;Lree0;JFFLbrc;FZLkud;III)Lzgz;

    .line 3270
    .line 3271
    .line 3272
    move-result-object v1

    .line 3273
    move-object/from16 v13, v20

    .line 3274
    .line 3275
    invoke-static {v1, v6}, Lfqr;->lOo(Lzgz;F)Lzgz;

    .line 3276
    .line 3277
    .line 3278
    move-result-object v12

    .line 3279
    const/16 v35, 0x0

    .line 3280
    .line 3281
    const v36, 0x1fff8

    .line 3282
    .line 3283
    .line 3284
    const/4 v15, 0x0

    .line 3285
    const-wide/16 v16, 0x0

    .line 3286
    .line 3287
    const/16 v18, 0x0

    .line 3288
    .line 3289
    const/16 v19, 0x0

    .line 3290
    .line 3291
    const/16 v20, 0x0

    .line 3292
    .line 3293
    const-wide/16 v21, 0x0

    .line 3294
    .line 3295
    const/16 v23, 0x0

    .line 3296
    .line 3297
    move-object/from16 v33, v13

    .line 3298
    .line 3299
    move-wide/from16 v13, v24

    .line 3300
    .line 3301
    const/16 v24, 0x0

    .line 3302
    .line 3303
    const-wide/16 v25, 0x0

    .line 3304
    .line 3305
    const/16 v27, 0x0

    .line 3306
    .line 3307
    const/16 v28, 0x0

    .line 3308
    .line 3309
    const/16 v29, 0x0

    .line 3310
    .line 3311
    const/16 v30, 0x0

    .line 3312
    .line 3313
    const/16 v31, 0x0

    .line 3314
    .line 3315
    const/16 v34, 0x0

    .line 3316
    .line 3317
    move-object v11, v0

    .line 3318
    move-object/from16 v32, v3

    .line 3319
    .line 3320
    invoke-static/range {v11 .. v36}, Lm7j0;->I(Ljava/lang/String;Lzgz;JLa1j0;JLunm;Ldom;Lgmm;JLk2j0;Lj0j0;JIZIILkotlin/jvm/functions/Function1;Lhaj0;Lkud;III)V

    .line 3321
    .line 3322
    .line 3323
    move-object/from16 v13, v33

    .line 3324
    .line 3325
    const/4 v15, 0x0

    .line 3326
    invoke-virtual {v13, v15}, Ltgn;->oI(Z)V

    .line 3327
    .line 3328
    .line 3329
    goto :goto_26

    .line 3330
    :cond_39
    const/4 v15, 0x0

    .line 3331
    const v0, -0x33fff5a1    # -3.3565052E7f

    .line 3332
    .line 3333
    .line 3334
    invoke-virtual {v13, v0}, Ltgn;->OIO(I)V

    .line 3335
    .line 3336
    .line 3337
    invoke-virtual {v13, v15}, Ltgn;->oI(Z)V

    .line 3338
    .line 3339
    .line 3340
    :goto_26
    invoke-virtual {v13, v15}, Ltgn;->oI(Z)V

    .line 3341
    .line 3342
    .line 3343
    :goto_27
    const/high16 v15, 0x41000000    # 8.0f

    .line 3344
    .line 3345
    goto :goto_28

    .line 3346
    :cond_3a
    move-object v8, v2

    .line 3347
    const/4 v15, 0x0

    .line 3348
    move-object v2, v1

    .line 3349
    const v0, -0x4bfe5279

    .line 3350
    .line 3351
    .line 3352
    invoke-virtual {v13, v0}, Ltgn;->OIO(I)V

    .line 3353
    .line 3354
    .line 3355
    invoke-virtual {v13, v15}, Ltgn;->oI(Z)V

    .line 3356
    .line 3357
    .line 3358
    goto :goto_27

    .line 3359
    :goto_28
    invoke-static {v7, v15}, Lj2f0;->Il(Lzgz;F)Lzgz;

    .line 3360
    .line 3361
    .line 3362
    move-result-object v0

    .line 3363
    invoke-static {v13, v0}, Lns30;->lI(Lkud;Lzgz;)V

    .line 3364
    .line 3365
    .line 3366
    move-object/from16 v0, p0

    .line 3367
    .line 3368
    iget-boolean v15, v0, Lcom/chuanyi/voyage/ui/aichat/lll;->IO:Z

    .line 3369
    .line 3370
    iget-object v1, v0, Lcom/chuanyi/voyage/ui/aichat/lll;->Io:Lkc10;

    .line 3371
    .line 3372
    move v3, v15

    .line 3373
    iget-boolean v15, v0, Lcom/chuanyi/voyage/ui/aichat/lll;->ol:Z

    .line 3374
    .line 3375
    iget-object v4, v0, Lcom/chuanyi/voyage/ui/aichat/lll;->oI:Lkotlin/jvm/functions/Function0;

    .line 3376
    .line 3377
    iget-object v6, v0, Lcom/chuanyi/voyage/ui/aichat/lll;->q:Lkc10;

    .line 3378
    .line 3379
    if-nez v3, :cond_3d

    .line 3380
    .line 3381
    const v0, -0x4bfd0159

    .line 3382
    .line 3383
    .line 3384
    invoke-virtual {v13, v0}, Ltgn;->OIO(I)V

    .line 3385
    .line 3386
    .line 3387
    const-wide v11, -0x517fefa0c56e39L

    .line 3388
    .line 3389
    .line 3390
    .line 3391
    .line 3392
    invoke-static {v11, v12}, Li6t0;->lO(J)Ljava/lang/String;

    .line 3393
    .line 3394
    .line 3395
    sget-object v0, Lri1;->IlI:Lf4r;

    .line 3396
    .line 3397
    const/high16 v11, 0x3f800000    # 1.0f

    .line 3398
    .line 3399
    invoke-static {v7, v11}, Lj2f0;->lO(Lzgz;F)Lzgz;

    .line 3400
    .line 3401
    .line 3402
    move-result-object v12

    .line 3403
    const-wide v16, -0x51800aa0c56e39L

    .line 3404
    .line 3405
    .line 3406
    .line 3407
    .line 3408
    invoke-static/range {v16 .. v17}, Li6t0;->lO(J)Ljava/lang/String;

    .line 3409
    .line 3410
    .line 3411
    invoke-virtual {v13, v5}, Ltgn;->lO(Ljava/lang/Object;)Z

    .line 3412
    .line 3413
    .line 3414
    move-result v3

    .line 3415
    invoke-virtual {v13, v8}, Ltgn;->lO(Ljava/lang/Object;)Z

    .line 3416
    .line 3417
    .line 3418
    move-result v7

    .line 3419
    or-int/2addr v3, v7

    .line 3420
    invoke-virtual {v13, v1}, Ltgn;->lO(Ljava/lang/Object;)Z

    .line 3421
    .line 3422
    .line 3423
    move-result v7

    .line 3424
    or-int/2addr v3, v7

    .line 3425
    invoke-virtual {v13, v10}, Ltgn;->Il(Ljava/lang/Object;)Z

    .line 3426
    .line 3427
    .line 3428
    move-result v7

    .line 3429
    or-int/2addr v3, v7

    .line 3430
    invoke-virtual {v13, v2}, Ltgn;->lO(Ljava/lang/Object;)Z

    .line 3431
    .line 3432
    .line 3433
    move-result v7

    .line 3434
    or-int/2addr v3, v7

    .line 3435
    move-object/from16 v7, v44

    .line 3436
    .line 3437
    invoke-virtual {v13, v7}, Ltgn;->lO(Ljava/lang/Object;)Z

    .line 3438
    .line 3439
    .line 3440
    move-result v11

    .line 3441
    or-int/2addr v3, v11

    .line 3442
    move-object/from16 v11, v42

    .line 3443
    .line 3444
    invoke-virtual {v13, v11}, Ltgn;->Il(Ljava/lang/Object;)Z

    .line 3445
    .line 3446
    .line 3447
    move-result v14

    .line 3448
    or-int/2addr v3, v14

    .line 3449
    invoke-virtual {v13, v15}, Ltgn;->lo(Z)Z

    .line 3450
    .line 3451
    .line 3452
    move-result v14

    .line 3453
    or-int/2addr v3, v14

    .line 3454
    invoke-virtual {v13, v4}, Ltgn;->lO(Ljava/lang/Object;)Z

    .line 3455
    .line 3456
    .line 3457
    move-result v14

    .line 3458
    or-int/2addr v3, v14

    .line 3459
    invoke-virtual {v13}, Ltgn;->IIo()Ljava/lang/Object;

    .line 3460
    .line 3461
    .line 3462
    move-result-object v14

    .line 3463
    if-nez v3, :cond_3b

    .line 3464
    .line 3465
    if-ne v14, v9, :cond_3c

    .line 3466
    .line 3467
    :cond_3b
    new-instance v14, Lmf1;

    .line 3468
    .line 3469
    const/16 v25, 0x0

    .line 3470
    .line 3471
    move-object/from16 v20, v1

    .line 3472
    .line 3473
    move-object/from16 v19, v2

    .line 3474
    .line 3475
    move-object/from16 v23, v4

    .line 3476
    .line 3477
    move-object/from16 v16, v5

    .line 3478
    .line 3479
    move-object/from16 v24, v6

    .line 3480
    .line 3481
    move-object/from16 v21, v7

    .line 3482
    .line 3483
    move-object/from16 v17, v8

    .line 3484
    .line 3485
    move-object/from16 v18, v10

    .line 3486
    .line 3487
    move-object/from16 v22, v11

    .line 3488
    .line 3489
    invoke-direct/range {v14 .. v25}, Lmf1;-><init>(ZLkc10;Lkc10;Lza1;Ljava/lang/String;Lkc10;Ljava/lang/String;Landroid/content/Context;Lkotlin/jvm/functions/Function0;Lkc10;B)V

    .line 3490
    .line 3491
    .line 3492
    invoke-virtual {v13, v14}, Ltgn;->oll(Ljava/lang/Object;)V

    .line 3493
    .line 3494
    .line 3495
    :cond_3c
    move-object v11, v14

    .line 3496
    check-cast v11, Lkotlin/jvm/functions/Function0;

    .line 3497
    .line 3498
    sget-object v17, Lrfs0;->II:Lggd;

    .line 3499
    .line 3500
    const v19, 0x30030

    .line 3501
    .line 3502
    .line 3503
    const/16 v20, 0xc

    .line 3504
    .line 3505
    move-object/from16 v33, v13

    .line 3506
    .line 3507
    const/4 v13, 0x0

    .line 3508
    const-wide/16 v14, 0x0

    .line 3509
    .line 3510
    move-object/from16 v16, v0

    .line 3511
    .line 3512
    move-object/from16 v18, v33

    .line 3513
    .line 3514
    invoke-static/range {v11 .. v20}, Lkc1;->lo(Lkotlin/jvm/functions/Function0;Lzgz;ZJLf4r;Lkotlin/jvm/functions/Function3;Lkud;II)V

    .line 3515
    .line 3516
    .line 3517
    move-object/from16 v13, v18

    .line 3518
    .line 3519
    const/4 v15, 0x0

    .line 3520
    invoke-virtual {v13, v15}, Ltgn;->oI(Z)V

    .line 3521
    .line 3522
    .line 3523
    goto/16 :goto_29

    .line 3524
    .line 3525
    :cond_3d
    move-object v14, v2

    .line 3526
    move-object/from16 v24, v6

    .line 3527
    .line 3528
    move-object/from16 v11, v42

    .line 3529
    .line 3530
    move-object/from16 v2, v44

    .line 3531
    .line 3532
    if-nez v15, :cond_40

    .line 3533
    .line 3534
    const v6, -0x4bf94b01

    .line 3535
    .line 3536
    .line 3537
    invoke-virtual {v13, v6}, Ltgn;->OIO(I)V

    .line 3538
    .line 3539
    .line 3540
    const-wide v15, -0x51802ba0c56e39L

    .line 3541
    .line 3542
    .line 3543
    .line 3544
    .line 3545
    invoke-static/range {v15 .. v16}, Li6t0;->lO(J)Ljava/lang/String;

    .line 3546
    .line 3547
    .line 3548
    sget-object v6, Lri1;->IlI:Lf4r;

    .line 3549
    .line 3550
    const/high16 v12, 0x3f800000    # 1.0f

    .line 3551
    .line 3552
    invoke-static {v7, v12}, Lj2f0;->lO(Lzgz;F)Lzgz;

    .line 3553
    .line 3554
    .line 3555
    move-result-object v12

    .line 3556
    const-wide v7, -0x518046a0c56e39L

    .line 3557
    .line 3558
    .line 3559
    .line 3560
    .line 3561
    invoke-static {v7, v8}, Li6t0;->lO(J)Ljava/lang/String;

    .line 3562
    .line 3563
    .line 3564
    invoke-virtual {v13, v3}, Ltgn;->lo(Z)Z

    .line 3565
    .line 3566
    .line 3567
    move-result v7

    .line 3568
    invoke-virtual {v13, v1}, Ltgn;->lO(Ljava/lang/Object;)Z

    .line 3569
    .line 3570
    .line 3571
    move-result v8

    .line 3572
    or-int/2addr v7, v8

    .line 3573
    invoke-virtual {v13, v5}, Ltgn;->lO(Ljava/lang/Object;)Z

    .line 3574
    .line 3575
    .line 3576
    move-result v8

    .line 3577
    or-int/2addr v7, v8

    .line 3578
    invoke-virtual {v13, v10}, Ltgn;->Il(Ljava/lang/Object;)Z

    .line 3579
    .line 3580
    .line 3581
    move-result v8

    .line 3582
    or-int/2addr v7, v8

    .line 3583
    invoke-virtual {v13, v14}, Ltgn;->lO(Ljava/lang/Object;)Z

    .line 3584
    .line 3585
    .line 3586
    move-result v8

    .line 3587
    or-int/2addr v7, v8

    .line 3588
    invoke-virtual {v13, v2}, Ltgn;->lO(Ljava/lang/Object;)Z

    .line 3589
    .line 3590
    .line 3591
    move-result v8

    .line 3592
    or-int/2addr v7, v8

    .line 3593
    invoke-virtual {v13, v11}, Ltgn;->Il(Ljava/lang/Object;)Z

    .line 3594
    .line 3595
    .line 3596
    move-result v8

    .line 3597
    or-int/2addr v7, v8

    .line 3598
    invoke-virtual {v13, v4}, Ltgn;->lO(Ljava/lang/Object;)Z

    .line 3599
    .line 3600
    .line 3601
    move-result v8

    .line 3602
    or-int/2addr v7, v8

    .line 3603
    iget-boolean v8, v0, Lcom/chuanyi/voyage/ui/aichat/lll;->oO:Z

    .line 3604
    .line 3605
    invoke-virtual {v13, v8}, Ltgn;->lo(Z)Z

    .line 3606
    .line 3607
    .line 3608
    move-result v15

    .line 3609
    or-int/2addr v7, v15

    .line 3610
    iget-object v0, v0, Lcom/chuanyi/voyage/ui/aichat/lll;->oo:Lkc10;

    .line 3611
    .line 3612
    invoke-virtual {v13, v0}, Ltgn;->lO(Ljava/lang/Object;)Z

    .line 3613
    .line 3614
    .line 3615
    move-result v15

    .line 3616
    or-int/2addr v7, v15

    .line 3617
    invoke-virtual {v13}, Ltgn;->IIo()Ljava/lang/Object;

    .line 3618
    .line 3619
    .line 3620
    move-result-object v15

    .line 3621
    if-nez v7, :cond_3e

    .line 3622
    .line 3623
    if-ne v15, v9, :cond_3f

    .line 3624
    .line 3625
    :cond_3e
    move-object/from16 v18, v14

    .line 3626
    .line 3627
    new-instance v14, Lnf1;

    .line 3628
    .line 3629
    const/16 v26, 0x0

    .line 3630
    .line 3631
    move-object/from16 v25, v0

    .line 3632
    .line 3633
    move-object/from16 v21, v2

    .line 3634
    .line 3635
    move v15, v3

    .line 3636
    move-object/from16 v23, v4

    .line 3637
    .line 3638
    move-object/from16 v19, v5

    .line 3639
    .line 3640
    move/from16 v16, v8

    .line 3641
    .line 3642
    move-object/from16 v17, v10

    .line 3643
    .line 3644
    move-object/from16 v22, v11

    .line 3645
    .line 3646
    move-object/from16 v20, v18

    .line 3647
    .line 3648
    move-object/from16 v18, v1

    .line 3649
    .line 3650
    invoke-direct/range {v14 .. v26}, Lnf1;-><init>(ZZLza1;Lkc10;Lkc10;Ljava/lang/String;Ljava/lang/String;Landroid/content/Context;Lkotlin/jvm/functions/Function0;Lkc10;Lkc10;B)V

    .line 3651
    .line 3652
    .line 3653
    invoke-virtual {v13, v14}, Ltgn;->oll(Ljava/lang/Object;)V

    .line 3654
    .line 3655
    .line 3656
    move-object v15, v14

    .line 3657
    :cond_3f
    move-object v11, v15

    .line 3658
    check-cast v11, Lkotlin/jvm/functions/Function0;

    .line 3659
    .line 3660
    sget-object v17, Lrfs0;->IO:Lggd;

    .line 3661
    .line 3662
    const v19, 0x30030

    .line 3663
    .line 3664
    .line 3665
    const/16 v20, 0xc

    .line 3666
    .line 3667
    move-object/from16 v33, v13

    .line 3668
    .line 3669
    const/4 v13, 0x0

    .line 3670
    const-wide/16 v14, 0x0

    .line 3671
    .line 3672
    move-object/from16 v16, v6

    .line 3673
    .line 3674
    move-object/from16 v18, v33

    .line 3675
    .line 3676
    invoke-static/range {v11 .. v20}, Lkc1;->lo(Lkotlin/jvm/functions/Function0;Lzgz;ZJLf4r;Lkotlin/jvm/functions/Function3;Lkud;II)V

    .line 3677
    .line 3678
    .line 3679
    move-object/from16 v13, v18

    .line 3680
    .line 3681
    const/4 v15, 0x0

    .line 3682
    invoke-virtual {v13, v15}, Ltgn;->oI(Z)V

    .line 3683
    .line 3684
    .line 3685
    goto :goto_29

    .line 3686
    :cond_40
    const/4 v15, 0x0

    .line 3687
    const v0, -0x4bf725b9

    .line 3688
    .line 3689
    .line 3690
    invoke-virtual {v13, v0}, Ltgn;->OIO(I)V

    .line 3691
    .line 3692
    .line 3693
    invoke-virtual {v13, v15}, Ltgn;->oI(Z)V

    .line 3694
    .line 3695
    .line 3696
    goto :goto_29

    .line 3697
    :cond_41
    invoke-virtual {v13}, Ltgn;->Ioo()V

    .line 3698
    .line 3699
    .line 3700
    :goto_29
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 3701
    .line 3702
    return-object v0
.end method
