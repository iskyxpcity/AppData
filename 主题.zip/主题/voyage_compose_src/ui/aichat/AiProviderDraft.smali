.class final Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;
.super Ljava/lang/Object;
.source "S"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000T\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0010\u000b\n\u0002\u0008\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0010\u0008\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0002\u0008\u0017\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\u0008\u001b\u0008\u0083\u0008\u0018\u0000 L2\u00020\u0001:\u0002MNB]\u0012\u0008\u0008\u0002\u0010\u0003\u001a\u00020\u0002\u0012\u0008\u0008\u0002\u0010\u0005\u001a\u00020\u0004\u0012\u0008\u0008\u0002\u0010\u0006\u001a\u00020\u0002\u0012\u0008\u0008\u0002\u0010\u0007\u001a\u00020\u0002\u0012\u0008\u0008\u0002\u0010\u0008\u001a\u00020\u0002\u0012\u0008\u0008\u0002\u0010\n\u001a\u00020\t\u0012\u0008\u0008\u0002\u0010\u000b\u001a\u00020\t\u0012\u000e\u0008\u0002\u0010\u000e\u001a\u0008\u0012\u0004\u0012\u00020\r0\u000c\u00a2\u0006\u0004\u0008\u000f\u0010\u0010Bm\u0008\u0010\u0012\u0006\u0010\u0012\u001a\u00020\u0011\u0012\u0008\u0010\u0003\u001a\u0004\u0018\u00010\u0002\u0012\u0008\u0010\u0005\u001a\u0004\u0018\u00010\u0004\u0012\u0008\u0010\u0006\u001a\u0004\u0018\u00010\u0002\u0012\u0008\u0010\u0007\u001a\u0004\u0018\u00010\u0002\u0012\u0008\u0010\u0008\u001a\u0004\u0018\u00010\u0002\u0012\u0006\u0010\n\u001a\u00020\t\u0012\u0006\u0010\u000b\u001a\u00020\t\u0012\u000e\u0010\u000e\u001a\n\u0012\u0004\u0012\u00020\r\u0018\u00010\u000c\u0012\u0008\u0010\u0014\u001a\u0004\u0018\u00010\u0013\u00a2\u0006\u0004\u0008\u000f\u0010\u0015J\u001d\u0010\u0019\u001a\u00020\u00182\u0006\u0010\u0016\u001a\u00020\u00022\u0006\u0010\u0017\u001a\u00020\u0002\u00a2\u0006\u0004\u0008\u0019\u0010\u001aJ\u0010\u0010\u001b\u001a\u00020\u0002H\u00c6\u0003\u00a2\u0006\u0004\u0008\u001b\u0010\u001cJ\u0010\u0010\u001d\u001a\u00020\u0004H\u00c6\u0003\u00a2\u0006\u0004\u0008\u001d\u0010\u001eJ\u0010\u0010\u001f\u001a\u00020\u0002H\u00c6\u0003\u00a2\u0006\u0004\u0008\u001f\u0010\u001cJ\u0010\u0010 \u001a\u00020\u0002H\u00c6\u0003\u00a2\u0006\u0004\u0008 \u0010\u001cJ\u0010\u0010!\u001a\u00020\u0002H\u00c6\u0003\u00a2\u0006\u0004\u0008!\u0010\u001cJ\u0010\u0010\"\u001a\u00020\tH\u00c6\u0003\u00a2\u0006\u0004\u0008\"\u0010#J\u0010\u0010$\u001a\u00020\tH\u00c6\u0003\u00a2\u0006\u0004\u0008$\u0010#J\u0016\u0010%\u001a\u0008\u0012\u0004\u0012\u00020\r0\u000cH\u00c6\u0003\u00a2\u0006\u0004\u0008%\u0010&Jf\u0010\'\u001a\u00020\u00002\u0008\u0008\u0002\u0010\u0003\u001a\u00020\u00022\u0008\u0008\u0002\u0010\u0005\u001a\u00020\u00042\u0008\u0008\u0002\u0010\u0006\u001a\u00020\u00022\u0008\u0008\u0002\u0010\u0007\u001a\u00020\u00022\u0008\u0008\u0002\u0010\u0008\u001a\u00020\u00022\u0008\u0008\u0002\u0010\n\u001a\u00020\t2\u0008\u0008\u0002\u0010\u000b\u001a\u00020\t2\u000e\u0008\u0002\u0010\u000e\u001a\u0008\u0012\u0004\u0012\u00020\r0\u000cH\u00c6\u0001\u00a2\u0006\u0004\u0008\'\u0010(J\u0010\u0010)\u001a\u00020\u0002H\u00d6\u0001\u00a2\u0006\u0004\u0008)\u0010\u001cJ\u0010\u0010*\u001a\u00020\u0011H\u00d6\u0001\u00a2\u0006\u0004\u0008*\u0010+J\u001a\u0010-\u001a\u00020\t2\u0008\u0010,\u001a\u0004\u0018\u00010\u0001H\u00d6\u0003\u00a2\u0006\u0004\u0008-\u0010.J\'\u00107\u001a\u0002042\u0006\u0010/\u001a\u00020\u00002\u0006\u00101\u001a\u0002002\u0006\u00103\u001a\u000202H\u0001\u00a2\u0006\u0004\u00085\u00106R\u0017\u0010\u0003\u001a\u00020\u00028\u0006\u00a2\u0006\u000c\n\u0004\u0008\u0003\u00108\u001a\u0004\u00089\u0010\u001cR\u0017\u0010\u0005\u001a\u00020\u00048\u0006\u00a2\u0006\u000c\n\u0004\u0008\u0005\u0010:\u001a\u0004\u0008;\u0010\u001eR\u0017\u0010\u0006\u001a\u00020\u00028\u0006\u00a2\u0006\u000c\n\u0004\u0008\u0006\u00108\u001a\u0004\u0008<\u0010\u001cR\u0017\u0010\u0007\u001a\u00020\u00028\u0006\u00a2\u0006\u000c\n\u0004\u0008\u0007\u00108\u001a\u0004\u0008=\u0010\u001cR\u0017\u0010\u0008\u001a\u00020\u00028\u0006\u00a2\u0006\u000c\n\u0004\u0008\u0008\u00108\u001a\u0004\u0008>\u0010\u001cR\u0017\u0010\n\u001a\u00020\t8\u0006\u00a2\u0006\u000c\n\u0004\u0008\n\u0010?\u001a\u0004\u0008@\u0010#R\u0017\u0010\u000b\u001a\u00020\t8\u0006\u00a2\u0006\u000c\n\u0004\u0008\u000b\u0010?\u001a\u0004\u0008A\u0010#R\u001d\u0010\u000e\u001a\u0008\u0012\u0004\u0012\u00020\r0\u000c8\u0006\u00a2\u0006\u000c\n\u0004\u0008\u000e\u0010B\u001a\u0004\u0008C\u0010&R\u0011\u0010E\u001a\u00020\t8F\u00a2\u0006\u0006\u001a\u0004\u0008D\u0010#R\u0011\u0010G\u001a\u00020\t8F\u00a2\u0006\u0006\u001a\u0004\u0008F\u0010#R\u0011\u0010I\u001a\u00020\t8F\u00a2\u0006\u0006\u001a\u0004\u0008H\u0010#R\u0011\u0010K\u001a\u00020\t8F\u00a2\u0006\u0006\u001a\u0004\u0008J\u0010#\u00a8\u0006O"
    }
    d2 = {
        "Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;",
        "",
        "",
        "name",
        "Ldx1;",
        "type",
        "baseUrl",
        "key",
        "headers",
        "",
        "enabled",
        "responses",
        "",
        "Lgt1;",
        "models",
        "<init>",
        "(Ljava/lang/String;Ldx1;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZLjava/util/List;)V",
        "",
        "seen0",
        "Lu3e0;",
        "serializationConstructorMarker",
        "(ILjava/lang/String;Ldx1;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZLjava/util/List;Lu3e0;)V",
        "id",
        "fallbackName",
        "Lxw1;",
        "provider",
        "(Ljava/lang/String;Ljava/lang/String;)Lxw1;",
        "component1",
        "()Ljava/lang/String;",
        "component2",
        "()Ldx1;",
        "component3",
        "component4",
        "component5",
        "component6",
        "()Z",
        "component7",
        "component8",
        "()Ljava/util/List;",
        "copy",
        "(Ljava/lang/String;Ldx1;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZLjava/util/List;)Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;",
        "toString",
        "hashCode",
        "()I",
        "other",
        "equals",
        "(Ljava/lang/Object;)Z",
        "self",
        "Lvud;",
        "output",
        "Le3e0;",
        "serialDesc",
        "",
        "write$Self$app",
        "(Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;Lvud;Le3e0;)V",
        "write$Self",
        "Ljava/lang/String;",
        "getName",
        "Ldx1;",
        "getType",
        "getBaseUrl",
        "getKey",
        "getHeaders",
        "Z",
        "getEnabled",
        "getResponses",
        "Ljava/util/List;",
        "getModels",
        "getUrlInvalid",
        "urlInvalid",
        "getUrlMissing",
        "urlMissing",
        "getKeyMissing",
        "keyMissing",
        "getValid",
        "valid",
        "Companion",
        "yw1",
        "com/chuanyi/voyage/ui/aichat/IlO",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation

.annotation runtime Lq3e0;
.end annotation


# static fields
.field private static final $childSerializers:[Laau;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "Laau;"
        }
    .end annotation
.end field

.field public static final Companion:Lyw1;


# instance fields
.field private final baseUrl:Ljava/lang/String;

.field private final enabled:Z

.field private final headers:Ljava/lang/String;

.field private final key:Ljava/lang/String;

.field private final models:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lgt1;",
            ">;"
        }
    .end annotation
.end field

.field private final name:Ljava/lang/String;

.field private final responses:Z

.field private final type:Ldx1;


# direct methods
.method static constructor <clinit>()V
    .locals 6

    .line 1
    new-instance v0, Lyw1;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->Companion:Lyw1;

    .line 7
    .line 8
    sget-object v0, Lygu;->I:Lygu;

    .line 9
    .line 10
    new-instance v1, Lcom/chuanyi/voyage/ui/aichat/IlI;

    .line 11
    .line 12
    const/4 v2, 0x0

    .line 13
    invoke-direct {v1, v2}, Lcom/chuanyi/voyage/ui/aichat/IlI;-><init>(B)V

    .line 14
    .line 15
    .line 16
    invoke-static {v0, v1}, Lesm;->Ol(Lygu;Lkotlin/jvm/functions/Function0;)Laau;

    .line 17
    .line 18
    .line 19
    move-result-object v1

    .line 20
    new-instance v3, Lcom/chuanyi/voyage/ui/aichat/IlI;

    .line 21
    .line 22
    const/4 v4, 0x1

    .line 23
    invoke-direct {v3, v4}, Lcom/chuanyi/voyage/ui/aichat/IlI;-><init>(B)V

    .line 24
    .line 25
    .line 26
    invoke-static {v0, v3}, Lesm;->Ol(Lygu;Lkotlin/jvm/functions/Function0;)Laau;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    const/16 v3, 0x8

    .line 31
    .line 32
    new-array v3, v3, [Laau;

    .line 33
    .line 34
    const/4 v5, 0x0

    .line 35
    aput-object v5, v3, v2

    .line 36
    .line 37
    aput-object v1, v3, v4

    .line 38
    .line 39
    const/4 v1, 0x2

    .line 40
    aput-object v5, v3, v1

    .line 41
    .line 42
    const/4 v1, 0x3

    .line 43
    aput-object v5, v3, v1

    .line 44
    .line 45
    const/4 v1, 0x4

    .line 46
    aput-object v5, v3, v1

    .line 47
    .line 48
    const/4 v1, 0x5

    .line 49
    aput-object v5, v3, v1

    .line 50
    .line 51
    const/4 v1, 0x6

    .line 52
    aput-object v5, v3, v1

    .line 53
    .line 54
    const/4 v1, 0x7

    .line 55
    aput-object v0, v3, v1

    .line 56
    .line 57
    sput-object v3, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->$childSerializers:[Laau;

    .line 58
    .line 59
    return-void
.end method

.method public constructor <init>()V
    .locals 11

    .line 131
    const/16 v9, 0xff

    const/4 v10, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    move-object v0, p0

    invoke-direct/range {v0 .. v10}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;-><init>(Ljava/lang/String;Ldx1;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZLjava/util/List;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/String;Ldx1;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZLjava/util/List;Lu3e0;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    and-int/lit8 p10, p1, 0x1

    .line 5
    .line 6
    if-nez p10, :cond_0

    .line 7
    .line 8
    const-wide v0, -0x527443a0c56e39L

    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 14
    .line 15
    .line 16
    move-result-object p2

    .line 17
    :cond_0
    iput-object p2, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->name:Ljava/lang/String;

    .line 18
    .line 19
    and-int/lit8 p2, p1, 0x2

    .line 20
    .line 21
    if-nez p2, :cond_1

    .line 22
    .line 23
    sget-object p2, Ldx1;->lI:Ldx1;

    .line 24
    .line 25
    iput-object p2, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->type:Ldx1;

    .line 26
    .line 27
    goto :goto_0

    .line 28
    :cond_1
    iput-object p3, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->type:Ldx1;

    .line 29
    .line 30
    :goto_0
    and-int/lit8 p2, p1, 0x4

    .line 31
    .line 32
    if-nez p2, :cond_2

    .line 33
    .line 34
    const-wide p2, -0x527444a0c56e39L

    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    invoke-static {p2, p3}, Li6t0;->lO(J)Ljava/lang/String;

    .line 40
    .line 41
    .line 42
    move-result-object p2

    .line 43
    iput-object p2, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->baseUrl:Ljava/lang/String;

    .line 44
    .line 45
    goto :goto_1

    .line 46
    :cond_2
    iput-object p4, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->baseUrl:Ljava/lang/String;

    .line 47
    .line 48
    :goto_1
    and-int/lit8 p2, p1, 0x8

    .line 49
    .line 50
    if-nez p2, :cond_3

    .line 51
    .line 52
    const-wide p2, -0x527445a0c56e39L

    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    invoke-static {p2, p3}, Li6t0;->lO(J)Ljava/lang/String;

    .line 58
    .line 59
    .line 60
    move-result-object p2

    .line 61
    iput-object p2, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->key:Ljava/lang/String;

    .line 62
    .line 63
    goto :goto_2

    .line 64
    :cond_3
    iput-object p5, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->key:Ljava/lang/String;

    .line 65
    .line 66
    :goto_2
    and-int/lit8 p2, p1, 0x10

    .line 67
    .line 68
    if-nez p2, :cond_4

    .line 69
    .line 70
    const-wide p2, -0x527446a0c56e39L

    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    invoke-static {p2, p3}, Li6t0;->lO(J)Ljava/lang/String;

    .line 76
    .line 77
    .line 78
    move-result-object p2

    .line 79
    iput-object p2, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->headers:Ljava/lang/String;

    .line 80
    .line 81
    goto :goto_3

    .line 82
    :cond_4
    iput-object p6, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->headers:Ljava/lang/String;

    .line 83
    .line 84
    :goto_3
    and-int/lit8 p2, p1, 0x20

    .line 85
    .line 86
    if-nez p2, :cond_5

    .line 87
    .line 88
    const/4 p2, 0x1

    .line 89
    iput-boolean p2, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->enabled:Z

    .line 90
    .line 91
    goto :goto_4

    .line 92
    :cond_5
    iput-boolean p7, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->enabled:Z

    .line 93
    .line 94
    :goto_4
    and-int/lit8 p2, p1, 0x40

    .line 95
    .line 96
    if-nez p2, :cond_6

    .line 97
    .line 98
    const/4 p2, 0x0

    .line 99
    iput-boolean p2, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->responses:Z

    .line 100
    .line 101
    goto :goto_5

    .line 102
    :cond_6
    iput-boolean p8, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->responses:Z

    .line 103
    .line 104
    :goto_5
    and-int/lit16 p1, p1, 0x80

    .line 105
    .line 106
    if-nez p1, :cond_7

    .line 107
    .line 108
    invoke-static {}, Loqc;->emptyList()Ljava/util/List;

    .line 109
    .line 110
    .line 111
    move-result-object p1

    .line 112
    iput-object p1, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->models:Ljava/util/List;

    .line 113
    .line 114
    return-void

    .line 115
    :cond_7
    iput-object p9, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->models:Ljava/util/List;

    .line 116
    .line 117
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ldx1;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZLjava/util/List;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ldx1;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "ZZ",
            "Ljava/util/List<",
            "Lgt1;",
            ">;)V"
        }
    .end annotation

    const-wide v0, -0x527373a0c56e39L

    const-wide v2, -0x527378a0c56e39L

    .line 118
    invoke-static {v0, v1, p1, v2, v3}, Lns;->lll(JLjava/lang/String;J)V

    .line 119
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-wide v0, -0x52737da0c56e39L

    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-wide v0, -0x527385a0c56e39L

    const-wide v2, -0x527389a0c56e39L

    .line 120
    invoke-static {v0, v1, p4, v2, v3}, Lns;->lll(JLjava/lang/String;J)V

    const-wide v0, -0x527391a0c56e39L

    .line 121
    invoke-static {v0, v1, p5, p8}, Lj51;->lII(JLjava/lang/String;Ljava/util/List;)V

    .line 122
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 123
    iput-object p1, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->name:Ljava/lang/String;

    .line 124
    iput-object p2, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->type:Ldx1;

    .line 125
    iput-object p3, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->baseUrl:Ljava/lang/String;

    .line 126
    iput-object p4, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->key:Ljava/lang/String;

    .line 127
    iput-object p5, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->headers:Ljava/lang/String;

    .line 128
    iput-boolean p6, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->enabled:Z

    .line 129
    iput-boolean p7, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->responses:Z

    .line 130
    iput-object p8, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->models:Ljava/util/List;

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Ldx1;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZLjava/util/List;ILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 2

    and-int/lit8 p10, p9, 0x1

    if-eqz p10, :cond_0

    const-wide v0, -0x527398a0c56e39L

    .line 132
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    move-result-object p1

    :cond_0
    and-int/lit8 p10, p9, 0x2

    if-eqz p10, :cond_1

    .line 133
    sget-object p2, Ldx1;->lI:Ldx1;

    :cond_1
    and-int/lit8 p10, p9, 0x4

    if-eqz p10, :cond_2

    const-wide v0, -0x527399a0c56e39L

    .line 134
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    move-result-object p3

    :cond_2
    and-int/lit8 p10, p9, 0x8

    if-eqz p10, :cond_3

    const-wide v0, -0x52739aa0c56e39L

    .line 135
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    move-result-object p4

    :cond_3
    and-int/lit8 p10, p9, 0x10

    if-eqz p10, :cond_4

    const-wide v0, -0x52739ba0c56e39L

    .line 136
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    move-result-object p5

    :cond_4
    and-int/lit8 p10, p9, 0x20

    if-eqz p10, :cond_5

    const/4 p6, 0x1

    :cond_5
    and-int/lit8 p10, p9, 0x40

    if-eqz p10, :cond_6

    const/4 p7, 0x0

    :cond_6
    and-int/lit16 p9, p9, 0x80

    if-eqz p9, :cond_7

    .line 137
    invoke-static {}, Loqc;->emptyList()Ljava/util/List;

    move-result-object p8

    :cond_7
    move p9, p7

    move-object p10, p8

    move-object p7, p5

    move p8, p6

    move-object p5, p3

    move-object p6, p4

    move-object p3, p1

    move-object p4, p2

    move-object p2, p0

    .line 138
    invoke-direct/range {p2 .. p10}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;-><init>(Ljava/lang/String;Ldx1;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZLjava/util/List;)V

    return-void
.end method

.method public static synthetic I()Ld9t;
    .locals 1

    .line 1
    invoke-static {}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->_childSerializers$_anonymous_()Ld9t;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    return-object v0
.end method

.method private static final synthetic _childSerializers$_anonymous_()Ld9t;
    .locals 1

    .line 1
    sget-object v0, Ldx1;->Companion:Lcx1;

    .line 2
    .line 3
    invoke-virtual {v0}, Lcx1;->serializer()Ld9t;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    return-object v0
.end method

.method private static final synthetic _childSerializers$_anonymous_$0()Ld9t;
    .locals 2

    .line 1
    new-instance v0, Lny5;

    .line 2
    .line 3
    sget-object v1, Let1;->l:Let1;

    .line 4
    .line 5
    invoke-direct {v0, v1}, Lny5;-><init>(Ld9t;)V

    .line 6
    .line 7
    .line 8
    return-object v0
.end method

.method public static final synthetic access$get$childSerializers$cp()[Laau;
    .locals 1

    .line 1
    sget-object v0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->$childSerializers:[Laau;

    .line 2
    .line 3
    return-object v0
.end method

.method public static synthetic copy$default(Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;Ljava/lang/String;Ldx1;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZLjava/util/List;ILjava/lang/Object;)Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;
    .locals 0

    .line 1
    and-int/lit8 p10, p9, 0x1

    .line 2
    .line 3
    if-eqz p10, :cond_0

    .line 4
    .line 5
    iget-object p1, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->name:Ljava/lang/String;

    .line 6
    .line 7
    :cond_0
    and-int/lit8 p10, p9, 0x2

    .line 8
    .line 9
    if-eqz p10, :cond_1

    .line 10
    .line 11
    iget-object p2, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->type:Ldx1;

    .line 12
    .line 13
    :cond_1
    and-int/lit8 p10, p9, 0x4

    .line 14
    .line 15
    if-eqz p10, :cond_2

    .line 16
    .line 17
    iget-object p3, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->baseUrl:Ljava/lang/String;

    .line 18
    .line 19
    :cond_2
    and-int/lit8 p10, p9, 0x8

    .line 20
    .line 21
    if-eqz p10, :cond_3

    .line 22
    .line 23
    iget-object p4, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->key:Ljava/lang/String;

    .line 24
    .line 25
    :cond_3
    and-int/lit8 p10, p9, 0x10

    .line 26
    .line 27
    if-eqz p10, :cond_4

    .line 28
    .line 29
    iget-object p5, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->headers:Ljava/lang/String;

    .line 30
    .line 31
    :cond_4
    and-int/lit8 p10, p9, 0x20

    .line 32
    .line 33
    if-eqz p10, :cond_5

    .line 34
    .line 35
    iget-boolean p6, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->enabled:Z

    .line 36
    .line 37
    :cond_5
    and-int/lit8 p10, p9, 0x40

    .line 38
    .line 39
    if-eqz p10, :cond_6

    .line 40
    .line 41
    iget-boolean p7, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->responses:Z

    .line 42
    .line 43
    :cond_6
    and-int/lit16 p9, p9, 0x80

    .line 44
    .line 45
    if-eqz p9, :cond_7

    .line 46
    .line 47
    iget-object p8, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->models:Ljava/util/List;

    .line 48
    .line 49
    :cond_7
    move p9, p7

    .line 50
    move-object p10, p8

    .line 51
    move-object p7, p5

    .line 52
    move p8, p6

    .line 53
    move-object p5, p3

    .line 54
    move-object p6, p4

    .line 55
    move-object p3, p1

    .line 56
    move-object p4, p2

    .line 57
    move-object p2, p0

    .line 58
    invoke-virtual/range {p2 .. p10}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->copy(Ljava/lang/String;Ldx1;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZLjava/util/List;)Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 59
    .line 60
    .line 61
    move-result-object p0

    .line 62
    return-object p0
.end method

.method public static synthetic l()Ld9t;
    .locals 1

    .line 1
    invoke-static {}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->_childSerializers$_anonymous_$0()Ld9t;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    return-object v0
.end method

.method public static final synthetic write$Self$app(Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;Lvud;Le3e0;)V
    .locals 5
    .annotation runtime Lkotlin/jvm/JvmStatic;
    .end annotation

    .line 1
    sget-object v0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->$childSerializers:[Laau;

    .line 2
    .line 3
    invoke-interface {p1, p2}, Lvud;->ll(Le3e0;)Z

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    if-eqz v1, :cond_0

    .line 8
    .line 9
    goto :goto_0

    .line 10
    :cond_0
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->name:Ljava/lang/String;

    .line 11
    .line 12
    const-wide v2, -0x52743fa0c56e39L

    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    invoke-static {v2, v3}, Li6t0;->lO(J)Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object v2

    .line 21
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 22
    .line 23
    .line 24
    move-result v1

    .line 25
    if-nez v1, :cond_1

    .line 26
    .line 27
    :goto_0
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->name:Ljava/lang/String;

    .line 28
    .line 29
    const/4 v2, 0x0

    .line 30
    invoke-interface {p1, p2, v2, v1}, Lvud;->lII(Le3e0;ILjava/lang/String;)V

    .line 31
    .line 32
    .line 33
    :cond_1
    invoke-interface {p1, p2}, Lvud;->ll(Le3e0;)Z

    .line 34
    .line 35
    .line 36
    move-result v1

    .line 37
    const/4 v2, 0x1

    .line 38
    if-eqz v1, :cond_2

    .line 39
    .line 40
    goto :goto_1

    .line 41
    :cond_2
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->type:Ldx1;

    .line 42
    .line 43
    sget-object v3, Ldx1;->lI:Ldx1;

    .line 44
    .line 45
    if-eq v1, v3, :cond_3

    .line 46
    .line 47
    :goto_1
    aget-object v1, v0, v2

    .line 48
    .line 49
    invoke-interface {v1}, Laau;->getValue()Ljava/lang/Object;

    .line 50
    .line 51
    .line 52
    move-result-object v1

    .line 53
    check-cast v1, Ld9t;

    .line 54
    .line 55
    iget-object v3, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->type:Ldx1;

    .line 56
    .line 57
    invoke-interface {p1, p2, v2, v1, v3}, Lvud;->lo(Le3e0;ILd9t;Ljava/lang/Object;)V

    .line 58
    .line 59
    .line 60
    :cond_3
    invoke-interface {p1, p2}, Lvud;->ll(Le3e0;)Z

    .line 61
    .line 62
    .line 63
    move-result v1

    .line 64
    if-eqz v1, :cond_4

    .line 65
    .line 66
    goto :goto_2

    .line 67
    :cond_4
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->baseUrl:Ljava/lang/String;

    .line 68
    .line 69
    const-wide v3, -0x527440a0c56e39L

    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    invoke-static {v3, v4}, Li6t0;->lO(J)Ljava/lang/String;

    .line 75
    .line 76
    .line 77
    move-result-object v3

    .line 78
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 79
    .line 80
    .line 81
    move-result v1

    .line 82
    if-nez v1, :cond_5

    .line 83
    .line 84
    :goto_2
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->baseUrl:Ljava/lang/String;

    .line 85
    .line 86
    const/4 v3, 0x2

    .line 87
    invoke-interface {p1, p2, v3, v1}, Lvud;->lII(Le3e0;ILjava/lang/String;)V

    .line 88
    .line 89
    .line 90
    :cond_5
    invoke-interface {p1, p2}, Lvud;->ll(Le3e0;)Z

    .line 91
    .line 92
    .line 93
    move-result v1

    .line 94
    if-eqz v1, :cond_6

    .line 95
    .line 96
    goto :goto_3

    .line 97
    :cond_6
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->key:Ljava/lang/String;

    .line 98
    .line 99
    const-wide v3, -0x527441a0c56e39L

    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    invoke-static {v3, v4}, Li6t0;->lO(J)Ljava/lang/String;

    .line 105
    .line 106
    .line 107
    move-result-object v3

    .line 108
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 109
    .line 110
    .line 111
    move-result v1

    .line 112
    if-nez v1, :cond_7

    .line 113
    .line 114
    :goto_3
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->key:Ljava/lang/String;

    .line 115
    .line 116
    const/4 v3, 0x3

    .line 117
    invoke-interface {p1, p2, v3, v1}, Lvud;->lII(Le3e0;ILjava/lang/String;)V

    .line 118
    .line 119
    .line 120
    :cond_7
    invoke-interface {p1, p2}, Lvud;->ll(Le3e0;)Z

    .line 121
    .line 122
    .line 123
    move-result v1

    .line 124
    if-eqz v1, :cond_8

    .line 125
    .line 126
    goto :goto_4

    .line 127
    :cond_8
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->headers:Ljava/lang/String;

    .line 128
    .line 129
    const-wide v3, -0x527442a0c56e39L

    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    invoke-static {v3, v4}, Li6t0;->lO(J)Ljava/lang/String;

    .line 135
    .line 136
    .line 137
    move-result-object v3

    .line 138
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 139
    .line 140
    .line 141
    move-result v1

    .line 142
    if-nez v1, :cond_9

    .line 143
    .line 144
    :goto_4
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->headers:Ljava/lang/String;

    .line 145
    .line 146
    const/4 v3, 0x4

    .line 147
    invoke-interface {p1, p2, v3, v1}, Lvud;->lII(Le3e0;ILjava/lang/String;)V

    .line 148
    .line 149
    .line 150
    :cond_9
    invoke-interface {p1, p2}, Lvud;->ll(Le3e0;)Z

    .line 151
    .line 152
    .line 153
    move-result v1

    .line 154
    if-eqz v1, :cond_a

    .line 155
    .line 156
    goto :goto_5

    .line 157
    :cond_a
    iget-boolean v1, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->enabled:Z

    .line 158
    .line 159
    if-eq v1, v2, :cond_b

    .line 160
    .line 161
    :goto_5
    iget-boolean v1, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->enabled:Z

    .line 162
    .line 163
    const/4 v2, 0x5

    .line 164
    invoke-interface {p1, p2, v2, v1}, Lvud;->llo(Le3e0;IZ)V

    .line 165
    .line 166
    .line 167
    :cond_b
    invoke-interface {p1, p2}, Lvud;->ll(Le3e0;)Z

    .line 168
    .line 169
    .line 170
    move-result v1

    .line 171
    if-eqz v1, :cond_c

    .line 172
    .line 173
    goto :goto_6

    .line 174
    :cond_c
    iget-boolean v1, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->responses:Z

    .line 175
    .line 176
    if-eqz v1, :cond_d

    .line 177
    .line 178
    :goto_6
    iget-boolean v1, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->responses:Z

    .line 179
    .line 180
    const/4 v2, 0x6

    .line 181
    invoke-interface {p1, p2, v2, v1}, Lvud;->llo(Le3e0;IZ)V

    .line 182
    .line 183
    .line 184
    :cond_d
    invoke-interface {p1, p2}, Lvud;->ll(Le3e0;)Z

    .line 185
    .line 186
    .line 187
    move-result v1

    .line 188
    if-eqz v1, :cond_e

    .line 189
    .line 190
    goto :goto_7

    .line 191
    :cond_e
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->models:Ljava/util/List;

    .line 192
    .line 193
    invoke-static {}, Loqc;->emptyList()Ljava/util/List;

    .line 194
    .line 195
    .line 196
    move-result-object v2

    .line 197
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 198
    .line 199
    .line 200
    move-result v1

    .line 201
    if-nez v1, :cond_f

    .line 202
    .line 203
    :goto_7
    const/4 v1, 0x7

    .line 204
    aget-object v0, v0, v1

    .line 205
    .line 206
    invoke-interface {v0}, Laau;->getValue()Ljava/lang/Object;

    .line 207
    .line 208
    .line 209
    move-result-object v0

    .line 210
    check-cast v0, Ld9t;

    .line 211
    .line 212
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->models:Ljava/util/List;

    .line 213
    .line 214
    invoke-interface {p1, p2, v1, v0, p0}, Lvud;->lo(Le3e0;ILd9t;Ljava/lang/Object;)V

    .line 215
    .line 216
    .line 217
    :cond_f
    return-void
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->name:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public final component2()Ldx1;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->type:Ldx1;

    .line 2
    .line 3
    return-object p0
.end method

.method public final component3()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->baseUrl:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public final component4()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->key:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public final component5()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->headers:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public final component6()Z
    .locals 0

    .line 1
    iget-boolean p0, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->enabled:Z

    .line 2
    .line 3
    return p0
.end method

.method public final component7()Z
    .locals 0

    .line 1
    iget-boolean p0, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->responses:Z

    .line 2
    .line 3
    return p0
.end method

.method public final component8()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lgt1;",
            ">;"
        }
    .end annotation

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->models:Ljava/util/List;

    .line 2
    .line 3
    return-object p0
.end method

.method public final copy(Ljava/lang/String;Ldx1;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZLjava/util/List;)Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ldx1;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "ZZ",
            "Ljava/util/List<",
            "Lgt1;",
            ">;)",
            "Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;"
        }
    .end annotation

    .line 1
    const-wide v0, -0x5273bda0c56e39L

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    const-wide v2, -0x5273c2a0c56e39L

    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    invoke-static {v0, v1, p1, v2, v3}, Lns;->lll(JLjava/lang/String;J)V

    .line 12
    .line 13
    .line 14
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    .line 16
    .line 17
    const-wide v0, -0x5273c7a0c56e39L

    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 26
    .line 27
    .line 28
    const-wide v0, -0x5273cfa0c56e39L

    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    const-wide v2, -0x5273d3a0c56e39L

    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    invoke-static {v0, v1, p4, v2, v3}, Lns;->lll(JLjava/lang/String;J)V

    .line 39
    .line 40
    .line 41
    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 42
    .line 43
    .line 44
    const-wide v0, -0x5273dba0c56e39L

    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 50
    .line 51
    .line 52
    invoke-virtual {p8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 53
    .line 54
    .line 55
    new-instance p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 56
    .line 57
    invoke-direct/range {p0 .. p8}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;-><init>(Ljava/lang/String;Ldx1;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZLjava/util/List;)V

    .line 58
    .line 59
    .line 60
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, p1, :cond_0

    .line 3
    .line 4
    return v0

    .line 5
    :cond_0
    instance-of v1, p1, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    if-nez v1, :cond_1

    .line 9
    .line 10
    return v2

    .line 11
    :cond_1
    check-cast p1, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 12
    .line 13
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->name:Ljava/lang/String;

    .line 14
    .line 15
    iget-object v3, p1, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->name:Ljava/lang/String;

    .line 16
    .line 17
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    move-result v1

    .line 21
    if-nez v1, :cond_2

    .line 22
    .line 23
    return v2

    .line 24
    :cond_2
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->type:Ldx1;

    .line 25
    .line 26
    iget-object v3, p1, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->type:Ldx1;

    .line 27
    .line 28
    if-eq v1, v3, :cond_3

    .line 29
    .line 30
    return v2

    .line 31
    :cond_3
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->baseUrl:Ljava/lang/String;

    .line 32
    .line 33
    iget-object v3, p1, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->baseUrl:Ljava/lang/String;

    .line 34
    .line 35
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 36
    .line 37
    .line 38
    move-result v1

    .line 39
    if-nez v1, :cond_4

    .line 40
    .line 41
    return v2

    .line 42
    :cond_4
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->key:Ljava/lang/String;

    .line 43
    .line 44
    iget-object v3, p1, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->key:Ljava/lang/String;

    .line 45
    .line 46
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 47
    .line 48
    .line 49
    move-result v1

    .line 50
    if-nez v1, :cond_5

    .line 51
    .line 52
    return v2

    .line 53
    :cond_5
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->headers:Ljava/lang/String;

    .line 54
    .line 55
    iget-object v3, p1, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->headers:Ljava/lang/String;

    .line 56
    .line 57
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 58
    .line 59
    .line 60
    move-result v1

    .line 61
    if-nez v1, :cond_6

    .line 62
    .line 63
    return v2

    .line 64
    :cond_6
    iget-boolean v1, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->enabled:Z

    .line 65
    .line 66
    iget-boolean v3, p1, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->enabled:Z

    .line 67
    .line 68
    if-eq v1, v3, :cond_7

    .line 69
    .line 70
    return v2

    .line 71
    :cond_7
    iget-boolean v1, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->responses:Z

    .line 72
    .line 73
    iget-boolean v3, p1, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->responses:Z

    .line 74
    .line 75
    if-eq v1, v3, :cond_8

    .line 76
    .line 77
    return v2

    .line 78
    :cond_8
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->models:Ljava/util/List;

    .line 79
    .line 80
    iget-object p1, p1, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->models:Ljava/util/List;

    .line 81
    .line 82
    invoke-static {p0, p1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 83
    .line 84
    .line 85
    move-result p0

    .line 86
    if-nez p0, :cond_9

    .line 87
    .line 88
    return v2

    .line 89
    :cond_9
    return v0
.end method

.method public final getBaseUrl()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->baseUrl:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public final getEnabled()Z
    .locals 0

    .line 1
    iget-boolean p0, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->enabled:Z

    .line 2
    .line 3
    return p0
.end method

.method public final getHeaders()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->headers:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public final getKey()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->key:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public final getKeyMissing()Z
    .locals 1

    .line 1
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->key:Ljava/lang/String;

    .line 2
    .line 3
    invoke-static {v0}, Ligh0;->isBlank(Ljava/lang/CharSequence;)Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->type:Ldx1;

    .line 10
    .line 11
    iget-boolean p0, p0, Ldx1;->O:Z

    .line 12
    .line 13
    if-nez p0, :cond_0

    .line 14
    .line 15
    const/4 p0, 0x1

    .line 16
    return p0

    .line 17
    :cond_0
    const/4 p0, 0x0

    .line 18
    return p0
.end method

.method public final getModels()Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lgt1;",
            ">;"
        }
    .end annotation

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->models:Ljava/util/List;

    .line 2
    .line 3
    return-object p0
.end method

.method public final getName()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->name:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public final getResponses()Z
    .locals 0

    .line 1
    iget-boolean p0, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->responses:Z

    .line 2
    .line 3
    return p0
.end method

.method public final getType()Ldx1;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->type:Ldx1;

    .line 2
    .line 3
    return-object p0
.end method

.method public final getUrlInvalid()Z
    .locals 3

    .line 1
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->baseUrl:Ljava/lang/String;

    .line 2
    .line 3
    invoke-static {v0}, Ligh0;->isBlank(Ljava/lang/CharSequence;)Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-nez v0, :cond_0

    .line 8
    .line 9
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->baseUrl:Ljava/lang/String;

    .line 10
    .line 11
    const-wide v1, -0x52739ca0c56e39L

    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object v1

    .line 20
    const/4 v2, 0x1

    .line 21
    invoke-static {v0, v1, v2}, Lfgh0;->startsWith(Ljava/lang/String;Ljava/lang/String;Z)Z

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    if-nez v0, :cond_0

    .line 26
    .line 27
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->baseUrl:Ljava/lang/String;

    .line 28
    .line 29
    const-wide v0, -0x5273a4a0c56e39L

    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    invoke-static {p0, v0, v2}, Lfgh0;->startsWith(Ljava/lang/String;Ljava/lang/String;Z)Z

    .line 39
    .line 40
    .line 41
    move-result p0

    .line 42
    if-nez p0, :cond_0

    .line 43
    .line 44
    return v2

    .line 45
    :cond_0
    const/4 p0, 0x0

    .line 46
    return p0
.end method

.method public final getUrlMissing()Z
    .locals 1

    .line 1
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->baseUrl:Ljava/lang/String;

    .line 2
    .line 3
    invoke-static {v0}, Ligh0;->isBlank(Ljava/lang/CharSequence;)Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->type:Ldx1;

    .line 10
    .line 11
    iget-object p0, p0, Ldx1;->I:Ljava/lang/String;

    .line 12
    .line 13
    invoke-static {p0}, Ligh0;->isBlank(Ljava/lang/CharSequence;)Z

    .line 14
    .line 15
    .line 16
    move-result p0

    .line 17
    if-eqz p0, :cond_0

    .line 18
    .line 19
    const/4 p0, 0x1

    .line 20
    return p0

    .line 21
    :cond_0
    const/4 p0, 0x0

    .line 22
    return p0
.end method

.method public final getValid()Z
    .locals 1

    .line 1
    invoke-virtual {p0}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->getUrlInvalid()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    invoke-virtual {p0}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->getUrlMissing()Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-nez v0, :cond_0

    .line 12
    .line 13
    invoke-virtual {p0}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->getKeyMissing()Z

    .line 14
    .line 15
    .line 16
    move-result p0

    .line 17
    if-nez p0, :cond_0

    .line 18
    .line 19
    const/4 p0, 0x1

    .line 20
    return p0

    .line 21
    :cond_0
    const/4 p0, 0x0

    .line 22
    return p0
.end method

.method public hashCode()I
    .locals 3

    .line 1
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->name:Ljava/lang/String;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    const/16 v1, 0x1f

    .line 8
    .line 9
    mul-int/2addr v0, v1

    .line 10
    iget-object v2, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->type:Ldx1;

    .line 11
    .line 12
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    .line 13
    .line 14
    .line 15
    move-result v2

    .line 16
    add-int/2addr v2, v0

    .line 17
    mul-int/2addr v2, v1

    .line 18
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->baseUrl:Ljava/lang/String;

    .line 19
    .line 20
    invoke-static {v2, v1, v0}, Lw280;->I(IILjava/lang/String;)I

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    iget-object v2, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->key:Ljava/lang/String;

    .line 25
    .line 26
    invoke-static {v0, v1, v2}, Lw280;->I(IILjava/lang/String;)I

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    iget-object v2, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->headers:Ljava/lang/String;

    .line 31
    .line 32
    invoke-static {v0, v1, v2}, Lw280;->I(IILjava/lang/String;)I

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    iget-boolean v2, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->enabled:Z

    .line 37
    .line 38
    invoke-static {v0, v1, v2}, Ljs2;->ll(IIZ)I

    .line 39
    .line 40
    .line 41
    move-result v0

    .line 42
    iget-boolean v2, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->responses:Z

    .line 43
    .line 44
    invoke-static {v0, v1, v2}, Ljs2;->ll(IIZ)I

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->models:Ljava/util/List;

    .line 49
    .line 50
    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    .line 51
    .line 52
    .line 53
    move-result p0

    .line 54
    add-int/2addr p0, v0

    .line 55
    return p0
.end method

.method public final provider(Ljava/lang/String;Ljava/lang/String;)Lxw1;
    .locals 12

    .line 1
    const-wide v0, -0x5273ada0c56e39L

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    const-wide v2, -0x5273b0a0c56e39L

    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    invoke-static {v0, v1, p1, v2, v3}, Lns;->lll(JLjava/lang/String;J)V

    .line 12
    .line 13
    .line 14
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    .line 16
    .line 17
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->name:Ljava/lang/String;

    .line 18
    .line 19
    invoke-static {v0}, Ligh0;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    invoke-static {v0}, Ligh0;->isBlank(Ljava/lang/CharSequence;)Z

    .line 28
    .line 29
    .line 30
    move-result v1

    .line 31
    if-eqz v1, :cond_0

    .line 32
    .line 33
    move-object v4, p2

    .line 34
    goto :goto_0

    .line 35
    :cond_0
    move-object v4, v0

    .line 36
    :goto_0
    iget-object v5, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->type:Ldx1;

    .line 37
    .line 38
    iget-object p2, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->baseUrl:Ljava/lang/String;

    .line 39
    .line 40
    invoke-static {p2}, Ligh0;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 41
    .line 42
    .line 43
    move-result-object p2

    .line 44
    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 45
    .line 46
    .line 47
    move-result-object v6

    .line 48
    iget-boolean v8, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->enabled:Z

    .line 49
    .line 50
    iget-object v9, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->models:Ljava/util/List;

    .line 51
    .line 52
    iget-boolean p2, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->responses:Z

    .line 53
    .line 54
    if-eqz p2, :cond_1

    .line 55
    .line 56
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->type:Ldx1;

    .line 57
    .line 58
    sget-object p2, Ldx1;->ll:Ldx1;

    .line 59
    .line 60
    if-ne p0, p2, :cond_1

    .line 61
    .line 62
    const/4 p0, 0x1

    .line 63
    :goto_1
    move v10, p0

    .line 64
    goto :goto_2

    .line 65
    :cond_1
    const/4 p0, 0x0

    .line 66
    goto :goto_1

    .line 67
    :goto_2
    new-instance v2, Lxw1;

    .line 68
    .line 69
    const/4 v7, 0x0

    .line 70
    const/16 v11, 0x230

    .line 71
    .line 72
    move-object v3, p1

    .line 73
    invoke-direct/range {v2 .. v11}, Lxw1;-><init>(Ljava/lang/String;Ljava/lang/String;Ldx1;Ljava/lang/String;Ljava/lang/String;ZLjava/util/List;ZI)V

    .line 74
    .line 75
    .line 76
    return-object v2
.end method

.method public toString()Ljava/lang/String;
    .locals 4

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-wide v1, -0x5273e2a0c56e39L

    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->name:Ljava/lang/String;

    .line 16
    .line 17
    const-wide v2, -0x5273f8a0c56e39L

    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    invoke-static {v2, v3, v1, v0}, Lti6;->Oo(JLjava/lang/String;Ljava/lang/StringBuilder;)V

    .line 23
    .line 24
    .line 25
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->type:Ldx1;

    .line 26
    .line 27
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 28
    .line 29
    .line 30
    const-wide v1, -0x527400a0c56e39L

    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 36
    .line 37
    .line 38
    move-result-object v1

    .line 39
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 40
    .line 41
    .line 42
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->baseUrl:Ljava/lang/String;

    .line 43
    .line 44
    const-wide v2, -0x52740ba0c56e39L    # -1.03741983165112E307

    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    invoke-static {v2, v3, v1, v0}, Lti6;->Oo(JLjava/lang/String;Ljava/lang/StringBuilder;)V

    .line 50
    .line 51
    .line 52
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->key:Ljava/lang/String;

    .line 53
    .line 54
    const-wide v2, -0x527412a0c56e39L

    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    invoke-static {v2, v3, v1, v0}, Lti6;->Oo(JLjava/lang/String;Ljava/lang/StringBuilder;)V

    .line 60
    .line 61
    .line 62
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->headers:Ljava/lang/String;

    .line 63
    .line 64
    const-wide v2, -0x52741da0c56e39L

    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    invoke-static {v2, v3, v1, v0}, Lti6;->Oo(JLjava/lang/String;Ljava/lang/StringBuilder;)V

    .line 70
    .line 71
    .line 72
    iget-boolean v1, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->enabled:Z

    .line 73
    .line 74
    const-wide v2, -0x527428a0c56e39L

    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    invoke-static {v2, v3, v0, v1}, LIO;->llo(JLjava/lang/StringBuilder;Z)V

    .line 80
    .line 81
    .line 82
    iget-boolean v1, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->responses:Z

    .line 83
    .line 84
    const-wide v2, -0x527435a0c56e39L

    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    invoke-static {v2, v3, v0, v1}, LIO;->llo(JLjava/lang/StringBuilder;Z)V

    .line 90
    .line 91
    .line 92
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->models:Ljava/util/List;

    .line 93
    .line 94
    const/16 v1, 0x29

    .line 95
    .line 96
    invoke-static {v1, v0, p0}, Lzad0;->Io(CLjava/lang/StringBuilder;Ljava/util/List;)Ljava/lang/String;

    .line 97
    .line 98
    .line 99
    move-result-object p0

    .line 100
    return-object p0
.end method
