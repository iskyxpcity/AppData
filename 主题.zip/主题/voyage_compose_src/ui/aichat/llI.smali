.class public final synthetic Lcom/chuanyi/voyage/ui/aichat/llI;
.super Ljava/lang/Object;
.source "S"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic I:Lqoe;

.field public final synthetic O:Lkc10;

.field public final synthetic l:Lza1;

.field public final synthetic lI:Ljava/lang/String;

.field public final synthetic ll:Ljava/lang/String;

.field public final synthetic o:Lkc10;


# direct methods
.method public synthetic constructor <init>(Lza1;Lqoe;Lkc10;Lkc10;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lcom/chuanyi/voyage/ui/aichat/llI;->l:Lza1;

    .line 5
    .line 6
    iput-object p2, p0, Lcom/chuanyi/voyage/ui/aichat/llI;->I:Lqoe;

    .line 7
    .line 8
    iput-object p3, p0, Lcom/chuanyi/voyage/ui/aichat/llI;->O:Lkc10;

    .line 9
    .line 10
    iput-object p4, p0, Lcom/chuanyi/voyage/ui/aichat/llI;->o:Lkc10;

    .line 11
    .line 12
    iput-object p5, p0, Lcom/chuanyi/voyage/ui/aichat/llI;->ll:Ljava/lang/String;

    .line 13
    .line 14
    iput-object p6, p0, Lcom/chuanyi/voyage/ui/aichat/llI;->lI:Ljava/lang/String;

    .line 15
    .line 16
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 11

    .line 1
    move-object v0, p1

    .line 2
    check-cast v0, Ljava/lang/String;

    .line 3
    .line 4
    const-wide v1, -0x518211a0c56e39L

    .line 5
    .line 6
    .line 7
    .line 8
    .line 9
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13
    .line 14
    .line 15
    const/4 p1, 0x2

    .line 16
    new-array v1, p1, [C

    .line 17
    .line 18
    fill-array-data v1, :array_0

    .line 19
    .line 20
    .line 21
    const/4 v4, 0x6

    .line 22
    const/4 v5, 0x0

    .line 23
    const/4 v2, 0x0

    .line 24
    const/4 v3, 0x0

    .line 25
    invoke-static/range {v0 .. v5}, Ligh0;->split$default(Ljava/lang/CharSequence;[CZIILjava/lang/Object;)Ljava/util/List;

    .line 26
    .line 27
    .line 28
    move-result-object p1

    .line 29
    check-cast p1, Ljava/lang/Iterable;

    .line 30
    .line 31
    new-instance v0, Ljava/util/ArrayList;

    .line 32
    .line 33
    const/16 v1, 0xa

    .line 34
    .line 35
    invoke-static {p1, v1}, Lpqc;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    .line 36
    .line 37
    .line 38
    move-result v2

    .line 39
    invoke-direct {v0, v2}, Ljava/util/ArrayList;-><init>(I)V

    .line 40
    .line 41
    .line 42
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 43
    .line 44
    .line 45
    move-result-object p1

    .line 46
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 47
    .line 48
    .line 49
    move-result v2

    .line 50
    if-eqz v2, :cond_0

    .line 51
    .line 52
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 53
    .line 54
    .line 55
    move-result-object v2

    .line 56
    check-cast v2, Ljava/lang/String;

    .line 57
    .line 58
    invoke-static {v2, v0}, LIO;->lII(Ljava/lang/String;Ljava/util/ArrayList;)V

    .line 59
    .line 60
    .line 61
    goto :goto_0

    .line 62
    :cond_0
    new-instance p1, Ljava/util/ArrayList;

    .line 63
    .line 64
    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    .line 65
    .line 66
    .line 67
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 68
    .line 69
    .line 70
    move-result-object v0

    .line 71
    :cond_1
    :goto_1
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 72
    .line 73
    .line 74
    move-result v2

    .line 75
    if-eqz v2, :cond_2

    .line 76
    .line 77
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 78
    .line 79
    .line 80
    move-result-object v2

    .line 81
    move-object v3, v2

    .line 82
    check-cast v3, Ljava/lang/String;

    .line 83
    .line 84
    invoke-virtual {v3}, Ljava/lang/String;->length()I

    .line 85
    .line 86
    .line 87
    move-result v3

    .line 88
    if-lez v3, :cond_1

    .line 89
    .line 90
    invoke-virtual {p1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 91
    .line 92
    .line 93
    goto :goto_1

    .line 94
    :cond_2
    invoke-static {p1}, Lyqc;->distinct(Ljava/lang/Iterable;)Ljava/util/List;

    .line 95
    .line 96
    .line 97
    move-result-object p1

    .line 98
    check-cast p1, Ljava/lang/Iterable;

    .line 99
    .line 100
    new-instance v0, Ljava/util/ArrayList;

    .line 101
    .line 102
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 103
    .line 104
    .line 105
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 106
    .line 107
    .line 108
    move-result-object p1

    .line 109
    :goto_2
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 110
    .line 111
    .line 112
    move-result v2

    .line 113
    iget-object v9, p0, Lcom/chuanyi/voyage/ui/aichat/llI;->O:Lkc10;

    .line 114
    .line 115
    if-eqz v2, :cond_6

    .line 116
    .line 117
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 118
    .line 119
    .line 120
    move-result-object v2

    .line 121
    move-object v3, v2

    .line 122
    check-cast v3, Ljava/lang/String;

    .line 123
    .line 124
    invoke-interface {v9}, Lubg0;->getValue()Ljava/lang/Object;

    .line 125
    .line 126
    .line 127
    move-result-object v4

    .line 128
    check-cast v4, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 129
    .line 130
    invoke-virtual {v4}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->getModels()Ljava/util/List;

    .line 131
    .line 132
    .line 133
    move-result-object v4

    .line 134
    check-cast v4, Ljava/lang/Iterable;

    .line 135
    .line 136
    instance-of v5, v4, Ljava/util/Collection;

    .line 137
    .line 138
    if-eqz v5, :cond_3

    .line 139
    .line 140
    move-object v5, v4

    .line 141
    check-cast v5, Ljava/util/Collection;

    .line 142
    .line 143
    invoke-interface {v5}, Ljava/util/Collection;->isEmpty()Z

    .line 144
    .line 145
    .line 146
    move-result v5

    .line 147
    if-eqz v5, :cond_3

    .line 148
    .line 149
    goto :goto_3

    .line 150
    :cond_3
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 151
    .line 152
    .line 153
    move-result-object v4

    .line 154
    :cond_4
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 155
    .line 156
    .line 157
    move-result v5

    .line 158
    if-eqz v5, :cond_5

    .line 159
    .line 160
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 161
    .line 162
    .line 163
    move-result-object v5

    .line 164
    check-cast v5, Lgt1;

    .line 165
    .line 166
    iget-object v5, v5, Lgt1;->l:Ljava/lang/String;

    .line 167
    .line 168
    invoke-static {v5, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 169
    .line 170
    .line 171
    move-result v5

    .line 172
    if-eqz v5, :cond_4

    .line 173
    .line 174
    goto :goto_2

    .line 175
    :cond_5
    :goto_3
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 176
    .line 177
    .line 178
    goto :goto_2

    .line 179
    :cond_6
    new-instance v8, Ljava/util/ArrayList;

    .line 180
    .line 181
    invoke-static {v0, v1}, Lpqc;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    .line 182
    .line 183
    .line 184
    move-result p1

    .line 185
    invoke-direct {v8, p1}, Ljava/util/ArrayList;-><init>(I)V

    .line 186
    .line 187
    .line 188
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 189
    .line 190
    .line 191
    move-result-object p1

    .line 192
    :goto_4
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 193
    .line 194
    .line 195
    move-result v0

    .line 196
    iget-object v4, p0, Lcom/chuanyi/voyage/ui/aichat/llI;->l:Lza1;

    .line 197
    .line 198
    if-eqz v0, :cond_7

    .line 199
    .line 200
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 201
    .line 202
    .line 203
    move-result-object v0

    .line 204
    check-cast v0, Ljava/lang/String;

    .line 205
    .line 206
    const-wide v1, -0x1e412a0c56e39L

    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 212
    .line 213
    .line 214
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 215
    .line 216
    .line 217
    iget-object v1, v4, Lza1;->o:Lzb1;

    .line 218
    .line 219
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 220
    .line 221
    .line 222
    const-wide v1, -0x1e82fa0c56e39L

    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 228
    .line 229
    .line 230
    sget-object v1, Lzb1;->lO:Lp0p;

    .line 231
    .line 232
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 233
    .line 234
    .line 235
    invoke-static {v0}, Lp0p;->Oo(Ljava/lang/String;)Lgt1;

    .line 236
    .line 237
    .line 238
    move-result-object v0

    .line 239
    invoke-virtual {v8, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 240
    .line 241
    .line 242
    goto :goto_4

    .line 243
    :cond_7
    new-instance p1, Lcom/chuanyi/voyage/ui/aichat/Ol;

    .line 244
    .line 245
    const/4 v0, 0x1

    .line 246
    invoke-direct {p1, v8, v0}, Lcom/chuanyi/voyage/ui/aichat/Ol;-><init>(Ljava/io/Serializable;B)V

    .line 247
    .line 248
    .line 249
    invoke-static {v9, p1}, Lcom/chuanyi/voyage/ui/aichat/Ill;->oO(Lkc10;Lkotlin/jvm/functions/Function1;)V

    .line 250
    .line 251
    .line 252
    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 253
    .line 254
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/aichat/llI;->o:Lkc10;

    .line 255
    .line 256
    invoke-interface {v0, p1}, Lkc10;->setValue(Ljava/lang/Object;)V

    .line 257
    .line 258
    .line 259
    invoke-interface {v9}, Lubg0;->getValue()Ljava/lang/Object;

    .line 260
    .line 261
    .line 262
    move-result-object p1

    .line 263
    move-object v5, p1

    .line 264
    check-cast v5, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 265
    .line 266
    new-instance v3, Lcom/chuanyi/voyage/ui/aichat/lII;

    .line 267
    .line 268
    const/4 v10, 0x0

    .line 269
    iget-object v6, p0, Lcom/chuanyi/voyage/ui/aichat/llI;->ll:Ljava/lang/String;

    .line 270
    .line 271
    iget-object v7, p0, Lcom/chuanyi/voyage/ui/aichat/llI;->lI:Ljava/lang/String;

    .line 272
    .line 273
    invoke-direct/range {v3 .. v10}, Lcom/chuanyi/voyage/ui/aichat/lII;-><init>(Lza1;Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;Lkc10;Lvce;)V

    .line 274
    .line 275
    .line 276
    const/4 p1, 0x3

    .line 277
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/aichat/llI;->I:Lqoe;

    .line 278
    .line 279
    const/4 v0, 0x0

    .line 280
    invoke-static {p0, v0, v0, v3, p1}, Lw19;->loI(Lqoe;Lhoe;Ltoe;Lkotlin/jvm/functions/Function2;I)Lp9g0;

    .line 281
    .line 282
    .line 283
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 284
    .line 285
    return-object p0

    .line 286
    nop

    .line 287
    :array_0
    .array-data 2
        0x2cs
        0xas
    .end array-data
.end method
