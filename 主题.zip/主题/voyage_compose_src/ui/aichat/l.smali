.class public final synthetic Lcom/chuanyi/voyage/ui/aichat/l;
.super Ljava/lang/Object;
.source "S"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic I:Ljava/lang/Object;

.field public final synthetic l:B


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;B)V
    .locals 0

    .line 1
    iput-byte p2, p0, Lcom/chuanyi/voyage/ui/aichat/l;->l:B

    .line 2
    .line 3
    iput-object p1, p0, Lcom/chuanyi/voyage/ui/aichat/l;->I:Ljava/lang/Object;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 30

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-byte v1, v0, Lcom/chuanyi/voyage/ui/aichat/l;->l:B

    .line 4
    .line 5
    iget-object v0, v0, Lcom/chuanyi/voyage/ui/aichat/l;->I:Ljava/lang/Object;

    .line 6
    .line 7
    packed-switch v1, :pswitch_data_0

    .line 8
    .line 9
    .line 10
    check-cast v0, Lkc10;

    .line 11
    .line 12
    move-object/from16 v1, p1

    .line 13
    .line 14
    check-cast v1, Lkud;

    .line 15
    .line 16
    move-object/from16 v2, p2

    .line 17
    .line 18
    check-cast v2, Ljava/lang/Integer;

    .line 19
    .line 20
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 21
    .line 22
    .line 23
    move-result v2

    .line 24
    const-wide v3, -0x517105a0c56e39L

    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    invoke-static {v3, v4}, Li6t0;->lO(J)Ljava/lang/String;

    .line 30
    .line 31
    .line 32
    and-int/lit8 v3, v2, 0x3

    .line 33
    .line 34
    const/4 v4, 0x2

    .line 35
    const/4 v5, 0x1

    .line 36
    if-eq v3, v4, :cond_0

    .line 37
    .line 38
    move v3, v5

    .line 39
    goto :goto_0

    .line 40
    :cond_0
    const/4 v3, 0x0

    .line 41
    :goto_0
    and-int/2addr v2, v5

    .line 42
    check-cast v1, Ltgn;

    .line 43
    .line 44
    invoke-virtual {v1, v2, v3}, Ltgn;->Iol(IZ)Z

    .line 45
    .line 46
    .line 47
    move-result v2

    .line 48
    if-eqz v2, :cond_2

    .line 49
    .line 50
    invoke-interface {v0}, Lubg0;->getValue()Ljava/lang/Object;

    .line 51
    .line 52
    .line 53
    move-result-object v0

    .line 54
    check-cast v0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 55
    .line 56
    invoke-virtual {v0}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->getType()Ldx1;

    .line 57
    .line 58
    .line 59
    move-result-object v0

    .line 60
    iget-object v0, v0, Ldx1;->I:Ljava/lang/String;

    .line 61
    .line 62
    invoke-static {v0}, Ligh0;->isBlank(Ljava/lang/CharSequence;)Z

    .line 63
    .line 64
    .line 65
    move-result v2

    .line 66
    if-eqz v2, :cond_1

    .line 67
    .line 68
    const-wide v2, -0x517180a0c56e39L

    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    invoke-static {v2, v3}, Li6t0;->lO(J)Ljava/lang/String;

    .line 74
    .line 75
    .line 76
    move-result-object v0

    .line 77
    :cond_1
    move-object v4, v0

    .line 78
    const/16 v28, 0x0

    .line 79
    .line 80
    const v29, 0x3fffe

    .line 81
    .line 82
    .line 83
    const/4 v5, 0x0

    .line 84
    const-wide/16 v6, 0x0

    .line 85
    .line 86
    const/4 v8, 0x0

    .line 87
    const-wide/16 v9, 0x0

    .line 88
    .line 89
    const/4 v11, 0x0

    .line 90
    const/4 v12, 0x0

    .line 91
    const/4 v13, 0x0

    .line 92
    const-wide/16 v14, 0x0

    .line 93
    .line 94
    const/16 v16, 0x0

    .line 95
    .line 96
    const/16 v17, 0x0

    .line 97
    .line 98
    const-wide/16 v18, 0x0

    .line 99
    .line 100
    const/16 v20, 0x0

    .line 101
    .line 102
    const/16 v21, 0x0

    .line 103
    .line 104
    const/16 v22, 0x0

    .line 105
    .line 106
    const/16 v23, 0x0

    .line 107
    .line 108
    const/16 v24, 0x0

    .line 109
    .line 110
    const/16 v25, 0x0

    .line 111
    .line 112
    const/16 v27, 0x0

    .line 113
    .line 114
    move-object/from16 v26, v1

    .line 115
    .line 116
    invoke-static/range {v4 .. v29}, Lm7j0;->I(Ljava/lang/String;Lzgz;JLa1j0;JLunm;Ldom;Lgmm;JLk2j0;Lj0j0;JIZIILkotlin/jvm/functions/Function1;Lhaj0;Lkud;III)V

    .line 117
    .line 118
    .line 119
    goto :goto_1

    .line 120
    :cond_2
    move-object/from16 v26, v1

    .line 121
    .line 122
    invoke-virtual/range {v26 .. v26}, Ltgn;->Ioo()V

    .line 123
    .line 124
    .line 125
    :goto_1
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 126
    .line 127
    return-object v0

    .line 128
    :pswitch_0
    check-cast v0, Lcom/chuanyi/voyage/ui/aichat/I;

    .line 129
    .line 130
    move-object/from16 v1, p1

    .line 131
    .line 132
    check-cast v1, Lhvc0;

    .line 133
    .line 134
    move-object/from16 v2, p2

    .line 135
    .line 136
    check-cast v2, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 137
    .line 138
    const-wide v3, -0x510753a0c56e39L

    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    invoke-static {v3, v4}, Li6t0;->lO(J)Ljava/lang/String;

    .line 144
    .line 145
    .line 146
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 147
    .line 148
    .line 149
    if-eqz v2, :cond_3

    .line 150
    .line 151
    invoke-virtual {v0, v2}, Lcom/chuanyi/voyage/ui/aichat/I;->I(Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;)Ljava/lang/String;

    .line 152
    .line 153
    .line 154
    move-result-object v0

    .line 155
    goto :goto_2

    .line 156
    :cond_3
    const/4 v0, 0x0

    .line 157
    :goto_2
    return-object v0

    .line 158
    :pswitch_1
    check-cast v0, Lcom/chuanyi/voyage/ui/aichat/I;

    .line 159
    .line 160
    move-object/from16 v1, p1

    .line 161
    .line 162
    check-cast v1, Lhvc0;

    .line 163
    .line 164
    move-object/from16 v2, p2

    .line 165
    .line 166
    check-cast v2, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 167
    .line 168
    const-wide v3, -0x510741a0c56e39L

    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    invoke-static {v3, v4}, Li6t0;->lO(J)Ljava/lang/String;

    .line 174
    .line 175
    .line 176
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 177
    .line 178
    .line 179
    const-wide v3, -0x51074da0c56e39L

    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    invoke-static {v3, v4}, Li6t0;->lO(J)Ljava/lang/String;

    .line 185
    .line 186
    .line 187
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 188
    .line 189
    .line 190
    invoke-virtual {v0, v2}, Lcom/chuanyi/voyage/ui/aichat/I;->I(Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;)Ljava/lang/String;

    .line 191
    .line 192
    .line 193
    move-result-object v0

    .line 194
    return-object v0

    .line 195
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
