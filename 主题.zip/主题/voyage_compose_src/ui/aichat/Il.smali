.class public final synthetic Lcom/chuanyi/voyage/ui/aichat/Il;
.super Ljava/lang/Object;
.source "S"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic I:Lza1;

.field public final synthetic O:Ljava/lang/String;

.field public final synthetic l:B

.field public final synthetic lI:Ljava/lang/Object;

.field public final synthetic ll:Lkc10;

.field public final synthetic o:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Lkc10;Lkc10;Lza1;Ljava/lang/String;Ljava/lang/String;)V
    .locals 1

    .line 19
    const/4 v0, 0x0

    iput-byte v0, p0, Lcom/chuanyi/voyage/ui/aichat/Il;->l:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/chuanyi/voyage/ui/aichat/Il;->ll:Lkc10;

    iput-object p2, p0, Lcom/chuanyi/voyage/ui/aichat/Il;->lI:Ljava/lang/Object;

    iput-object p3, p0, Lcom/chuanyi/voyage/ui/aichat/Il;->I:Lza1;

    iput-object p4, p0, Lcom/chuanyi/voyage/ui/aichat/Il;->O:Ljava/lang/String;

    iput-object p5, p0, Lcom/chuanyi/voyage/ui/aichat/Il;->o:Ljava/lang/String;

    return-void
.end method

.method public synthetic constructor <init>(Lqoe;Lkc10;Lza1;Ljava/lang/String;Ljava/lang/String;)V
    .locals 1

    .line 18
    const/4 v0, 0x2

    iput-byte v0, p0, Lcom/chuanyi/voyage/ui/aichat/Il;->l:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/chuanyi/voyage/ui/aichat/Il;->lI:Ljava/lang/Object;

    iput-object p2, p0, Lcom/chuanyi/voyage/ui/aichat/Il;->ll:Lkc10;

    iput-object p3, p0, Lcom/chuanyi/voyage/ui/aichat/Il;->I:Lza1;

    iput-object p4, p0, Lcom/chuanyi/voyage/ui/aichat/Il;->O:Ljava/lang/String;

    iput-object p5, p0, Lcom/chuanyi/voyage/ui/aichat/Il;->o:Ljava/lang/String;

    return-void
.end method

.method public synthetic constructor <init>(Lza1;Ljava/lang/String;Ljava/lang/String;Lkc10;Lkc10;)V
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-byte v0, p0, Lcom/chuanyi/voyage/ui/aichat/Il;->l:B

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/chuanyi/voyage/ui/aichat/Il;->I:Lza1;

    .line 8
    .line 9
    iput-object p2, p0, Lcom/chuanyi/voyage/ui/aichat/Il;->O:Ljava/lang/String;

    .line 10
    .line 11
    iput-object p3, p0, Lcom/chuanyi/voyage/ui/aichat/Il;->o:Ljava/lang/String;

    .line 12
    .line 13
    iput-object p4, p0, Lcom/chuanyi/voyage/ui/aichat/Il;->ll:Lkc10;

    .line 14
    .line 15
    iput-object p5, p0, Lcom/chuanyi/voyage/ui/aichat/Il;->lI:Ljava/lang/Object;

    .line 16
    .line 17
    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 15

    .line 1
    iget-byte v0, p0, Lcom/chuanyi/voyage/ui/aichat/Il;->l:B

    .line 2
    .line 3
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/aichat/Il;->ll:Lkc10;

    .line 4
    .line 5
    iget-object v2, p0, Lcom/chuanyi/voyage/ui/aichat/Il;->o:Ljava/lang/String;

    .line 6
    .line 7
    iget-object v3, p0, Lcom/chuanyi/voyage/ui/aichat/Il;->O:Ljava/lang/String;

    .line 8
    .line 9
    const/4 v4, 0x3

    .line 10
    const/4 v5, 0x0

    .line 11
    iget-object v6, p0, Lcom/chuanyi/voyage/ui/aichat/Il;->lI:Ljava/lang/Object;

    .line 12
    .line 13
    packed-switch v0, :pswitch_data_0

    .line 14
    .line 15
    .line 16
    check-cast v6, Lqoe;

    .line 17
    .line 18
    iget-object v12, p0, Lcom/chuanyi/voyage/ui/aichat/Il;->ll:Lkc10;

    .line 19
    .line 20
    invoke-interface {v12}, Lubg0;->getValue()Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    move-object v9, v0

    .line 25
    check-cast v9, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 26
    .line 27
    new-instance v7, Lcom/chuanyi/voyage/ui/aichat/lIl;

    .line 28
    .line 29
    const/4 v13, 0x0

    .line 30
    iget-object v8, p0, Lcom/chuanyi/voyage/ui/aichat/Il;->I:Lza1;

    .line 31
    .line 32
    iget-object v10, p0, Lcom/chuanyi/voyage/ui/aichat/Il;->O:Ljava/lang/String;

    .line 33
    .line 34
    iget-object v11, p0, Lcom/chuanyi/voyage/ui/aichat/Il;->o:Ljava/lang/String;

    .line 35
    .line 36
    invoke-direct/range {v7 .. v13}, Lcom/chuanyi/voyage/ui/aichat/lIl;-><init>(Lza1;Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;Ljava/lang/String;Ljava/lang/String;Lkc10;Lvce;)V

    .line 37
    .line 38
    .line 39
    invoke-static {v6, v5, v5, v7, v4}, Lw19;->loI(Lqoe;Lhoe;Ltoe;Lkotlin/jvm/functions/Function2;I)Lp9g0;

    .line 40
    .line 41
    .line 42
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 43
    .line 44
    return-object p0

    .line 45
    :pswitch_0
    check-cast v6, Lkc10;

    .line 46
    .line 47
    invoke-interface {v1}, Lubg0;->getValue()Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    check-cast v0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 52
    .line 53
    invoke-virtual {v0}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->getValid()Z

    .line 54
    .line 55
    .line 56
    move-result v1

    .line 57
    if-nez v1, :cond_0

    .line 58
    .line 59
    sget-object p0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 60
    .line 61
    invoke-interface {v6, p0}, Lkc10;->setValue(Ljava/lang/Object;)V

    .line 62
    .line 63
    .line 64
    goto :goto_0

    .line 65
    :cond_0
    invoke-virtual {v0, v3, v2}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->provider(Ljava/lang/String;Ljava/lang/String;)Lxw1;

    .line 66
    .line 67
    .line 68
    move-result-object v9

    .line 69
    invoke-virtual {v0}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->getKey()Ljava/lang/String;

    .line 70
    .line 71
    .line 72
    move-result-object v10

    .line 73
    invoke-virtual {v0}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->getHeaders()Ljava/lang/String;

    .line 74
    .line 75
    .line 76
    move-result-object v1

    .line 77
    invoke-static {v1}, Lcom/chuanyi/voyage/ui/aichat/Ill;->lIO(Ljava/lang/String;)Ljava/util/Map;

    .line 78
    .line 79
    .line 80
    move-result-object v11

    .line 81
    invoke-virtual {v0}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->getModels()Ljava/util/List;

    .line 82
    .line 83
    .line 84
    move-result-object v0

    .line 85
    invoke-static {v0}, Lyqc;->first(Ljava/util/List;)Ljava/lang/Object;

    .line 86
    .line 87
    .line 88
    move-result-object v0

    .line 89
    move-object v12, v0

    .line 90
    check-cast v12, Lgt1;

    .line 91
    .line 92
    const-wide v0, -0x1e3a0a0c56e39L

    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 98
    .line 99
    .line 100
    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 101
    .line 102
    .line 103
    const-wide v0, -0x1e3a9a0c56e39L

    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 109
    .line 110
    .line 111
    const-wide v0, -0x1e3ada0c56e39L

    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    invoke-static {v11, v10, v0, v1}, Lkh0;->lIo(Ljava/util/Map;Ljava/lang/String;J)V

    .line 117
    .line 118
    .line 119
    const-wide v0, -0x1e3b5a0c56e39L

    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 125
    .line 126
    .line 127
    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 128
    .line 129
    .line 130
    new-instance v0, Ljava/lang/StringBuilder;

    .line 131
    .line 132
    const-wide v1, -0x1e3bba0c56e39L

    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 138
    .line 139
    .line 140
    move-result-object v1

    .line 141
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 142
    .line 143
    .line 144
    iget-object v1, v9, Lxw1;->l:Ljava/lang/String;

    .line 145
    .line 146
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 147
    .line 148
    .line 149
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 150
    .line 151
    .line 152
    move-result-object v13

    .line 153
    iget-object v8, p0, Lcom/chuanyi/voyage/ui/aichat/Il;->I:Lza1;

    .line 154
    .line 155
    invoke-static {v8}, Lb6h;->loI(Ll2n0;)Ltac;

    .line 156
    .line 157
    .line 158
    move-result-object p0

    .line 159
    new-instance v7, Lva1;

    .line 160
    .line 161
    const/4 v14, 0x0

    .line 162
    invoke-direct/range {v7 .. v14}, Lva1;-><init>(Lza1;Lxw1;Ljava/lang/String;Ljava/util/Map;Lgt1;Ljava/lang/String;Lvce;)V

    .line 163
    .line 164
    .line 165
    invoke-static {p0, v5, v5, v7, v4}, Lw19;->loI(Lqoe;Lhoe;Ltoe;Lkotlin/jvm/functions/Function2;I)Lp9g0;

    .line 166
    .line 167
    .line 168
    :goto_0
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 169
    .line 170
    return-object p0

    .line 171
    :pswitch_1
    check-cast v6, Lkc10;

    .line 172
    .line 173
    invoke-interface {v1}, Lubg0;->getValue()Ljava/lang/Object;

    .line 174
    .line 175
    .line 176
    move-result-object v0

    .line 177
    check-cast v0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 178
    .line 179
    invoke-virtual {v0}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->getKey()Ljava/lang/String;

    .line 180
    .line 181
    .line 182
    move-result-object v0

    .line 183
    invoke-static {v0}, Ligh0;->isBlank(Ljava/lang/CharSequence;)Z

    .line 184
    .line 185
    .line 186
    move-result v0

    .line 187
    if-eqz v0, :cond_1

    .line 188
    .line 189
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 190
    .line 191
    invoke-interface {v6, v0}, Lkc10;->setValue(Ljava/lang/Object;)V

    .line 192
    .line 193
    .line 194
    :cond_1
    invoke-interface {v1}, Lubg0;->getValue()Ljava/lang/Object;

    .line 195
    .line 196
    .line 197
    move-result-object v0

    .line 198
    check-cast v0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 199
    .line 200
    invoke-virtual {v0, v3, v2}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->provider(Ljava/lang/String;Ljava/lang/String;)Lxw1;

    .line 201
    .line 202
    .line 203
    move-result-object v5

    .line 204
    invoke-virtual {v0}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->getKey()Ljava/lang/String;

    .line 205
    .line 206
    .line 207
    move-result-object v6

    .line 208
    invoke-virtual {v0}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->getHeaders()Ljava/lang/String;

    .line 209
    .line 210
    .line 211
    move-result-object v0

    .line 212
    invoke-static {v0}, Lcom/chuanyi/voyage/ui/aichat/Ill;->lIO(Ljava/lang/String;)Ljava/util/Map;

    .line 213
    .line 214
    .line 215
    move-result-object v7

    .line 216
    const-wide/16 v8, 0x0

    .line 217
    .line 218
    const/16 v10, 0x8

    .line 219
    .line 220
    iget-object v4, p0, Lcom/chuanyi/voyage/ui/aichat/Il;->I:Lza1;

    .line 221
    .line 222
    invoke-static/range {v4 .. v10}, Lza1;->Ol(Lza1;Lxw1;Ljava/lang/String;Ljava/util/Map;JI)V

    .line 223
    .line 224
    .line 225
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 226
    .line 227
    return-object p0

    .line 228
    nop

    .line 229
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
