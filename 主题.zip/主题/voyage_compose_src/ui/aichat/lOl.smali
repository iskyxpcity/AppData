.class public final Lcom/chuanyi/voyage/ui/aichat/lOl;
.super Li0i0;
.source "S"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic I:Lkc10;

.field public final synthetic O:Lkc10;

.field public final synthetic l:Lxw1;


# direct methods
.method public constructor <init>(Lxw1;Lkc10;Lkc10;Lvce;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lcom/chuanyi/voyage/ui/aichat/lOl;->l:Lxw1;

    .line 2
    .line 3
    iput-object p2, p0, Lcom/chuanyi/voyage/ui/aichat/lOl;->I:Lkc10;

    .line 4
    .line 5
    iput-object p3, p0, Lcom/chuanyi/voyage/ui/aichat/lOl;->O:Lkc10;

    .line 6
    .line 7
    const/4 p1, 0x2

    .line 8
    invoke-direct {p0, p1, p4}, Li0i0;-><init>(ILvce;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lvce;)Lvce;
    .locals 2

    .line 1
    new-instance p1, Lcom/chuanyi/voyage/ui/aichat/lOl;

    .line 2
    .line 3
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/aichat/lOl;->I:Lkc10;

    .line 4
    .line 5
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/aichat/lOl;->O:Lkc10;

    .line 6
    .line 7
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/aichat/lOl;->l:Lxw1;

    .line 8
    .line 9
    invoke-direct {p1, p0, v0, v1, p2}, Lcom/chuanyi/voyage/ui/aichat/lOl;-><init>(Lxw1;Lkc10;Lkc10;Lvce;)V

    .line 10
    .line 11
    .line 12
    return-object p1
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lqoe;

    .line 2
    .line 3
    check-cast p2, Lvce;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, Lcom/chuanyi/voyage/ui/aichat/lOl;->create(Ljava/lang/Object;Lvce;)Lvce;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    check-cast p0, Lcom/chuanyi/voyage/ui/aichat/lOl;

    .line 10
    .line 11
    sget-object p1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 12
    .line 13
    invoke-virtual {p0, p1}, Lcom/chuanyi/voyage/ui/aichat/lOl;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 11

    .line 1
    sget-object v0, Lroe;->l:Lroe;

    .line 2
    .line 3
    invoke-static {p1}, Lcp30;->IoO(Ljava/lang/Object;)V

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, Lcom/chuanyi/voyage/ui/aichat/lOl;->l:Lxw1;

    .line 7
    .line 8
    if-eqz p1, :cond_2

    .line 9
    .line 10
    iget-boolean v6, p1, Lxw1;->lO:Z

    .line 11
    .line 12
    sget-object p1, Lcom/chuanyi/voyage/ui/aichat/Ill;->l:Lzus;

    .line 13
    .line 14
    iget-object p1, p0, Lcom/chuanyi/voyage/ui/aichat/lOl;->I:Lkc10;

    .line 15
    .line 16
    invoke-interface {p1}, Lubg0;->getValue()Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    check-cast v0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 21
    .line 22
    if-nez v0, :cond_0

    .line 23
    .line 24
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 25
    .line 26
    return-object p0

    .line 27
    :cond_0
    invoke-virtual {v0}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->getEnabled()Z

    .line 28
    .line 29
    .line 30
    move-result v1

    .line 31
    if-eq v6, v1, :cond_1

    .line 32
    .line 33
    const/16 v9, 0xdf

    .line 34
    .line 35
    const/4 v10, 0x0

    .line 36
    const/4 v1, 0x0

    .line 37
    const/4 v2, 0x0

    .line 38
    const/4 v3, 0x0

    .line 39
    const/4 v4, 0x0

    .line 40
    const/4 v5, 0x0

    .line 41
    const/4 v7, 0x0

    .line 42
    const/4 v8, 0x0

    .line 43
    invoke-static/range {v0 .. v10}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->copy$default(Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;Ljava/lang/String;Ldx1;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZLjava/util/List;ILjava/lang/Object;)Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    invoke-interface {p1, v0}, Lkc10;->setValue(Ljava/lang/Object;)V

    .line 48
    .line 49
    .line 50
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/aichat/lOl;->O:Lkc10;

    .line 51
    .line 52
    invoke-interface {p0}, Lubg0;->getValue()Ljava/lang/Object;

    .line 53
    .line 54
    .line 55
    move-result-object p1

    .line 56
    move-object v0, p1

    .line 57
    check-cast v0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 58
    .line 59
    invoke-static/range {v0 .. v10}, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;->copy$default(Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;Ljava/lang/String;Ldx1;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZLjava/util/List;ILjava/lang/Object;)Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 60
    .line 61
    .line 62
    move-result-object p1

    .line 63
    invoke-interface {p0, p1}, Lkc10;->setValue(Ljava/lang/Object;)V

    .line 64
    .line 65
    .line 66
    :cond_1
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 67
    .line 68
    return-object p0

    .line 69
    :cond_2
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 70
    .line 71
    return-object p0
.end method
