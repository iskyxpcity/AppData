.class public final synthetic Lcom/chuanyi/voyage/ui/aichat/lIO;
.super Ljava/lang/Object;
.source "S"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic l:Lkc10;


# direct methods
.method public synthetic constructor <init>(Lkc10;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lcom/chuanyi/voyage/ui/aichat/lIO;->l:Lkc10;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 1

    .line 1
    sget-object v0, Lcom/chuanyi/voyage/ui/aichat/Ill;->l:Lzus;

    .line 2
    .line 3
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/aichat/lIO;->l:Lkc10;

    .line 4
    .line 5
    invoke-interface {p0}, Lubg0;->getValue()Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    check-cast p0, Lcom/chuanyi/voyage/ui/aichat/AiProviderDraft;

    .line 10
    .line 11
    return-object p0
.end method
