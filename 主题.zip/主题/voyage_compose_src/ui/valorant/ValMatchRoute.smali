.class public final Lcom/chuanyi/voyage/ui/valorant/ValMatchRoute;
.super Ljava/lang/Object;
.source "S"

# interfaces
.implements Lbm10;


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000N\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0010\u0008\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\u0008\t\n\u0002\u0010\u000e\n\u0002\u0008\u0004\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\u0008\n\u0008\u0087\u0008\u0018\u0000 *2\u00020\u0001:\u0002+,B\u0017\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u00a2\u0006\u0004\u0008\u0006\u0010\u0007B/\u0008\u0010\u0012\u0006\u0010\t\u001a\u00020\u0008\u0012\u0008\u0010\u0003\u001a\u0004\u0018\u00010\u0002\u0012\u0008\u0010\u0005\u001a\u0004\u0018\u00010\u0004\u0012\u0008\u0010\u000b\u001a\u0004\u0018\u00010\n\u00a2\u0006\u0004\u0008\u0006\u0010\u000cJ\'\u0010\u0015\u001a\u00020\u00122\u0006\u0010\r\u001a\u00020\u00002\u0006\u0010\u000f\u001a\u00020\u000e2\u0006\u0010\u0011\u001a\u00020\u0010H\u0001\u00a2\u0006\u0004\u0008\u0013\u0010\u0014J\u0010\u0010\u0016\u001a\u00020\u0002H\u00c6\u0003\u00a2\u0006\u0004\u0008\u0016\u0010\u0017J\u0010\u0010\u0018\u001a\u00020\u0004H\u00c6\u0003\u00a2\u0006\u0004\u0008\u0018\u0010\u0019J$\u0010\u001a\u001a\u00020\u00002\u0008\u0008\u0002\u0010\u0003\u001a\u00020\u00022\u0008\u0008\u0002\u0010\u0005\u001a\u00020\u0004H\u00c6\u0001\u00a2\u0006\u0004\u0008\u001a\u0010\u001bJ\u0010\u0010\u001d\u001a\u00020\u001cH\u00d6\u0001\u00a2\u0006\u0004\u0008\u001d\u0010\u001eJ\u0010\u0010\u001f\u001a\u00020\u0008H\u00d6\u0001\u00a2\u0006\u0004\u0008\u001f\u0010 J\u001a\u0010$\u001a\u00020#2\u0008\u0010\"\u001a\u0004\u0018\u00010!H\u00d6\u0003\u00a2\u0006\u0004\u0008$\u0010%R\u0017\u0010\u0003\u001a\u00020\u00028\u0006\u00a2\u0006\u000c\n\u0004\u0008\u0003\u0010&\u001a\u0004\u0008\'\u0010\u0017R\u0017\u0010\u0005\u001a\u00020\u00048\u0006\u00a2\u0006\u000c\n\u0004\u0008\u0005\u0010(\u001a\u0004\u0008)\u0010\u0019\u00a8\u0006-"
    }
    d2 = {
        "Lcom/chuanyi/voyage/ui/valorant/ValMatchRoute;",
        "Lbm10;",
        "Ly2m0;",
        "player",
        "Ln1m0;",
        "match",
        "<init>",
        "(Ly2m0;Ln1m0;)V",
        "",
        "seen0",
        "Lu3e0;",
        "serializationConstructorMarker",
        "(ILy2m0;Ln1m0;Lu3e0;)V",
        "self",
        "Lvud;",
        "output",
        "Le3e0;",
        "serialDesc",
        "",
        "write$Self$app",
        "(Lcom/chuanyi/voyage/ui/valorant/ValMatchRoute;Lvud;Le3e0;)V",
        "write$Self",
        "component1",
        "()Ly2m0;",
        "component2",
        "()Ln1m0;",
        "copy",
        "(Ly2m0;Ln1m0;)Lcom/chuanyi/voyage/ui/valorant/ValMatchRoute;",
        "",
        "toString",
        "()Ljava/lang/String;",
        "hashCode",
        "()I",
        "",
        "other",
        "",
        "equals",
        "(Ljava/lang/Object;)Z",
        "Ly2m0;",
        "getPlayer",
        "Ln1m0;",
        "getMatch",
        "Companion",
        "v1m0",
        "w1m0",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation

.annotation runtime Lq3e0;
.end annotation


# static fields
.field public static final $stable:I

.field public static final Companion:Lw1m0;


# instance fields
.field private final match:Ln1m0;

.field private final player:Ly2m0;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, Lw1m0;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lcom/chuanyi/voyage/ui/valorant/ValMatchRoute;->Companion:Lw1m0;

    .line 7
    .line 8
    sget-object v0, Ln1m0;->Companion:Lm1m0;

    .line 9
    .line 10
    sget-object v0, Ly2m0;->Companion:Lx2m0;

    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    sput v0, Lcom/chuanyi/voyage/ui/valorant/ValMatchRoute;->$stable:I

    .line 14
    .line 15
    return-void
.end method

.method public synthetic constructor <init>(ILy2m0;Ln1m0;Lu3e0;)V
    .locals 1

    and-int/lit8 p4, p1, 0x3

    const/4 v0, 0x3

    if-ne v0, p4, :cond_0

    .line 31
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Lcom/chuanyi/voyage/ui/valorant/ValMatchRoute;->player:Ly2m0;

    iput-object p3, p0, Lcom/chuanyi/voyage/ui/valorant/ValMatchRoute;->match:Ln1m0;

    return-void

    :cond_0
    sget-object p0, Lv1m0;->l:Lv1m0;

    invoke-virtual {p0}, Lv1m0;->getDescriptor()Le3e0;

    move-result-object p0

    invoke-static {p1, v0, p0}, Lqmu0;->lIl(IILe3e0;)V

    const/4 p0, 0x0

    throw p0
.end method

.method public constructor <init>(Ly2m0;Ln1m0;)V
    .locals 2

    .line 1
    const-wide v0, -0x11d8ab4a0c56e39L

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    const-wide v0, -0x11d8abba0c56e39L

    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 21
    .line 22
    .line 23
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 24
    .line 25
    .line 26
    iput-object p1, p0, Lcom/chuanyi/voyage/ui/valorant/ValMatchRoute;->player:Ly2m0;

    .line 27
    .line 28
    iput-object p2, p0, Lcom/chuanyi/voyage/ui/valorant/ValMatchRoute;->match:Ln1m0;

    .line 29
    .line 30
    return-void
.end method

.method public static synthetic copy$default(Lcom/chuanyi/voyage/ui/valorant/ValMatchRoute;Ly2m0;Ln1m0;ILjava/lang/Object;)Lcom/chuanyi/voyage/ui/valorant/ValMatchRoute;
    .locals 0

    .line 1
    and-int/lit8 p4, p3, 0x1

    .line 2
    .line 3
    if-eqz p4, :cond_0

    .line 4
    .line 5
    iget-object p1, p0, Lcom/chuanyi/voyage/ui/valorant/ValMatchRoute;->player:Ly2m0;

    .line 6
    .line 7
    :cond_0
    and-int/lit8 p3, p3, 0x2

    .line 8
    .line 9
    if-eqz p3, :cond_1

    .line 10
    .line 11
    iget-object p2, p0, Lcom/chuanyi/voyage/ui/valorant/ValMatchRoute;->match:Ln1m0;

    .line 12
    .line 13
    :cond_1
    invoke-virtual {p0, p1, p2}, Lcom/chuanyi/voyage/ui/valorant/ValMatchRoute;->copy(Ly2m0;Ln1m0;)Lcom/chuanyi/voyage/ui/valorant/ValMatchRoute;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    return-object p0
.end method

.method public static final synthetic write$Self$app(Lcom/chuanyi/voyage/ui/valorant/ValMatchRoute;Lvud;Le3e0;)V
    .locals 3
    .annotation runtime Lkotlin/jvm/JvmStatic;
    .end annotation

    .line 1
    sget-object v0, Lw2m0;->l:Lw2m0;

    .line 2
    .line 3
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/valorant/ValMatchRoute;->player:Ly2m0;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    invoke-interface {p1, p2, v2, v0, v1}, Lvud;->lo(Le3e0;ILd9t;Ljava/lang/Object;)V

    .line 7
    .line 8
    .line 9
    sget-object v0, Ll1m0;->l:Ll1m0;

    .line 10
    .line 11
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/valorant/ValMatchRoute;->match:Ln1m0;

    .line 12
    .line 13
    const/4 v1, 0x1

    .line 14
    invoke-interface {p1, p2, v1, v0, p0}, Lvud;->lo(Le3e0;ILd9t;Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    return-void
.end method


# virtual methods
.method public final component1()Ly2m0;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/valorant/ValMatchRoute;->player:Ly2m0;

    .line 2
    .line 3
    return-object p0
.end method

.method public final component2()Ln1m0;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/valorant/ValMatchRoute;->match:Ln1m0;

    .line 2
    .line 3
    return-object p0
.end method

.method public final copy(Ly2m0;Ln1m0;)Lcom/chuanyi/voyage/ui/valorant/ValMatchRoute;
    .locals 2

    .line 1
    const-wide v0, -0x11d8ac1a0c56e39L

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    const-wide v0, -0x11d8ac8a0c56e39L

    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 21
    .line 22
    .line 23
    new-instance p0, Lcom/chuanyi/voyage/ui/valorant/ValMatchRoute;

    .line 24
    .line 25
    invoke-direct {p0, p1, p2}, Lcom/chuanyi/voyage/ui/valorant/ValMatchRoute;-><init>(Ly2m0;Ln1m0;)V

    .line 26
    .line 27
    .line 28
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, p1, :cond_0

    .line 3
    .line 4
    return v0

    .line 5
    :cond_0
    instance-of v1, p1, Lcom/chuanyi/voyage/ui/valorant/ValMatchRoute;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    if-nez v1, :cond_1

    .line 9
    .line 10
    return v2

    .line 11
    :cond_1
    check-cast p1, Lcom/chuanyi/voyage/ui/valorant/ValMatchRoute;

    .line 12
    .line 13
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/valorant/ValMatchRoute;->player:Ly2m0;

    .line 14
    .line 15
    iget-object v3, p1, Lcom/chuanyi/voyage/ui/valorant/ValMatchRoute;->player:Ly2m0;

    .line 16
    .line 17
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    move-result v1

    .line 21
    if-nez v1, :cond_2

    .line 22
    .line 23
    return v2

    .line 24
    :cond_2
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/valorant/ValMatchRoute;->match:Ln1m0;

    .line 25
    .line 26
    iget-object p1, p1, Lcom/chuanyi/voyage/ui/valorant/ValMatchRoute;->match:Ln1m0;

    .line 27
    .line 28
    invoke-static {p0, p1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 29
    .line 30
    .line 31
    move-result p0

    .line 32
    if-nez p0, :cond_3

    .line 33
    .line 34
    return v2

    .line 35
    :cond_3
    return v0
.end method

.method public final getMatch()Ln1m0;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/valorant/ValMatchRoute;->match:Ln1m0;

    .line 2
    .line 3
    return-object p0
.end method

.method public final getPlayer()Ly2m0;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/valorant/ValMatchRoute;->player:Ly2m0;

    .line 2
    .line 3
    return-object p0
.end method

.method public hashCode()I
    .locals 1

    .line 1
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/valorant/ValMatchRoute;->player:Ly2m0;

    .line 2
    .line 3
    invoke-virtual {v0}, Ly2m0;->hashCode()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    mul-int/lit8 v0, v0, 0x1f

    .line 8
    .line 9
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/valorant/ValMatchRoute;->match:Ln1m0;

    .line 10
    .line 11
    invoke-virtual {p0}, Ln1m0;->hashCode()I

    .line 12
    .line 13
    .line 14
    move-result p0

    .line 15
    add-int/2addr p0, v0

    .line 16
    return p0
.end method

.method public toString()Ljava/lang/String;
    .locals 3

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-wide v1, -0x11d8acea0c56e39L

    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/valorant/ValMatchRoute;->player:Ly2m0;

    .line 16
    .line 17
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 18
    .line 19
    .line 20
    const-wide v1, -0x11d8ae4a0c56e39L

    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object v1

    .line 29
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 30
    .line 31
    .line 32
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/valorant/ValMatchRoute;->match:Ln1m0;

    .line 33
    .line 34
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 35
    .line 36
    .line 37
    const/16 p0, 0x29

    .line 38
    .line 39
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 40
    .line 41
    .line 42
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 43
    .line 44
    .line 45
    move-result-object p0

    .line 46
    return-object p0
.end method
