.class public final Lcom/chuanyi/voyage/ui/valorant/ValBoardRoute;
.super Ljava/lang/Object;
.source "S"

# interfaces
.implements Lbm10;


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000H\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0010\u0008\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\u0008\u0007\n\u0002\u0010\u000e\n\u0002\u0008\u0004\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\u0008\u0008\u0008\u0087\u0008\u0018\u0000 $2\u00020\u0001:\u0002%&B\u000f\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u00a2\u0006\u0004\u0008\u0004\u0010\u0005B%\u0008\u0010\u0012\u0006\u0010\u0007\u001a\u00020\u0006\u0012\u0008\u0010\u0003\u001a\u0004\u0018\u00010\u0002\u0012\u0008\u0010\t\u001a\u0004\u0018\u00010\u0008\u00a2\u0006\u0004\u0008\u0004\u0010\nJ\'\u0010\u0013\u001a\u00020\u00102\u0006\u0010\u000b\u001a\u00020\u00002\u0006\u0010\r\u001a\u00020\u000c2\u0006\u0010\u000f\u001a\u00020\u000eH\u0001\u00a2\u0006\u0004\u0008\u0011\u0010\u0012J\u0010\u0010\u0014\u001a\u00020\u0002H\u00c6\u0003\u00a2\u0006\u0004\u0008\u0014\u0010\u0015J\u001a\u0010\u0016\u001a\u00020\u00002\u0008\u0008\u0002\u0010\u0003\u001a\u00020\u0002H\u00c6\u0001\u00a2\u0006\u0004\u0008\u0016\u0010\u0017J\u0010\u0010\u0019\u001a\u00020\u0018H\u00d6\u0001\u00a2\u0006\u0004\u0008\u0019\u0010\u001aJ\u0010\u0010\u001b\u001a\u00020\u0006H\u00d6\u0001\u00a2\u0006\u0004\u0008\u001b\u0010\u001cJ\u001a\u0010 \u001a\u00020\u001f2\u0008\u0010\u001e\u001a\u0004\u0018\u00010\u001dH\u00d6\u0003\u00a2\u0006\u0004\u0008 \u0010!R\u0017\u0010\u0003\u001a\u00020\u00028\u0006\u00a2\u0006\u000c\n\u0004\u0008\u0003\u0010\"\u001a\u0004\u0008#\u0010\u0015\u00a8\u0006\'"
    }
    d2 = {
        "Lcom/chuanyi/voyage/ui/valorant/ValBoardRoute;",
        "Lbm10;",
        "Lm5m0;",
        "shard",
        "<init>",
        "(Lm5m0;)V",
        "",
        "seen0",
        "Lu3e0;",
        "serializationConstructorMarker",
        "(ILm5m0;Lu3e0;)V",
        "self",
        "Lvud;",
        "output",
        "Le3e0;",
        "serialDesc",
        "",
        "write$Self$app",
        "(Lcom/chuanyi/voyage/ui/valorant/ValBoardRoute;Lvud;Le3e0;)V",
        "write$Self",
        "component1",
        "()Lm5m0;",
        "copy",
        "(Lm5m0;)Lcom/chuanyi/voyage/ui/valorant/ValBoardRoute;",
        "",
        "toString",
        "()Ljava/lang/String;",
        "hashCode",
        "()I",
        "",
        "other",
        "",
        "equals",
        "(Ljava/lang/Object;)Z",
        "Lm5m0;",
        "getShard",
        "Companion",
        "fwl0",
        "gwl0",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation

.annotation runtime Lq3e0;
.end annotation


# static fields
.field private static final $childSerializers:[Laau;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "Laau;"
        }
    .end annotation
.end field

.field public static final $stable:I

.field public static final Companion:Lgwl0;


# instance fields
.field private final shard:Lm5m0;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    new-instance v0, Lgwl0;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lcom/chuanyi/voyage/ui/valorant/ValBoardRoute;->Companion:Lgwl0;

    .line 7
    .line 8
    sget-object v0, Lygu;->I:Lygu;

    .line 9
    .line 10
    new-instance v1, Lurl0;

    .line 11
    .line 12
    const/16 v2, 0xf

    .line 13
    .line 14
    invoke-direct {v1, v2}, Lurl0;-><init>(B)V

    .line 15
    .line 16
    .line 17
    invoke-static {v0, v1}, Lesm;->Ol(Lygu;Lkotlin/jvm/functions/Function0;)Laau;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    const/4 v1, 0x1

    .line 22
    new-array v1, v1, [Laau;

    .line 23
    .line 24
    const/4 v2, 0x0

    .line 25
    aput-object v0, v1, v2

    .line 26
    .line 27
    sput-object v1, Lcom/chuanyi/voyage/ui/valorant/ValBoardRoute;->$childSerializers:[Laau;

    .line 28
    .line 29
    return-void
.end method

.method public synthetic constructor <init>(ILm5m0;Lu3e0;)V
    .locals 1

    .line 1
    and-int/lit8 p3, p1, 0x1

    .line 2
    .line 3
    const/4 v0, 0x1

    .line 4
    if-ne v0, p3, :cond_0

    .line 5
    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object p2, p0, Lcom/chuanyi/voyage/ui/valorant/ValBoardRoute;->shard:Lm5m0;

    .line 10
    .line 11
    return-void

    .line 12
    :cond_0
    sget-object p0, Lfwl0;->l:Lfwl0;

    .line 13
    .line 14
    invoke-virtual {p0}, Lfwl0;->getDescriptor()Le3e0;

    .line 15
    .line 16
    .line 17
    move-result-object p0

    .line 18
    invoke-static {p1, v0, p0}, Lqmu0;->lIl(IILe3e0;)V

    .line 19
    .line 20
    .line 21
    const/4 p0, 0x0

    .line 22
    throw p0
.end method

.method public constructor <init>(Lm5m0;)V
    .locals 2

    const-wide v0, -0x11ce045a0c56e39L

    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 23
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 24
    iput-object p1, p0, Lcom/chuanyi/voyage/ui/valorant/ValBoardRoute;->shard:Lm5m0;

    return-void
.end method

.method private static final synthetic _childSerializers$_anonymous_()Ld9t;
    .locals 1

    .line 1
    sget-object v0, Lm5m0;->Companion:Ll5m0;

    .line 2
    .line 3
    invoke-virtual {v0}, Ll5m0;->serializer()Ld9t;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    return-object v0
.end method

.method public static final synthetic access$get$childSerializers$cp()[Laau;
    .locals 1

    .line 1
    sget-object v0, Lcom/chuanyi/voyage/ui/valorant/ValBoardRoute;->$childSerializers:[Laau;

    .line 2
    .line 3
    return-object v0
.end method

.method public static synthetic copy$default(Lcom/chuanyi/voyage/ui/valorant/ValBoardRoute;Lm5m0;ILjava/lang/Object;)Lcom/chuanyi/voyage/ui/valorant/ValBoardRoute;
    .locals 0

    .line 1
    and-int/lit8 p2, p2, 0x1

    .line 2
    .line 3
    if-eqz p2, :cond_0

    .line 4
    .line 5
    iget-object p1, p0, Lcom/chuanyi/voyage/ui/valorant/ValBoardRoute;->shard:Lm5m0;

    .line 6
    .line 7
    :cond_0
    invoke-virtual {p0, p1}, Lcom/chuanyi/voyage/ui/valorant/ValBoardRoute;->copy(Lm5m0;)Lcom/chuanyi/voyage/ui/valorant/ValBoardRoute;

    .line 8
    .line 9
    .line 10
    move-result-object p0

    .line 11
    return-object p0
.end method

.method public static synthetic l()Ld9t;
    .locals 1

    .line 1
    invoke-static {}, Lcom/chuanyi/voyage/ui/valorant/ValBoardRoute;->_childSerializers$_anonymous_()Ld9t;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    return-object v0
.end method

.method public static final synthetic write$Self$app(Lcom/chuanyi/voyage/ui/valorant/ValBoardRoute;Lvud;Le3e0;)V
    .locals 2
    .annotation runtime Lkotlin/jvm/JvmStatic;
    .end annotation

    .line 1
    sget-object v0, Lcom/chuanyi/voyage/ui/valorant/ValBoardRoute;->$childSerializers:[Laau;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    aget-object v0, v0, v1

    .line 5
    .line 6
    invoke-interface {v0}, Laau;->getValue()Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    check-cast v0, Ld9t;

    .line 11
    .line 12
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/valorant/ValBoardRoute;->shard:Lm5m0;

    .line 13
    .line 14
    invoke-interface {p1, p2, v1, v0, p0}, Lvud;->lo(Le3e0;ILd9t;Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    return-void
.end method


# virtual methods
.method public final component1()Lm5m0;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/valorant/ValBoardRoute;->shard:Lm5m0;

    .line 2
    .line 3
    return-object p0
.end method

.method public final copy(Lm5m0;)Lcom/chuanyi/voyage/ui/valorant/ValBoardRoute;
    .locals 2

    .line 1
    const-wide v0, -0x11ce04ba0c56e39L

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    new-instance p0, Lcom/chuanyi/voyage/ui/valorant/ValBoardRoute;

    .line 13
    .line 14
    invoke-direct {p0, p1}, Lcom/chuanyi/voyage/ui/valorant/ValBoardRoute;-><init>(Lm5m0;)V

    .line 15
    .line 16
    .line 17
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 3

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, p1, :cond_0

    .line 3
    .line 4
    return v0

    .line 5
    :cond_0
    instance-of v1, p1, Lcom/chuanyi/voyage/ui/valorant/ValBoardRoute;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    if-nez v1, :cond_1

    .line 9
    .line 10
    return v2

    .line 11
    :cond_1
    check-cast p1, Lcom/chuanyi/voyage/ui/valorant/ValBoardRoute;

    .line 12
    .line 13
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/valorant/ValBoardRoute;->shard:Lm5m0;

    .line 14
    .line 15
    iget-object p1, p1, Lcom/chuanyi/voyage/ui/valorant/ValBoardRoute;->shard:Lm5m0;

    .line 16
    .line 17
    if-eq p0, p1, :cond_2

    .line 18
    .line 19
    return v2

    .line 20
    :cond_2
    return v0
.end method

.method public final getShard()Lm5m0;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/valorant/ValBoardRoute;->shard:Lm5m0;

    .line 2
    .line 3
    return-object p0
.end method

.method public hashCode()I
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/valorant/ValBoardRoute;->shard:Lm5m0;

    .line 2
    .line 3
    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public toString()Ljava/lang/String;
    .locals 3

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-wide v1, -0x11ce051a0c56e39L    # -1.6393014000520738E303

    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/valorant/ValBoardRoute;->shard:Lm5m0;

    .line 16
    .line 17
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 18
    .line 19
    .line 20
    const/16 p0, 0x29

    .line 21
    .line 22
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 23
    .line 24
    .line 25
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object p0

    .line 29
    return-object p0
.end method
