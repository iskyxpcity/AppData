.class public final enum Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;
.super Ljava/lang/Enum;
.source "S"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0011\u0008\u0087\u0081\u0002\u0018\u0000 \u000e2\u0008\u0012\u0004\u0012\u00020\u00000\u0001:\u0001\u000fB\u0019\u0008\u0002\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u00a2\u0006\u0004\u0008\u0006\u0010\u0007R\u0017\u0010\u0003\u001a\u00020\u00028\u0006\u00a2\u0006\u000c\n\u0004\u0008\u0003\u0010\u0008\u001a\u0004\u0008\t\u0010\nR\u0017\u0010\u0005\u001a\u00020\u00048\u0006\u00a2\u0006\u000c\n\u0004\u0008\u0005\u0010\u000b\u001a\u0004\u0008\u000c\u0010\rj\u0002\u0008\u0010j\u0002\u0008\u0011j\u0002\u0008\u0012j\u0002\u0008\u0013j\u0002\u0008\u0014\u00a8\u0006\u0015"
    }
    d2 = {
        "Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;",
        "",
        "",
        "label",
        "Lrul0;",
        "kind",
        "<init>",
        "(Ljava/lang/String;ILjava/lang/String;Lrul0;)V",
        "Ljava/lang/String;",
        "getLabel",
        "()Ljava/lang/String;",
        "Lrul0;",
        "getKind",
        "()Lrul0;",
        "Companion",
        "x0m0",
        "RIOT",
        "WEGAME_QQ",
        "MVAL_QQ",
        "WEGAME_WECHAT",
        "MVAL_WECHAT",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation

.annotation runtime Lq3e0;
.end annotation


# static fields
.field private static final synthetic $ENTRIES:Lkotlin/enums/EnumEntries;

.field private static final synthetic $VALUES:[Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;

.field private static final $cachedSerializer$delegate:Laau;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Laau;"
        }
    .end annotation
.end field

.field public static final Companion:Lx0m0;

.field public static final enum MVAL_QQ:Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;

.field public static final enum MVAL_WECHAT:Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;

.field public static final enum RIOT:Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;

.field public static final enum WEGAME_QQ:Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;

.field public static final enum WEGAME_WECHAT:Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;


# instance fields
.field private final kind:Lrul0;

.field private final label:Ljava/lang/String;


# direct methods
.method private static final synthetic $values()[Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;
    .locals 5

    .line 1
    sget-object v0, Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;->RIOT:Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;

    .line 2
    .line 3
    sget-object v1, Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;->WEGAME_QQ:Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;

    .line 4
    .line 5
    sget-object v2, Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;->MVAL_QQ:Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;

    .line 6
    .line 7
    sget-object v3, Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;->WEGAME_WECHAT:Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;

    .line 8
    .line 9
    sget-object v4, Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;->MVAL_WECHAT:Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;

    .line 10
    .line 11
    filled-new-array {v0, v1, v2, v3, v4}, [Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    return-object v0
.end method

.method static constructor <clinit>()V
    .locals 7

    .line 1
    new-instance v0, Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;

    .line 2
    .line 3
    const-wide v1, -0x11d5d61a0c56e39L

    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    const-wide v2, -0x11d5d66a0c56e39L

    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    invoke-static {v2, v3}, Li6t0;->lO(J)Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object v2

    .line 21
    sget-object v3, Lrul0;->o:Lrul0;

    .line 22
    .line 23
    const/4 v4, 0x0

    .line 24
    invoke-direct {v0, v1, v4, v2, v3}, Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;-><init>(Ljava/lang/String;ILjava/lang/String;Lrul0;)V

    .line 25
    .line 26
    .line 27
    sput-object v0, Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;->RIOT:Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;

    .line 28
    .line 29
    new-instance v0, Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;

    .line 30
    .line 31
    const-wide v1, -0x11d5d70a0c56e39L

    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 37
    .line 38
    .line 39
    move-result-object v1

    .line 40
    const-wide v2, -0x11d5d7aa0c56e39L

    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    invoke-static {v2, v3}, Li6t0;->lO(J)Ljava/lang/String;

    .line 46
    .line 47
    .line 48
    move-result-object v2

    .line 49
    sget-object v3, Lrul0;->ll:Lrul0;

    .line 50
    .line 51
    const/4 v4, 0x1

    .line 52
    invoke-direct {v0, v1, v4, v2, v3}, Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;-><init>(Ljava/lang/String;ILjava/lang/String;Lrul0;)V

    .line 53
    .line 54
    .line 55
    sput-object v0, Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;->WEGAME_QQ:Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;

    .line 56
    .line 57
    new-instance v0, Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;

    .line 58
    .line 59
    const-wide v1, -0x11d5d87a0c56e39L

    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 65
    .line 66
    .line 67
    move-result-object v1

    .line 68
    const-wide v4, -0x11d5d8fa0c56e39L

    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    invoke-static {v4, v5}, Li6t0;->lO(J)Ljava/lang/String;

    .line 74
    .line 75
    .line 76
    move-result-object v2

    .line 77
    sget-object v4, Lrul0;->lI:Lrul0;

    .line 78
    .line 79
    const/4 v5, 0x2

    .line 80
    invoke-direct {v0, v1, v5, v2, v4}, Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;-><init>(Ljava/lang/String;ILjava/lang/String;Lrul0;)V

    .line 81
    .line 82
    .line 83
    sput-object v0, Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;->MVAL_QQ:Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;

    .line 84
    .line 85
    new-instance v0, Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;

    .line 86
    .line 87
    const-wide v1, -0x11d5d9ca0c56e39L

    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 93
    .line 94
    .line 95
    move-result-object v1

    .line 96
    const-wide v5, -0x11d5daaa0c56e39L

    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    invoke-static {v5, v6}, Li6t0;->lO(J)Ljava/lang/String;

    .line 102
    .line 103
    .line 104
    move-result-object v2

    .line 105
    const/4 v5, 0x3

    .line 106
    invoke-direct {v0, v1, v5, v2, v3}, Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;-><init>(Ljava/lang/String;ILjava/lang/String;Lrul0;)V

    .line 107
    .line 108
    .line 109
    sput-object v0, Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;->WEGAME_WECHAT:Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;

    .line 110
    .line 111
    new-instance v0, Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;

    .line 112
    .line 113
    const-wide v1, -0x11d5db6a0c56e39L

    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 119
    .line 120
    .line 121
    move-result-object v1

    .line 122
    const-wide v2, -0x11d5dc2a0c56e39L

    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    invoke-static {v2, v3}, Li6t0;->lO(J)Ljava/lang/String;

    .line 128
    .line 129
    .line 130
    move-result-object v2

    .line 131
    const/4 v3, 0x4

    .line 132
    invoke-direct {v0, v1, v3, v2, v4}, Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;-><init>(Ljava/lang/String;ILjava/lang/String;Lrul0;)V

    .line 133
    .line 134
    .line 135
    sput-object v0, Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;->MVAL_WECHAT:Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;

    .line 136
    .line 137
    invoke-static {}, Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;->$values()[Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;

    .line 138
    .line 139
    .line 140
    move-result-object v0

    .line 141
    sput-object v0, Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;->$VALUES:[Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;

    .line 142
    .line 143
    invoke-static {v0}, Lkotlin/enums/EnumEntriesKt;->enumEntries([Ljava/lang/Enum;)Lkotlin/enums/EnumEntries;

    .line 144
    .line 145
    .line 146
    move-result-object v0

    .line 147
    sput-object v0, Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;->$ENTRIES:Lkotlin/enums/EnumEntries;

    .line 148
    .line 149
    new-instance v0, Lx0m0;

    .line 150
    .line 151
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 152
    .line 153
    .line 154
    sput-object v0, Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;->Companion:Lx0m0;

    .line 155
    .line 156
    sget-object v0, Lygu;->I:Lygu;

    .line 157
    .line 158
    new-instance v1, Lurl0;

    .line 159
    .line 160
    const/16 v2, 0x16

    .line 161
    .line 162
    invoke-direct {v1, v2}, Lurl0;-><init>(B)V

    .line 163
    .line 164
    .line 165
    invoke-static {v0, v1}, Lesm;->Ol(Lygu;Lkotlin/jvm/functions/Function0;)Laau;

    .line 166
    .line 167
    .line 168
    move-result-object v0

    .line 169
    sput-object v0, Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;->$cachedSerializer$delegate:Laau;

    .line 170
    .line 171
    return-void
.end method

.method private constructor <init>(Ljava/lang/String;ILjava/lang/String;Lrul0;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lrul0;",
            ")V"
        }
    .end annotation

    .line 1
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 2
    .line 3
    .line 4
    iput-object p3, p0, Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;->label:Ljava/lang/String;

    .line 5
    .line 6
    iput-object p4, p0, Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;->kind:Lrul0;

    .line 7
    .line 8
    return-void
.end method

.method private static final _init_$_anonymous_()Ld9t;
    .locals 3

    .line 1
    const-wide v0, -0x11d5d33a0c56e39L

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    invoke-static {}, Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;->values()[Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    .line 16
    .line 17
    new-instance v2, Lu5k;

    .line 18
    .line 19
    invoke-direct {v2, v0, v1}, Lu5k;-><init>(Ljava/lang/String;[Ljava/lang/Enum;)V

    .line 20
    .line 21
    .line 22
    return-object v2
.end method

.method public static final synthetic access$get$cachedSerializer$delegate$cp()Laau;
    .locals 1

    .line 1
    sget-object v0, Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;->$cachedSerializer$delegate:Laau;

    .line 2
    .line 3
    return-object v0
.end method

.method public static getEntries()Lkotlin/enums/EnumEntries;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/enums/EnumEntries<",
            "Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;",
            ">;"
        }
    .end annotation

    .line 1
    sget-object v0, Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;->$ENTRIES:Lkotlin/enums/EnumEntries;

    .line 2
    .line 3
    return-object v0
.end method

.method public static synthetic l()Ld9t;
    .locals 1

    .line 1
    invoke-static {}, Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;->_init_$_anonymous_()Ld9t;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;
    .locals 1

    .line 1
    const-class v0, Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;

    .line 2
    .line 3
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;

    .line 8
    .line 9
    return-object p0
.end method

.method public static values()[Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;
    .locals 1

    .line 1
    sget-object v0, Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;->$VALUES:[Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, [Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;

    .line 8
    .line 9
    return-object v0
.end method


# virtual methods
.method public final getKind()Lrul0;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;->kind:Lrul0;

    .line 2
    .line 3
    return-object p0
.end method

.method public final getLabel()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/valorant/ValLoginMethod;->label:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method
