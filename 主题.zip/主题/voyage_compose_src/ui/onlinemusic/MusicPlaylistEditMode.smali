.class public final enum Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;
.super Ljava/lang/Enum;
.source "S"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u000c\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\u0008\u0008\u0008\u0081\u0081\u0002\u0018\u0000 \u00042\u0008\u0012\u0004\u0012\u00020\u00000\u0001:\u0001\u0005B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003j\u0002\u0008\u0006j\u0002\u0008\u0007j\u0002\u0008\u0008\u00a8\u0006\t"
    }
    d2 = {
        "Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;",
        "",
        "<init>",
        "(Ljava/lang/String;I)V",
        "Companion",
        "ut00",
        "CREATE",
        "EDIT",
        "ADD",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation

.annotation runtime Lq3e0;
.end annotation


# static fields
.field private static final synthetic $ENTRIES:Lkotlin/enums/EnumEntries;

.field private static final synthetic $VALUES:[Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;

.field private static final $cachedSerializer$delegate:Laau;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Laau;"
        }
    .end annotation
.end field

.field public static final enum ADD:Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;

.field public static final enum CREATE:Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;

.field public static final Companion:Lut00;

.field public static final enum EDIT:Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;


# direct methods
.method private static final synthetic $values()[Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;
    .locals 3

    .line 1
    sget-object v0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;->CREATE:Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;

    .line 2
    .line 3
    sget-object v1, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;->EDIT:Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;

    .line 4
    .line 5
    sget-object v2, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;->ADD:Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;

    .line 6
    .line 7
    filled-new-array {v0, v1, v2}, [Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    return-object v0
.end method

.method static constructor <clinit>()V
    .locals 3

    .line 1
    new-instance v0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;

    .line 2
    .line 3
    const-wide v1, -0xd9de72a0c56e39L

    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    const/4 v2, 0x0

    .line 13
    invoke-direct {v0, v1, v2}, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;-><init>(Ljava/lang/String;I)V

    .line 14
    .line 15
    .line 16
    sput-object v0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;->CREATE:Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;

    .line 17
    .line 18
    new-instance v0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;

    .line 19
    .line 20
    const-wide v1, -0xd9de79a0c56e39L

    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object v1

    .line 29
    const/4 v2, 0x1

    .line 30
    invoke-direct {v0, v1, v2}, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;-><init>(Ljava/lang/String;I)V

    .line 31
    .line 32
    .line 33
    sput-object v0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;->EDIT:Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;

    .line 34
    .line 35
    new-instance v0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;

    .line 36
    .line 37
    const-wide v1, -0xd9de7ea0c56e39L

    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 43
    .line 44
    .line 45
    move-result-object v1

    .line 46
    const/4 v2, 0x2

    .line 47
    invoke-direct {v0, v1, v2}, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;-><init>(Ljava/lang/String;I)V

    .line 48
    .line 49
    .line 50
    sput-object v0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;->ADD:Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;

    .line 51
    .line 52
    invoke-static {}, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;->$values()[Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;

    .line 53
    .line 54
    .line 55
    move-result-object v0

    .line 56
    sput-object v0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;->$VALUES:[Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;

    .line 57
    .line 58
    invoke-static {v0}, Lkotlin/enums/EnumEntriesKt;->enumEntries([Ljava/lang/Enum;)Lkotlin/enums/EnumEntries;

    .line 59
    .line 60
    .line 61
    move-result-object v0

    .line 62
    sput-object v0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;->$ENTRIES:Lkotlin/enums/EnumEntries;

    .line 63
    .line 64
    new-instance v0, Lut00;

    .line 65
    .line 66
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 67
    .line 68
    .line 69
    sput-object v0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;->Companion:Lut00;

    .line 70
    .line 71
    sget-object v0, Lygu;->I:Lygu;

    .line 72
    .line 73
    new-instance v1, Les00;

    .line 74
    .line 75
    const/4 v2, 0x4

    .line 76
    invoke-direct {v1, v2}, Les00;-><init>(B)V

    .line 77
    .line 78
    .line 79
    invoke-static {v0, v1}, Lesm;->Ol(Lygu;Lkotlin/jvm/functions/Function0;)Laau;

    .line 80
    .line 81
    .line 82
    move-result-object v0

    .line 83
    sput-object v0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;->$cachedSerializer$delegate:Laau;

    .line 84
    .line 85
    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 1
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method private static final _init_$_anonymous_()Ld9t;
    .locals 3

    .line 1
    const-wide v0, -0xd9de3aa0c56e39L

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    invoke-static {}, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;->values()[Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    .line 16
    .line 17
    new-instance v2, Lu5k;

    .line 18
    .line 19
    invoke-direct {v2, v0, v1}, Lu5k;-><init>(Ljava/lang/String;[Ljava/lang/Enum;)V

    .line 20
    .line 21
    .line 22
    return-object v2
.end method

.method public static final synthetic access$get$cachedSerializer$delegate$cp()Laau;
    .locals 1

    .line 1
    sget-object v0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;->$cachedSerializer$delegate:Laau;

    .line 2
    .line 3
    return-object v0
.end method

.method public static getEntries()Lkotlin/enums/EnumEntries;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/enums/EnumEntries<",
            "Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;",
            ">;"
        }
    .end annotation

    .line 1
    sget-object v0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;->$ENTRIES:Lkotlin/enums/EnumEntries;

    .line 2
    .line 3
    return-object v0
.end method

.method public static synthetic l()Ld9t;
    .locals 1

    .line 1
    invoke-static {}, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;->_init_$_anonymous_()Ld9t;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;
    .locals 1

    .line 1
    const-class v0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;

    .line 2
    .line 3
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;

    .line 8
    .line 9
    return-object p0
.end method

.method public static values()[Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;
    .locals 1

    .line 1
    sget-object v0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;->$VALUES:[Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, [Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;

    .line 8
    .line 9
    return-object v0
.end method
