.class public final Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditRoute;
.super Ljava/lang/Object;
.source "S"

# interfaces
.implements Lbm10;


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000F\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\u0008\u0003\n\u0002\u0010\u0008\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\u0008\u000c\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\u0008\n\u0008\u0081\u0008\u0018\u0000 (2\u00020\u0001:\u0002)*B\u0019\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0008\u0008\u0002\u0010\u0005\u001a\u00020\u0004\u00a2\u0006\u0004\u0008\u0006\u0010\u0007B/\u0008\u0010\u0012\u0006\u0010\t\u001a\u00020\u0008\u0012\u0008\u0010\u0003\u001a\u0004\u0018\u00010\u0002\u0012\u0008\u0010\u0005\u001a\u0004\u0018\u00010\u0004\u0012\u0008\u0010\u000b\u001a\u0004\u0018\u00010\n\u00a2\u0006\u0004\u0008\u0006\u0010\u000cJ\'\u0010\u0015\u001a\u00020\u00122\u0006\u0010\r\u001a\u00020\u00002\u0006\u0010\u000f\u001a\u00020\u000e2\u0006\u0010\u0011\u001a\u00020\u0010H\u0001\u00a2\u0006\u0004\u0008\u0013\u0010\u0014J\u0010\u0010\u0016\u001a\u00020\u0002H\u00c6\u0003\u00a2\u0006\u0004\u0008\u0016\u0010\u0017J\u0010\u0010\u0018\u001a\u00020\u0004H\u00c6\u0003\u00a2\u0006\u0004\u0008\u0018\u0010\u0019J$\u0010\u001a\u001a\u00020\u00002\u0008\u0008\u0002\u0010\u0003\u001a\u00020\u00022\u0008\u0008\u0002\u0010\u0005\u001a\u00020\u0004H\u00c6\u0001\u00a2\u0006\u0004\u0008\u001a\u0010\u001bJ\u0010\u0010\u001c\u001a\u00020\u0004H\u00d6\u0001\u00a2\u0006\u0004\u0008\u001c\u0010\u0019J\u0010\u0010\u001d\u001a\u00020\u0008H\u00d6\u0001\u00a2\u0006\u0004\u0008\u001d\u0010\u001eJ\u001a\u0010\"\u001a\u00020!2\u0008\u0010 \u001a\u0004\u0018\u00010\u001fH\u00d6\u0003\u00a2\u0006\u0004\u0008\"\u0010#R\u0017\u0010\u0003\u001a\u00020\u00028\u0006\u00a2\u0006\u000c\n\u0004\u0008\u0003\u0010$\u001a\u0004\u0008%\u0010\u0017R\u0017\u0010\u0005\u001a\u00020\u00048\u0006\u00a2\u0006\u000c\n\u0004\u0008\u0005\u0010&\u001a\u0004\u0008\'\u0010\u0019\u00a8\u0006+"
    }
    d2 = {
        "Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditRoute;",
        "Lbm10;",
        "Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;",
        "mode",
        "",
        "key",
        "<init>",
        "(Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;Ljava/lang/String;)V",
        "",
        "seen0",
        "Lu3e0;",
        "serializationConstructorMarker",
        "(ILcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;Ljava/lang/String;Lu3e0;)V",
        "self",
        "Lvud;",
        "output",
        "Le3e0;",
        "serialDesc",
        "",
        "write$Self$app",
        "(Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditRoute;Lvud;Le3e0;)V",
        "write$Self",
        "component1",
        "()Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;",
        "component2",
        "()Ljava/lang/String;",
        "copy",
        "(Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;Ljava/lang/String;)Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditRoute;",
        "toString",
        "hashCode",
        "()I",
        "",
        "other",
        "",
        "equals",
        "(Ljava/lang/Object;)Z",
        "Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;",
        "getMode",
        "Ljava/lang/String;",
        "getKey",
        "Companion",
        "vt00",
        "wt00",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation

.annotation runtime Lq3e0;
.end annotation


# static fields
.field private static final $childSerializers:[Laau;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "Laau;"
        }
    .end annotation
.end field

.field public static final $stable:I

.field public static final Companion:Lwt00;


# instance fields
.field private final key:Ljava/lang/String;

.field private final mode:Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    new-instance v0, Lwt00;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditRoute;->Companion:Lwt00;

    .line 7
    .line 8
    sget-object v0, Lygu;->I:Lygu;

    .line 9
    .line 10
    new-instance v1, Les00;

    .line 11
    .line 12
    const/4 v2, 0x5

    .line 13
    invoke-direct {v1, v2}, Les00;-><init>(B)V

    .line 14
    .line 15
    .line 16
    invoke-static {v0, v1}, Lesm;->Ol(Lygu;Lkotlin/jvm/functions/Function0;)Laau;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    const/4 v1, 0x2

    .line 21
    new-array v1, v1, [Laau;

    .line 22
    .line 23
    const/4 v2, 0x0

    .line 24
    aput-object v0, v1, v2

    .line 25
    .line 26
    const/4 v0, 0x0

    .line 27
    const/4 v2, 0x1

    .line 28
    aput-object v0, v1, v2

    .line 29
    .line 30
    sput-object v1, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditRoute;->$childSerializers:[Laau;

    .line 31
    .line 32
    return-void
.end method

.method public synthetic constructor <init>(ILcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;Ljava/lang/String;Lu3e0;)V
    .locals 1

    .line 1
    and-int/lit8 p4, p1, 0x1

    .line 2
    .line 3
    const/4 v0, 0x1

    .line 4
    if-ne v0, p4, :cond_1

    .line 5
    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object p2, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditRoute;->mode:Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;

    .line 10
    .line 11
    and-int/lit8 p1, p1, 0x2

    .line 12
    .line 13
    if-nez p1, :cond_0

    .line 14
    .line 15
    const-wide p1, -0xd9df12a0c56e39L

    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    invoke-static {p1, p2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object p1

    .line 24
    iput-object p1, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditRoute;->key:Ljava/lang/String;

    .line 25
    .line 26
    return-void

    .line 27
    :cond_0
    iput-object p3, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditRoute;->key:Ljava/lang/String;

    .line 28
    .line 29
    return-void

    .line 30
    :cond_1
    sget-object p0, Lvt00;->l:Lvt00;

    .line 31
    .line 32
    invoke-virtual {p0}, Lvt00;->getDescriptor()Le3e0;

    .line 33
    .line 34
    .line 35
    move-result-object p0

    .line 36
    invoke-static {p1, v0, p0}, Lqmu0;->lIl(IILe3e0;)V

    .line 37
    .line 38
    .line 39
    const/4 p0, 0x0

    .line 40
    throw p0
.end method

.method public constructor <init>(Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;Ljava/lang/String;)V
    .locals 2

    const-wide v0, -0xd9dedaa0c56e39L

    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-wide v0, -0xd9dedfa0c56e39L

    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 41
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 42
    iput-object p1, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditRoute;->mode:Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;

    iput-object p2, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditRoute;->key:Ljava/lang/String;

    return-void
.end method

.method public synthetic constructor <init>(Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 0

    and-int/lit8 p3, p3, 0x2

    if-eqz p3, :cond_0

    const-wide p2, -0xd9dee3a0c56e39L

    .line 43
    invoke-static {p2, p3}, Li6t0;->lO(J)Ljava/lang/String;

    move-result-object p2

    :cond_0
    invoke-direct {p0, p1, p2}, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditRoute;-><init>(Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;Ljava/lang/String;)V

    return-void
.end method

.method private static final synthetic _childSerializers$_anonymous_()Ld9t;
    .locals 1

    .line 1
    sget-object v0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;->Companion:Lut00;

    .line 2
    .line 3
    invoke-virtual {v0}, Lut00;->serializer()Ld9t;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    return-object v0
.end method

.method public static final synthetic access$get$childSerializers$cp()[Laau;
    .locals 1

    .line 1
    sget-object v0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditRoute;->$childSerializers:[Laau;

    .line 2
    .line 3
    return-object v0
.end method

.method public static synthetic copy$default(Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditRoute;Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;Ljava/lang/String;ILjava/lang/Object;)Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditRoute;
    .locals 0

    .line 1
    and-int/lit8 p4, p3, 0x1

    .line 2
    .line 3
    if-eqz p4, :cond_0

    .line 4
    .line 5
    iget-object p1, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditRoute;->mode:Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;

    .line 6
    .line 7
    :cond_0
    and-int/lit8 p3, p3, 0x2

    .line 8
    .line 9
    if-eqz p3, :cond_1

    .line 10
    .line 11
    iget-object p2, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditRoute;->key:Ljava/lang/String;

    .line 12
    .line 13
    :cond_1
    invoke-virtual {p0, p1, p2}, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditRoute;->copy(Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;Ljava/lang/String;)Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditRoute;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    return-object p0
.end method

.method public static synthetic l()Ld9t;
    .locals 1

    .line 1
    invoke-static {}, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditRoute;->_childSerializers$_anonymous_()Ld9t;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    return-object v0
.end method

.method public static final synthetic write$Self$app(Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditRoute;Lvud;Le3e0;)V
    .locals 3
    .annotation runtime Lkotlin/jvm/JvmStatic;
    .end annotation

    .line 1
    sget-object v0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditRoute;->$childSerializers:[Laau;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    aget-object v0, v0, v1

    .line 5
    .line 6
    invoke-interface {v0}, Laau;->getValue()Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    check-cast v0, Ld9t;

    .line 11
    .line 12
    iget-object v2, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditRoute;->mode:Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;

    .line 13
    .line 14
    invoke-interface {p1, p2, v1, v0, v2}, Lvud;->lo(Le3e0;ILd9t;Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    invoke-interface {p1, p2}, Lvud;->ll(Le3e0;)Z

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    if-eqz v0, :cond_0

    .line 22
    .line 23
    goto :goto_0

    .line 24
    :cond_0
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditRoute;->key:Ljava/lang/String;

    .line 25
    .line 26
    const-wide v1, -0xd9df11a0c56e39L

    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 32
    .line 33
    .line 34
    move-result-object v1

    .line 35
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    if-nez v0, :cond_1

    .line 40
    .line 41
    :goto_0
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditRoute;->key:Ljava/lang/String;

    .line 42
    .line 43
    const/4 v0, 0x1

    .line 44
    invoke-interface {p1, p2, v0, p0}, Lvud;->lII(Le3e0;ILjava/lang/String;)V

    .line 45
    .line 46
    .line 47
    :cond_1
    return-void
.end method


# virtual methods
.method public final component1()Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditRoute;->mode:Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;

    .line 2
    .line 3
    return-object p0
.end method

.method public final component2()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditRoute;->key:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public final copy(Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;Ljava/lang/String;)Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditRoute;
    .locals 2

    .line 1
    const-wide v0, -0xd9dee4a0c56e39L

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    const-wide v0, -0xd9dee9a0c56e39L

    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 21
    .line 22
    .line 23
    new-instance p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditRoute;

    .line 24
    .line 25
    invoke-direct {p0, p1, p2}, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditRoute;-><init>(Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;Ljava/lang/String;)V

    .line 26
    .line 27
    .line 28
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, p1, :cond_0

    .line 3
    .line 4
    return v0

    .line 5
    :cond_0
    instance-of v1, p1, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditRoute;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    if-nez v1, :cond_1

    .line 9
    .line 10
    return v2

    .line 11
    :cond_1
    check-cast p1, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditRoute;

    .line 12
    .line 13
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditRoute;->mode:Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;

    .line 14
    .line 15
    iget-object v3, p1, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditRoute;->mode:Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;

    .line 16
    .line 17
    if-eq v1, v3, :cond_2

    .line 18
    .line 19
    return v2

    .line 20
    :cond_2
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditRoute;->key:Ljava/lang/String;

    .line 21
    .line 22
    iget-object p1, p1, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditRoute;->key:Ljava/lang/String;

    .line 23
    .line 24
    invoke-static {p0, p1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result p0

    .line 28
    if-nez p0, :cond_3

    .line 29
    .line 30
    return v2

    .line 31
    :cond_3
    return v0
.end method

.method public final getKey()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditRoute;->key:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public final getMode()Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditRoute;->mode:Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;

    .line 2
    .line 3
    return-object p0
.end method

.method public hashCode()I
    .locals 1

    .line 1
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditRoute;->mode:Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    mul-int/lit8 v0, v0, 0x1f

    .line 8
    .line 9
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditRoute;->key:Ljava/lang/String;

    .line 10
    .line 11
    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    .line 12
    .line 13
    .line 14
    move-result p0

    .line 15
    add-int/2addr p0, v0

    .line 16
    return p0
.end method

.method public toString()Ljava/lang/String;
    .locals 3

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-wide v1, -0xd9deeda0c56e39L

    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditRoute;->mode:Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditMode;

    .line 16
    .line 17
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 18
    .line 19
    .line 20
    const-wide v1, -0xd9df0aa0c56e39L

    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object v1

    .line 29
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 30
    .line 31
    .line 32
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicPlaylistEditRoute;->key:Ljava/lang/String;

    .line 33
    .line 34
    const/16 v1, 0x29

    .line 35
    .line 36
    invoke-static {v1, p0, v0}, Lqhk;->IO(CLjava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 37
    .line 38
    .line 39
    move-result-object p0

    .line 40
    return-object p0
.end method
