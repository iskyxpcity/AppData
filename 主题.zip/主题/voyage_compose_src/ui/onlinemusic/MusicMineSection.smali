.class public final enum Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;
.super Ljava/lang/Enum;
.source "S"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\u0010\u0008\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0010\u0008\u0081\u0081\u0002\u0018\u0000 \u000e2\u0008\u0012\u0004\u0012\u00020\u00000\u0001:\u0001\u000fB\u001b\u0008\u0002\u0012\u0008\u0008\u0001\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u00a2\u0006\u0004\u0008\u0006\u0010\u0007R\u001a\u0010\u0003\u001a\u00020\u00028\u0006X\u0087\u0004\u00a2\u0006\u000c\n\u0004\u0008\u0003\u0010\u0008\u001a\u0004\u0008\t\u0010\nR\u0017\u0010\u0005\u001a\u00020\u00048\u0006\u00a2\u0006\u000c\n\u0004\u0008\u0005\u0010\u000b\u001a\u0004\u0008\u000c\u0010\rj\u0002\u0008\u0010j\u0002\u0008\u0011j\u0002\u0008\u0012j\u0002\u0008\u0013\u00a8\u0006\u0014"
    }
    d2 = {
        "Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;",
        "",
        "",
        "label",
        "Lf4r;",
        "icon",
        "<init>",
        "(Ljava/lang/String;IILf4r;)V",
        "I",
        "getLabel",
        "()I",
        "Lf4r;",
        "getIcon",
        "()Lf4r;",
        "Companion",
        "bn00",
        "FAVORITES",
        "RECENT",
        "DOWNLOADS",
        "QUEUE",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation

.annotation runtime Lq3e0;
.end annotation


# static fields
.field private static final synthetic $ENTRIES:Lkotlin/enums/EnumEntries;

.field private static final synthetic $VALUES:[Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;

.field private static final $cachedSerializer$delegate:Laau;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Laau;"
        }
    .end annotation
.end field

.field public static final Companion:Lbn00;

.field public static final enum DOWNLOADS:Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;

.field public static final enum FAVORITES:Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;

.field public static final enum QUEUE:Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;

.field public static final enum RECENT:Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;


# instance fields
.field private final icon:Lf4r;

.field private final label:I


# direct methods
.method private static final synthetic $values()[Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;
    .locals 4

    .line 1
    sget-object v0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;->FAVORITES:Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;

    .line 2
    .line 3
    sget-object v1, Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;->RECENT:Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;

    .line 4
    .line 5
    sget-object v2, Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;->DOWNLOADS:Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;

    .line 6
    .line 7
    sget-object v3, Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;->QUEUE:Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;

    .line 8
    .line 9
    filled-new-array {v0, v1, v2, v3}, [Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    return-object v0
.end method

.method static constructor <clinit>()V
    .locals 5

    .line 1
    new-instance v0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;

    .line 2
    .line 3
    const-wide v1, -0xd96c8ea0c56e39L

    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    sget-object v2, Ldi00;->l:Lf4r;

    .line 13
    .line 14
    sget-object v2, Ldi00;->oo:Lf4r;

    .line 15
    .line 16
    const/4 v3, 0x0

    .line 17
    const v4, 0x7f1217d9

    .line 18
    .line 19
    .line 20
    invoke-direct {v0, v1, v3, v4, v2}, Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;-><init>(Ljava/lang/String;IILf4r;)V

    .line 21
    .line 22
    .line 23
    sput-object v0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;->FAVORITES:Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;

    .line 24
    .line 25
    new-instance v0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;

    .line 26
    .line 27
    const-wide v1, -0xd96c98a0c56e39L

    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 33
    .line 34
    .line 35
    move-result-object v1

    .line 36
    const v2, 0x7f1217de

    .line 37
    .line 38
    .line 39
    sget-object v3, Ldi00;->llI:Lf4r;

    .line 40
    .line 41
    const/4 v4, 0x1

    .line 42
    invoke-direct {v0, v1, v4, v2, v3}, Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;-><init>(Ljava/lang/String;IILf4r;)V

    .line 43
    .line 44
    .line 45
    sput-object v0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;->RECENT:Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;

    .line 46
    .line 47
    new-instance v0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;

    .line 48
    .line 49
    const-wide v1, -0xd96c9fa0c56e39L

    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 55
    .line 56
    .line 57
    move-result-object v1

    .line 58
    const v2, 0x7f1217d8

    .line 59
    .line 60
    .line 61
    sget-object v3, Ldi00;->V:Lf4r;

    .line 62
    .line 63
    const/4 v4, 0x2

    .line 64
    invoke-direct {v0, v1, v4, v2, v3}, Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;-><init>(Ljava/lang/String;IILf4r;)V

    .line 65
    .line 66
    .line 67
    sput-object v0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;->DOWNLOADS:Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;

    .line 68
    .line 69
    new-instance v0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;

    .line 70
    .line 71
    const-wide v1, -0xd96ca9a0c56e39L

    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 77
    .line 78
    .line 79
    move-result-object v1

    .line 80
    const v2, 0x7f1217dd

    .line 81
    .line 82
    .line 83
    sget-object v3, Ldi00;->llO:Lf4r;

    .line 84
    .line 85
    const/4 v4, 0x3

    .line 86
    invoke-direct {v0, v1, v4, v2, v3}, Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;-><init>(Ljava/lang/String;IILf4r;)V

    .line 87
    .line 88
    .line 89
    sput-object v0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;->QUEUE:Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;

    .line 90
    .line 91
    invoke-static {}, Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;->$values()[Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;

    .line 92
    .line 93
    .line 94
    move-result-object v0

    .line 95
    sput-object v0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;->$VALUES:[Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;

    .line 96
    .line 97
    invoke-static {v0}, Lkotlin/enums/EnumEntriesKt;->enumEntries([Ljava/lang/Enum;)Lkotlin/enums/EnumEntries;

    .line 98
    .line 99
    .line 100
    move-result-object v0

    .line 101
    sput-object v0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;->$ENTRIES:Lkotlin/enums/EnumEntries;

    .line 102
    .line 103
    new-instance v0, Lbn00;

    .line 104
    .line 105
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 106
    .line 107
    .line 108
    sput-object v0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;->Companion:Lbn00;

    .line 109
    .line 110
    sget-object v0, Lygu;->I:Lygu;

    .line 111
    .line 112
    new-instance v1, Lyi00;

    .line 113
    .line 114
    const/16 v2, 0x16

    .line 115
    .line 116
    invoke-direct {v1, v2}, Lyi00;-><init>(B)V

    .line 117
    .line 118
    .line 119
    invoke-static {v0, v1}, Lesm;->Ol(Lygu;Lkotlin/jvm/functions/Function0;)Laau;

    .line 120
    .line 121
    .line 122
    move-result-object v0

    .line 123
    sput-object v0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;->$cachedSerializer$delegate:Laau;

    .line 124
    .line 125
    return-void
.end method

.method private constructor <init>(Ljava/lang/String;IILf4r;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Lf4r;",
            ")V"
        }
    .end annotation

    .line 1
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 2
    .line 3
    .line 4
    iput p3, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;->label:I

    .line 5
    .line 6
    iput-object p4, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;->icon:Lf4r;

    .line 7
    .line 8
    return-void
.end method

.method private static final _init_$_anonymous_()Ld9t;
    .locals 3

    .line 1
    const-wide v0, -0xd96c5ba0c56e39L

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    invoke-static {}, Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;->values()[Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    .line 16
    .line 17
    new-instance v2, Lu5k;

    .line 18
    .line 19
    invoke-direct {v2, v0, v1}, Lu5k;-><init>(Ljava/lang/String;[Ljava/lang/Enum;)V

    .line 20
    .line 21
    .line 22
    return-object v2
.end method

.method public static final synthetic access$get$cachedSerializer$delegate$cp()Laau;
    .locals 1

    .line 1
    sget-object v0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;->$cachedSerializer$delegate:Laau;

    .line 2
    .line 3
    return-object v0
.end method

.method public static getEntries()Lkotlin/enums/EnumEntries;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/enums/EnumEntries<",
            "Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;",
            ">;"
        }
    .end annotation

    .line 1
    sget-object v0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;->$ENTRIES:Lkotlin/enums/EnumEntries;

    .line 2
    .line 3
    return-object v0
.end method

.method public static synthetic l()Ld9t;
    .locals 1

    .line 1
    invoke-static {}, Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;->_init_$_anonymous_()Ld9t;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;
    .locals 1

    .line 1
    const-class v0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;

    .line 2
    .line 3
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;

    .line 8
    .line 9
    return-object p0
.end method

.method public static values()[Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;
    .locals 1

    .line 1
    sget-object v0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;->$VALUES:[Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, [Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;

    .line 8
    .line 9
    return-object v0
.end method


# virtual methods
.method public final getIcon()Lf4r;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;->icon:Lf4r;

    .line 2
    .line 3
    return-object p0
.end method

.method public final getLabel()I
    .locals 0

    .line 1
    iget p0, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicMineSection;->label:I

    .line 2
    .line 3
    return p0
.end method
