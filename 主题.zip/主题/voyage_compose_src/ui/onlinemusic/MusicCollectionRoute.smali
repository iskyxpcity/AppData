.class public final Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;
.super Ljava/lang/Object;
.source "S"

# interfaces
.implements Lbm10;


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000P\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\u0008\u0004\n\u0002\u0010\u0008\n\u0000\n\u0002\u0010\u000b\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\u0008\u0012\n\u0002\u0010\u0000\n\u0002\u0008\u000e\n\u0002\u0018\u0002\n\u0002\u0008\u0007\u0008\u0081\u0008\u0018\u0000 >2\u00020\u0001:\u0002?@BG\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u0012\u0006\u0010\u0006\u001a\u00020\u0004\u0012\u0008\u0008\u0002\u0010\u0007\u001a\u00020\u0004\u0012\u0008\u0008\u0002\u0010\u0008\u001a\u00020\u0004\u0012\u0008\u0008\u0002\u0010\n\u001a\u00020\t\u0012\u0008\u0008\u0002\u0010\u000c\u001a\u00020\u000b\u00a2\u0006\u0004\u0008\r\u0010\u000eB]\u0008\u0010\u0012\u0006\u0010\u000f\u001a\u00020\t\u0012\u0008\u0010\u0003\u001a\u0004\u0018\u00010\u0002\u0012\u0008\u0010\u0005\u001a\u0004\u0018\u00010\u0004\u0012\u0008\u0010\u0006\u001a\u0004\u0018\u00010\u0004\u0012\u0008\u0010\u0007\u001a\u0004\u0018\u00010\u0004\u0012\u0008\u0010\u0008\u001a\u0004\u0018\u00010\u0004\u0012\u0006\u0010\n\u001a\u00020\t\u0012\u0006\u0010\u000c\u001a\u00020\u000b\u0012\u0008\u0010\u0011\u001a\u0004\u0018\u00010\u0010\u00a2\u0006\u0004\u0008\r\u0010\u0012J\'\u0010\u001b\u001a\u00020\u00182\u0006\u0010\u0013\u001a\u00020\u00002\u0006\u0010\u0015\u001a\u00020\u00142\u0006\u0010\u0017\u001a\u00020\u0016H\u0001\u00a2\u0006\u0004\u0008\u0019\u0010\u001aJ\u0010\u0010\u001c\u001a\u00020\u0002H\u00c6\u0003\u00a2\u0006\u0004\u0008\u001c\u0010\u001dJ\u0010\u0010\u001e\u001a\u00020\u0004H\u00c6\u0003\u00a2\u0006\u0004\u0008\u001e\u0010\u001fJ\u0010\u0010 \u001a\u00020\u0004H\u00c6\u0003\u00a2\u0006\u0004\u0008 \u0010\u001fJ\u0010\u0010!\u001a\u00020\u0004H\u00c6\u0003\u00a2\u0006\u0004\u0008!\u0010\u001fJ\u0010\u0010\"\u001a\u00020\u0004H\u00c6\u0003\u00a2\u0006\u0004\u0008\"\u0010\u001fJ\u0010\u0010#\u001a\u00020\tH\u00c6\u0003\u00a2\u0006\u0004\u0008#\u0010$J\u0010\u0010%\u001a\u00020\u000bH\u00c6\u0003\u00a2\u0006\u0004\u0008%\u0010&JV\u0010\'\u001a\u00020\u00002\u0008\u0008\u0002\u0010\u0003\u001a\u00020\u00022\u0008\u0008\u0002\u0010\u0005\u001a\u00020\u00042\u0008\u0008\u0002\u0010\u0006\u001a\u00020\u00042\u0008\u0008\u0002\u0010\u0007\u001a\u00020\u00042\u0008\u0008\u0002\u0010\u0008\u001a\u00020\u00042\u0008\u0008\u0002\u0010\n\u001a\u00020\t2\u0008\u0008\u0002\u0010\u000c\u001a\u00020\u000bH\u00c6\u0001\u00a2\u0006\u0004\u0008\'\u0010(J\u0010\u0010)\u001a\u00020\u0004H\u00d6\u0001\u00a2\u0006\u0004\u0008)\u0010\u001fJ\u0010\u0010*\u001a\u00020\tH\u00d6\u0001\u00a2\u0006\u0004\u0008*\u0010$J\u001a\u0010-\u001a\u00020\u000b2\u0008\u0010,\u001a\u0004\u0018\u00010+H\u00d6\u0003\u00a2\u0006\u0004\u0008-\u0010.R\u0017\u0010\u0003\u001a\u00020\u00028\u0006\u00a2\u0006\u000c\n\u0004\u0008\u0003\u0010/\u001a\u0004\u00080\u0010\u001dR\u0017\u0010\u0005\u001a\u00020\u00048\u0006\u00a2\u0006\u000c\n\u0004\u0008\u0005\u00101\u001a\u0004\u00082\u0010\u001fR\u0017\u0010\u0006\u001a\u00020\u00048\u0006\u00a2\u0006\u000c\n\u0004\u0008\u0006\u00101\u001a\u0004\u00083\u0010\u001fR\u0017\u0010\u0007\u001a\u00020\u00048\u0006\u00a2\u0006\u000c\n\u0004\u0008\u0007\u00101\u001a\u0004\u00084\u0010\u001fR\u0017\u0010\u0008\u001a\u00020\u00048\u0006\u00a2\u0006\u000c\n\u0004\u0008\u0008\u00101\u001a\u0004\u00085\u0010\u001fR\u0017\u0010\n\u001a\u00020\t8\u0006\u00a2\u0006\u000c\n\u0004\u0008\n\u00106\u001a\u0004\u00087\u0010$R\u0017\u0010\u000c\u001a\u00020\u000b8\u0006\u00a2\u0006\u000c\n\u0004\u0008\u000c\u00108\u001a\u0004\u00089\u0010&R\u0011\u0010=\u001a\u00020:8F\u00a2\u0006\u0006\u001a\u0004\u0008;\u0010<\u00a8\u0006A"
    }
    d2 = {
        "Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;",
        "Lbm10;",
        "Lc900;",
        "kind",
        "",
        "id",
        "title",
        "artwork",
        "period",
        "",
        "color",
        "",
        "standalone",
        "<init>",
        "(Lc900;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IZ)V",
        "seen0",
        "Lu3e0;",
        "serializationConstructorMarker",
        "(ILc900;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IZLu3e0;)V",
        "self",
        "Lvud;",
        "output",
        "Le3e0;",
        "serialDesc",
        "",
        "write$Self$app",
        "(Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;Lvud;Le3e0;)V",
        "write$Self",
        "component1",
        "()Lc900;",
        "component2",
        "()Ljava/lang/String;",
        "component3",
        "component4",
        "component5",
        "component6",
        "()I",
        "component7",
        "()Z",
        "copy",
        "(Lc900;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IZ)Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;",
        "toString",
        "hashCode",
        "",
        "other",
        "equals",
        "(Ljava/lang/Object;)Z",
        "Lc900;",
        "getKind",
        "Ljava/lang/String;",
        "getId",
        "getTitle",
        "getArtwork",
        "getPeriod",
        "I",
        "getColor",
        "Z",
        "getStandalone",
        "Lb900;",
        "getKey",
        "()Lb900;",
        "key",
        "Companion",
        "g900",
        "h900",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation

.annotation runtime Lq3e0;
.end annotation


# static fields
.field private static final $childSerializers:[Laau;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "Laau;"
        }
    .end annotation
.end field

.field public static final $stable:I

.field public static final Companion:Lh900;


# instance fields
.field private final artwork:Ljava/lang/String;

.field private final color:I

.field private final id:Ljava/lang/String;

.field private final kind:Lc900;

.field private final period:Ljava/lang/String;

.field private final standalone:Z

.field private final title:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    .line 1
    new-instance v0, Lh900;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->Companion:Lh900;

    .line 7
    .line 8
    sget-object v0, Lygu;->I:Lygu;

    .line 9
    .line 10
    new-instance v1, Ly800;

    .line 11
    .line 12
    const/4 v2, 0x2

    .line 13
    invoke-direct {v1, v2}, Ly800;-><init>(B)V

    .line 14
    .line 15
    .line 16
    invoke-static {v0, v1}, Lesm;->Ol(Lygu;Lkotlin/jvm/functions/Function0;)Laau;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    const/4 v1, 0x7

    .line 21
    new-array v1, v1, [Laau;

    .line 22
    .line 23
    const/4 v3, 0x0

    .line 24
    aput-object v0, v1, v3

    .line 25
    .line 26
    const/4 v0, 0x1

    .line 27
    const/4 v3, 0x0

    .line 28
    aput-object v3, v1, v0

    .line 29
    .line 30
    aput-object v3, v1, v2

    .line 31
    .line 32
    const/4 v0, 0x3

    .line 33
    aput-object v3, v1, v0

    .line 34
    .line 35
    const/4 v0, 0x4

    .line 36
    aput-object v3, v1, v0

    .line 37
    .line 38
    const/4 v0, 0x5

    .line 39
    aput-object v3, v1, v0

    .line 40
    .line 41
    const/4 v0, 0x6

    .line 42
    aput-object v3, v1, v0

    .line 43
    .line 44
    sput-object v1, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->$childSerializers:[Laau;

    .line 45
    .line 46
    return-void
.end method

.method public synthetic constructor <init>(ILc900;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IZLu3e0;)V
    .locals 1

    .line 1
    and-int/lit8 p9, p1, 0x7

    .line 2
    .line 3
    const/4 v0, 0x7

    .line 4
    if-ne v0, p9, :cond_4

    .line 5
    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object p2, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->kind:Lc900;

    .line 10
    .line 11
    iput-object p3, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->id:Ljava/lang/String;

    .line 12
    .line 13
    iput-object p4, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->title:Ljava/lang/String;

    .line 14
    .line 15
    and-int/lit8 p2, p1, 0x8

    .line 16
    .line 17
    if-nez p2, :cond_0

    .line 18
    .line 19
    const-wide p2, -0xd6c475a0c56e39L

    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    invoke-static {p2, p3}, Li6t0;->lO(J)Ljava/lang/String;

    .line 25
    .line 26
    .line 27
    move-result-object p2

    .line 28
    iput-object p2, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->artwork:Ljava/lang/String;

    .line 29
    .line 30
    goto :goto_0

    .line 31
    :cond_0
    iput-object p5, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->artwork:Ljava/lang/String;

    .line 32
    .line 33
    :goto_0
    and-int/lit8 p2, p1, 0x10

    .line 34
    .line 35
    if-nez p2, :cond_1

    .line 36
    .line 37
    const-wide p2, -0xd6c476a0c56e39L

    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    invoke-static {p2, p3}, Li6t0;->lO(J)Ljava/lang/String;

    .line 43
    .line 44
    .line 45
    move-result-object p2

    .line 46
    iput-object p2, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->period:Ljava/lang/String;

    .line 47
    .line 48
    goto :goto_1

    .line 49
    :cond_1
    iput-object p6, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->period:Ljava/lang/String;

    .line 50
    .line 51
    :goto_1
    and-int/lit8 p2, p1, 0x20

    .line 52
    .line 53
    const/4 p3, 0x0

    .line 54
    if-nez p2, :cond_2

    .line 55
    .line 56
    iput p3, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->color:I

    .line 57
    .line 58
    goto :goto_2

    .line 59
    :cond_2
    iput p7, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->color:I

    .line 60
    .line 61
    :goto_2
    and-int/lit8 p1, p1, 0x40

    .line 62
    .line 63
    if-nez p1, :cond_3

    .line 64
    .line 65
    iput-boolean p3, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->standalone:Z

    .line 66
    .line 67
    return-void

    .line 68
    :cond_3
    iput-boolean p8, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->standalone:Z

    .line 69
    .line 70
    return-void

    .line 71
    :cond_4
    sget-object p0, Lg900;->l:Lg900;

    .line 72
    .line 73
    invoke-virtual {p0}, Lg900;->getDescriptor()Le3e0;

    .line 74
    .line 75
    .line 76
    move-result-object p0

    .line 77
    invoke-static {p1, v0, p0}, Lqmu0;->lIl(IILe3e0;)V

    .line 78
    .line 79
    .line 80
    const/4 p0, 0x0

    .line 81
    throw p0
.end method

.method public constructor <init>(Lc900;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IZ)V
    .locals 4

    const-wide v0, -0xd6c3e1a0c56e39L

    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-wide v0, -0xd6c3e6a0c56e39L

    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    const-wide v0, -0xd6c3e9a0c56e39L

    .line 82
    invoke-static {v0, v1, p2, p3}, Lw280;->oO(JLjava/lang/String;Ljava/lang/String;)V

    const-wide v0, -0xd6c3efa0c56e39L

    const-wide v2, -0xd6c3f7a0c56e39L

    .line 83
    invoke-static {v0, v1, p4, v2, v3}, Lns;->lll(JLjava/lang/String;J)V

    .line 84
    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 85
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 86
    iput-object p1, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->kind:Lc900;

    .line 87
    iput-object p2, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->id:Ljava/lang/String;

    .line 88
    iput-object p3, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->title:Ljava/lang/String;

    .line 89
    iput-object p4, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->artwork:Ljava/lang/String;

    .line 90
    iput-object p5, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->period:Ljava/lang/String;

    .line 91
    iput p6, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->color:I

    .line 92
    iput-boolean p7, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->standalone:Z

    return-void
.end method

.method public synthetic constructor <init>(Lc900;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IZILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 8

    and-int/lit8 v0, p8, 0x8

    if-eqz v0, :cond_0

    const-wide v0, -0xd6c3fea0c56e39L

    .line 93
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    move-result-object p4

    :cond_0
    move-object v4, p4

    and-int/lit8 p4, p8, 0x10

    if-eqz p4, :cond_1

    const-wide p4, -0xd6c3ffa0c56e39L

    .line 94
    invoke-static {p4, p5}, Li6t0;->lO(J)Ljava/lang/String;

    move-result-object p5

    :cond_1
    move-object v5, p5

    and-int/lit8 p4, p8, 0x20

    const/4 p5, 0x0

    if-eqz p4, :cond_2

    move v6, p5

    goto :goto_0

    :cond_2
    move v6, p6

    :goto_0
    and-int/lit8 p4, p8, 0x40

    if-eqz p4, :cond_3

    move v7, p5

    :goto_1
    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    goto :goto_2

    :cond_3
    move v7, p7

    goto :goto_1

    .line 95
    :goto_2
    invoke-direct/range {v0 .. v7}, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;-><init>(Lc900;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IZ)V

    return-void
.end method

.method private static final _childSerializers$_anonymous_()Ld9t;
    .locals 3

    .line 1
    const-wide v0, -0xd6c477a0c56e39L

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    invoke-static {}, Lc900;->values()[Lc900;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    .line 16
    .line 17
    new-instance v2, Lu5k;

    .line 18
    .line 19
    invoke-direct {v2, v0, v1}, Lu5k;-><init>(Ljava/lang/String;[Ljava/lang/Enum;)V

    .line 20
    .line 21
    .line 22
    return-object v2
.end method

.method public static final synthetic access$get$childSerializers$cp()[Laau;
    .locals 1

    .line 1
    sget-object v0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->$childSerializers:[Laau;

    .line 2
    .line 3
    return-object v0
.end method

.method public static synthetic copy$default(Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;Lc900;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IZILjava/lang/Object;)Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;
    .locals 0

    .line 1
    and-int/lit8 p9, p8, 0x1

    .line 2
    .line 3
    if-eqz p9, :cond_0

    .line 4
    .line 5
    iget-object p1, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->kind:Lc900;

    .line 6
    .line 7
    :cond_0
    and-int/lit8 p9, p8, 0x2

    .line 8
    .line 9
    if-eqz p9, :cond_1

    .line 10
    .line 11
    iget-object p2, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->id:Ljava/lang/String;

    .line 12
    .line 13
    :cond_1
    and-int/lit8 p9, p8, 0x4

    .line 14
    .line 15
    if-eqz p9, :cond_2

    .line 16
    .line 17
    iget-object p3, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->title:Ljava/lang/String;

    .line 18
    .line 19
    :cond_2
    and-int/lit8 p9, p8, 0x8

    .line 20
    .line 21
    if-eqz p9, :cond_3

    .line 22
    .line 23
    iget-object p4, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->artwork:Ljava/lang/String;

    .line 24
    .line 25
    :cond_3
    and-int/lit8 p9, p8, 0x10

    .line 26
    .line 27
    if-eqz p9, :cond_4

    .line 28
    .line 29
    iget-object p5, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->period:Ljava/lang/String;

    .line 30
    .line 31
    :cond_4
    and-int/lit8 p9, p8, 0x20

    .line 32
    .line 33
    if-eqz p9, :cond_5

    .line 34
    .line 35
    iget p6, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->color:I

    .line 36
    .line 37
    :cond_5
    and-int/lit8 p8, p8, 0x40

    .line 38
    .line 39
    if-eqz p8, :cond_6

    .line 40
    .line 41
    iget-boolean p7, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->standalone:Z

    .line 42
    .line 43
    :cond_6
    move p8, p6

    .line 44
    move p9, p7

    .line 45
    move-object p6, p4

    .line 46
    move-object p7, p5

    .line 47
    move-object p4, p2

    .line 48
    move-object p5, p3

    .line 49
    move-object p2, p0

    .line 50
    move-object p3, p1

    .line 51
    invoke-virtual/range {p2 .. p9}, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->copy(Lc900;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IZ)Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;

    .line 52
    .line 53
    .line 54
    move-result-object p0

    .line 55
    return-object p0
.end method

.method public static synthetic l()Ld9t;
    .locals 1

    .line 1
    invoke-static {}, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->_childSerializers$_anonymous_()Ld9t;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    return-object v0
.end method

.method public static final synthetic write$Self$app(Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;Lvud;Le3e0;)V
    .locals 3
    .annotation runtime Lkotlin/jvm/JvmStatic;
    .end annotation

    .line 1
    sget-object v0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->$childSerializers:[Laau;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    aget-object v0, v0, v1

    .line 5
    .line 6
    invoke-interface {v0}, Laau;->getValue()Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    check-cast v0, Ld9t;

    .line 11
    .line 12
    iget-object v2, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->kind:Lc900;

    .line 13
    .line 14
    invoke-interface {p1, p2, v1, v0, v2}, Lvud;->lo(Le3e0;ILd9t;Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    const/4 v0, 0x1

    .line 18
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->id:Ljava/lang/String;

    .line 19
    .line 20
    invoke-interface {p1, p2, v0, v1}, Lvud;->lII(Le3e0;ILjava/lang/String;)V

    .line 21
    .line 22
    .line 23
    const/4 v0, 0x2

    .line 24
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->title:Ljava/lang/String;

    .line 25
    .line 26
    invoke-interface {p1, p2, v0, v1}, Lvud;->lII(Le3e0;ILjava/lang/String;)V

    .line 27
    .line 28
    .line 29
    invoke-interface {p1, p2}, Lvud;->ll(Le3e0;)Z

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    if-eqz v0, :cond_0

    .line 34
    .line 35
    goto :goto_0

    .line 36
    :cond_0
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->artwork:Ljava/lang/String;

    .line 37
    .line 38
    const-wide v1, -0xd6c473a0c56e39L

    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 44
    .line 45
    .line 46
    move-result-object v1

    .line 47
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 48
    .line 49
    .line 50
    move-result v0

    .line 51
    if-nez v0, :cond_1

    .line 52
    .line 53
    :goto_0
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->artwork:Ljava/lang/String;

    .line 54
    .line 55
    const/4 v1, 0x3

    .line 56
    invoke-interface {p1, p2, v1, v0}, Lvud;->lII(Le3e0;ILjava/lang/String;)V

    .line 57
    .line 58
    .line 59
    :cond_1
    invoke-interface {p1, p2}, Lvud;->ll(Le3e0;)Z

    .line 60
    .line 61
    .line 62
    move-result v0

    .line 63
    if-eqz v0, :cond_2

    .line 64
    .line 65
    goto :goto_1

    .line 66
    :cond_2
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->period:Ljava/lang/String;

    .line 67
    .line 68
    const-wide v1, -0xd6c474a0c56e39L

    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 74
    .line 75
    .line 76
    move-result-object v1

    .line 77
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 78
    .line 79
    .line 80
    move-result v0

    .line 81
    if-nez v0, :cond_3

    .line 82
    .line 83
    :goto_1
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->period:Ljava/lang/String;

    .line 84
    .line 85
    const/4 v1, 0x4

    .line 86
    invoke-interface {p1, p2, v1, v0}, Lvud;->lII(Le3e0;ILjava/lang/String;)V

    .line 87
    .line 88
    .line 89
    :cond_3
    invoke-interface {p1, p2}, Lvud;->ll(Le3e0;)Z

    .line 90
    .line 91
    .line 92
    move-result v0

    .line 93
    if-eqz v0, :cond_4

    .line 94
    .line 95
    goto :goto_2

    .line 96
    :cond_4
    iget v0, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->color:I

    .line 97
    .line 98
    if-eqz v0, :cond_5

    .line 99
    .line 100
    :goto_2
    iget v0, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->color:I

    .line 101
    .line 102
    const/4 v1, 0x5

    .line 103
    invoke-interface {p1, v1, v0, p2}, Lvud;->lOO(IILe3e0;)V

    .line 104
    .line 105
    .line 106
    :cond_5
    invoke-interface {p1, p2}, Lvud;->ll(Le3e0;)Z

    .line 107
    .line 108
    .line 109
    move-result v0

    .line 110
    if-eqz v0, :cond_6

    .line 111
    .line 112
    goto :goto_3

    .line 113
    :cond_6
    iget-boolean v0, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->standalone:Z

    .line 114
    .line 115
    if-eqz v0, :cond_7

    .line 116
    .line 117
    :goto_3
    iget-boolean p0, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->standalone:Z

    .line 118
    .line 119
    const/4 v0, 0x6

    .line 120
    invoke-interface {p1, p2, v0, p0}, Lvud;->llo(Le3e0;IZ)V

    .line 121
    .line 122
    .line 123
    :cond_7
    return-void
.end method


# virtual methods
.method public final component1()Lc900;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->kind:Lc900;

    .line 2
    .line 3
    return-object p0
.end method

.method public final component2()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->id:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public final component3()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->title:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public final component4()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->artwork:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public final component5()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->period:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public final component6()I
    .locals 0

    .line 1
    iget p0, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->color:I

    .line 2
    .line 3
    return p0
.end method

.method public final component7()Z
    .locals 0

    .line 1
    iget-boolean p0, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->standalone:Z

    .line 2
    .line 3
    return p0
.end method

.method public final copy(Lc900;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IZ)Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;
    .locals 4

    .line 1
    const-wide v0, -0xd6c400a0c56e39L

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    const-wide v0, -0xd6c405a0c56e39L

    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    const-wide v0, -0xd6c408a0c56e39L

    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    invoke-static {v0, v1, p2, p3}, Lw280;->oO(JLjava/lang/String;Ljava/lang/String;)V

    .line 26
    .line 27
    .line 28
    const-wide v0, -0xd6c40ea0c56e39L

    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    const-wide v2, -0xd6c416a0c56e39L

    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    invoke-static {v0, v1, p4, v2, v3}, Lns;->lll(JLjava/lang/String;J)V

    .line 39
    .line 40
    .line 41
    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 42
    .line 43
    .line 44
    new-instance p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;

    .line 45
    .line 46
    invoke-direct/range {p0 .. p7}, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;-><init>(Lc900;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IZ)V

    .line 47
    .line 48
    .line 49
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, p1, :cond_0

    .line 3
    .line 4
    return v0

    .line 5
    :cond_0
    instance-of v1, p1, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    if-nez v1, :cond_1

    .line 9
    .line 10
    return v2

    .line 11
    :cond_1
    check-cast p1, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;

    .line 12
    .line 13
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->kind:Lc900;

    .line 14
    .line 15
    iget-object v3, p1, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->kind:Lc900;

    .line 16
    .line 17
    if-eq v1, v3, :cond_2

    .line 18
    .line 19
    return v2

    .line 20
    :cond_2
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->id:Ljava/lang/String;

    .line 21
    .line 22
    iget-object v3, p1, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->id:Ljava/lang/String;

    .line 23
    .line 24
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v1

    .line 28
    if-nez v1, :cond_3

    .line 29
    .line 30
    return v2

    .line 31
    :cond_3
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->title:Ljava/lang/String;

    .line 32
    .line 33
    iget-object v3, p1, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->title:Ljava/lang/String;

    .line 34
    .line 35
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 36
    .line 37
    .line 38
    move-result v1

    .line 39
    if-nez v1, :cond_4

    .line 40
    .line 41
    return v2

    .line 42
    :cond_4
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->artwork:Ljava/lang/String;

    .line 43
    .line 44
    iget-object v3, p1, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->artwork:Ljava/lang/String;

    .line 45
    .line 46
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 47
    .line 48
    .line 49
    move-result v1

    .line 50
    if-nez v1, :cond_5

    .line 51
    .line 52
    return v2

    .line 53
    :cond_5
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->period:Ljava/lang/String;

    .line 54
    .line 55
    iget-object v3, p1, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->period:Ljava/lang/String;

    .line 56
    .line 57
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 58
    .line 59
    .line 60
    move-result v1

    .line 61
    if-nez v1, :cond_6

    .line 62
    .line 63
    return v2

    .line 64
    :cond_6
    iget v1, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->color:I

    .line 65
    .line 66
    iget v3, p1, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->color:I

    .line 67
    .line 68
    if-eq v1, v3, :cond_7

    .line 69
    .line 70
    return v2

    .line 71
    :cond_7
    iget-boolean p0, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->standalone:Z

    .line 72
    .line 73
    iget-boolean p1, p1, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->standalone:Z

    .line 74
    .line 75
    if-eq p0, p1, :cond_8

    .line 76
    .line 77
    return v2

    .line 78
    :cond_8
    return v0
.end method

.method public final getArtwork()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->artwork:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public final getColor()I
    .locals 0

    .line 1
    iget p0, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->color:I

    .line 2
    .line 3
    return p0
.end method

.method public final getId()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->id:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public final getKey()Lb900;
    .locals 3

    .line 1
    new-instance v0, Lb900;

    .line 2
    .line 3
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->kind:Lc900;

    .line 4
    .line 5
    iget-object v2, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->id:Ljava/lang/String;

    .line 6
    .line 7
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->period:Ljava/lang/String;

    .line 8
    .line 9
    invoke-direct {v0, v1, v2, p0}, Lb900;-><init>(Lc900;Ljava/lang/String;Ljava/lang/String;)V

    .line 10
    .line 11
    .line 12
    return-object v0
.end method

.method public final getKind()Lc900;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->kind:Lc900;

    .line 2
    .line 3
    return-object p0
.end method

.method public final getPeriod()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->period:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public final getStandalone()Z
    .locals 0

    .line 1
    iget-boolean p0, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->standalone:Z

    .line 2
    .line 3
    return p0
.end method

.method public final getTitle()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->title:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public hashCode()I
    .locals 3

    .line 1
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->kind:Lc900;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    const/16 v1, 0x1f

    .line 8
    .line 9
    mul-int/2addr v0, v1

    .line 10
    iget-object v2, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->id:Ljava/lang/String;

    .line 11
    .line 12
    invoke-static {v0, v1, v2}, Lw280;->I(IILjava/lang/String;)I

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    iget-object v2, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->title:Ljava/lang/String;

    .line 17
    .line 18
    invoke-static {v0, v1, v2}, Lw280;->I(IILjava/lang/String;)I

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    iget-object v2, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->artwork:Ljava/lang/String;

    .line 23
    .line 24
    invoke-static {v0, v1, v2}, Lw280;->I(IILjava/lang/String;)I

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    iget-object v2, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->period:Ljava/lang/String;

    .line 29
    .line 30
    invoke-static {v0, v1, v2}, Lw280;->I(IILjava/lang/String;)I

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    iget v2, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->color:I

    .line 35
    .line 36
    invoke-static {v2, v0, v1}, Ljs2;->o(III)I

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    iget-boolean p0, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->standalone:Z

    .line 41
    .line 42
    invoke-static {p0}, Ljava/lang/Boolean;->hashCode(Z)I

    .line 43
    .line 44
    .line 45
    move-result p0

    .line 46
    add-int/2addr p0, v0

    .line 47
    return p0
.end method

.method public toString()Ljava/lang/String;
    .locals 4

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-wide v1, -0xd6c41da0c56e39L

    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->kind:Lc900;

    .line 16
    .line 17
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 18
    .line 19
    .line 20
    const-wide v1, -0xd6c438a0c56e39L

    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object v1

    .line 29
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 30
    .line 31
    .line 32
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->id:Ljava/lang/String;

    .line 33
    .line 34
    const-wide v2, -0xd6c43ea0c56e39L

    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    invoke-static {v2, v3, v1, v0}, Lti6;->Oo(JLjava/lang/String;Ljava/lang/StringBuilder;)V

    .line 40
    .line 41
    .line 42
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->title:Ljava/lang/String;

    .line 43
    .line 44
    const-wide v2, -0xd6c447a0c56e39L

    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    invoke-static {v2, v3, v1, v0}, Lti6;->Oo(JLjava/lang/String;Ljava/lang/StringBuilder;)V

    .line 50
    .line 51
    .line 52
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->artwork:Ljava/lang/String;

    .line 53
    .line 54
    const-wide v2, -0xd6c452a0c56e39L

    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    invoke-static {v2, v3, v1, v0}, Lti6;->Oo(JLjava/lang/String;Ljava/lang/StringBuilder;)V

    .line 60
    .line 61
    .line 62
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->period:Ljava/lang/String;

    .line 63
    .line 64
    const-wide v2, -0xd6c45ca0c56e39L

    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    invoke-static {v2, v3, v1, v0}, Lti6;->Oo(JLjava/lang/String;Ljava/lang/StringBuilder;)V

    .line 70
    .line 71
    .line 72
    iget v1, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->color:I

    .line 73
    .line 74
    const-wide v2, -0xd6c465a0c56e39L

    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    invoke-static {v1, v2, v3, v0}, Lcoe;->lIl(IJLjava/lang/StringBuilder;)V

    .line 80
    .line 81
    .line 82
    iget-boolean p0, p0, Lcom/chuanyi/voyage/ui/onlinemusic/MusicCollectionRoute;->standalone:Z

    .line 83
    .line 84
    const/16 v1, 0x29

    .line 85
    .line 86
    invoke-static {v0, p0, v1}, Lzad0;->OO(Ljava/lang/StringBuilder;ZC)Ljava/lang/String;

    .line 87
    .line 88
    .line 89
    move-result-object p0

    .line 90
    return-object p0
.end method
