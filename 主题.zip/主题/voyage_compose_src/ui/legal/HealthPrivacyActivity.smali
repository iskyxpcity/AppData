.class public final Lcom/chuanyi/voyage/ui/legal/HealthPrivacyActivity;
.super Lcfd;
.source "S"

# interfaces
.implements Lgmn;


# static fields
.field public static final synthetic o:I


# instance fields
.field public final I:Ljava/lang/Object;

.field public O:Z

.field public volatile l:Lpm;


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, Lcfd;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Ljava/lang/Object;

    .line 5
    .line 6
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, Lcom/chuanyi/voyage/ui/legal/HealthPrivacyActivity;->I:Ljava/lang/Object;

    .line 10
    .line 11
    const/4 v0, 0x0

    .line 12
    iput-boolean v0, p0, Lcom/chuanyi/voyage/ui/legal/HealthPrivacyActivity;->O:Z

    .line 13
    .line 14
    new-instance v0, Lbv4;

    .line 15
    .line 16
    const/4 v1, 0x4

    .line 17
    invoke-direct {v0, p0, v1}, Lbv4;-><init>(Lcfd;B)V

    .line 18
    .line 19
    .line 20
    invoke-virtual {p0, v0}, Lcfd;->addOnContextAvailableListener(Lvz30;)V

    .line 21
    .line 22
    .line 23
    return-void
.end method


# virtual methods
.method public final I()Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-virtual {p0}, Lcom/chuanyi/voyage/ui/legal/HealthPrivacyActivity;->II()Lpm;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    invoke-virtual {p0}, Lpm;->I()Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    return-object p0
.end method

.method public final II()Lpm;
    .locals 2

    .line 1
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/legal/HealthPrivacyActivity;->l:Lpm;

    .line 2
    .line 3
    if-nez v0, :cond_1

    .line 4
    .line 5
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/legal/HealthPrivacyActivity;->I:Ljava/lang/Object;

    .line 6
    .line 7
    monitor-enter v0

    .line 8
    :try_start_0
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/legal/HealthPrivacyActivity;->l:Lpm;

    .line 9
    .line 10
    if-nez v1, :cond_0

    .line 11
    .line 12
    new-instance v1, Lpm;

    .line 13
    .line 14
    invoke-direct {v1, p0}, Lpm;-><init>(Landroid/app/Activity;)V

    .line 15
    .line 16
    .line 17
    iput-object v1, p0, Lcom/chuanyi/voyage/ui/legal/HealthPrivacyActivity;->l:Lpm;

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :catchall_0
    move-exception p0

    .line 21
    goto :goto_1

    .line 22
    :cond_0
    :goto_0
    monitor-exit v0

    .line 23
    goto :goto_2

    .line 24
    :goto_1
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 25
    throw p0

    .line 26
    :cond_1
    :goto_2
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/legal/HealthPrivacyActivity;->l:Lpm;

    .line 27
    .line 28
    return-object p0
.end method

.method public final IO(Landroid/os/Bundle;)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Lcfd;->onCreate(Landroid/os/Bundle;)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Lcom/chuanyi/voyage/ui/legal/HealthPrivacyActivity;->II()Lpm;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    invoke-virtual {p0}, Lpm;->o()V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public final attachBaseContext(Landroid/content/Context;)V
    .locals 2

    .line 1
    const-wide v0, -0xafd874a0c56e39L

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    invoke-super {p0, p1}, Landroid/content/ContextWrapper;->attachBaseContext(Landroid/content/Context;)V

    .line 13
    .line 14
    .line 15
    sget-object p1, Lh15;->l:Lh15;

    .line 16
    .line 17
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 18
    .line 19
    .line 20
    invoke-static {p0}, Lh15;->I(Landroid/view/ContextThemeWrapper;)V

    .line 21
    .line 22
    .line 23
    return-void
.end method

.method public final getDefaultViewModelProviderFactory()Lq2n0;
    .locals 1

    .line 1
    invoke-super {p0}, Lcfd;->getDefaultViewModelProviderFactory()Lq2n0;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-static {p0, v0}, Lot8;->lIl(Lcfd;Lq2n0;)Ltfp;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    return-object p0
.end method

.method public final onCreate(Landroid/os/Bundle;)V
    .locals 3

    .line 1
    invoke-virtual {p0, p1}, Lcom/chuanyi/voyage/ui/legal/HealthPrivacyActivity;->IO(Landroid/os/Bundle;)V

    .line 2
    .line 3
    .line 4
    invoke-static {p0}, Ljgj;->I(Lcfd;)V

    .line 5
    .line 6
    .line 7
    new-instance p1, Lxzl;

    .line 8
    .line 9
    const/16 v0, 0x18

    .line 10
    .line 11
    invoke-direct {p1, p0, v0}, Lxzl;-><init>(Ljava/lang/Object;B)V

    .line 12
    .line 13
    .line 14
    new-instance v0, Lggd;

    .line 15
    .line 16
    const v1, -0x4f05d3f4

    .line 17
    .line 18
    .line 19
    const/4 v2, 0x1

    .line 20
    invoke-direct {v0, p1, v1, v2}, Lggd;-><init>(Ljava/lang/Object;IZ)V

    .line 21
    .line 22
    .line 23
    invoke-static {p0, v0}, Ldfd;->l(Lcfd;Lggd;)V

    .line 24
    .line 25
    .line 26
    return-void
.end method

.method public final onDestroy()V
    .locals 0

    .line 1
    invoke-super {p0}, Landroid/app/Activity;->onDestroy()V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Lcom/chuanyi/voyage/ui/legal/HealthPrivacyActivity;->II()Lpm;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    invoke-virtual {p0}, Lpm;->l()V

    .line 9
    .line 10
    .line 11
    return-void
.end method
