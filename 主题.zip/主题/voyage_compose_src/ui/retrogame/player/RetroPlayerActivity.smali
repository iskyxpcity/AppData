.class public final Lcom/chuanyi/voyage/ui/retrogame/player/RetroPlayerActivity;
.super Lzfp;
.source "S"


# static fields
.field public static final lI:Lef8;

.field public static final lO:Lzus;


# instance fields
.field public final ll:Ly3i0;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    const-wide v0, -0xf70b1da0c56e39L    # -8.55718060110196E303

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    new-instance v0, Lef8;

    .line 10
    .line 11
    const/16 v1, 0x1c

    .line 12
    .line 13
    invoke-direct {v0, v1}, Lef8;-><init>(B)V

    .line 14
    .line 15
    .line 16
    sput-object v0, Lcom/chuanyi/voyage/ui/retrogame/player/RetroPlayerActivity;->lI:Lef8;

    .line 17
    .line 18
    new-instance v0, Libb0;

    .line 19
    .line 20
    const/16 v1, 0x16

    .line 21
    .line 22
    invoke-direct {v0, v1}, Libb0;-><init>(B)V

    .line 23
    .line 24
    .line 25
    sget-object v1, Lqqs;->o:Lpqs;

    .line 26
    .line 27
    invoke-static {v1, v0}, Lewm;->ll(Lqqs;Lkotlin/jvm/functions/Function1;)Lzus;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    sput-object v0, Lcom/chuanyi/voyage/ui/retrogame/player/RetroPlayerActivity;->lO:Lzus;

    .line 32
    .line 33
    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .line 1
    const/4 v0, 0x1

    .line 2
    invoke-direct {p0, v0}, Lzfp;-><init>(B)V

    .line 3
    .line 4
    .line 5
    new-instance v0, Lo490;

    .line 6
    .line 7
    const/16 v1, 0x1a

    .line 8
    .line 9
    invoke-direct {v0, p0, v1}, Lo490;-><init>(Ljava/lang/Object;B)V

    .line 10
    .line 11
    .line 12
    new-instance v1, Ly3i0;

    .line 13
    .line 14
    invoke-direct {v1, v0}, Ly3i0;-><init>(Lkotlin/jvm/functions/Function0;)V

    .line 15
    .line 16
    .line 17
    iput-object v1, p0, Lcom/chuanyi/voyage/ui/retrogame/player/RetroPlayerActivity;->ll:Ly3i0;

    .line 18
    .line 19
    return-void
.end method


# virtual methods
.method public final IO()Llvb0;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/retrogame/player/RetroPlayerActivity;->ll:Ly3i0;

    .line 2
    .line 3
    invoke-virtual {p0}, Ly3i0;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Llvb0;

    .line 8
    .line 9
    return-object p0
.end method

.method public final attachBaseContext(Landroid/content/Context;)V
    .locals 2

    .line 1
    const-wide v0, -0xf7084aa0c56e39L

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    invoke-super {p0, p1}, Landroid/content/ContextWrapper;->attachBaseContext(Landroid/content/Context;)V

    .line 13
    .line 14
    .line 15
    sget-object p1, Lh15;->l:Lh15;

    .line 16
    .line 17
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 18
    .line 19
    .line 20
    invoke-static {p0}, Lh15;->I(Landroid/view/ContextThemeWrapper;)V

    .line 21
    .line 22
    .line 23
    return-void
.end method

.method public final dispatchGenericMotionEvent(Landroid/view/MotionEvent;)Z
    .locals 18

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    const-wide v1, -0xf7087aa0c56e39L

    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    invoke-virtual/range {p0 .. p0}, Lcom/chuanyi/voyage/ui/retrogame/player/RetroPlayerActivity;->IO()Llvb0;

    .line 15
    .line 16
    .line 17
    move-result-object v1

    .line 18
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 19
    .line 20
    .line 21
    const-wide v2, -0xf6d7d4a0c56e39L

    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    invoke-static {v2, v3}, Li6t0;->lO(J)Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    iget-object v2, v1, Llvb0;->lI:Lkvb0;

    .line 30
    .line 31
    sget-object v3, Lkvb0;->l:Lkvb0;

    .line 32
    .line 33
    if-ne v2, v3, :cond_1

    .line 34
    .line 35
    :cond_0
    :goto_0
    const/16 v16, 0x1

    .line 36
    .line 37
    goto/16 :goto_2

    .line 38
    .line 39
    :cond_1
    const v2, 0x1000010

    .line 40
    .line 41
    .line 42
    invoke-virtual {v0, v2}, Landroid/view/InputEvent;->isFromSource(I)Z

    .line 43
    .line 44
    .line 45
    move-result v3

    .line 46
    if-eqz v3, :cond_0

    .line 47
    .line 48
    invoke-virtual {v0}, Landroid/view/MotionEvent;->getActionMasked()I

    .line 49
    .line 50
    .line 51
    move-result v3

    .line 52
    const/4 v6, 0x2

    .line 53
    if-eq v3, v6, :cond_2

    .line 54
    .line 55
    goto :goto_0

    .line 56
    :cond_2
    invoke-virtual {v0}, Landroid/view/InputEvent;->getDevice()Landroid/view/InputDevice;

    .line 57
    .line 58
    .line 59
    move-result-object v3

    .line 60
    if-nez v3, :cond_3

    .line 61
    .line 62
    goto :goto_0

    .line 63
    :cond_3
    const-wide v6, -0xf6d749a0c56e39L

    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    invoke-static {v6, v7}, Li6t0;->lO(J)Ljava/lang/String;

    .line 69
    .line 70
    .line 71
    invoke-virtual {v3}, Landroid/view/InputDevice;->isVirtual()Z

    .line 72
    .line 73
    .line 74
    move-result v6

    .line 75
    if-eqz v6, :cond_4

    .line 76
    .line 77
    goto :goto_0

    .line 78
    :cond_4
    invoke-virtual {v3}, Landroid/view/InputDevice;->getSources()I

    .line 79
    .line 80
    .line 81
    move-result v6

    .line 82
    and-int/lit16 v7, v6, 0x401

    .line 83
    .line 84
    const/16 v8, 0x401

    .line 85
    .line 86
    if-eq v7, v8, :cond_5

    .line 87
    .line 88
    and-int/2addr v6, v2

    .line 89
    if-ne v6, v2, :cond_0

    .line 90
    .line 91
    :cond_5
    iget-object v2, v1, Llvb0;->II:Ljava/util/HashMap;

    .line 92
    .line 93
    invoke-virtual {v3}, Landroid/view/InputDevice;->getId()I

    .line 94
    .line 95
    .line 96
    move-result v6

    .line 97
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 98
    .line 99
    .line 100
    move-result-object v6

    .line 101
    invoke-virtual {v2, v6}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 102
    .line 103
    .line 104
    move-result-object v2

    .line 105
    check-cast v2, Ljava/lang/Integer;

    .line 106
    .line 107
    if-eqz v2, :cond_0

    .line 108
    .line 109
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 110
    .line 111
    .line 112
    move-result v2

    .line 113
    iget-object v6, v1, Llvb0;->Il:Ljava/util/HashMap;

    .line 114
    .line 115
    invoke-virtual {v3}, Landroid/view/InputDevice;->getId()I

    .line 116
    .line 117
    .line 118
    move-result v7

    .line 119
    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 120
    .line 121
    .line 122
    move-result-object v7

    .line 123
    invoke-virtual {v6, v7}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 124
    .line 125
    .line 126
    move-result-object v8

    .line 127
    if-nez v8, :cond_6

    .line 128
    .line 129
    new-instance v8, Ljvb0;

    .line 130
    .line 131
    invoke-direct {v8, v2}, Ljvb0;-><init>(I)V

    .line 132
    .line 133
    .line 134
    invoke-virtual {v6, v7, v8}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 135
    .line 136
    .line 137
    :cond_6
    check-cast v8, Ljvb0;

    .line 138
    .line 139
    iget-object v6, v8, Ljvb0;->o:Ljava/util/EnumSet;

    .line 140
    .line 141
    iget-object v7, v8, Ljvb0;->O:Ljava/util/EnumSet;

    .line 142
    .line 143
    const-class v9, Lesb0;

    .line 144
    .line 145
    invoke-static {v9}, Ljava/util/EnumSet;->noneOf(Ljava/lang/Class;)Ljava/util/EnumSet;

    .line 146
    .line 147
    .line 148
    move-result-object v10

    .line 149
    invoke-virtual {v10, v7}, Ljava/util/AbstractCollection;->addAll(Ljava/util/Collection;)Z

    .line 150
    .line 151
    .line 152
    invoke-virtual {v10, v6}, Ljava/util/AbstractCollection;->addAll(Ljava/util/Collection;)Z

    .line 153
    .line 154
    .line 155
    invoke-static {v9}, Ljava/util/EnumSet;->noneOf(Ljava/lang/Class;)Ljava/util/EnumSet;

    .line 156
    .line 157
    .line 158
    move-result-object v11

    .line 159
    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 160
    .line 161
    .line 162
    const/16 v12, 0xf

    .line 163
    .line 164
    invoke-static {v0, v3, v12}, Llvb0;->l(Landroid/view/MotionEvent;Landroid/view/InputDevice;I)F

    .line 165
    .line 166
    .line 167
    move-result v12

    .line 168
    sget-object v13, Lesb0;->o:Lesb0;

    .line 169
    .line 170
    sget-object v14, Lesb0;->ll:Lesb0;

    .line 171
    .line 172
    invoke-static {v11, v7, v12, v13, v14}, Lf5w0;->l(Ljava/util/EnumSet;Ljava/util/EnumSet;FLesb0;Lesb0;)V

    .line 173
    .line 174
    .line 175
    const/16 v12, 0x10

    .line 176
    .line 177
    invoke-static {v0, v3, v12}, Llvb0;->l(Landroid/view/MotionEvent;Landroid/view/InputDevice;I)F

    .line 178
    .line 179
    .line 180
    move-result v12

    .line 181
    sget-object v15, Lesb0;->I:Lesb0;

    .line 182
    .line 183
    sget-object v4, Lesb0;->O:Lesb0;

    .line 184
    .line 185
    invoke-static {v11, v7, v12, v15, v4}, Lf5w0;->l(Ljava/util/EnumSet;Ljava/util/EnumSet;FLesb0;Lesb0;)V

    .line 186
    .line 187
    .line 188
    const/16 v12, 0xb

    .line 189
    .line 190
    invoke-static {v0, v3, v12}, Llvb0;->l(Landroid/view/MotionEvent;Landroid/view/InputDevice;I)F

    .line 191
    .line 192
    .line 193
    move-result v12

    .line 194
    sget-object v5, Lesb0;->g:Lesb0;

    .line 195
    .line 196
    move-object/from16 p0, v9

    .line 197
    .line 198
    sget-object v9, Lesb0;->h:Lesb0;

    .line 199
    .line 200
    invoke-static {v11, v7, v12, v5, v9}, Lf5w0;->l(Ljava/util/EnumSet;Ljava/util/EnumSet;FLesb0;Lesb0;)V

    .line 201
    .line 202
    .line 203
    const/16 v5, 0xe

    .line 204
    .line 205
    invoke-static {v0, v3, v5}, Llvb0;->l(Landroid/view/MotionEvent;Landroid/view/InputDevice;I)F

    .line 206
    .line 207
    .line 208
    move-result v5

    .line 209
    sget-object v9, Lesb0;->oo:Lesb0;

    .line 210
    .line 211
    sget-object v12, Lesb0;->f:Lesb0;

    .line 212
    .line 213
    invoke-static {v11, v7, v5, v9, v12}, Lf5w0;->l(Ljava/util/EnumSet;Ljava/util/EnumSet;FLesb0;Lesb0;)V

    .line 214
    .line 215
    .line 216
    const/16 v5, 0x11

    .line 217
    .line 218
    invoke-static {v0, v3, v5}, Llvb0;->l(Landroid/view/MotionEvent;Landroid/view/InputDevice;I)F

    .line 219
    .line 220
    .line 221
    move-result v5

    .line 222
    const/16 v9, 0x17

    .line 223
    .line 224
    invoke-static {v0, v3, v9}, Llvb0;->l(Landroid/view/MotionEvent;Landroid/view/InputDevice;I)F

    .line 225
    .line 226
    .line 227
    move-result v9

    .line 228
    invoke-static {v5, v9}, Ljava/lang/Math;->max(FF)F

    .line 229
    .line 230
    .line 231
    move-result v5

    .line 232
    sget-object v9, Lesb0;->Io:Lesb0;

    .line 233
    .line 234
    invoke-static {v11, v7, v5, v9}, Lf5w0;->I(Ljava/util/EnumSet;Ljava/util/EnumSet;FLesb0;)V

    .line 235
    .line 236
    .line 237
    const/16 v5, 0x12

    .line 238
    .line 239
    invoke-static {v0, v3, v5}, Llvb0;->l(Landroid/view/MotionEvent;Landroid/view/InputDevice;I)F

    .line 240
    .line 241
    .line 242
    move-result v5

    .line 243
    const/16 v9, 0x16

    .line 244
    .line 245
    invoke-static {v0, v3, v9}, Llvb0;->l(Landroid/view/MotionEvent;Landroid/view/InputDevice;I)F

    .line 246
    .line 247
    .line 248
    move-result v9

    .line 249
    invoke-static {v5, v9}, Ljava/lang/Math;->max(FF)F

    .line 250
    .line 251
    .line 252
    move-result v5

    .line 253
    sget-object v9, Lesb0;->Ol:Lesb0;

    .line 254
    .line 255
    invoke-static {v11, v7, v5, v9}, Lf5w0;->I(Ljava/util/EnumSet;Ljava/util/EnumSet;FLesb0;)V

    .line 256
    .line 257
    .line 258
    invoke-static/range {p0 .. p0}, Ljava/util/EnumSet;->noneOf(Ljava/lang/Class;)Ljava/util/EnumSet;

    .line 259
    .line 260
    .line 261
    move-result-object v5

    .line 262
    iget-boolean v9, v1, Llvb0;->lo:Z

    .line 263
    .line 264
    if-eqz v9, :cond_7

    .line 265
    .line 266
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 267
    .line 268
    .line 269
    const/4 v9, 0x0

    .line 270
    invoke-static {v0, v3, v9}, Llvb0;->l(Landroid/view/MotionEvent;Landroid/view/InputDevice;I)F

    .line 271
    .line 272
    .line 273
    move-result v9

    .line 274
    invoke-static {v5, v6, v9, v13, v14}, Lf5w0;->l(Ljava/util/EnumSet;Ljava/util/EnumSet;FLesb0;Lesb0;)V

    .line 275
    .line 276
    .line 277
    const/4 v9, 0x1

    .line 278
    invoke-static {v0, v3, v9}, Llvb0;->l(Landroid/view/MotionEvent;Landroid/view/InputDevice;I)F

    .line 279
    .line 280
    .line 281
    move-result v0

    .line 282
    invoke-static {v5, v6, v0, v15, v4}, Lf5w0;->l(Ljava/util/EnumSet;Ljava/util/EnumSet;FLesb0;Lesb0;)V

    .line 283
    .line 284
    .line 285
    :cond_7
    invoke-virtual {v7}, Ljava/util/AbstractCollection;->clear()V

    .line 286
    .line 287
    .line 288
    invoke-static {v7, v11}, Luqc;->addAll(Ljava/util/Collection;Ljava/lang/Iterable;)Z

    .line 289
    .line 290
    .line 291
    invoke-virtual {v6}, Ljava/util/AbstractCollection;->clear()V

    .line 292
    .line 293
    .line 294
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 295
    .line 296
    .line 297
    invoke-static {v6, v5}, Luqc;->addAll(Ljava/util/Collection;Ljava/lang/Iterable;)Z

    .line 298
    .line 299
    .line 300
    iget-object v0, v1, Llvb0;->lI:Lkvb0;

    .line 301
    .line 302
    sget-object v3, Lkvb0;->O:Lkvb0;

    .line 303
    .line 304
    if-ne v0, v3, :cond_b

    .line 305
    .line 306
    invoke-static {v11, v5}, Lvae0;->lIO(Ljava/util/Set;Ljava/lang/Iterable;)Ljava/util/LinkedHashSet;

    .line 307
    .line 308
    .line 309
    move-result-object v0

    .line 310
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 311
    .line 312
    .line 313
    move-result-object v0

    .line 314
    :cond_8
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 315
    .line 316
    .line 317
    move-result v3

    .line 318
    if-eqz v3, :cond_9

    .line 319
    .line 320
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 321
    .line 322
    .line 323
    move-result-object v3

    .line 324
    move-object v4, v3

    .line 325
    check-cast v4, Lesb0;

    .line 326
    .line 327
    invoke-virtual {v10, v4}, Ljava/util/AbstractCollection;->contains(Ljava/lang/Object;)Z

    .line 328
    .line 329
    .line 330
    move-result v4

    .line 331
    if-nez v4, :cond_8

    .line 332
    .line 333
    goto :goto_1

    .line 334
    :cond_9
    const/4 v3, 0x0

    .line 335
    :goto_1
    check-cast v3, Lesb0;

    .line 336
    .line 337
    if-eqz v3, :cond_a

    .line 338
    .line 339
    iget-object v0, v1, Llvb0;->ll:Lyh80;

    .line 340
    .line 341
    if-eqz v0, :cond_a

    .line 342
    .line 343
    const-wide v4, -0xf70cffa0c56e39L

    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    invoke-static {v4, v5}, Li6t0;->lO(J)Ljava/lang/String;

    .line 349
    .line 350
    .line 351
    iget-object v1, v0, Lyh80;->o:Ljava/lang/Object;

    .line 352
    .line 353
    check-cast v1, Lvhf0;

    .line 354
    .line 355
    invoke-virtual {v1, v2}, Lvhf0;->Il(I)V

    .line 356
    .line 357
    .line 358
    iget-object v1, v0, Lyh80;->ll:Ljava/lang/Object;

    .line 359
    .line 360
    check-cast v1, Lvhf0;

    .line 361
    .line 362
    invoke-virtual {v1, v2}, Lvhf0;->Il(I)V

    .line 363
    .line 364
    .line 365
    iget-object v0, v0, Lyh80;->lI:Ljava/lang/Object;

    .line 366
    .line 367
    check-cast v0, Lvhf0;

    .line 368
    .line 369
    invoke-virtual {v3}, Ljava/lang/Enum;->ordinal()I

    .line 370
    .line 371
    .line 372
    move-result v1

    .line 373
    invoke-virtual {v0, v1}, Lvhf0;->Il(I)V

    .line 374
    .line 375
    .line 376
    const/16 v16, 0x1

    .line 377
    .line 378
    return v16

    .line 379
    :cond_a
    const/16 v16, 0x1

    .line 380
    .line 381
    goto :goto_3

    .line 382
    :cond_b
    const/16 v16, 0x1

    .line 383
    .line 384
    invoke-virtual {v1, v8}, Llvb0;->ll(Ljvb0;)V

    .line 385
    .line 386
    .line 387
    return v16

    .line 388
    :goto_2
    invoke-super/range {p0 .. p1}, Landroid/app/Activity;->dispatchGenericMotionEvent(Landroid/view/MotionEvent;)Z

    .line 389
    .line 390
    .line 391
    move-result v0

    .line 392
    if-eqz v0, :cond_c

    .line 393
    .line 394
    :goto_3
    return v16

    .line 395
    :cond_c
    const/16 v17, 0x0

    .line 396
    .line 397
    return v17
.end method

.method public final dispatchKeyEvent(Landroid/view/KeyEvent;)Z
    .locals 8

    .line 1
    const-wide v0, -0xf70874a0c56e39L

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    invoke-virtual {p0}, Lcom/chuanyi/voyage/ui/retrogame/player/RetroPlayerActivity;->IO()Llvb0;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 17
    .line 18
    .line 19
    iget-object v1, v0, Llvb0;->Il:Ljava/util/HashMap;

    .line 20
    .line 21
    const-wide v2, -0xf6d7cea0c56e39L

    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    invoke-static {v2, v3}, Li6t0;->lO(J)Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    iget-object v2, v0, Llvb0;->lI:Lkvb0;

    .line 30
    .line 31
    sget-object v3, Lkvb0;->l:Lkvb0;

    .line 32
    .line 33
    const/4 v4, 0x1

    .line 34
    if-ne v2, v3, :cond_0

    .line 35
    .line 36
    goto/16 :goto_1

    .line 37
    .line 38
    :cond_0
    invoke-virtual {p1}, Landroid/view/InputEvent;->getDevice()Landroid/view/InputDevice;

    .line 39
    .line 40
    .line 41
    move-result-object v2

    .line 42
    if-nez v2, :cond_1

    .line 43
    .line 44
    goto/16 :goto_1

    .line 45
    .line 46
    :cond_1
    const-wide v5, -0xf6d749a0c56e39L

    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    invoke-static {v5, v6}, Li6t0;->lO(J)Ljava/lang/String;

    .line 52
    .line 53
    .line 54
    invoke-virtual {v2}, Landroid/view/InputDevice;->isVirtual()Z

    .line 55
    .line 56
    .line 57
    move-result v3

    .line 58
    if-eqz v3, :cond_2

    .line 59
    .line 60
    goto/16 :goto_1

    .line 61
    .line 62
    :cond_2
    invoke-virtual {v2}, Landroid/view/InputDevice;->getSources()I

    .line 63
    .line 64
    .line 65
    move-result v3

    .line 66
    and-int/lit16 v5, v3, 0x401

    .line 67
    .line 68
    const/16 v6, 0x401

    .line 69
    .line 70
    if-eq v5, v6, :cond_3

    .line 71
    .line 72
    const v5, 0x1000010

    .line 73
    .line 74
    .line 75
    and-int/2addr v3, v5

    .line 76
    if-ne v3, v5, :cond_14

    .line 77
    .line 78
    :cond_3
    iget-object v3, v0, Llvb0;->II:Ljava/util/HashMap;

    .line 79
    .line 80
    invoke-virtual {v2}, Landroid/view/InputDevice;->getId()I

    .line 81
    .line 82
    .line 83
    move-result v5

    .line 84
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 85
    .line 86
    .line 87
    move-result-object v5

    .line 88
    invoke-virtual {v3, v5}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 89
    .line 90
    .line 91
    move-result-object v3

    .line 92
    check-cast v3, Ljava/lang/Integer;

    .line 93
    .line 94
    if-eqz v3, :cond_14

    .line 95
    .line 96
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 97
    .line 98
    .line 99
    move-result v3

    .line 100
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    .line 101
    .line 102
    .line 103
    move-result v5

    .line 104
    const/16 v6, 0x6e

    .line 105
    .line 106
    if-ne v5, v6, :cond_6

    .line 107
    .line 108
    iget-object v3, v0, Llvb0;->lI:Lkvb0;

    .line 109
    .line 110
    sget-object v5, Lkvb0;->I:Lkvb0;

    .line 111
    .line 112
    if-eq v3, v5, :cond_4

    .line 113
    .line 114
    goto/16 :goto_1

    .line 115
    .line 116
    :cond_4
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getAction()I

    .line 117
    .line 118
    .line 119
    move-result p0

    .line 120
    if-ne p0, v4, :cond_15

    .line 121
    .line 122
    invoke-virtual {p1}, Landroid/view/KeyEvent;->isCanceled()Z

    .line 123
    .line 124
    .line 125
    move-result p0

    .line 126
    if-nez p0, :cond_15

    .line 127
    .line 128
    invoke-virtual {v2}, Landroid/view/InputDevice;->getId()I

    .line 129
    .line 130
    .line 131
    move-result p0

    .line 132
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 133
    .line 134
    .line 135
    move-result-object p0

    .line 136
    invoke-virtual {v1, p0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 137
    .line 138
    .line 139
    move-result-object p0

    .line 140
    check-cast p0, Ljvb0;

    .line 141
    .line 142
    if-eqz p0, :cond_5

    .line 143
    .line 144
    invoke-virtual {v0, p0}, Llvb0;->O(Ljvb0;)V

    .line 145
    .line 146
    .line 147
    :cond_5
    iget-object p0, v0, Llvb0;->ll:Lyh80;

    .line 148
    .line 149
    if-eqz p0, :cond_15

    .line 150
    .line 151
    iget-object p0, p0, Lyh80;->O:Ljava/lang/Object;

    .line 152
    .line 153
    check-cast p0, Lkc10;

    .line 154
    .line 155
    invoke-static {p0, v4}, Lryb0;->OI(Lkc10;Z)V

    .line 156
    .line 157
    .line 158
    return v4

    .line 159
    :cond_6
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    .line 160
    .line 161
    .line 162
    move-result v5

    .line 163
    const/16 v6, 0x60

    .line 164
    .line 165
    if-eq v5, v6, :cond_a

    .line 166
    .line 167
    const/16 v6, 0x61

    .line 168
    .line 169
    if-eq v5, v6, :cond_9

    .line 170
    .line 171
    const/16 v6, 0x63

    .line 172
    .line 173
    if-eq v5, v6, :cond_8

    .line 174
    .line 175
    const/16 v6, 0x64

    .line 176
    .line 177
    if-eq v5, v6, :cond_7

    .line 178
    .line 179
    packed-switch v5, :pswitch_data_0

    .line 180
    .line 181
    .line 182
    packed-switch v5, :pswitch_data_1

    .line 183
    .line 184
    .line 185
    const/4 v5, 0x0

    .line 186
    goto :goto_0

    .line 187
    :pswitch_0
    sget-object v5, Lesb0;->oO:Lesb0;

    .line 188
    .line 189
    goto :goto_0

    .line 190
    :pswitch_1
    sget-object v5, Lesb0;->oI:Lesb0;

    .line 191
    .line 192
    goto :goto_0

    .line 193
    :pswitch_2
    sget-object v5, Lesb0;->ol:Lesb0;

    .line 194
    .line 195
    goto :goto_0

    .line 196
    :pswitch_3
    sget-object v5, Lesb0;->Oo:Lesb0;

    .line 197
    .line 198
    goto :goto_0

    .line 199
    :pswitch_4
    sget-object v5, Lesb0;->Ol:Lesb0;

    .line 200
    .line 201
    goto :goto_0

    .line 202
    :pswitch_5
    sget-object v5, Lesb0;->Io:Lesb0;

    .line 203
    .line 204
    goto :goto_0

    .line 205
    :pswitch_6
    sget-object v5, Lesb0;->IO:Lesb0;

    .line 206
    .line 207
    goto :goto_0

    .line 208
    :pswitch_7
    sget-object v5, Lesb0;->II:Lesb0;

    .line 209
    .line 210
    goto :goto_0

    .line 211
    :pswitch_8
    sget-object v5, Lesb0;->ll:Lesb0;

    .line 212
    .line 213
    goto :goto_0

    .line 214
    :pswitch_9
    sget-object v5, Lesb0;->o:Lesb0;

    .line 215
    .line 216
    goto :goto_0

    .line 217
    :pswitch_a
    sget-object v5, Lesb0;->O:Lesb0;

    .line 218
    .line 219
    goto :goto_0

    .line 220
    :pswitch_b
    sget-object v5, Lesb0;->I:Lesb0;

    .line 221
    .line 222
    goto :goto_0

    .line 223
    :cond_7
    sget-object v5, Lesb0;->Il:Lesb0;

    .line 224
    .line 225
    goto :goto_0

    .line 226
    :cond_8
    sget-object v5, Lesb0;->lo:Lesb0;

    .line 227
    .line 228
    goto :goto_0

    .line 229
    :cond_9
    sget-object v5, Lesb0;->lO:Lesb0;

    .line 230
    .line 231
    goto :goto_0

    .line 232
    :cond_a
    :pswitch_c
    sget-object v5, Lesb0;->lI:Lesb0;

    .line 233
    .line 234
    :goto_0
    if-nez v5, :cond_b

    .line 235
    .line 236
    goto/16 :goto_1

    .line 237
    .line 238
    :cond_b
    invoke-virtual {v2}, Landroid/view/InputDevice;->getId()I

    .line 239
    .line 240
    .line 241
    move-result p0

    .line 242
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 243
    .line 244
    .line 245
    move-result-object p0

    .line 246
    invoke-virtual {v1, p0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 247
    .line 248
    .line 249
    move-result-object v6

    .line 250
    if-nez v6, :cond_c

    .line 251
    .line 252
    new-instance v6, Ljvb0;

    .line 253
    .line 254
    invoke-direct {v6, v3}, Ljvb0;-><init>(I)V

    .line 255
    .line 256
    .line 257
    invoke-virtual {v1, p0, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 258
    .line 259
    .line 260
    :cond_c
    check-cast v6, Ljvb0;

    .line 261
    .line 262
    iget-object p0, v6, Ljvb0;->I:Ljava/util/EnumSet;

    .line 263
    .line 264
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getAction()I

    .line 265
    .line 266
    .line 267
    move-result v7

    .line 268
    if-eqz v7, :cond_e

    .line 269
    .line 270
    if-eq v7, v4, :cond_d

    .line 271
    .line 272
    goto/16 :goto_2

    .line 273
    .line 274
    :cond_d
    invoke-interface {p0, v5}, Ljava/util/Collection;->remove(Ljava/lang/Object;)Z

    .line 275
    .line 276
    .line 277
    invoke-virtual {v0, v6}, Llvb0;->ll(Ljvb0;)V

    .line 278
    .line 279
    .line 280
    return v4

    .line 281
    :cond_e
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getRepeatCount()I

    .line 282
    .line 283
    .line 284
    move-result p1

    .line 285
    if-nez p1, :cond_15

    .line 286
    .line 287
    iget-object p1, v0, Llvb0;->lI:Lkvb0;

    .line 288
    .line 289
    sget-object v7, Lkvb0;->O:Lkvb0;

    .line 290
    .line 291
    if-ne p1, v7, :cond_f

    .line 292
    .line 293
    iget-object p0, v0, Llvb0;->ll:Lyh80;

    .line 294
    .line 295
    if-eqz p0, :cond_15

    .line 296
    .line 297
    const-wide v0, -0xf70cffa0c56e39L

    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 303
    .line 304
    .line 305
    iget-object p1, p0, Lyh80;->o:Ljava/lang/Object;

    .line 306
    .line 307
    check-cast p1, Lvhf0;

    .line 308
    .line 309
    invoke-virtual {p1, v3}, Lvhf0;->Il(I)V

    .line 310
    .line 311
    .line 312
    iget-object p1, p0, Lyh80;->ll:Ljava/lang/Object;

    .line 313
    .line 314
    check-cast p1, Lvhf0;

    .line 315
    .line 316
    invoke-virtual {p1, v3}, Lvhf0;->Il(I)V

    .line 317
    .line 318
    .line 319
    iget-object p0, p0, Lyh80;->lI:Ljava/lang/Object;

    .line 320
    .line 321
    check-cast p0, Lvhf0;

    .line 322
    .line 323
    invoke-virtual {v5}, Ljava/lang/Enum;->ordinal()I

    .line 324
    .line 325
    .line 326
    move-result p1

    .line 327
    invoke-virtual {p0, p1}, Lvhf0;->Il(I)V

    .line 328
    .line 329
    .line 330
    return v4

    .line 331
    :cond_f
    invoke-interface {p0, v5}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 332
    .line 333
    .line 334
    sget-object p1, Lesb0;->oI:Lesb0;

    .line 335
    .line 336
    if-ne v5, p1, :cond_10

    .line 337
    .line 338
    sget-object v3, Lesb0;->oO:Lesb0;

    .line 339
    .line 340
    invoke-virtual {p0, v3}, Ljava/util/AbstractCollection;->contains(Ljava/lang/Object;)Z

    .line 341
    .line 342
    .line 343
    move-result v3

    .line 344
    if-nez v3, :cond_11

    .line 345
    .line 346
    :cond_10
    sget-object v3, Lesb0;->oO:Lesb0;

    .line 347
    .line 348
    if-ne v5, v3, :cond_13

    .line 349
    .line 350
    invoke-virtual {p0, p1}, Ljava/util/AbstractCollection;->contains(Ljava/lang/Object;)Z

    .line 351
    .line 352
    .line 353
    move-result p0

    .line 354
    if-eqz p0, :cond_13

    .line 355
    .line 356
    :cond_11
    invoke-virtual {v2}, Landroid/view/InputDevice;->getId()I

    .line 357
    .line 358
    .line 359
    move-result p0

    .line 360
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 361
    .line 362
    .line 363
    move-result-object p0

    .line 364
    invoke-virtual {v1, p0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 365
    .line 366
    .line 367
    move-result-object p0

    .line 368
    check-cast p0, Ljvb0;

    .line 369
    .line 370
    if-eqz p0, :cond_12

    .line 371
    .line 372
    invoke-virtual {v0, p0}, Llvb0;->O(Ljvb0;)V

    .line 373
    .line 374
    .line 375
    :cond_12
    iget-object p0, v0, Llvb0;->ll:Lyh80;

    .line 376
    .line 377
    if-eqz p0, :cond_15

    .line 378
    .line 379
    iget-object p0, p0, Lyh80;->O:Ljava/lang/Object;

    .line 380
    .line 381
    check-cast p0, Lkc10;

    .line 382
    .line 383
    invoke-static {p0, v4}, Lryb0;->OI(Lkc10;Z)V

    .line 384
    .line 385
    .line 386
    return v4

    .line 387
    :cond_13
    invoke-virtual {v0, v6}, Llvb0;->ll(Ljvb0;)V

    .line 388
    .line 389
    .line 390
    return v4

    .line 391
    :cond_14
    :goto_1
    invoke-super {p0, p1}, Landroidx/core/app/ComponentActivity;->dispatchKeyEvent(Landroid/view/KeyEvent;)Z

    .line 392
    .line 393
    .line 394
    move-result p0

    .line 395
    if-eqz p0, :cond_16

    .line 396
    .line 397
    :cond_15
    :goto_2
    return v4

    .line 398
    :cond_16
    const/4 p0, 0x0

    .line 399
    return p0

    .line 400
    nop

    .line 401
    :pswitch_data_0
    .packed-switch 0x13
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_c
    .end packed-switch

    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    :pswitch_data_1
    .packed-switch 0x66
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final onCreate(Landroid/os/Bundle;)V
    .locals 6

    .line 1
    new-instance v0, Lm4i0;

    .line 2
    .line 3
    new-instance v1, Lmuh0;

    .line 4
    .line 5
    const/16 v2, 0x10

    .line 6
    .line 7
    invoke-direct {v1, v2}, Lmuh0;-><init>(B)V

    .line 8
    .line 9
    .line 10
    const/4 v3, 0x0

    .line 11
    const/4 v4, 0x2

    .line 12
    invoke-direct {v0, v3, v3, v4, v1}, Lm4i0;-><init>(IIILkotlin/jvm/functions/Function1;)V

    .line 13
    .line 14
    .line 15
    new-instance v1, Lm4i0;

    .line 16
    .line 17
    new-instance v5, Lmuh0;

    .line 18
    .line 19
    invoke-direct {v5, v2}, Lmuh0;-><init>(B)V

    .line 20
    .line 21
    .line 22
    invoke-direct {v1, v3, v3, v4, v5}, Lm4i0;-><init>(IIILkotlin/jvm/functions/Function1;)V

    .line 23
    .line 24
    .line 25
    invoke-static {p0, v0, v1}, Ljgj;->l(Lcfd;Lm4i0;Lm4i0;)V

    .line 26
    .line 27
    .line 28
    invoke-super {p0, p1}, Lzfp;->onCreate(Landroid/os/Bundle;)V

    .line 29
    .line 30
    .line 31
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 32
    .line 33
    .line 34
    move-result-object p1

    .line 35
    if-eqz p1, :cond_0

    .line 36
    .line 37
    const-wide v0, -0xf70852a0c56e39L

    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 43
    .line 44
    .line 45
    move-result-object v0

    .line 46
    invoke-virtual {p1, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 47
    .line 48
    .line 49
    move-result-object p1

    .line 50
    goto :goto_0

    .line 51
    :cond_0
    const/4 p1, 0x0

    .line 52
    :goto_0
    sget-object v0, Lcom/chuanyi/voyage/ui/retrogame/player/RetroPlayerActivity;->lI:Lef8;

    .line 53
    .line 54
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 55
    .line 56
    .line 57
    invoke-static {p1}, Lef8;->llo(Ljava/lang/String;)Lwtb0;

    .line 58
    .line 59
    .line 60
    move-result-object p1

    .line 61
    if-nez p1, :cond_1

    .line 62
    .line 63
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    .line 64
    .line 65
    .line 66
    return-void

    .line 67
    :cond_1
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 68
    .line 69
    const/16 v0, 0x1e

    .line 70
    .line 71
    const/4 v1, 0x1

    .line 72
    if-lt p1, v0, :cond_2

    .line 73
    .line 74
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 75
    .line 76
    .line 77
    move-result-object p1

    .line 78
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 79
    .line 80
    .line 81
    move-result-object v0

    .line 82
    invoke-virtual {v0}, Landroid/view/Window;->getAttributes()Landroid/view/WindowManager$LayoutParams;

    .line 83
    .line 84
    .line 85
    move-result-object v0

    .line 86
    const/4 v2, 0x3

    .line 87
    invoke-static {v0, v2}, Lauc;->IO(Landroid/view/WindowManager$LayoutParams;I)V

    .line 88
    .line 89
    .line 90
    invoke-virtual {p1, v0}, Landroid/view/Window;->setAttributes(Landroid/view/WindowManager$LayoutParams;)V

    .line 91
    .line 92
    .line 93
    goto :goto_1

    .line 94
    :cond_2
    const/16 v0, 0x1c

    .line 95
    .line 96
    if-lt p1, v0, :cond_3

    .line 97
    .line 98
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 99
    .line 100
    .line 101
    move-result-object p1

    .line 102
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 103
    .line 104
    .line 105
    move-result-object v0

    .line 106
    invoke-virtual {v0}, Landroid/view/Window;->getAttributes()Landroid/view/WindowManager$LayoutParams;

    .line 107
    .line 108
    .line 109
    move-result-object v0

    .line 110
    invoke-static {v0, v1}, Lauc;->IO(Landroid/view/WindowManager$LayoutParams;I)V

    .line 111
    .line 112
    .line 113
    invoke-virtual {p1, v0}, Landroid/view/Window;->setAttributes(Landroid/view/WindowManager$LayoutParams;)V

    .line 114
    .line 115
    .line 116
    :cond_3
    :goto_1
    new-instance p1, Lwxb0;

    .line 117
    .line 118
    invoke-direct {p1, p0, v3}, Lwxb0;-><init>(Lcom/chuanyi/voyage/ui/retrogame/player/RetroPlayerActivity;B)V

    .line 119
    .line 120
    .line 121
    new-instance v0, Lggd;

    .line 122
    .line 123
    const v2, -0x2b9a789e

    .line 124
    .line 125
    .line 126
    invoke-direct {v0, p1, v2, v1}, Lggd;-><init>(Ljava/lang/Object;IZ)V

    .line 127
    .line 128
    .line 129
    invoke-static {p0, v0}, Ldfd;->l(Lcfd;Lggd;)V

    .line 130
    .line 131
    .line 132
    return-void
.end method

.method public final onStart()V
    .locals 2

    .line 1
    invoke-super {p0}, Landroid/app/Activity;->onStart()V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Lcom/chuanyi/voyage/ui/retrogame/player/RetroPlayerActivity;->IO()Llvb0;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    iget-object v0, p0, Llvb0;->l:Landroid/hardware/input/InputManager;

    .line 9
    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    iget-object v1, p0, Llvb0;->I:Landroid/os/Handler;

    .line 13
    .line 14
    invoke-virtual {v0, p0, v1}, Landroid/hardware/input/InputManager;->registerInputDeviceListener(Landroid/hardware/input/InputManager$InputDeviceListener;Landroid/os/Handler;)V

    .line 15
    .line 16
    .line 17
    :cond_0
    invoke-virtual {p0}, Llvb0;->I()V

    .line 18
    .line 19
    .line 20
    return-void
.end method

.method public final onStop()V
    .locals 2

    .line 1
    invoke-virtual {p0}, Lcom/chuanyi/voyage/ui/retrogame/player/RetroPlayerActivity;->IO()Llvb0;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iget-object v1, v0, Llvb0;->l:Landroid/hardware/input/InputManager;

    .line 6
    .line 7
    if-eqz v1, :cond_0

    .line 8
    .line 9
    invoke-virtual {v1, v0}, Landroid/hardware/input/InputManager;->unregisterInputDeviceListener(Landroid/hardware/input/InputManager$InputDeviceListener;)V

    .line 10
    .line 11
    .line 12
    :cond_0
    invoke-virtual {v0}, Llvb0;->o()V

    .line 13
    .line 14
    .line 15
    invoke-super {p0}, Landroid/app/Activity;->onStop()V

    .line 16
    .line 17
    .line 18
    return-void
.end method

.method public final onWindowFocusChanged(Z)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Landroid/app/Activity;->onWindowFocusChanged(Z)V

    .line 2
    .line 3
    .line 4
    if-nez p1, :cond_0

    .line 5
    .line 6
    invoke-virtual {p0}, Lcom/chuanyi/voyage/ui/retrogame/player/RetroPlayerActivity;->IO()Llvb0;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    invoke-virtual {p0}, Llvb0;->o()V

    .line 11
    .line 12
    .line 13
    :cond_0
    return-void
.end method
