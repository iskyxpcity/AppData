.class public final Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;
.super Ljava/lang/Object;
.source "S"

# interfaces
.implements Lcom/chuanyi/voyage/ui/navigation/AppRoute;


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000@\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0008\u0006\n\u0002\u0010\u0008\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\u0008\r\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\u0008\u000b\u0008\u0087\u0008\u0018\u0000 +2\u00020\u0001:\u0002,-B+\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0004\u001a\u00020\u0002\u0012\u0008\u0008\u0002\u0010\u0005\u001a\u00020\u0002\u0012\u0008\u0008\u0002\u0010\u0006\u001a\u00020\u0002\u00a2\u0006\u0004\u0008\u0007\u0010\u0008BC\u0008\u0010\u0012\u0006\u0010\n\u001a\u00020\t\u0012\u0008\u0010\u0003\u001a\u0004\u0018\u00010\u0002\u0012\u0008\u0010\u0004\u001a\u0004\u0018\u00010\u0002\u0012\u0008\u0010\u0005\u001a\u0004\u0018\u00010\u0002\u0012\u0008\u0010\u0006\u001a\u0004\u0018\u00010\u0002\u0012\u0008\u0010\u000c\u001a\u0004\u0018\u00010\u000b\u00a2\u0006\u0004\u0008\u0007\u0010\rJ\'\u0010\u0016\u001a\u00020\u00132\u0006\u0010\u000e\u001a\u00020\u00002\u0006\u0010\u0010\u001a\u00020\u000f2\u0006\u0010\u0012\u001a\u00020\u0011H\u0001\u00a2\u0006\u0004\u0008\u0014\u0010\u0015J\u0010\u0010\u0017\u001a\u00020\u0002H\u00c6\u0003\u00a2\u0006\u0004\u0008\u0017\u0010\u0018J\u0010\u0010\u0019\u001a\u00020\u0002H\u00c6\u0003\u00a2\u0006\u0004\u0008\u0019\u0010\u0018J\u0010\u0010\u001a\u001a\u00020\u0002H\u00c6\u0003\u00a2\u0006\u0004\u0008\u001a\u0010\u0018J\u0010\u0010\u001b\u001a\u00020\u0002H\u00c6\u0003\u00a2\u0006\u0004\u0008\u001b\u0010\u0018J8\u0010\u001c\u001a\u00020\u00002\u0008\u0008\u0002\u0010\u0003\u001a\u00020\u00022\u0008\u0008\u0002\u0010\u0004\u001a\u00020\u00022\u0008\u0008\u0002\u0010\u0005\u001a\u00020\u00022\u0008\u0008\u0002\u0010\u0006\u001a\u00020\u0002H\u00c6\u0001\u00a2\u0006\u0004\u0008\u001c\u0010\u001dJ\u0010\u0010\u001e\u001a\u00020\u0002H\u00d6\u0001\u00a2\u0006\u0004\u0008\u001e\u0010\u0018J\u0010\u0010\u001f\u001a\u00020\tH\u00d6\u0001\u00a2\u0006\u0004\u0008\u001f\u0010 J\u001a\u0010$\u001a\u00020#2\u0008\u0010\"\u001a\u0004\u0018\u00010!H\u00d6\u0003\u00a2\u0006\u0004\u0008$\u0010%R\u0017\u0010\u0003\u001a\u00020\u00028\u0006\u00a2\u0006\u000c\n\u0004\u0008\u0003\u0010&\u001a\u0004\u0008\'\u0010\u0018R\u0017\u0010\u0004\u001a\u00020\u00028\u0006\u00a2\u0006\u000c\n\u0004\u0008\u0004\u0010&\u001a\u0004\u0008(\u0010\u0018R\u0017\u0010\u0005\u001a\u00020\u00028\u0006\u00a2\u0006\u000c\n\u0004\u0008\u0005\u0010&\u001a\u0004\u0008)\u0010\u0018R\u0017\u0010\u0006\u001a\u00020\u00028\u0006\u00a2\u0006\u000c\n\u0004\u0008\u0006\u0010&\u001a\u0004\u0008*\u0010\u0018\u00a8\u0006."
    }
    d2 = {
        "Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/AppRoute;",
        "",
        "source",
        "id",
        "title",
        "image",
        "<init>",
        "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V",
        "",
        "seen0",
        "Lu3e0;",
        "serializationConstructorMarker",
        "(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lu3e0;)V",
        "self",
        "Lvud;",
        "output",
        "Le3e0;",
        "serialDesc",
        "",
        "write$Self$app",
        "(Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;Lvud;Le3e0;)V",
        "write$Self",
        "component1",
        "()Ljava/lang/String;",
        "component2",
        "component3",
        "component4",
        "copy",
        "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;",
        "toString",
        "hashCode",
        "()I",
        "",
        "other",
        "",
        "equals",
        "(Ljava/lang/Object;)Z",
        "Ljava/lang/String;",
        "getSource",
        "getId",
        "getTitle",
        "getImage",
        "Companion",
        "mta0",
        "nta0",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation

.annotation runtime Lq3e0;
.end annotation


# static fields
.field public static final $stable:I

.field public static final Companion:Lnta0;


# instance fields
.field private final id:Ljava/lang/String;

.field private final image:Ljava/lang/String;

.field private final source:Ljava/lang/String;

.field private final title:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, Lnta0;

    .line 2
    .line 3
    invoke-direct {v0}, Lnta0;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;->Companion:Lnta0;

    .line 7
    .line 8
    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lu3e0;)V
    .locals 1

    .line 1
    and-int/lit8 p6, p1, 0x3

    .line 2
    .line 3
    const/4 v0, 0x3

    .line 4
    if-ne v0, p6, :cond_2

    .line 5
    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object p2, p0, Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;->source:Ljava/lang/String;

    .line 10
    .line 11
    iput-object p3, p0, Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;->id:Ljava/lang/String;

    .line 12
    .line 13
    and-int/lit8 p2, p1, 0x4

    .line 14
    .line 15
    if-nez p2, :cond_0

    .line 16
    .line 17
    const-wide p2, -0xc749a7a0c56e39L

    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    invoke-static {p2, p3}, Li6t0;->lO(J)Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    move-result-object p2

    .line 26
    iput-object p2, p0, Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;->title:Ljava/lang/String;

    .line 27
    .line 28
    goto :goto_0

    .line 29
    :cond_0
    iput-object p4, p0, Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;->title:Ljava/lang/String;

    .line 30
    .line 31
    :goto_0
    and-int/lit8 p1, p1, 0x8

    .line 32
    .line 33
    if-nez p1, :cond_1

    .line 34
    .line 35
    const-wide p1, -0xc749a8a0c56e39L

    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    invoke-static {p1, p2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 41
    .line 42
    .line 43
    move-result-object p1

    .line 44
    iput-object p1, p0, Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;->image:Ljava/lang/String;

    .line 45
    .line 46
    return-void

    .line 47
    :cond_1
    iput-object p5, p0, Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;->image:Ljava/lang/String;

    .line 48
    .line 49
    return-void

    .line 50
    :cond_2
    sget-object p0, Lmta0;->l:Lmta0;

    .line 51
    .line 52
    invoke-virtual {p0}, Lmta0;->getDescriptor()Le3e0;

    .line 53
    .line 54
    .line 55
    move-result-object p0

    .line 56
    invoke-static {p1, v0, p0}, Lqmu0;->lIl(IILe3e0;)V

    .line 57
    .line 58
    .line 59
    const/4 p0, 0x0

    .line 60
    throw p0
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 4

    const-wide v0, -0xc74945a0c56e39L

    const-wide v2, -0xc7494ca0c56e39L

    .line 61
    invoke-static {v0, v1, p1, v2, v3}, Lns;->lll(JLjava/lang/String;J)V

    const-wide v0, -0xc7494fa0c56e39L

    .line 62
    invoke-static {v0, v1, p2, p3}, Lw280;->oO(JLjava/lang/String;Ljava/lang/String;)V

    const-wide v0, -0xc74955a0c56e39L

    .line 63
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 64
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 65
    iput-object p1, p0, Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;->source:Ljava/lang/String;

    .line 66
    iput-object p2, p0, Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;->id:Ljava/lang/String;

    .line 67
    iput-object p3, p0, Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;->title:Ljava/lang/String;

    .line 68
    iput-object p4, p0, Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;->image:Ljava/lang/String;

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 2

    and-int/lit8 p6, p5, 0x4

    if-eqz p6, :cond_0

    const-wide v0, -0xc7495ba0c56e39L

    .line 69
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    move-result-object p3

    :cond_0
    and-int/lit8 p5, p5, 0x8

    if-eqz p5, :cond_1

    const-wide p4, -0xc7495ca0c56e39L    # -6.77904725566472E304

    .line 70
    invoke-static {p4, p5}, Li6t0;->lO(J)Ljava/lang/String;

    move-result-object p4

    .line 71
    :cond_1
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public static synthetic copy$default(Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;
    .locals 0

    .line 1
    and-int/lit8 p6, p5, 0x1

    .line 2
    .line 3
    if-eqz p6, :cond_0

    .line 4
    .line 5
    iget-object p1, p0, Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;->source:Ljava/lang/String;

    .line 6
    .line 7
    :cond_0
    and-int/lit8 p6, p5, 0x2

    .line 8
    .line 9
    if-eqz p6, :cond_1

    .line 10
    .line 11
    iget-object p2, p0, Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;->id:Ljava/lang/String;

    .line 12
    .line 13
    :cond_1
    and-int/lit8 p6, p5, 0x4

    .line 14
    .line 15
    if-eqz p6, :cond_2

    .line 16
    .line 17
    iget-object p3, p0, Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;->title:Ljava/lang/String;

    .line 18
    .line 19
    :cond_2
    and-int/lit8 p5, p5, 0x8

    .line 20
    .line 21
    if-eqz p5, :cond_3

    .line 22
    .line 23
    iget-object p4, p0, Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;->image:Ljava/lang/String;

    .line 24
    .line 25
    :cond_3
    invoke-virtual {p0, p1, p2, p3, p4}, Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;->copy(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;

    .line 26
    .line 27
    .line 28
    move-result-object p0

    .line 29
    return-object p0
.end method

.method public static final synthetic write$Self$app(Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;Lvud;Le3e0;)V
    .locals 3
    .annotation runtime Lkotlin/jvm/JvmStatic;
    .end annotation

    .line 1
    const/4 v0, 0x0

    .line 2
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;->source:Ljava/lang/String;

    .line 3
    .line 4
    invoke-interface {p1, p2, v0, v1}, Lvud;->lII(Le3e0;ILjava/lang/String;)V

    .line 5
    .line 6
    .line 7
    const/4 v0, 0x1

    .line 8
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;->id:Ljava/lang/String;

    .line 9
    .line 10
    invoke-interface {p1, p2, v0, v1}, Lvud;->lII(Le3e0;ILjava/lang/String;)V

    .line 11
    .line 12
    .line 13
    invoke-interface {p1, p2}, Lvud;->ll(Le3e0;)Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    if-eqz v0, :cond_0

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;->title:Ljava/lang/String;

    .line 21
    .line 22
    const-wide v1, -0xc749a5a0c56e39L

    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object v1

    .line 31
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 32
    .line 33
    .line 34
    move-result v0

    .line 35
    if-nez v0, :cond_1

    .line 36
    .line 37
    :goto_0
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;->title:Ljava/lang/String;

    .line 38
    .line 39
    const/4 v1, 0x2

    .line 40
    invoke-interface {p1, p2, v1, v0}, Lvud;->lII(Le3e0;ILjava/lang/String;)V

    .line 41
    .line 42
    .line 43
    :cond_1
    invoke-interface {p1, p2}, Lvud;->ll(Le3e0;)Z

    .line 44
    .line 45
    .line 46
    move-result v0

    .line 47
    if-eqz v0, :cond_2

    .line 48
    .line 49
    goto :goto_1

    .line 50
    :cond_2
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;->image:Ljava/lang/String;

    .line 51
    .line 52
    const-wide v1, -0xc749a6a0c56e39L

    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 58
    .line 59
    .line 60
    move-result-object v1

    .line 61
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 62
    .line 63
    .line 64
    move-result v0

    .line 65
    if-nez v0, :cond_3

    .line 66
    .line 67
    :goto_1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;->image:Ljava/lang/String;

    .line 68
    .line 69
    const/4 v0, 0x3

    .line 70
    invoke-interface {p1, p2, v0, p0}, Lvud;->lII(Le3e0;ILjava/lang/String;)V

    .line 71
    .line 72
    .line 73
    :cond_3
    return-void
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;->source:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public final component2()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;->id:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public final component3()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;->title:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public final component4()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;->image:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public final copy(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;
    .locals 4

    .line 1
    const-wide v0, -0xc7495da0c56e39L

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    const-wide v2, -0xc74964a0c56e39L

    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    invoke-static {v0, v1, p1, v2, v3}, Lns;->lll(JLjava/lang/String;J)V

    .line 12
    .line 13
    .line 14
    const-wide v0, -0xc74967a0c56e39L

    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    invoke-static {v0, v1, p2, p3}, Lw280;->oO(JLjava/lang/String;Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    const-wide v0, -0xc7496da0c56e39L

    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 31
    .line 32
    .line 33
    new-instance p0, Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;

    .line 34
    .line 35
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 36
    .line 37
    .line 38
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, p1, :cond_0

    .line 3
    .line 4
    return v0

    .line 5
    :cond_0
    instance-of v1, p1, Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    if-nez v1, :cond_1

    .line 9
    .line 10
    return v2

    .line 11
    :cond_1
    check-cast p1, Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;

    .line 12
    .line 13
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;->source:Ljava/lang/String;

    .line 14
    .line 15
    iget-object v3, p1, Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;->source:Ljava/lang/String;

    .line 16
    .line 17
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    move-result v1

    .line 21
    if-nez v1, :cond_2

    .line 22
    .line 23
    return v2

    .line 24
    :cond_2
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;->id:Ljava/lang/String;

    .line 25
    .line 26
    iget-object v3, p1, Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;->id:Ljava/lang/String;

    .line 27
    .line 28
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 29
    .line 30
    .line 31
    move-result v1

    .line 32
    if-nez v1, :cond_3

    .line 33
    .line 34
    return v2

    .line 35
    :cond_3
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;->title:Ljava/lang/String;

    .line 36
    .line 37
    iget-object v3, p1, Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;->title:Ljava/lang/String;

    .line 38
    .line 39
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 40
    .line 41
    .line 42
    move-result v1

    .line 43
    if-nez v1, :cond_4

    .line 44
    .line 45
    return v2

    .line 46
    :cond_4
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;->image:Ljava/lang/String;

    .line 47
    .line 48
    iget-object p1, p1, Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;->image:Ljava/lang/String;

    .line 49
    .line 50
    invoke-static {p0, p1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 51
    .line 52
    .line 53
    move-result p0

    .line 54
    if-nez p0, :cond_5

    .line 55
    .line 56
    return v2

    .line 57
    :cond_5
    return v0
.end method

.method public final getId()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;->id:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public final getImage()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;->image:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public final getSource()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;->source:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public final getTitle()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;->title:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public hashCode()I
    .locals 3

    .line 1
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;->source:Ljava/lang/String;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    const/16 v1, 0x1f

    .line 8
    .line 9
    mul-int/2addr v0, v1

    .line 10
    iget-object v2, p0, Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;->id:Ljava/lang/String;

    .line 11
    .line 12
    invoke-static {v0, v1, v2}, Lw280;->I(IILjava/lang/String;)I

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    iget-object v2, p0, Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;->title:Ljava/lang/String;

    .line 17
    .line 18
    invoke-static {v0, v1, v2}, Lw280;->I(IILjava/lang/String;)I

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;->image:Ljava/lang/String;

    .line 23
    .line 24
    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    .line 25
    .line 26
    .line 27
    move-result p0

    .line 28
    add-int/2addr p0, v0

    .line 29
    return p0
.end method

.method public toString()Ljava/lang/String;
    .locals 4

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-wide v1, -0xc74973a0c56e39L

    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;->source:Ljava/lang/String;

    .line 16
    .line 17
    const-wide v2, -0xc7498da0c56e39L

    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    invoke-static {v2, v3, v1, v0}, Lti6;->Oo(JLjava/lang/String;Ljava/lang/StringBuilder;)V

    .line 23
    .line 24
    .line 25
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;->id:Ljava/lang/String;

    .line 26
    .line 27
    const-wide v2, -0xc74993a0c56e39L

    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    invoke-static {v2, v3, v1, v0}, Lti6;->Oo(JLjava/lang/String;Ljava/lang/StringBuilder;)V

    .line 33
    .line 34
    .line 35
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;->title:Ljava/lang/String;

    .line 36
    .line 37
    const-wide v2, -0xc7499ca0c56e39L

    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    invoke-static {v2, v3, v1, v0}, Lti6;->Oo(JLjava/lang/String;Ljava/lang/StringBuilder;)V

    .line 43
    .line 44
    .line 45
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;->image:Ljava/lang/String;

    .line 46
    .line 47
    const/16 v1, 0x29

    .line 48
    .line 49
    invoke-static {v1, p0, v0}, Lqhk;->IO(CLjava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 50
    .line 51
    .line 52
    move-result-object p0

    .line 53
    return-object p0
.end method
