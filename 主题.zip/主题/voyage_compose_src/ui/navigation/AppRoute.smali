.class public interface abstract Lcom/chuanyi/voyage/ui/navigation/AppRoute;
.super Ljava/lang/Object;
.source "S"

# interfaces
.implements Lbm10;


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u00ca\u0005\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\u0008w\u0018\u0000 \u00022\u00020\u0001:\u0001\u0003\u0082\u0001\u00e2\u0001\u0004\u0005\u0006\u0007\u0008\t\n\u000b\u000c\r\u000e\u000f\u0010\u0011\u0012\u0013\u0014\u0015\u0016\u0017\u0018\u0019\u001a\u001b\u001c\u001d\u001e\u001f !\"#$%&\'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~\u007f\u0080\u0001\u0081\u0001\u0082\u0001\u0083\u0001\u0084\u0001\u0085\u0001\u0086\u0001\u0087\u0001\u0088\u0001\u0089\u0001\u008a\u0001\u008b\u0001\u008c\u0001\u008d\u0001\u008e\u0001\u008f\u0001\u0090\u0001\u0091\u0001\u0092\u0001\u0093\u0001\u0094\u0001\u0095\u0001\u0096\u0001\u0097\u0001\u0098\u0001\u0099\u0001\u009a\u0001\u009b\u0001\u009c\u0001\u009d\u0001\u009e\u0001\u009f\u0001\u00a0\u0001\u00a1\u0001\u00a2\u0001\u00a3\u0001\u00a4\u0001\u00a5\u0001\u00a6\u0001\u00a7\u0001\u00a8\u0001\u00a9\u0001\u00aa\u0001\u00ab\u0001\u00ac\u0001\u00ad\u0001\u00ae\u0001\u00af\u0001\u00b0\u0001\u00b1\u0001\u00b2\u0001\u00a8\u0006\u00b3\u0001\u00c0\u0006\u0003"
    }
    d2 = {
        "Lcom/chuanyi/voyage/ui/navigation/AppRoute;",
        "Lbm10;",
        "Companion",
        "i45",
        "Lcom/chuanyi/voyage/ui/navigation/AboutRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/AccountBindingRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/AccountDeletionRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/AdbDebugActionsRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/AdbDebugDevicesRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/AdbDebugTerminalRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/AegisLineEditorRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/AegisLinesRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/AlmanacCalendarRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/AlmanacHolidaysRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/AlmanacPickRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/AlmanacSettingsRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/AppInfoRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/AppUpdateRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/AutoClickEditorRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/AutoClickSettingsRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/AutoSignRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/AvatarAlbumRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/AvatarAnimeRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/AvatarFeedRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/AvatarSearchRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/AvatarStudioRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/AvatarViewerRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/BaziChartRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/BaziEditRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/BaziPlaceRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/BaziRecordsRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/BaziReverseRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/BaziSettingsRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/BmiHistoryRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/CardKeyRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/CellSiteRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/CheckoutRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/CleanerRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/CloudBackupRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/ConnectedAccountsRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/CrashCenterRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/DocScanRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/DownloadDetailRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/DownloadsRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/FastbootConsoleRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/FastbootFlashRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/FastbootLocalPartitionsRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/FastbootPartitionsRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/FastbootVariablesRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/FeedbackComposeRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/FeedbackDetailRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/FeedbackRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/HearingResultRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/HearingTestRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/HomeRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/ImageCropperRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/ImagePromptDetailRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/InviteRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/LeaderboardPeriodRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/LeaderboardPeriodsRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/LeaderboardRewardsRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/LeaderboardRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/LegalDocumentRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/LifeEventRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/LifeGridSettingsRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/LoginDevicesRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/LoginRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/LotteryRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/MagazineArticleRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/MagazineBackupRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/MagazineIssueRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/MagazinePagesRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/MagazinePeriodicalRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/MagazineSearchRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/MagazineSettingsRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/MagazineSourceEditRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/MagazineSourcePickRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/MagazineSourcesRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/MagazineSubscriptionsRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/MediaPickerRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/MessageCategoryRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/MessageDetailRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/MessageSettingsRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/MessagesRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/MineRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/NoticeDetailRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/NoticeRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/NovelBackupRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/NovelBookRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/NovelChangeSourceRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/NovelCloudBackupsRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/NovelDiscoverCustomizeRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/NovelDiscoverWidgetRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/NovelDiscoverWidgetSourceRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/NovelDownloadRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/NovelExploreSourceRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/NovelHttpTtsEditRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/NovelReaderRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/NovelReplaceRulesRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/NovelRestoreRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/NovelSearchRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/NovelSearchStyleRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/NovelSettingsRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/NovelSourceEditRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/NovelSourcesRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/NovelSubscriptionsRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/NovelTtsRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/NovelVoicesRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/OAuthLinkRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/OpenSourceRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/OrdersRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/PanDriveRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/PanLoginRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/PasswordRecoveryRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/PdfToolRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/PdfToolsHubRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/PerpetualCalcRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/PerpetualEventEditRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/PerpetualEventsRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/PerpetualFestivalsRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/PerpetualPlaceRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/PerpetualRegionsRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/PerpetualSettingsRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/PointsCenterRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/PointsRecordsRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/ProfileRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/QrLoginRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/QuickToolPickerRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/QuickToolSettingsRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/ReactionRecordsRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/ReactionSettingsRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/ReactionTestRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/RecipeCookRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/RecipeDetailRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/RecipeScanRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/RecoveryCodesRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/RegisterRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/ReleaseHistoryRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/RewardedAdRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/SchulteRecordsRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/SchulteSettingsRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/SchulteTrainRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/SecurityRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/SensorDetailRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/SettingsRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/StorageBrowserRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/StorageExportsRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/StorageGrantsRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/StorageRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/StoreRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/ThemeSchemeEditorRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/ThemeSettingsRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/ToolManagerRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/ToolRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/ToolUpdatesRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/ToolsRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/VideoParseAccountRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/VocabBooksRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/VocabImportRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/VocabListRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/VocabSearchRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/VocabSettingsRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/VocabStatsRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/VocabStudyRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/VocabWordRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/WalletRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/WallpaperApplyRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/WallpaperMineRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/WallpaperSearchRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/WallpaperSettingsRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/WallpaperSourceRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/WallpaperViewerRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/WebDavAccountRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/WebViewRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/WoodfishSettingsRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/WoodfishStatsRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/YtdlpLoginRoute;",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation

.annotation runtime Lq3e0;
.end annotation


# static fields
.field public static final Companion:Li45;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    sget-object v0, Li45;->l:Li45;

    .line 2
    .line 3
    sput-object v0, Lcom/chuanyi/voyage/ui/navigation/AppRoute;->Companion:Li45;

    .line 4
    .line 5
    return-void
.end method
