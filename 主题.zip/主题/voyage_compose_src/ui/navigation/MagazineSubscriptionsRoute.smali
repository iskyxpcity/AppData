.class public final Lcom/chuanyi/voyage/ui/navigation/MagazineSubscriptionsRoute;
.super Ljava/lang/Object;
.source "S"

# interfaces
.implements Lcom/chuanyi/voyage/ui/navigation/AppRoute;


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u00002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0010\u000e\n\u0002\u0008\u0002\n\u0002\u0010\u0008\n\u0002\u0008\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\u0008\u0003\u0008\u00c7\n\u0018\u00002\u00020\u0001B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003J\u0013\u0010\u0005\u001a\u0008\u0012\u0004\u0012\u00020\u00000\u0004\u00a2\u0006\u0004\u0008\u0005\u0010\u0006J\u0010\u0010\u0008\u001a\u00020\u0007H\u00d6\u0001\u00a2\u0006\u0004\u0008\u0008\u0010\tJ\u0010\u0010\u000b\u001a\u00020\nH\u00d6\u0001\u00a2\u0006\u0004\u0008\u000b\u0010\u000cJ\u001a\u0010\u0010\u001a\u00020\u000f2\u0008\u0010\u000e\u001a\u0004\u0018\u00010\rH\u00d6\u0003\u00a2\u0006\u0004\u0008\u0010\u0010\u0011\u00a8\u0006\u0012"
    }
    d2 = {
        "Lcom/chuanyi/voyage/ui/navigation/MagazineSubscriptionsRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/AppRoute;",
        "<init>",
        "()V",
        "Ld9t;",
        "serializer",
        "()Ld9t;",
        "",
        "toString",
        "()Ljava/lang/String;",
        "",
        "hashCode",
        "()I",
        "",
        "other",
        "",
        "equals",
        "(Ljava/lang/Object;)Z",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation

.annotation runtime Lq3e0;
.end annotation


# static fields
.field private static final synthetic $cachedSerializer$delegate:Laau;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Laau;"
        }
    .end annotation
.end field

.field public static final $stable:I

.field public static final INSTANCE:Lcom/chuanyi/voyage/ui/navigation/MagazineSubscriptionsRoute;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    new-instance v0, Lcom/chuanyi/voyage/ui/navigation/MagazineSubscriptionsRoute;

    .line 2
    .line 3
    invoke-direct {v0}, Lcom/chuanyi/voyage/ui/navigation/MagazineSubscriptionsRoute;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lcom/chuanyi/voyage/ui/navigation/MagazineSubscriptionsRoute;->INSTANCE:Lcom/chuanyi/voyage/ui/navigation/MagazineSubscriptionsRoute;

    .line 7
    .line 8
    sget-object v0, Lygu;->I:Lygu;

    .line 9
    .line 10
    new-instance v1, Lq1x;

    .line 11
    .line 12
    const/16 v2, 0x10

    .line 13
    .line 14
    invoke-direct {v1, v2}, Lq1x;-><init>(B)V

    .line 15
    .line 16
    .line 17
    invoke-static {v0, v1}, Lesm;->Ol(Lygu;Lkotlin/jvm/functions/Function0;)Laau;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    sput-object v0, Lcom/chuanyi/voyage/ui/navigation/MagazineSubscriptionsRoute;->$cachedSerializer$delegate:Laau;

    .line 22
    .line 23
    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method private static final synthetic _init_$_anonymous_()Ld9t;
    .locals 4

    .line 1
    new-instance v0, Lu5k;

    .line 2
    .line 3
    const-wide v1, -0xc72d5da0c56e39L

    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    sget-object v2, Lcom/chuanyi/voyage/ui/navigation/MagazineSubscriptionsRoute;->INSTANCE:Lcom/chuanyi/voyage/ui/navigation/MagazineSubscriptionsRoute;

    .line 13
    .line 14
    const/4 v3, 0x0

    .line 15
    new-array v3, v3, [Ljava/lang/annotation/Annotation;

    .line 16
    .line 17
    invoke-direct {v0, v1, v2, v3}, Lu5k;-><init>(Ljava/lang/String;Ljava/lang/Object;[Ljava/lang/annotation/Annotation;)V

    .line 18
    .line 19
    .line 20
    return-object v0
.end method

.method private final synthetic get$cachedSerializer()Ld9t;
    .locals 0

    .line 1
    sget-object p0, Lcom/chuanyi/voyage/ui/navigation/MagazineSubscriptionsRoute;->$cachedSerializer$delegate:Laau;

    .line 2
    .line 3
    invoke-interface {p0}, Laau;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Ld9t;

    .line 8
    .line 9
    return-object p0
.end method

.method public static synthetic l()Ld9t;
    .locals 1

    .line 1
    invoke-static {}, Lcom/chuanyi/voyage/ui/navigation/MagazineSubscriptionsRoute;->_init_$_anonymous_()Ld9t;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    return-object v0
.end method


# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, p1, :cond_0

    .line 3
    .line 4
    return v0

    .line 5
    :cond_0
    instance-of p0, p1, Lcom/chuanyi/voyage/ui/navigation/MagazineSubscriptionsRoute;

    .line 6
    .line 7
    if-nez p0, :cond_1

    .line 8
    .line 9
    const/4 p0, 0x0

    .line 10
    return p0

    .line 11
    :cond_1
    return v0
.end method

.method public hashCode()I
    .locals 0

    .line 1
    const p0, 0x6204c048

    .line 2
    .line 3
    .line 4
    return p0
.end method

.method public final serializer()Ld9t;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ld9t;"
        }
    .end annotation

    .line 1
    invoke-direct {p0}, Lcom/chuanyi/voyage/ui/navigation/MagazineSubscriptionsRoute;->get$cachedSerializer()Ld9t;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public toString()Ljava/lang/String;
    .locals 2

    .line 1
    const-wide v0, -0xc72d42a0c56e39L

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    return-object p0
.end method
