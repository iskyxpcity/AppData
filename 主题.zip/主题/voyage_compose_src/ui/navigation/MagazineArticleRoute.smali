.class public final Lcom/chuanyi/voyage/ui/navigation/MagazineArticleRoute;
.super Ljava/lang/Object;
.source "S"

# interfaces
.implements Lcom/chuanyi/voyage/ui/navigation/AppRoute;


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000@\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0008\u0005\n\u0002\u0010\u0008\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\u0008\u000c\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\u0008\n\u0008\u0087\u0008\u0018\u0000 (2\u00020\u0001:\u0002)*B\'\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\n\u0008\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0002\u0012\n\u0008\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u0002\u00a2\u0006\u0004\u0008\u0006\u0010\u0007B9\u0008\u0010\u0012\u0006\u0010\t\u001a\u00020\u0008\u0012\u0008\u0010\u0003\u001a\u0004\u0018\u00010\u0002\u0012\u0008\u0010\u0004\u001a\u0004\u0018\u00010\u0002\u0012\u0008\u0010\u0005\u001a\u0004\u0018\u00010\u0002\u0012\u0008\u0010\u000b\u001a\u0004\u0018\u00010\n\u00a2\u0006\u0004\u0008\u0006\u0010\u000cJ\'\u0010\u0015\u001a\u00020\u00122\u0006\u0010\r\u001a\u00020\u00002\u0006\u0010\u000f\u001a\u00020\u000e2\u0006\u0010\u0011\u001a\u00020\u0010H\u0001\u00a2\u0006\u0004\u0008\u0013\u0010\u0014J\u0010\u0010\u0016\u001a\u00020\u0002H\u00c6\u0003\u00a2\u0006\u0004\u0008\u0016\u0010\u0017J\u0012\u0010\u0018\u001a\u0004\u0018\u00010\u0002H\u00c6\u0003\u00a2\u0006\u0004\u0008\u0018\u0010\u0017J\u0012\u0010\u0019\u001a\u0004\u0018\u00010\u0002H\u00c6\u0003\u00a2\u0006\u0004\u0008\u0019\u0010\u0017J2\u0010\u001a\u001a\u00020\u00002\u0008\u0008\u0002\u0010\u0003\u001a\u00020\u00022\n\u0008\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u00022\n\u0008\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u0002H\u00c6\u0001\u00a2\u0006\u0004\u0008\u001a\u0010\u001bJ\u0010\u0010\u001c\u001a\u00020\u0002H\u00d6\u0001\u00a2\u0006\u0004\u0008\u001c\u0010\u0017J\u0010\u0010\u001d\u001a\u00020\u0008H\u00d6\u0001\u00a2\u0006\u0004\u0008\u001d\u0010\u001eJ\u001a\u0010\"\u001a\u00020!2\u0008\u0010 \u001a\u0004\u0018\u00010\u001fH\u00d6\u0003\u00a2\u0006\u0004\u0008\"\u0010#R\u0017\u0010\u0003\u001a\u00020\u00028\u0006\u00a2\u0006\u000c\n\u0004\u0008\u0003\u0010$\u001a\u0004\u0008%\u0010\u0017R\u0019\u0010\u0004\u001a\u0004\u0018\u00010\u00028\u0006\u00a2\u0006\u000c\n\u0004\u0008\u0004\u0010$\u001a\u0004\u0008&\u0010\u0017R\u0019\u0010\u0005\u001a\u0004\u0018\u00010\u00028\u0006\u00a2\u0006\u000c\n\u0004\u0008\u0005\u0010$\u001a\u0004\u0008\'\u0010\u0017\u00a8\u0006+"
    }
    d2 = {
        "Lcom/chuanyi/voyage/ui/navigation/MagazineArticleRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/AppRoute;",
        "",
        "article",
        "issue",
        "periodical",
        "<init>",
        "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V",
        "",
        "seen0",
        "Lu3e0;",
        "serializationConstructorMarker",
        "(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Lu3e0;)V",
        "self",
        "Lvud;",
        "output",
        "Le3e0;",
        "serialDesc",
        "",
        "write$Self$app",
        "(Lcom/chuanyi/voyage/ui/navigation/MagazineArticleRoute;Lvud;Le3e0;)V",
        "write$Self",
        "component1",
        "()Ljava/lang/String;",
        "component2",
        "component3",
        "copy",
        "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/chuanyi/voyage/ui/navigation/MagazineArticleRoute;",
        "toString",
        "hashCode",
        "()I",
        "",
        "other",
        "",
        "equals",
        "(Ljava/lang/Object;)Z",
        "Ljava/lang/String;",
        "getArticle",
        "getIssue",
        "getPeriodical",
        "Companion",
        "xvw",
        "yvw",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation

.annotation runtime Lq3e0;
.end annotation


# static fields
.field public static final $stable:I

.field public static final Companion:Lyvw;


# instance fields
.field private final article:Ljava/lang/String;

.field private final issue:Ljava/lang/String;

.field private final periodical:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, Lyvw;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lcom/chuanyi/voyage/ui/navigation/MagazineArticleRoute;->Companion:Lyvw;

    .line 7
    .line 8
    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Lu3e0;)V
    .locals 2

    .line 1
    and-int/lit8 p5, p1, 0x1

    .line 2
    .line 3
    const/4 v0, 0x0

    .line 4
    const/4 v1, 0x1

    .line 5
    if-ne v1, p5, :cond_2

    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    iput-object p2, p0, Lcom/chuanyi/voyage/ui/navigation/MagazineArticleRoute;->article:Ljava/lang/String;

    .line 11
    .line 12
    and-int/lit8 p2, p1, 0x2

    .line 13
    .line 14
    if-nez p2, :cond_0

    .line 15
    .line 16
    iput-object v0, p0, Lcom/chuanyi/voyage/ui/navigation/MagazineArticleRoute;->issue:Ljava/lang/String;

    .line 17
    .line 18
    goto :goto_0

    .line 19
    :cond_0
    iput-object p3, p0, Lcom/chuanyi/voyage/ui/navigation/MagazineArticleRoute;->issue:Ljava/lang/String;

    .line 20
    .line 21
    :goto_0
    and-int/lit8 p1, p1, 0x4

    .line 22
    .line 23
    if-nez p1, :cond_1

    .line 24
    .line 25
    iput-object v0, p0, Lcom/chuanyi/voyage/ui/navigation/MagazineArticleRoute;->periodical:Ljava/lang/String;

    .line 26
    .line 27
    return-void

    .line 28
    :cond_1
    iput-object p4, p0, Lcom/chuanyi/voyage/ui/navigation/MagazineArticleRoute;->periodical:Ljava/lang/String;

    .line 29
    .line 30
    return-void

    .line 31
    :cond_2
    sget-object p0, Lxvw;->l:Lxvw;

    .line 32
    .line 33
    invoke-virtual {p0}, Lxvw;->getDescriptor()Le3e0;

    .line 34
    .line 35
    .line 36
    move-result-object p0

    .line 37
    invoke-static {p1, v1, p0}, Lqmu0;->lIl(IILe3e0;)V

    .line 38
    .line 39
    .line 40
    throw v0
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 2

    const-wide v0, -0xc728e9a0c56e39L

    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 41
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 42
    iput-object p1, p0, Lcom/chuanyi/voyage/ui/navigation/MagazineArticleRoute;->article:Ljava/lang/String;

    iput-object p2, p0, Lcom/chuanyi/voyage/ui/navigation/MagazineArticleRoute;->issue:Ljava/lang/String;

    iput-object p3, p0, Lcom/chuanyi/voyage/ui/navigation/MagazineArticleRoute;->periodical:Ljava/lang/String;

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 1

    and-int/lit8 p5, p4, 0x2

    const/4 v0, 0x0

    if-eqz p5, :cond_0

    move-object p2, v0

    :cond_0
    and-int/lit8 p4, p4, 0x4

    if-eqz p4, :cond_1

    move-object p3, v0

    .line 43
    :cond_1
    invoke-direct {p0, p1, p2, p3}, Lcom/chuanyi/voyage/ui/navigation/MagazineArticleRoute;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public static synthetic copy$default(Lcom/chuanyi/voyage/ui/navigation/MagazineArticleRoute;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Lcom/chuanyi/voyage/ui/navigation/MagazineArticleRoute;
    .locals 0

    .line 1
    and-int/lit8 p5, p4, 0x1

    .line 2
    .line 3
    if-eqz p5, :cond_0

    .line 4
    .line 5
    iget-object p1, p0, Lcom/chuanyi/voyage/ui/navigation/MagazineArticleRoute;->article:Ljava/lang/String;

    .line 6
    .line 7
    :cond_0
    and-int/lit8 p5, p4, 0x2

    .line 8
    .line 9
    if-eqz p5, :cond_1

    .line 10
    .line 11
    iget-object p2, p0, Lcom/chuanyi/voyage/ui/navigation/MagazineArticleRoute;->issue:Ljava/lang/String;

    .line 12
    .line 13
    :cond_1
    and-int/lit8 p4, p4, 0x4

    .line 14
    .line 15
    if-eqz p4, :cond_2

    .line 16
    .line 17
    iget-object p3, p0, Lcom/chuanyi/voyage/ui/navigation/MagazineArticleRoute;->periodical:Ljava/lang/String;

    .line 18
    .line 19
    :cond_2
    invoke-virtual {p0, p1, p2, p3}, Lcom/chuanyi/voyage/ui/navigation/MagazineArticleRoute;->copy(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/chuanyi/voyage/ui/navigation/MagazineArticleRoute;

    .line 20
    .line 21
    .line 22
    move-result-object p0

    .line 23
    return-object p0
.end method

.method public static final synthetic write$Self$app(Lcom/chuanyi/voyage/ui/navigation/MagazineArticleRoute;Lvud;Le3e0;)V
    .locals 3
    .annotation runtime Lkotlin/jvm/JvmStatic;
    .end annotation

    .line 1
    const/4 v0, 0x0

    .line 2
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/navigation/MagazineArticleRoute;->article:Ljava/lang/String;

    .line 3
    .line 4
    invoke-interface {p1, p2, v0, v1}, Lvud;->lII(Le3e0;ILjava/lang/String;)V

    .line 5
    .line 6
    .line 7
    invoke-interface {p1, p2}, Lvud;->ll(Le3e0;)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_0

    .line 12
    .line 13
    goto :goto_0

    .line 14
    :cond_0
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/navigation/MagazineArticleRoute;->issue:Ljava/lang/String;

    .line 15
    .line 16
    if-eqz v0, :cond_1

    .line 17
    .line 18
    :goto_0
    sget-object v0, Lxeh0;->l:Lxeh0;

    .line 19
    .line 20
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/navigation/MagazineArticleRoute;->issue:Ljava/lang/String;

    .line 21
    .line 22
    const/4 v2, 0x1

    .line 23
    invoke-interface {p1, p2, v2, v0, v1}, Lvud;->Io(Le3e0;ILd9t;Ljava/lang/Object;)V

    .line 24
    .line 25
    .line 26
    :cond_1
    invoke-interface {p1, p2}, Lvud;->ll(Le3e0;)Z

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    if-eqz v0, :cond_2

    .line 31
    .line 32
    goto :goto_1

    .line 33
    :cond_2
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/navigation/MagazineArticleRoute;->periodical:Ljava/lang/String;

    .line 34
    .line 35
    if-eqz v0, :cond_3

    .line 36
    .line 37
    :goto_1
    sget-object v0, Lxeh0;->l:Lxeh0;

    .line 38
    .line 39
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/navigation/MagazineArticleRoute;->periodical:Ljava/lang/String;

    .line 40
    .line 41
    const/4 v1, 0x2

    .line 42
    invoke-interface {p1, p2, v1, v0, p0}, Lvud;->Io(Le3e0;ILd9t;Ljava/lang/Object;)V

    .line 43
    .line 44
    .line 45
    :cond_3
    return-void
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/navigation/MagazineArticleRoute;->article:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public final component2()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/navigation/MagazineArticleRoute;->issue:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public final component3()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/navigation/MagazineArticleRoute;->periodical:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public final copy(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/chuanyi/voyage/ui/navigation/MagazineArticleRoute;
    .locals 2

    .line 1
    const-wide v0, -0xc728f1a0c56e39L    # -6.81378338820784E304

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    new-instance p0, Lcom/chuanyi/voyage/ui/navigation/MagazineArticleRoute;

    .line 13
    .line 14
    invoke-direct {p0, p1, p2, p3}, Lcom/chuanyi/voyage/ui/navigation/MagazineArticleRoute;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, p1, :cond_0

    .line 3
    .line 4
    return v0

    .line 5
    :cond_0
    instance-of v1, p1, Lcom/chuanyi/voyage/ui/navigation/MagazineArticleRoute;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    if-nez v1, :cond_1

    .line 9
    .line 10
    return v2

    .line 11
    :cond_1
    check-cast p1, Lcom/chuanyi/voyage/ui/navigation/MagazineArticleRoute;

    .line 12
    .line 13
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/navigation/MagazineArticleRoute;->article:Ljava/lang/String;

    .line 14
    .line 15
    iget-object v3, p1, Lcom/chuanyi/voyage/ui/navigation/MagazineArticleRoute;->article:Ljava/lang/String;

    .line 16
    .line 17
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    move-result v1

    .line 21
    if-nez v1, :cond_2

    .line 22
    .line 23
    return v2

    .line 24
    :cond_2
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/navigation/MagazineArticleRoute;->issue:Ljava/lang/String;

    .line 25
    .line 26
    iget-object v3, p1, Lcom/chuanyi/voyage/ui/navigation/MagazineArticleRoute;->issue:Ljava/lang/String;

    .line 27
    .line 28
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 29
    .line 30
    .line 31
    move-result v1

    .line 32
    if-nez v1, :cond_3

    .line 33
    .line 34
    return v2

    .line 35
    :cond_3
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/navigation/MagazineArticleRoute;->periodical:Ljava/lang/String;

    .line 36
    .line 37
    iget-object p1, p1, Lcom/chuanyi/voyage/ui/navigation/MagazineArticleRoute;->periodical:Ljava/lang/String;

    .line 38
    .line 39
    invoke-static {p0, p1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 40
    .line 41
    .line 42
    move-result p0

    .line 43
    if-nez p0, :cond_4

    .line 44
    .line 45
    return v2

    .line 46
    :cond_4
    return v0
.end method

.method public final getArticle()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/navigation/MagazineArticleRoute;->article:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public final getIssue()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/navigation/MagazineArticleRoute;->issue:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public final getPeriodical()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/navigation/MagazineArticleRoute;->periodical:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public hashCode()I
    .locals 3

    .line 1
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/navigation/MagazineArticleRoute;->article:Ljava/lang/String;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    mul-int/lit8 v0, v0, 0x1f

    .line 8
    .line 9
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/navigation/MagazineArticleRoute;->issue:Ljava/lang/String;

    .line 10
    .line 11
    const/4 v2, 0x0

    .line 12
    if-nez v1, :cond_0

    .line 13
    .line 14
    move v1, v2

    .line 15
    goto :goto_0

    .line 16
    :cond_0
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    :goto_0
    add-int/2addr v0, v1

    .line 21
    mul-int/lit8 v0, v0, 0x1f

    .line 22
    .line 23
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/navigation/MagazineArticleRoute;->periodical:Ljava/lang/String;

    .line 24
    .line 25
    if-nez p0, :cond_1

    .line 26
    .line 27
    goto :goto_1

    .line 28
    :cond_1
    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    .line 29
    .line 30
    .line 31
    move-result v2

    .line 32
    :goto_1
    add-int/2addr v0, v2

    .line 33
    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 4

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-wide v1, -0xc728f9a0c56e39L

    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/navigation/MagazineArticleRoute;->article:Ljava/lang/String;

    .line 16
    .line 17
    const-wide v2, -0xc72917a0c56e39L

    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    invoke-static {v2, v3, v1, v0}, Lti6;->Oo(JLjava/lang/String;Ljava/lang/StringBuilder;)V

    .line 23
    .line 24
    .line 25
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/navigation/MagazineArticleRoute;->issue:Ljava/lang/String;

    .line 26
    .line 27
    const-wide v2, -0xc72920a0c56e39L

    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    invoke-static {v2, v3, v1, v0}, Lti6;->Oo(JLjava/lang/String;Ljava/lang/StringBuilder;)V

    .line 33
    .line 34
    .line 35
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/navigation/MagazineArticleRoute;->periodical:Ljava/lang/String;

    .line 36
    .line 37
    const/16 v1, 0x29

    .line 38
    .line 39
    invoke-static {v1, p0, v0}, Lqhk;->IO(CLjava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 40
    .line 41
    .line 42
    move-result-object p0

    .line 43
    return-object p0
.end method
