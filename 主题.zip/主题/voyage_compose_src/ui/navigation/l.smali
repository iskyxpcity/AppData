.class public final synthetic Lcom/chuanyi/voyage/ui/navigation/l;
.super Ljava/lang/Object;
.source "S"

# interfaces
.implements Lymn;


# static fields
.field private static final descriptor:Le3e0;

.field public static final l:Lcom/chuanyi/voyage/ui/navigation/l;


# direct methods
.method static constructor <clinit>()V
    .locals 5

    .line 1
    new-instance v0, Lcom/chuanyi/voyage/ui/navigation/l;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lcom/chuanyi/voyage/ui/navigation/l;->l:Lcom/chuanyi/voyage/ui/navigation/l;

    .line 7
    .line 8
    new-instance v1, Le480;

    .line 9
    .line 10
    const-wide v2, -0xc73521a0c56e39L

    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    invoke-static {v2, v3}, Li6t0;->lO(J)Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    move-result-object v2

    .line 19
    const/4 v3, 0x4

    .line 20
    invoke-direct {v1, v2, v0, v3}, Le480;-><init>(Ljava/lang/String;Lymn;I)V

    .line 21
    .line 22
    .line 23
    const-wide v2, -0xc73562a0c56e39L

    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    invoke-static {v2, v3}, Li6t0;->lO(J)Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    const/4 v2, 0x0

    .line 33
    invoke-virtual {v1, v0, v2}, Le480;->II(Ljava/lang/String;Z)V

    .line 34
    .line 35
    .line 36
    const-wide v3, -0xc73568a0c56e39L

    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    invoke-static {v3, v4}, Li6t0;->lO(J)Ljava/lang/String;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    invoke-virtual {v1, v0, v2}, Le480;->II(Ljava/lang/String;Z)V

    .line 46
    .line 47
    .line 48
    const-wide v3, -0xc73572a0c56e39L

    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    invoke-static {v3, v4}, Li6t0;->lO(J)Ljava/lang/String;

    .line 54
    .line 55
    .line 56
    move-result-object v0

    .line 57
    invoke-virtual {v1, v0, v2}, Le480;->II(Ljava/lang/String;Z)V

    .line 58
    .line 59
    .line 60
    const-wide v3, -0xc73576a0c56e39L

    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    invoke-static {v3, v4}, Li6t0;->lO(J)Ljava/lang/String;

    .line 66
    .line 67
    .line 68
    move-result-object v0

    .line 69
    invoke-virtual {v1, v0, v2}, Le480;->II(Ljava/lang/String;Z)V

    .line 70
    .line 71
    .line 72
    sput-object v1, Lcom/chuanyi/voyage/ui/navigation/l;->descriptor:Le3e0;

    .line 73
    .line 74
    return-void
.end method


# virtual methods
.method public final childSerializers()[Ld9t;
    .locals 3

    .line 1
    const/4 p0, 0x4

    .line 2
    new-array p0, p0, [Ld9t;

    .line 3
    .line 4
    sget-object v0, Lnp10;->l:Lnp10;

    .line 5
    .line 6
    const/4 v1, 0x0

    .line 7
    aput-object v0, p0, v1

    .line 8
    .line 9
    sget-object v0, Lq0w;->l:Lq0w;

    .line 10
    .line 11
    const/4 v1, 0x1

    .line 12
    aput-object v0, p0, v1

    .line 13
    .line 14
    sget-object v1, Lrlr;->l:Lrlr;

    .line 15
    .line 16
    const/4 v2, 0x2

    .line 17
    aput-object v1, p0, v2

    .line 18
    .line 19
    const/4 v1, 0x3

    .line 20
    aput-object v0, p0, v1

    .line 21
    .line 22
    return-object p0
.end method

.method public final deserialize(Laag;)Ljava/lang/Object;
    .locals 14

    .line 1
    const-wide v0, -0xc73519a0c56e39L

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    sget-object p0, Lcom/chuanyi/voyage/ui/navigation/l;->descriptor:Le3e0;

    .line 10
    .line 11
    invoke-interface {p1, p0}, Laag;->I(Le3e0;)Luud;

    .line 12
    .line 13
    .line 14
    move-result-object p1

    .line 15
    const/4 v0, 0x1

    .line 16
    const/4 v1, 0x0

    .line 17
    const/4 v2, 0x0

    .line 18
    const-wide/16 v3, 0x0

    .line 19
    .line 20
    move v6, v1

    .line 21
    move v10, v6

    .line 22
    move-object v7, v2

    .line 23
    move-wide v8, v3

    .line 24
    move-wide v11, v8

    .line 25
    move v3, v0

    .line 26
    :goto_0
    if-eqz v3, :cond_5

    .line 27
    .line 28
    invoke-interface {p1, p0}, Luud;->ol(Le3e0;)I

    .line 29
    .line 30
    .line 31
    move-result v4

    .line 32
    const/4 v5, -0x1

    .line 33
    if-eq v4, v5, :cond_4

    .line 34
    .line 35
    if-eqz v4, :cond_3

    .line 36
    .line 37
    if-eq v4, v0, :cond_2

    .line 38
    .line 39
    const/4 v5, 0x2

    .line 40
    if-eq v4, v5, :cond_1

    .line 41
    .line 42
    const/4 v5, 0x3

    .line 43
    if-ne v4, v5, :cond_0

    .line 44
    .line 45
    invoke-interface {p1, p0, v5}, Luud;->Ol(Le3e0;I)J

    .line 46
    .line 47
    .line 48
    move-result-wide v11

    .line 49
    or-int/lit8 v6, v6, 0x8

    .line 50
    .line 51
    goto :goto_0

    .line 52
    :cond_0
    invoke-static {v4}, Lauc;->lO(I)V

    .line 53
    .line 54
    .line 55
    return-object v2

    .line 56
    :cond_1
    invoke-interface {p1, p0, v5}, Luud;->Il(Le3e0;I)I

    .line 57
    .line 58
    .line 59
    move-result v10

    .line 60
    or-int/lit8 v6, v6, 0x4

    .line 61
    .line 62
    goto :goto_0

    .line 63
    :cond_2
    invoke-interface {p1, p0, v0}, Luud;->Ol(Le3e0;I)J

    .line 64
    .line 65
    .line 66
    move-result-wide v8

    .line 67
    or-int/lit8 v6, v6, 0x2

    .line 68
    .line 69
    goto :goto_0

    .line 70
    :cond_3
    sget-object v4, Lnp10;->l:Lnp10;

    .line 71
    .line 72
    invoke-interface {p1, p0, v1, v4, v7}, Luud;->oO(Le3e0;ILf1h;Ljava/lang/Object;)Ljava/lang/Object;

    .line 73
    .line 74
    .line 75
    move-result-object v4

    .line 76
    move-object v7, v4

    .line 77
    check-cast v7, Lcom/chuanyi/voyage/ui/navigation/NavigationScene;

    .line 78
    .line 79
    or-int/lit8 v6, v6, 0x1

    .line 80
    .line 81
    goto :goto_0

    .line 82
    :cond_4
    move v3, v1

    .line 83
    goto :goto_0

    .line 84
    :cond_5
    invoke-interface {p1, p0}, Luud;->l(Le3e0;)V

    .line 85
    .line 86
    .line 87
    new-instance v5, Lcom/chuanyi/voyage/ui/navigation/NavigationSceneStore$SavedScene;

    .line 88
    .line 89
    const/4 v13, 0x0

    .line 90
    invoke-direct/range {v5 .. v13}, Lcom/chuanyi/voyage/ui/navigation/NavigationSceneStore$SavedScene;-><init>(ILcom/chuanyi/voyage/ui/navigation/NavigationScene;JIJLu3e0;)V

    .line 91
    .line 92
    .line 93
    return-object v5
.end method

.method public final getDescriptor()Le3e0;
    .locals 0

    .line 1
    sget-object p0, Lcom/chuanyi/voyage/ui/navigation/l;->descriptor:Le3e0;

    .line 2
    .line 3
    return-object p0
.end method

.method public final serialize(Lgqj;Ljava/lang/Object;)V
    .locals 2

    .line 1
    check-cast p2, Lcom/chuanyi/voyage/ui/navigation/NavigationSceneStore$SavedScene;

    .line 2
    .line 3
    const-wide v0, -0xc7350ba0c56e39L

    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    const-wide v0, -0xc73513a0c56e39L

    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 20
    .line 21
    .line 22
    sget-object p0, Lcom/chuanyi/voyage/ui/navigation/l;->descriptor:Le3e0;

    .line 23
    .line 24
    invoke-interface {p1, p0}, Lgqj;->I(Le3e0;)Lvud;

    .line 25
    .line 26
    .line 27
    move-result-object p1

    .line 28
    invoke-static {p2, p1, p0}, Lcom/chuanyi/voyage/ui/navigation/NavigationSceneStore$SavedScene;->write$Self$app(Lcom/chuanyi/voyage/ui/navigation/NavigationSceneStore$SavedScene;Lvud;Le3e0;)V

    .line 29
    .line 30
    .line 31
    invoke-interface {p1, p0}, Lvud;->l(Le3e0;)V

    .line 32
    .line 33
    .line 34
    return-void
.end method
