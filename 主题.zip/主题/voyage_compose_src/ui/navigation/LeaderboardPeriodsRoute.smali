.class public final Lcom/chuanyi/voyage/ui/navigation/LeaderboardPeriodsRoute;
.super Ljava/lang/Object;
.source "S"

# interfaces
.implements Lcom/chuanyi/voyage/ui/navigation/AppRoute;


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000@\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0008\u0004\n\u0002\u0010\u0008\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\u0008\u000b\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\u0008\t\u0008\u0087\u0008\u0018\u0000 %2\u00020\u0001:\u0002&\'B\u0019\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0008\u0008\u0002\u0010\u0004\u001a\u00020\u0002\u00a2\u0006\u0004\u0008\u0005\u0010\u0006B/\u0008\u0010\u0012\u0006\u0010\u0008\u001a\u00020\u0007\u0012\u0008\u0010\u0003\u001a\u0004\u0018\u00010\u0002\u0012\u0008\u0010\u0004\u001a\u0004\u0018\u00010\u0002\u0012\u0008\u0010\n\u001a\u0004\u0018\u00010\t\u00a2\u0006\u0004\u0008\u0005\u0010\u000bJ\'\u0010\u0014\u001a\u00020\u00112\u0006\u0010\u000c\u001a\u00020\u00002\u0006\u0010\u000e\u001a\u00020\r2\u0006\u0010\u0010\u001a\u00020\u000fH\u0001\u00a2\u0006\u0004\u0008\u0012\u0010\u0013J\u0010\u0010\u0015\u001a\u00020\u0002H\u00c6\u0003\u00a2\u0006\u0004\u0008\u0015\u0010\u0016J\u0010\u0010\u0017\u001a\u00020\u0002H\u00c6\u0003\u00a2\u0006\u0004\u0008\u0017\u0010\u0016J$\u0010\u0018\u001a\u00020\u00002\u0008\u0008\u0002\u0010\u0003\u001a\u00020\u00022\u0008\u0008\u0002\u0010\u0004\u001a\u00020\u0002H\u00c6\u0001\u00a2\u0006\u0004\u0008\u0018\u0010\u0019J\u0010\u0010\u001a\u001a\u00020\u0002H\u00d6\u0001\u00a2\u0006\u0004\u0008\u001a\u0010\u0016J\u0010\u0010\u001b\u001a\u00020\u0007H\u00d6\u0001\u00a2\u0006\u0004\u0008\u001b\u0010\u001cJ\u001a\u0010 \u001a\u00020\u001f2\u0008\u0010\u001e\u001a\u0004\u0018\u00010\u001dH\u00d6\u0003\u00a2\u0006\u0004\u0008 \u0010!R\u0017\u0010\u0003\u001a\u00020\u00028\u0006\u00a2\u0006\u000c\n\u0004\u0008\u0003\u0010\"\u001a\u0004\u0008#\u0010\u0016R\u0017\u0010\u0004\u001a\u00020\u00028\u0006\u00a2\u0006\u000c\n\u0004\u0008\u0004\u0010\"\u001a\u0004\u0008$\u0010\u0016\u00a8\u0006("
    }
    d2 = {
        "Lcom/chuanyi/voyage/ui/navigation/LeaderboardPeriodsRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/AppRoute;",
        "",
        "boardKey",
        "boardLabel",
        "<init>",
        "(Ljava/lang/String;Ljava/lang/String;)V",
        "",
        "seen0",
        "Lu3e0;",
        "serializationConstructorMarker",
        "(ILjava/lang/String;Ljava/lang/String;Lu3e0;)V",
        "self",
        "Lvud;",
        "output",
        "Le3e0;",
        "serialDesc",
        "",
        "write$Self$app",
        "(Lcom/chuanyi/voyage/ui/navigation/LeaderboardPeriodsRoute;Lvud;Le3e0;)V",
        "write$Self",
        "component1",
        "()Ljava/lang/String;",
        "component2",
        "copy",
        "(Ljava/lang/String;Ljava/lang/String;)Lcom/chuanyi/voyage/ui/navigation/LeaderboardPeriodsRoute;",
        "toString",
        "hashCode",
        "()I",
        "",
        "other",
        "",
        "equals",
        "(Ljava/lang/Object;)Z",
        "Ljava/lang/String;",
        "getBoardKey",
        "getBoardLabel",
        "Companion",
        "niu",
        "oiu",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation

.annotation runtime Lq3e0;
.end annotation


# static fields
.field public static final $stable:I

.field public static final Companion:Loiu;


# instance fields
.field private final boardKey:Ljava/lang/String;

.field private final boardLabel:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, Loiu;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lcom/chuanyi/voyage/ui/navigation/LeaderboardPeriodsRoute;->Companion:Loiu;

    .line 7
    .line 8
    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/String;Ljava/lang/String;Lu3e0;)V
    .locals 1

    .line 1
    and-int/lit8 p4, p1, 0x1

    .line 2
    .line 3
    const/4 v0, 0x1

    .line 4
    if-ne v0, p4, :cond_1

    .line 5
    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object p2, p0, Lcom/chuanyi/voyage/ui/navigation/LeaderboardPeriodsRoute;->boardKey:Ljava/lang/String;

    .line 10
    .line 11
    and-int/lit8 p1, p1, 0x2

    .line 12
    .line 13
    if-nez p1, :cond_0

    .line 14
    .line 15
    const-wide p1, -0xc725bda0c56e39L

    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    invoke-static {p1, p2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object p1

    .line 24
    iput-object p1, p0, Lcom/chuanyi/voyage/ui/navigation/LeaderboardPeriodsRoute;->boardLabel:Ljava/lang/String;

    .line 25
    .line 26
    return-void

    .line 27
    :cond_0
    iput-object p3, p0, Lcom/chuanyi/voyage/ui/navigation/LeaderboardPeriodsRoute;->boardLabel:Ljava/lang/String;

    .line 28
    .line 29
    return-void

    .line 30
    :cond_1
    sget-object p0, Lniu;->l:Lniu;

    .line 31
    .line 32
    invoke-virtual {p0}, Lniu;->getDescriptor()Le3e0;

    .line 33
    .line 34
    .line 35
    move-result-object p0

    .line 36
    invoke-static {p1, v0, p0}, Lqmu0;->lIl(IILe3e0;)V

    .line 37
    .line 38
    .line 39
    const/4 p0, 0x0

    .line 40
    throw p0
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;)V
    .locals 4

    const-wide v0, -0xc72563a0c56e39L

    const-wide v2, -0xc7256ca0c56e39L

    .line 41
    invoke-static {v0, v1, p1, v2, v3}, Lns;->lll(JLjava/lang/String;J)V

    .line 42
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 43
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 44
    iput-object p1, p0, Lcom/chuanyi/voyage/ui/navigation/LeaderboardPeriodsRoute;->boardKey:Ljava/lang/String;

    iput-object p2, p0, Lcom/chuanyi/voyage/ui/navigation/LeaderboardPeriodsRoute;->boardLabel:Ljava/lang/String;

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 0

    and-int/lit8 p3, p3, 0x2

    if-eqz p3, :cond_0

    const-wide p2, -0xc72577a0c56e39L

    .line 45
    invoke-static {p2, p3}, Li6t0;->lO(J)Ljava/lang/String;

    move-result-object p2

    :cond_0
    invoke-direct {p0, p1, p2}, Lcom/chuanyi/voyage/ui/navigation/LeaderboardPeriodsRoute;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public static synthetic copy$default(Lcom/chuanyi/voyage/ui/navigation/LeaderboardPeriodsRoute;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Lcom/chuanyi/voyage/ui/navigation/LeaderboardPeriodsRoute;
    .locals 0

    .line 1
    and-int/lit8 p4, p3, 0x1

    .line 2
    .line 3
    if-eqz p4, :cond_0

    .line 4
    .line 5
    iget-object p1, p0, Lcom/chuanyi/voyage/ui/navigation/LeaderboardPeriodsRoute;->boardKey:Ljava/lang/String;

    .line 6
    .line 7
    :cond_0
    and-int/lit8 p3, p3, 0x2

    .line 8
    .line 9
    if-eqz p3, :cond_1

    .line 10
    .line 11
    iget-object p2, p0, Lcom/chuanyi/voyage/ui/navigation/LeaderboardPeriodsRoute;->boardLabel:Ljava/lang/String;

    .line 12
    .line 13
    :cond_1
    invoke-virtual {p0, p1, p2}, Lcom/chuanyi/voyage/ui/navigation/LeaderboardPeriodsRoute;->copy(Ljava/lang/String;Ljava/lang/String;)Lcom/chuanyi/voyage/ui/navigation/LeaderboardPeriodsRoute;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    return-object p0
.end method

.method public static final synthetic write$Self$app(Lcom/chuanyi/voyage/ui/navigation/LeaderboardPeriodsRoute;Lvud;Le3e0;)V
    .locals 3
    .annotation runtime Lkotlin/jvm/JvmStatic;
    .end annotation

    .line 1
    const/4 v0, 0x0

    .line 2
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/navigation/LeaderboardPeriodsRoute;->boardKey:Ljava/lang/String;

    .line 3
    .line 4
    invoke-interface {p1, p2, v0, v1}, Lvud;->lII(Le3e0;ILjava/lang/String;)V

    .line 5
    .line 6
    .line 7
    invoke-interface {p1, p2}, Lvud;->ll(Le3e0;)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_0

    .line 12
    .line 13
    goto :goto_0

    .line 14
    :cond_0
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/navigation/LeaderboardPeriodsRoute;->boardLabel:Ljava/lang/String;

    .line 15
    .line 16
    const-wide v1, -0xc725bca0c56e39L    # -6.81721974979573E304

    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    if-nez v0, :cond_1

    .line 30
    .line 31
    :goto_0
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/navigation/LeaderboardPeriodsRoute;->boardLabel:Ljava/lang/String;

    .line 32
    .line 33
    const/4 v0, 0x1

    .line 34
    invoke-interface {p1, p2, v0, p0}, Lvud;->lII(Le3e0;ILjava/lang/String;)V

    .line 35
    .line 36
    .line 37
    :cond_1
    return-void
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/navigation/LeaderboardPeriodsRoute;->boardKey:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public final component2()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/navigation/LeaderboardPeriodsRoute;->boardLabel:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public final copy(Ljava/lang/String;Ljava/lang/String;)Lcom/chuanyi/voyage/ui/navigation/LeaderboardPeriodsRoute;
    .locals 4

    .line 1
    const-wide v0, -0xc72578a0c56e39L

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    const-wide v2, -0xc72581a0c56e39L

    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    invoke-static {v0, v1, p1, v2, v3}, Lns;->lll(JLjava/lang/String;J)V

    .line 12
    .line 13
    .line 14
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    .line 16
    .line 17
    new-instance p0, Lcom/chuanyi/voyage/ui/navigation/LeaderboardPeriodsRoute;

    .line 18
    .line 19
    invoke-direct {p0, p1, p2}, Lcom/chuanyi/voyage/ui/navigation/LeaderboardPeriodsRoute;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, p1, :cond_0

    .line 3
    .line 4
    return v0

    .line 5
    :cond_0
    instance-of v1, p1, Lcom/chuanyi/voyage/ui/navigation/LeaderboardPeriodsRoute;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    if-nez v1, :cond_1

    .line 9
    .line 10
    return v2

    .line 11
    :cond_1
    check-cast p1, Lcom/chuanyi/voyage/ui/navigation/LeaderboardPeriodsRoute;

    .line 12
    .line 13
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/navigation/LeaderboardPeriodsRoute;->boardKey:Ljava/lang/String;

    .line 14
    .line 15
    iget-object v3, p1, Lcom/chuanyi/voyage/ui/navigation/LeaderboardPeriodsRoute;->boardKey:Ljava/lang/String;

    .line 16
    .line 17
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    move-result v1

    .line 21
    if-nez v1, :cond_2

    .line 22
    .line 23
    return v2

    .line 24
    :cond_2
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/navigation/LeaderboardPeriodsRoute;->boardLabel:Ljava/lang/String;

    .line 25
    .line 26
    iget-object p1, p1, Lcom/chuanyi/voyage/ui/navigation/LeaderboardPeriodsRoute;->boardLabel:Ljava/lang/String;

    .line 27
    .line 28
    invoke-static {p0, p1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 29
    .line 30
    .line 31
    move-result p0

    .line 32
    if-nez p0, :cond_3

    .line 33
    .line 34
    return v2

    .line 35
    :cond_3
    return v0
.end method

.method public final getBoardKey()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/navigation/LeaderboardPeriodsRoute;->boardKey:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public final getBoardLabel()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/navigation/LeaderboardPeriodsRoute;->boardLabel:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public hashCode()I
    .locals 1

    .line 1
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/navigation/LeaderboardPeriodsRoute;->boardKey:Ljava/lang/String;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    mul-int/lit8 v0, v0, 0x1f

    .line 8
    .line 9
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/navigation/LeaderboardPeriodsRoute;->boardLabel:Ljava/lang/String;

    .line 10
    .line 11
    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    .line 12
    .line 13
    .line 14
    move-result p0

    .line 15
    add-int/2addr p0, v0

    .line 16
    return p0
.end method

.method public toString()Ljava/lang/String;
    .locals 4

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-wide v1, -0xc7258ca0c56e39L

    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/navigation/LeaderboardPeriodsRoute;->boardKey:Ljava/lang/String;

    .line 16
    .line 17
    const-wide v2, -0xc725aea0c56e39L

    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    invoke-static {v2, v3, v1, v0}, Lti6;->Oo(JLjava/lang/String;Ljava/lang/StringBuilder;)V

    .line 23
    .line 24
    .line 25
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/navigation/LeaderboardPeriodsRoute;->boardLabel:Ljava/lang/String;

    .line 26
    .line 27
    const/16 v1, 0x29

    .line 28
    .line 29
    invoke-static {v1, p0, v0}, Lqhk;->IO(CLjava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 30
    .line 31
    .line 32
    move-result-object p0

    .line 33
    return-object p0
.end method
