.class public final Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;
.super Ljava/lang/Object;
.source "S"

# interfaces
.implements Lcom/chuanyi/voyage/ui/navigation/AppRoute;


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000@\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0008\u0008\n\u0002\u0010\u0008\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\u0008\u000f\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\u0008\r\u0008\u0087\u0008\u0018\u0000 12\u00020\u0001:\u000223BC\u0012\u0008\u0008\u0002\u0010\u0003\u001a\u00020\u0002\u0012\u0008\u0008\u0002\u0010\u0004\u001a\u00020\u0002\u0012\u0008\u0008\u0002\u0010\u0005\u001a\u00020\u0002\u0012\u0008\u0008\u0002\u0010\u0006\u001a\u00020\u0002\u0012\u0008\u0008\u0002\u0010\u0007\u001a\u00020\u0002\u0012\u0008\u0008\u0002\u0010\u0008\u001a\u00020\u0002\u00a2\u0006\u0004\u0008\t\u0010\nBW\u0008\u0010\u0012\u0006\u0010\u000c\u001a\u00020\u000b\u0012\u0008\u0010\u0003\u001a\u0004\u0018\u00010\u0002\u0012\u0008\u0010\u0004\u001a\u0004\u0018\u00010\u0002\u0012\u0008\u0010\u0005\u001a\u0004\u0018\u00010\u0002\u0012\u0008\u0010\u0006\u001a\u0004\u0018\u00010\u0002\u0012\u0008\u0010\u0007\u001a\u0004\u0018\u00010\u0002\u0012\u0008\u0010\u0008\u001a\u0004\u0018\u00010\u0002\u0012\u0008\u0010\u000e\u001a\u0004\u0018\u00010\r\u00a2\u0006\u0004\u0008\t\u0010\u000fJ\'\u0010\u0018\u001a\u00020\u00152\u0006\u0010\u0010\u001a\u00020\u00002\u0006\u0010\u0012\u001a\u00020\u00112\u0006\u0010\u0014\u001a\u00020\u0013H\u0001\u00a2\u0006\u0004\u0008\u0016\u0010\u0017J\u0010\u0010\u0019\u001a\u00020\u0002H\u00c6\u0003\u00a2\u0006\u0004\u0008\u0019\u0010\u001aJ\u0010\u0010\u001b\u001a\u00020\u0002H\u00c6\u0003\u00a2\u0006\u0004\u0008\u001b\u0010\u001aJ\u0010\u0010\u001c\u001a\u00020\u0002H\u00c6\u0003\u00a2\u0006\u0004\u0008\u001c\u0010\u001aJ\u0010\u0010\u001d\u001a\u00020\u0002H\u00c6\u0003\u00a2\u0006\u0004\u0008\u001d\u0010\u001aJ\u0010\u0010\u001e\u001a\u00020\u0002H\u00c6\u0003\u00a2\u0006\u0004\u0008\u001e\u0010\u001aJ\u0010\u0010\u001f\u001a\u00020\u0002H\u00c6\u0003\u00a2\u0006\u0004\u0008\u001f\u0010\u001aJL\u0010 \u001a\u00020\u00002\u0008\u0008\u0002\u0010\u0003\u001a\u00020\u00022\u0008\u0008\u0002\u0010\u0004\u001a\u00020\u00022\u0008\u0008\u0002\u0010\u0005\u001a\u00020\u00022\u0008\u0008\u0002\u0010\u0006\u001a\u00020\u00022\u0008\u0008\u0002\u0010\u0007\u001a\u00020\u00022\u0008\u0008\u0002\u0010\u0008\u001a\u00020\u0002H\u00c6\u0001\u00a2\u0006\u0004\u0008 \u0010!J\u0010\u0010\"\u001a\u00020\u0002H\u00d6\u0001\u00a2\u0006\u0004\u0008\"\u0010\u001aJ\u0010\u0010#\u001a\u00020\u000bH\u00d6\u0001\u00a2\u0006\u0004\u0008#\u0010$J\u001a\u0010(\u001a\u00020\'2\u0008\u0010&\u001a\u0004\u0018\u00010%H\u00d6\u0003\u00a2\u0006\u0004\u0008(\u0010)R\u0017\u0010\u0003\u001a\u00020\u00028\u0006\u00a2\u0006\u000c\n\u0004\u0008\u0003\u0010*\u001a\u0004\u0008+\u0010\u001aR\u0017\u0010\u0004\u001a\u00020\u00028\u0006\u00a2\u0006\u000c\n\u0004\u0008\u0004\u0010*\u001a\u0004\u0008,\u0010\u001aR\u0017\u0010\u0005\u001a\u00020\u00028\u0006\u00a2\u0006\u000c\n\u0004\u0008\u0005\u0010*\u001a\u0004\u0008-\u0010\u001aR\u0017\u0010\u0006\u001a\u00020\u00028\u0006\u00a2\u0006\u000c\n\u0004\u0008\u0006\u0010*\u001a\u0004\u0008.\u0010\u001aR\u0017\u0010\u0007\u001a\u00020\u00028\u0006\u00a2\u0006\u000c\n\u0004\u0008\u0007\u0010*\u001a\u0004\u0008/\u0010\u001aR\u0017\u0010\u0008\u001a\u00020\u00028\u0006\u00a2\u0006\u000c\n\u0004\u0008\u0008\u0010*\u001a\u0004\u00080\u0010\u001a\u00a8\u00064"
    }
    d2 = {
        "Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/AppRoute;",
        "",
        "source",
        "channel",
        "keyword",
        "title",
        "topic",
        "color",
        "<init>",
        "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V",
        "",
        "seen0",
        "Lu3e0;",
        "serializationConstructorMarker",
        "(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lu3e0;)V",
        "self",
        "Lvud;",
        "output",
        "Le3e0;",
        "serialDesc",
        "",
        "write$Self$app",
        "(Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;Lvud;Le3e0;)V",
        "write$Self",
        "component1",
        "()Ljava/lang/String;",
        "component2",
        "component3",
        "component4",
        "component5",
        "component6",
        "copy",
        "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;",
        "toString",
        "hashCode",
        "()I",
        "",
        "other",
        "",
        "equals",
        "(Ljava/lang/Object;)Z",
        "Ljava/lang/String;",
        "getSource",
        "getChannel",
        "getKeyword",
        "getTitle",
        "getTopic",
        "getColor",
        "Companion",
        "abo0",
        "bbo0",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation

.annotation runtime Lq3e0;
.end annotation


# static fields
.field public static final $stable:I

.field public static final Companion:Lbbo0;


# instance fields
.field private final channel:Ljava/lang/String;

.field private final color:Ljava/lang/String;

.field private final keyword:Ljava/lang/String;

.field private final source:Ljava/lang/String;

.field private final title:Ljava/lang/String;

.field private final topic:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, Lbbo0;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->Companion:Lbbo0;

    .line 7
    .line 8
    return-void
.end method

.method public constructor <init>()V
    .locals 9

    .line 121
    const/16 v7, 0x3f

    const/4 v8, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object v0, p0

    invoke-direct/range {v0 .. v8}, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lu3e0;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    and-int/lit8 p8, p1, 0x1

    .line 5
    .line 6
    if-nez p8, :cond_0

    .line 7
    .line 8
    const-wide v0, -0xc7a40ea0c56e39L

    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 14
    .line 15
    .line 16
    move-result-object p2

    .line 17
    :cond_0
    iput-object p2, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->source:Ljava/lang/String;

    .line 18
    .line 19
    and-int/lit8 p2, p1, 0x2

    .line 20
    .line 21
    if-nez p2, :cond_1

    .line 22
    .line 23
    const-wide p2, -0xc7a40fa0c56e39L

    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    invoke-static {p2, p3}, Li6t0;->lO(J)Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    move-result-object p2

    .line 32
    iput-object p2, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->channel:Ljava/lang/String;

    .line 33
    .line 34
    goto :goto_0

    .line 35
    :cond_1
    iput-object p3, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->channel:Ljava/lang/String;

    .line 36
    .line 37
    :goto_0
    and-int/lit8 p2, p1, 0x4

    .line 38
    .line 39
    if-nez p2, :cond_2

    .line 40
    .line 41
    const-wide p2, -0xc7a410a0c56e39L

    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    invoke-static {p2, p3}, Li6t0;->lO(J)Ljava/lang/String;

    .line 47
    .line 48
    .line 49
    move-result-object p2

    .line 50
    iput-object p2, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->keyword:Ljava/lang/String;

    .line 51
    .line 52
    goto :goto_1

    .line 53
    :cond_2
    iput-object p4, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->keyword:Ljava/lang/String;

    .line 54
    .line 55
    :goto_1
    and-int/lit8 p2, p1, 0x8

    .line 56
    .line 57
    if-nez p2, :cond_3

    .line 58
    .line 59
    const-wide p2, -0xc7a411a0c56e39L

    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    invoke-static {p2, p3}, Li6t0;->lO(J)Ljava/lang/String;

    .line 65
    .line 66
    .line 67
    move-result-object p2

    .line 68
    iput-object p2, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->title:Ljava/lang/String;

    .line 69
    .line 70
    goto :goto_2

    .line 71
    :cond_3
    iput-object p5, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->title:Ljava/lang/String;

    .line 72
    .line 73
    :goto_2
    and-int/lit8 p2, p1, 0x10

    .line 74
    .line 75
    if-nez p2, :cond_4

    .line 76
    .line 77
    const-wide p2, -0xc7a412a0c56e39L

    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    invoke-static {p2, p3}, Li6t0;->lO(J)Ljava/lang/String;

    .line 83
    .line 84
    .line 85
    move-result-object p2

    .line 86
    iput-object p2, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->topic:Ljava/lang/String;

    .line 87
    .line 88
    goto :goto_3

    .line 89
    :cond_4
    iput-object p6, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->topic:Ljava/lang/String;

    .line 90
    .line 91
    :goto_3
    and-int/lit8 p1, p1, 0x20

    .line 92
    .line 93
    if-nez p1, :cond_5

    .line 94
    .line 95
    const-wide p1, -0xc7a413a0c56e39L

    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    invoke-static {p1, p2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 101
    .line 102
    .line 103
    move-result-object p1

    .line 104
    iput-object p1, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->color:Ljava/lang/String;

    .line 105
    .line 106
    return-void

    .line 107
    :cond_5
    iput-object p7, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->color:Ljava/lang/String;

    .line 108
    .line 109
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 4

    const-wide v0, -0xc7a364a0c56e39L

    const-wide v2, -0xc7a36ba0c56e39L

    .line 110
    invoke-static {v0, v1, p1, v2, v3}, Lns;->lll(JLjava/lang/String;J)V

    const-wide v0, -0xc7a373a0c56e39L

    .line 111
    invoke-static {v0, v1, p2, p3}, Lw280;->oO(JLjava/lang/String;Ljava/lang/String;)V

    const-wide v0, -0xc7a37ba0c56e39L

    const-wide v2, -0xc7a381a0c56e39L

    .line 112
    invoke-static {v0, v1, p4, v2, v3}, Lns;->lll(JLjava/lang/String;J)V

    const-wide v0, -0xc7a387a0c56e39L

    .line 113
    invoke-static {v0, v1, p5, p6}, Lw280;->oO(JLjava/lang/String;Ljava/lang/String;)V

    .line 114
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 115
    iput-object p1, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->source:Ljava/lang/String;

    .line 116
    iput-object p2, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->channel:Ljava/lang/String;

    .line 117
    iput-object p3, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->keyword:Ljava/lang/String;

    .line 118
    iput-object p4, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->title:Ljava/lang/String;

    .line 119
    iput-object p5, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->topic:Ljava/lang/String;

    .line 120
    iput-object p6, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->color:Ljava/lang/String;

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 2

    and-int/lit8 p8, p7, 0x1

    if-eqz p8, :cond_0

    const-wide v0, -0xc7a38da0c56e39L

    .line 122
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    move-result-object p1

    :cond_0
    and-int/lit8 p8, p7, 0x2

    if-eqz p8, :cond_1

    const-wide v0, -0xc7a38ea0c56e39L

    .line 123
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    move-result-object p2

    :cond_1
    and-int/lit8 p8, p7, 0x4

    if-eqz p8, :cond_2

    const-wide v0, -0xc7a38fa0c56e39L

    .line 124
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    move-result-object p3

    :cond_2
    and-int/lit8 p8, p7, 0x8

    if-eqz p8, :cond_3

    const-wide v0, -0xc7a390a0c56e39L

    .line 125
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    move-result-object p4

    :cond_3
    and-int/lit8 p8, p7, 0x10

    if-eqz p8, :cond_4

    const-wide v0, -0xc7a391a0c56e39L

    .line 126
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    move-result-object p5

    :cond_4
    and-int/lit8 p7, p7, 0x20

    if-eqz p7, :cond_5

    const-wide p6, -0xc7a392a0c56e39L

    .line 127
    invoke-static {p6, p7}, Li6t0;->lO(J)Ljava/lang/String;

    move-result-object p6

    :cond_5
    move-object p7, p5

    move-object p8, p6

    move-object p5, p3

    move-object p6, p4

    move-object p3, p1

    move-object p4, p2

    move-object p2, p0

    .line 128
    invoke-direct/range {p2 .. p8}, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public static synthetic copy$default(Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;
    .locals 0

    .line 1
    and-int/lit8 p8, p7, 0x1

    .line 2
    .line 3
    if-eqz p8, :cond_0

    .line 4
    .line 5
    iget-object p1, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->source:Ljava/lang/String;

    .line 6
    .line 7
    :cond_0
    and-int/lit8 p8, p7, 0x2

    .line 8
    .line 9
    if-eqz p8, :cond_1

    .line 10
    .line 11
    iget-object p2, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->channel:Ljava/lang/String;

    .line 12
    .line 13
    :cond_1
    and-int/lit8 p8, p7, 0x4

    .line 14
    .line 15
    if-eqz p8, :cond_2

    .line 16
    .line 17
    iget-object p3, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->keyword:Ljava/lang/String;

    .line 18
    .line 19
    :cond_2
    and-int/lit8 p8, p7, 0x8

    .line 20
    .line 21
    if-eqz p8, :cond_3

    .line 22
    .line 23
    iget-object p4, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->title:Ljava/lang/String;

    .line 24
    .line 25
    :cond_3
    and-int/lit8 p8, p7, 0x10

    .line 26
    .line 27
    if-eqz p8, :cond_4

    .line 28
    .line 29
    iget-object p5, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->topic:Ljava/lang/String;

    .line 30
    .line 31
    :cond_4
    and-int/lit8 p7, p7, 0x20

    .line 32
    .line 33
    if-eqz p7, :cond_5

    .line 34
    .line 35
    iget-object p6, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->color:Ljava/lang/String;

    .line 36
    .line 37
    :cond_5
    move-object p7, p5

    .line 38
    move-object p8, p6

    .line 39
    move-object p5, p3

    .line 40
    move-object p6, p4

    .line 41
    move-object p3, p1

    .line 42
    move-object p4, p2

    .line 43
    move-object p2, p0

    .line 44
    invoke-virtual/range {p2 .. p8}, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->copy(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;

    .line 45
    .line 46
    .line 47
    move-result-object p0

    .line 48
    return-object p0
.end method

.method public static final synthetic write$Self$app(Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;Lvud;Le3e0;)V
    .locals 3
    .annotation runtime Lkotlin/jvm/JvmStatic;
    .end annotation

    .line 1
    invoke-interface {p1, p2}, Lvud;->ll(Le3e0;)Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    goto :goto_0

    .line 8
    :cond_0
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->source:Ljava/lang/String;

    .line 9
    .line 10
    const-wide v1, -0xc7a408a0c56e39L

    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    if-nez v0, :cond_1

    .line 24
    .line 25
    :goto_0
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->source:Ljava/lang/String;

    .line 26
    .line 27
    const/4 v1, 0x0

    .line 28
    invoke-interface {p1, p2, v1, v0}, Lvud;->lII(Le3e0;ILjava/lang/String;)V

    .line 29
    .line 30
    .line 31
    :cond_1
    invoke-interface {p1, p2}, Lvud;->ll(Le3e0;)Z

    .line 32
    .line 33
    .line 34
    move-result v0

    .line 35
    if-eqz v0, :cond_2

    .line 36
    .line 37
    goto :goto_1

    .line 38
    :cond_2
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->channel:Ljava/lang/String;

    .line 39
    .line 40
    const-wide v1, -0xc7a409a0c56e39L

    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 46
    .line 47
    .line 48
    move-result-object v1

    .line 49
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 50
    .line 51
    .line 52
    move-result v0

    .line 53
    if-nez v0, :cond_3

    .line 54
    .line 55
    :goto_1
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->channel:Ljava/lang/String;

    .line 56
    .line 57
    const/4 v1, 0x1

    .line 58
    invoke-interface {p1, p2, v1, v0}, Lvud;->lII(Le3e0;ILjava/lang/String;)V

    .line 59
    .line 60
    .line 61
    :cond_3
    invoke-interface {p1, p2}, Lvud;->ll(Le3e0;)Z

    .line 62
    .line 63
    .line 64
    move-result v0

    .line 65
    if-eqz v0, :cond_4

    .line 66
    .line 67
    goto :goto_2

    .line 68
    :cond_4
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->keyword:Ljava/lang/String;

    .line 69
    .line 70
    const-wide v1, -0xc7a40aa0c56e39L

    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 76
    .line 77
    .line 78
    move-result-object v1

    .line 79
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 80
    .line 81
    .line 82
    move-result v0

    .line 83
    if-nez v0, :cond_5

    .line 84
    .line 85
    :goto_2
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->keyword:Ljava/lang/String;

    .line 86
    .line 87
    const/4 v1, 0x2

    .line 88
    invoke-interface {p1, p2, v1, v0}, Lvud;->lII(Le3e0;ILjava/lang/String;)V

    .line 89
    .line 90
    .line 91
    :cond_5
    invoke-interface {p1, p2}, Lvud;->ll(Le3e0;)Z

    .line 92
    .line 93
    .line 94
    move-result v0

    .line 95
    if-eqz v0, :cond_6

    .line 96
    .line 97
    goto :goto_3

    .line 98
    :cond_6
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->title:Ljava/lang/String;

    .line 99
    .line 100
    const-wide v1, -0xc7a40ba0c56e39L

    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 106
    .line 107
    .line 108
    move-result-object v1

    .line 109
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 110
    .line 111
    .line 112
    move-result v0

    .line 113
    if-nez v0, :cond_7

    .line 114
    .line 115
    :goto_3
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->title:Ljava/lang/String;

    .line 116
    .line 117
    const/4 v1, 0x3

    .line 118
    invoke-interface {p1, p2, v1, v0}, Lvud;->lII(Le3e0;ILjava/lang/String;)V

    .line 119
    .line 120
    .line 121
    :cond_7
    invoke-interface {p1, p2}, Lvud;->ll(Le3e0;)Z

    .line 122
    .line 123
    .line 124
    move-result v0

    .line 125
    if-eqz v0, :cond_8

    .line 126
    .line 127
    goto :goto_4

    .line 128
    :cond_8
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->topic:Ljava/lang/String;

    .line 129
    .line 130
    const-wide v1, -0xc7a40ca0c56e39L

    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 136
    .line 137
    .line 138
    move-result-object v1

    .line 139
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 140
    .line 141
    .line 142
    move-result v0

    .line 143
    if-nez v0, :cond_9

    .line 144
    .line 145
    :goto_4
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->topic:Ljava/lang/String;

    .line 146
    .line 147
    const/4 v1, 0x4

    .line 148
    invoke-interface {p1, p2, v1, v0}, Lvud;->lII(Le3e0;ILjava/lang/String;)V

    .line 149
    .line 150
    .line 151
    :cond_9
    invoke-interface {p1, p2}, Lvud;->ll(Le3e0;)Z

    .line 152
    .line 153
    .line 154
    move-result v0

    .line 155
    if-eqz v0, :cond_a

    .line 156
    .line 157
    goto :goto_5

    .line 158
    :cond_a
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->color:Ljava/lang/String;

    .line 159
    .line 160
    const-wide v1, -0xc7a40da0c56e39L

    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 166
    .line 167
    .line 168
    move-result-object v1

    .line 169
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 170
    .line 171
    .line 172
    move-result v0

    .line 173
    if-nez v0, :cond_b

    .line 174
    .line 175
    :goto_5
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->color:Ljava/lang/String;

    .line 176
    .line 177
    const/4 v0, 0x5

    .line 178
    invoke-interface {p1, p2, v0, p0}, Lvud;->lII(Le3e0;ILjava/lang/String;)V

    .line 179
    .line 180
    .line 181
    :cond_b
    return-void
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->source:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public final component2()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->channel:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public final component3()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->keyword:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public final component4()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->title:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public final component5()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->topic:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public final component6()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->color:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public final copy(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;
    .locals 4

    .line 1
    const-wide v0, -0xc7a393a0c56e39L    # -6.68238127409063E304

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    const-wide v2, -0xc7a39aa0c56e39L

    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    invoke-static {v0, v1, p1, v2, v3}, Lns;->lll(JLjava/lang/String;J)V

    .line 12
    .line 13
    .line 14
    const-wide v0, -0xc7a3a2a0c56e39L

    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    invoke-static {v0, v1, p2, p3}, Lw280;->oO(JLjava/lang/String;Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    const-wide v0, -0xc7a3aaa0c56e39L

    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    const-wide v2, -0xc7a3b0a0c56e39L

    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    invoke-static {v0, v1, p4, v2, v3}, Lns;->lll(JLjava/lang/String;J)V

    .line 33
    .line 34
    .line 35
    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 36
    .line 37
    .line 38
    const-wide v0, -0xc7a3b6a0c56e39L

    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 44
    .line 45
    .line 46
    invoke-virtual {p6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 47
    .line 48
    .line 49
    new-instance p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;

    .line 50
    .line 51
    invoke-direct/range {p0 .. p6}, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 52
    .line 53
    .line 54
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, p1, :cond_0

    .line 3
    .line 4
    return v0

    .line 5
    :cond_0
    instance-of v1, p1, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    if-nez v1, :cond_1

    .line 9
    .line 10
    return v2

    .line 11
    :cond_1
    check-cast p1, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;

    .line 12
    .line 13
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->source:Ljava/lang/String;

    .line 14
    .line 15
    iget-object v3, p1, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->source:Ljava/lang/String;

    .line 16
    .line 17
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    move-result v1

    .line 21
    if-nez v1, :cond_2

    .line 22
    .line 23
    return v2

    .line 24
    :cond_2
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->channel:Ljava/lang/String;

    .line 25
    .line 26
    iget-object v3, p1, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->channel:Ljava/lang/String;

    .line 27
    .line 28
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 29
    .line 30
    .line 31
    move-result v1

    .line 32
    if-nez v1, :cond_3

    .line 33
    .line 34
    return v2

    .line 35
    :cond_3
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->keyword:Ljava/lang/String;

    .line 36
    .line 37
    iget-object v3, p1, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->keyword:Ljava/lang/String;

    .line 38
    .line 39
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 40
    .line 41
    .line 42
    move-result v1

    .line 43
    if-nez v1, :cond_4

    .line 44
    .line 45
    return v2

    .line 46
    :cond_4
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->title:Ljava/lang/String;

    .line 47
    .line 48
    iget-object v3, p1, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->title:Ljava/lang/String;

    .line 49
    .line 50
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 51
    .line 52
    .line 53
    move-result v1

    .line 54
    if-nez v1, :cond_5

    .line 55
    .line 56
    return v2

    .line 57
    :cond_5
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->topic:Ljava/lang/String;

    .line 58
    .line 59
    iget-object v3, p1, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->topic:Ljava/lang/String;

    .line 60
    .line 61
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 62
    .line 63
    .line 64
    move-result v1

    .line 65
    if-nez v1, :cond_6

    .line 66
    .line 67
    return v2

    .line 68
    :cond_6
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->color:Ljava/lang/String;

    .line 69
    .line 70
    iget-object p1, p1, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->color:Ljava/lang/String;

    .line 71
    .line 72
    invoke-static {p0, p1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 73
    .line 74
    .line 75
    move-result p0

    .line 76
    if-nez p0, :cond_7

    .line 77
    .line 78
    return v2

    .line 79
    :cond_7
    return v0
.end method

.method public final getChannel()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->channel:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public final getColor()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->color:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public final getKeyword()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->keyword:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public final getSource()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->source:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public final getTitle()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->title:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public final getTopic()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->topic:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public hashCode()I
    .locals 3

    .line 1
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->source:Ljava/lang/String;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    const/16 v1, 0x1f

    .line 8
    .line 9
    mul-int/2addr v0, v1

    .line 10
    iget-object v2, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->channel:Ljava/lang/String;

    .line 11
    .line 12
    invoke-static {v0, v1, v2}, Lw280;->I(IILjava/lang/String;)I

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    iget-object v2, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->keyword:Ljava/lang/String;

    .line 17
    .line 18
    invoke-static {v0, v1, v2}, Lw280;->I(IILjava/lang/String;)I

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    iget-object v2, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->title:Ljava/lang/String;

    .line 23
    .line 24
    invoke-static {v0, v1, v2}, Lw280;->I(IILjava/lang/String;)I

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    iget-object v2, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->topic:Ljava/lang/String;

    .line 29
    .line 30
    invoke-static {v0, v1, v2}, Lw280;->I(IILjava/lang/String;)I

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->color:Ljava/lang/String;

    .line 35
    .line 36
    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    .line 37
    .line 38
    .line 39
    move-result p0

    .line 40
    add-int/2addr p0, v0

    .line 41
    return p0
.end method

.method public toString()Ljava/lang/String;
    .locals 4

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-wide v1, -0xc7a3bca0c56e39L

    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->source:Ljava/lang/String;

    .line 16
    .line 17
    const-wide v2, -0xc7a3d7a0c56e39L

    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    invoke-static {v2, v3, v1, v0}, Lti6;->Oo(JLjava/lang/String;Ljava/lang/StringBuilder;)V

    .line 23
    .line 24
    .line 25
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->channel:Ljava/lang/String;

    .line 26
    .line 27
    const-wide v2, -0xc7a3e2a0c56e39L

    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    invoke-static {v2, v3, v1, v0}, Lti6;->Oo(JLjava/lang/String;Ljava/lang/StringBuilder;)V

    .line 33
    .line 34
    .line 35
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->keyword:Ljava/lang/String;

    .line 36
    .line 37
    const-wide v2, -0xc7a3eda0c56e39L

    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    invoke-static {v2, v3, v1, v0}, Lti6;->Oo(JLjava/lang/String;Ljava/lang/StringBuilder;)V

    .line 43
    .line 44
    .line 45
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->title:Ljava/lang/String;

    .line 46
    .line 47
    const-wide v2, -0xc7a3f6a0c56e39L

    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    invoke-static {v2, v3, v1, v0}, Lti6;->Oo(JLjava/lang/String;Ljava/lang/StringBuilder;)V

    .line 53
    .line 54
    .line 55
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->topic:Ljava/lang/String;

    .line 56
    .line 57
    const-wide v2, -0xc7a3ffa0c56e39L

    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    invoke-static {v2, v3, v1, v0}, Lti6;->Oo(JLjava/lang/String;Ljava/lang/StringBuilder;)V

    .line 63
    .line 64
    .line 65
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/navigation/WallpaperFeedRoute;->color:Ljava/lang/String;

    .line 66
    .line 67
    const/16 v1, 0x29

    .line 68
    .line 69
    invoke-static {v1, p0, v0}, Lqhk;->IO(CLjava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 70
    .line 71
    .line 72
    move-result-object p0

    .line 73
    return-object p0
.end method
