.class public final Lcom/chuanyi/voyage/ui/navigation/I;
.super Ljava/lang/Object;
.source "S"

# interfaces
.implements Lt2l;


# static fields
.field public static volatile I:Ljo50;

.field public static final O:Ljava/util/concurrent/atomic/AtomicBoolean;

.field public static final l:Lcom/chuanyi/voyage/ui/navigation/I;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    const-wide v0, -0xc73626a0c56e39L

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    new-instance v0, Lcom/chuanyi/voyage/ui/navigation/I;

    .line 10
    .line 11
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 12
    .line 13
    .line 14
    sput-object v0, Lcom/chuanyi/voyage/ui/navigation/I;->l:Lcom/chuanyi/voyage/ui/navigation/I;

    .line 15
    .line 16
    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 17
    .line 18
    const/4 v1, 0x0

    .line 19
    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    .line 20
    .line 21
    .line 22
    sput-object v0, Lcom/chuanyi/voyage/ui/navigation/I;->O:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 23
    .line 24
    return-void
.end method

.method public static I(Landroid/content/Context;)Lcom/chuanyi/voyage/ui/navigation/NavigationScene;
    .locals 13

    .line 1
    const-wide v0, -0xc735e2a0c56e39L    # -6.799916560021871E304

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    sget-object v0, Lcom/chuanyi/voyage/ui/navigation/I;->O:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 13
    .line 14
    const/4 v1, 0x0

    .line 15
    const/4 v2, 0x1

    .line 16
    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    const/4 v3, 0x0

    .line 21
    if-nez v0, :cond_0

    .line 22
    .line 23
    goto :goto_1

    .line 24
    :cond_0
    new-instance v0, Ljava/io/File;

    .line 25
    .line 26
    invoke-virtual {p0}, Landroid/content/Context;->getNoBackupFilesDir()Ljava/io/File;

    .line 27
    .line 28
    .line 29
    move-result-object v4

    .line 30
    const-wide v5, -0xc7360fa0c56e39L

    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    invoke-static {v5, v6}, Li6t0;->lO(J)Ljava/lang/String;

    .line 36
    .line 37
    .line 38
    move-result-object v5

    .line 39
    invoke-direct {v0, v4, v5}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 40
    .line 41
    .line 42
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    .line 43
    .line 44
    .line 45
    move-result v4

    .line 46
    if-nez v4, :cond_1

    .line 47
    .line 48
    goto :goto_1

    .line 49
    :cond_1
    :try_start_0
    sget-object v4, Lpp10;->l:Lzus;

    .line 50
    .line 51
    sget-object v5, Lcom/chuanyi/voyage/ui/navigation/NavigationSceneStore$SavedScene;->Companion:Lqp10;

    .line 52
    .line 53
    invoke-virtual {v5}, Lqp10;->serializer()Ld9t;

    .line 54
    .line 55
    .line 56
    move-result-object v5

    .line 57
    check-cast v5, Lf1h;

    .line 58
    .line 59
    invoke-static {v0, v3, v2, v3}, Lurl;->readText$default(Ljava/io/File;Ljava/nio/charset/Charset;ILjava/lang/Object;)Ljava/lang/String;

    .line 60
    .line 61
    .line 62
    move-result-object v6

    .line 63
    invoke-virtual {v4, v5, v6}, Lqqs;->I(Lf1h;Ljava/lang/String;)Ljava/lang/Object;

    .line 64
    .line 65
    .line 66
    move-result-object v4

    .line 67
    check-cast v4, Lcom/chuanyi/voyage/ui/navigation/NavigationSceneStore$SavedScene;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 68
    .line 69
    goto :goto_0

    .line 70
    :catchall_0
    move-exception v4

    .line 71
    new-instance v5, Lvqb0;

    .line 72
    .line 73
    invoke-direct {v5, v4}, Lvqb0;-><init>(Ljava/lang/Throwable;)V

    .line 74
    .line 75
    .line 76
    move-object v4, v5

    .line 77
    :goto_0
    nop

    .line 78
    instance-of v5, v4, Lvqb0;

    .line 79
    .line 80
    if-eqz v5, :cond_2

    .line 81
    .line 82
    move-object v4, v3

    .line 83
    :cond_2
    check-cast v4, Lcom/chuanyi/voyage/ui/navigation/NavigationSceneStore$SavedScene;

    .line 84
    .line 85
    invoke-virtual {v0}, Ljava/io/File;->delete()Z

    .line 86
    .line 87
    .line 88
    if-nez v4, :cond_3

    .line 89
    .line 90
    goto :goto_1

    .line 91
    :cond_3
    invoke-virtual {v4}, Lcom/chuanyi/voyage/ui/navigation/NavigationSceneStore$SavedScene;->getPid()I

    .line 92
    .line 93
    .line 94
    move-result v0

    .line 95
    invoke-static {}, Landroid/os/Process;->myPid()I

    .line 96
    .line 97
    .line 98
    move-result v5

    .line 99
    if-ne v0, v5, :cond_4

    .line 100
    .line 101
    :goto_1
    return-object v3

    .line 102
    :cond_4
    invoke-virtual {v4}, Lcom/chuanyi/voyage/ui/navigation/NavigationSceneStore$SavedScene;->getSavedAtMs()J

    .line 103
    .line 104
    .line 105
    move-result-wide v5

    .line 106
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 107
    .line 108
    .line 109
    move-result-wide v7

    .line 110
    invoke-virtual {v4}, Lcom/chuanyi/voyage/ui/navigation/NavigationSceneStore$SavedScene;->getPid()I

    .line 111
    .line 112
    .line 113
    move-result v0

    .line 114
    sget v9, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 115
    .line 116
    const/16 v10, 0x1e

    .line 117
    .line 118
    if-ge v9, v10, :cond_5

    .line 119
    .line 120
    :goto_2
    move-object p0, v3

    .line 121
    goto :goto_6

    .line 122
    :cond_5
    const-class v9, Landroid/app/ActivityManager;

    .line 123
    .line 124
    invoke-virtual {p0, v9}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    .line 125
    .line 126
    .line 127
    move-result-object v9

    .line 128
    check-cast v9, Landroid/app/ActivityManager;

    .line 129
    .line 130
    if-nez v9, :cond_6

    .line 131
    .line 132
    goto :goto_2

    .line 133
    :cond_6
    :try_start_1
    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 134
    .line 135
    .line 136
    move-result-object v10

    .line 137
    invoke-virtual {v9, v10, v0, v2}, Landroid/app/ActivityManager;->getHistoricalProcessExitReasons(Ljava/lang/String;II)Ljava/util/List;

    .line 138
    .line 139
    .line 140
    move-result-object v0

    .line 141
    const-wide v9, -0xc735eaa0c56e39L

    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    invoke-static {v9, v10}, Li6t0;->lO(J)Ljava/lang/String;

    .line 147
    .line 148
    .line 149
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 150
    .line 151
    .line 152
    check-cast v0, Ljava/lang/Iterable;

    .line 153
    .line 154
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 155
    .line 156
    .line 157
    move-result-object v0

    .line 158
    :cond_7
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 159
    .line 160
    .line 161
    move-result v9

    .line 162
    if-eqz v9, :cond_8

    .line 163
    .line 164
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 165
    .line 166
    .line 167
    move-result-object v9

    .line 168
    move-object v10, v9

    .line 169
    check-cast v10, Landroid/app/ApplicationExitInfo;

    .line 170
    .line 171
    invoke-virtual {v10}, Landroid/app/ApplicationExitInfo;->getProcessName()Ljava/lang/String;

    .line 172
    .line 173
    .line 174
    move-result-object v10

    .line 175
    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 176
    .line 177
    .line 178
    move-result-object v11

    .line 179
    invoke-static {v10, v11}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 180
    .line 181
    .line 182
    move-result v10

    .line 183
    if-eqz v10, :cond_7

    .line 184
    .line 185
    goto :goto_3

    .line 186
    :catchall_1
    move-exception p0

    .line 187
    goto :goto_4

    .line 188
    :cond_8
    move-object v9, v3

    .line 189
    :goto_3
    check-cast v9, Landroid/app/ApplicationExitInfo;

    .line 190
    .line 191
    if-eqz v9, :cond_9

    .line 192
    .line 193
    invoke-virtual {v9}, Landroid/app/ApplicationExitInfo;->getTimestamp()J

    .line 194
    .line 195
    .line 196
    move-result-wide v9

    .line 197
    invoke-static {v9, v10}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 198
    .line 199
    .line 200
    move-result-object p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 201
    goto :goto_5

    .line 202
    :cond_9
    move-object p0, v3

    .line 203
    goto :goto_5

    .line 204
    :goto_4
    new-instance v0, Lvqb0;

    .line 205
    .line 206
    invoke-direct {v0, p0}, Lvqb0;-><init>(Ljava/lang/Throwable;)V

    .line 207
    .line 208
    .line 209
    move-object p0, v0

    .line 210
    :goto_5
    nop

    .line 211
    instance-of v0, p0, Lvqb0;

    .line 212
    .line 213
    if-eqz v0, :cond_a

    .line 214
    .line 215
    move-object p0, v3

    .line 216
    :cond_a
    check-cast p0, Ljava/lang/Long;

    .line 217
    .line 218
    :goto_6
    invoke-virtual {v4}, Lcom/chuanyi/voyage/ui/navigation/NavigationSceneStore$SavedScene;->getVersionCode()J

    .line 219
    .line 220
    .line 221
    move-result-wide v9

    .line 222
    const-wide/32 v11, 0xf4a75

    .line 223
    .line 224
    .line 225
    cmp-long v0, v9, v11

    .line 226
    .line 227
    if-nez v0, :cond_b

    .line 228
    .line 229
    move v0, v2

    .line 230
    goto :goto_7

    .line 231
    :cond_b
    move v0, v1

    .line 232
    :goto_7
    sget-object v9, Lpp10;->l:Lzus;

    .line 233
    .line 234
    if-nez v0, :cond_c

    .line 235
    .line 236
    goto :goto_9

    .line 237
    :cond_c
    cmp-long v0, v7, v5

    .line 238
    .line 239
    if-gez v0, :cond_d

    .line 240
    .line 241
    goto :goto_9

    .line 242
    :cond_d
    if-nez p0, :cond_e

    .line 243
    .line 244
    sub-long/2addr v7, v5

    .line 245
    const-wide/32 v5, 0x1b7740

    .line 246
    .line 247
    .line 248
    cmp-long p0, v7, v5

    .line 249
    .line 250
    if-gtz p0, :cond_10

    .line 251
    .line 252
    :goto_8
    move v1, v2

    .line 253
    goto :goto_9

    .line 254
    :cond_e
    invoke-virtual {p0}, Ljava/lang/Long;->longValue()J

    .line 255
    .line 256
    .line 257
    move-result-wide v9

    .line 258
    cmp-long v0, v9, v5

    .line 259
    .line 260
    if-ltz v0, :cond_10

    .line 261
    .line 262
    invoke-virtual {p0}, Ljava/lang/Long;->longValue()J

    .line 263
    .line 264
    .line 265
    move-result-wide v9

    .line 266
    sub-long/2addr v9, v5

    .line 267
    const-wide/32 v5, 0x927c0

    .line 268
    .line 269
    .line 270
    cmp-long v0, v9, v5

    .line 271
    .line 272
    if-lez v0, :cond_f

    .line 273
    .line 274
    goto :goto_9

    .line 275
    :cond_f
    invoke-virtual {p0}, Ljava/lang/Long;->longValue()J

    .line 276
    .line 277
    .line 278
    move-result-wide v5

    .line 279
    sub-long/2addr v7, v5

    .line 280
    const-wide/16 v5, 0x0

    .line 281
    .line 282
    cmp-long p0, v5, v7

    .line 283
    .line 284
    if-gtz p0, :cond_10

    .line 285
    .line 286
    const-wide/32 v5, 0x1b7741

    .line 287
    .line 288
    .line 289
    cmp-long p0, v7, v5

    .line 290
    .line 291
    if-gez p0, :cond_10

    .line 292
    .line 293
    goto :goto_8

    .line 294
    :cond_10
    :goto_9
    invoke-virtual {v4}, Lcom/chuanyi/voyage/ui/navigation/NavigationSceneStore$SavedScene;->getScene()Lcom/chuanyi/voyage/ui/navigation/NavigationScene;

    .line 295
    .line 296
    .line 297
    move-result-object p0

    .line 298
    if-eqz v1, :cond_11

    .line 299
    .line 300
    move-object v3, p0

    .line 301
    :cond_11
    return-object v3
.end method


# virtual methods
.method public final l(Landroid/content/Context;)Z
    .locals 7

    .line 1
    const-wide v0, -0xc735d5a0c56e39L    # -6.79997097256833E304

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    sget-object p0, Lcom/chuanyi/voyage/ui/navigation/I;->I:Ljo50;

    .line 13
    .line 14
    if-eqz p0, :cond_2

    .line 15
    .line 16
    iget-object p0, p0, Ljo50;->I:Ljava/lang/Object;

    .line 17
    .line 18
    move-object v1, p0

    .line 19
    check-cast v1, Lcom/chuanyi/voyage/ui/navigation/NavigationScene;

    .line 20
    .line 21
    if-nez v1, :cond_0

    .line 22
    .line 23
    goto :goto_0

    .line 24
    :cond_0
    new-instance v0, Lcom/chuanyi/voyage/ui/navigation/NavigationSceneStore$SavedScene;

    .line 25
    .line 26
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 27
    .line 28
    .line 29
    move-result-wide v2

    .line 30
    invoke-static {}, Landroid/os/Process;->myPid()I

    .line 31
    .line 32
    .line 33
    move-result v4

    .line 34
    const-wide/32 v5, 0xf4a75

    .line 35
    .line 36
    .line 37
    invoke-direct/range {v0 .. v6}, Lcom/chuanyi/voyage/ui/navigation/NavigationSceneStore$SavedScene;-><init>(Lcom/chuanyi/voyage/ui/navigation/NavigationScene;JIJ)V

    .line 38
    .line 39
    .line 40
    new-instance p0, Ljava/io/File;

    .line 41
    .line 42
    invoke-virtual {p1}, Landroid/content/Context;->getNoBackupFilesDir()Ljava/io/File;

    .line 43
    .line 44
    .line 45
    move-result-object p1

    .line 46
    const-wide v1, -0xc7360fa0c56e39L

    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 52
    .line 53
    .line 54
    move-result-object v1

    .line 55
    invoke-direct {p0, p1, v1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 56
    .line 57
    .line 58
    invoke-virtual {p0}, Ljava/io/File;->getParentFile()Ljava/io/File;

    .line 59
    .line 60
    .line 61
    move-result-object p1

    .line 62
    if-eqz p1, :cond_1

    .line 63
    .line 64
    invoke-virtual {p1}, Ljava/io/File;->mkdirs()Z

    .line 65
    .line 66
    .line 67
    :cond_1
    new-instance p1, Ljava/io/File;

    .line 68
    .line 69
    invoke-virtual {p0}, Ljava/io/File;->getParentFile()Ljava/io/File;

    .line 70
    .line 71
    .line 72
    move-result-object v1

    .line 73
    new-instance v2, Ljava/lang/StringBuilder;

    .line 74
    .line 75
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 76
    .line 77
    .line 78
    const-wide v3, -0xc735dda0c56e39L    # -6.799937487924355E304

    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    invoke-static {v3, v4, p0, v2}, Lok;->II(JLjava/io/File;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 84
    .line 85
    .line 86
    move-result-object v2

    .line 87
    invoke-direct {p1, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 88
    .line 89
    .line 90
    sget-object v1, Lpp10;->l:Lzus;

    .line 91
    .line 92
    sget-object v2, Lcom/chuanyi/voyage/ui/navigation/NavigationSceneStore$SavedScene;->Companion:Lqp10;

    .line 93
    .line 94
    invoke-virtual {v2}, Lqp10;->serializer()Ld9t;

    .line 95
    .line 96
    .line 97
    move-result-object v2

    .line 98
    check-cast v2, Ld9t;

    .line 99
    .line 100
    invoke-virtual {v1, v2, v0}, Lqqs;->o(Ld9t;Ljava/lang/Object;)Ljava/lang/String;

    .line 101
    .line 102
    .line 103
    move-result-object v0

    .line 104
    const/4 v1, 0x2

    .line 105
    const/4 v2, 0x0

    .line 106
    invoke-static {p1, v0, v2, v1, v2}, Lurl;->writeText$default(Ljava/io/File;Ljava/lang/String;Ljava/nio/charset/Charset;ILjava/lang/Object;)V

    .line 107
    .line 108
    .line 109
    invoke-virtual {p1, p0}, Ljava/io/File;->renameTo(Ljava/io/File;)Z

    .line 110
    .line 111
    .line 112
    move-result p0

    .line 113
    return p0

    .line 114
    :cond_2
    :goto_0
    const/4 p0, 0x1

    .line 115
    return p0
.end method
