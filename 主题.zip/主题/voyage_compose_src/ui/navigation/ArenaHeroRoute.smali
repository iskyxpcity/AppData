.class public final Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;
.super Ljava/lang/Object;
.source "S"

# interfaces
.implements Lcom/chuanyi/voyage/ui/navigation/AppRoute;


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000@\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0008\n\u0000\n\u0002\u0010\u000e\n\u0002\u0008\u0008\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\u0008\u000f\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\u0008\u000e\u0008\u0087\u0008\u0018\u0000 22\u00020\u0001:\u000234B7\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u0012\u0006\u0010\u0006\u001a\u00020\u0004\u0012\u0006\u0010\u0007\u001a\u00020\u0004\u0012\u0006\u0010\u0008\u001a\u00020\u0002\u0012\u0006\u0010\t\u001a\u00020\u0002\u00a2\u0006\u0004\u0008\n\u0010\u000bBQ\u0008\u0010\u0012\u0006\u0010\u000c\u001a\u00020\u0002\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0008\u0010\u0005\u001a\u0004\u0018\u00010\u0004\u0012\u0008\u0010\u0006\u001a\u0004\u0018\u00010\u0004\u0012\u0008\u0010\u0007\u001a\u0004\u0018\u00010\u0004\u0012\u0006\u0010\u0008\u001a\u00020\u0002\u0012\u0006\u0010\t\u001a\u00020\u0002\u0012\u0008\u0010\u000e\u001a\u0004\u0018\u00010\r\u00a2\u0006\u0004\u0008\n\u0010\u000fJ\'\u0010\u0018\u001a\u00020\u00152\u0006\u0010\u0010\u001a\u00020\u00002\u0006\u0010\u0012\u001a\u00020\u00112\u0006\u0010\u0014\u001a\u00020\u0013H\u0001\u00a2\u0006\u0004\u0008\u0016\u0010\u0017J\u0010\u0010\u0019\u001a\u00020\u0002H\u00c6\u0003\u00a2\u0006\u0004\u0008\u0019\u0010\u001aJ\u0010\u0010\u001b\u001a\u00020\u0004H\u00c6\u0003\u00a2\u0006\u0004\u0008\u001b\u0010\u001cJ\u0010\u0010\u001d\u001a\u00020\u0004H\u00c6\u0003\u00a2\u0006\u0004\u0008\u001d\u0010\u001cJ\u0010\u0010\u001e\u001a\u00020\u0004H\u00c6\u0003\u00a2\u0006\u0004\u0008\u001e\u0010\u001cJ\u0010\u0010\u001f\u001a\u00020\u0002H\u00c6\u0003\u00a2\u0006\u0004\u0008\u001f\u0010\u001aJ\u0010\u0010 \u001a\u00020\u0002H\u00c6\u0003\u00a2\u0006\u0004\u0008 \u0010\u001aJL\u0010!\u001a\u00020\u00002\u0008\u0008\u0002\u0010\u0003\u001a\u00020\u00022\u0008\u0008\u0002\u0010\u0005\u001a\u00020\u00042\u0008\u0008\u0002\u0010\u0006\u001a\u00020\u00042\u0008\u0008\u0002\u0010\u0007\u001a\u00020\u00042\u0008\u0008\u0002\u0010\u0008\u001a\u00020\u00022\u0008\u0008\u0002\u0010\t\u001a\u00020\u0002H\u00c6\u0001\u00a2\u0006\u0004\u0008!\u0010\"J\u0010\u0010#\u001a\u00020\u0004H\u00d6\u0001\u00a2\u0006\u0004\u0008#\u0010\u001cJ\u0010\u0010$\u001a\u00020\u0002H\u00d6\u0001\u00a2\u0006\u0004\u0008$\u0010\u001aJ\u001a\u0010(\u001a\u00020\'2\u0008\u0010&\u001a\u0004\u0018\u00010%H\u00d6\u0003\u00a2\u0006\u0004\u0008(\u0010)R\u0017\u0010\u0003\u001a\u00020\u00028\u0006\u00a2\u0006\u000c\n\u0004\u0008\u0003\u0010*\u001a\u0004\u0008+\u0010\u001aR\u0017\u0010\u0005\u001a\u00020\u00048\u0006\u00a2\u0006\u000c\n\u0004\u0008\u0005\u0010,\u001a\u0004\u0008-\u0010\u001cR\u0017\u0010\u0006\u001a\u00020\u00048\u0006\u00a2\u0006\u000c\n\u0004\u0008\u0006\u0010,\u001a\u0004\u0008.\u0010\u001cR\u0017\u0010\u0007\u001a\u00020\u00048\u0006\u00a2\u0006\u000c\n\u0004\u0008\u0007\u0010,\u001a\u0004\u0008/\u0010\u001cR\u0017\u0010\u0008\u001a\u00020\u00028\u0006\u00a2\u0006\u000c\n\u0004\u0008\u0008\u0010*\u001a\u0004\u00080\u0010\u001aR\u0017\u0010\t\u001a\u00020\u00028\u0006\u00a2\u0006\u000c\n\u0004\u0008\t\u0010*\u001a\u0004\u00081\u0010\u001a\u00a8\u00065"
    }
    d2 = {
        "Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/AppRoute;",
        "",
        "heroId",
        "",
        "heroName",
        "iconUrl",
        "date",
        "areaId",
        "segmentMode",
        "<init>",
        "(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;II)V",
        "seen0",
        "Lu3e0;",
        "serializationConstructorMarker",
        "(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;IILu3e0;)V",
        "self",
        "Lvud;",
        "output",
        "Le3e0;",
        "serialDesc",
        "",
        "write$Self$app",
        "(Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;Lvud;Le3e0;)V",
        "write$Self",
        "component1",
        "()I",
        "component2",
        "()Ljava/lang/String;",
        "component3",
        "component4",
        "component5",
        "component6",
        "copy",
        "(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;II)Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;",
        "toString",
        "hashCode",
        "",
        "other",
        "",
        "equals",
        "(Ljava/lang/Object;)Z",
        "I",
        "getHeroId",
        "Ljava/lang/String;",
        "getHeroName",
        "getIconUrl",
        "getDate",
        "getAreaId",
        "getSegmentMode",
        "Companion",
        "xp5",
        "yp5",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation

.annotation runtime Lq3e0;
.end annotation


# static fields
.field public static final $stable:I

.field public static final Companion:Lyp5;


# instance fields
.field private final areaId:I

.field private final date:Ljava/lang/String;

.field private final heroId:I

.field private final heroName:Ljava/lang/String;

.field private final iconUrl:Ljava/lang/String;

.field private final segmentMode:I


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, Lyp5;

    .line 2
    .line 3
    invoke-direct {v0}, Lyp5;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->Companion:Lyp5;

    .line 7
    .line 8
    return-void
.end method

.method public synthetic constructor <init>(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;IILu3e0;)V
    .locals 1

    and-int/lit8 p8, p1, 0x3f

    const/16 v0, 0x3f

    if-ne v0, p8, :cond_0

    .line 38
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p2, p0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->heroId:I

    iput-object p3, p0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->heroName:Ljava/lang/String;

    iput-object p4, p0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->iconUrl:Ljava/lang/String;

    iput-object p5, p0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->date:Ljava/lang/String;

    iput p6, p0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->areaId:I

    iput p7, p0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->segmentMode:I

    return-void

    :cond_0
    sget-object p0, Lxp5;->l:Lxp5;

    invoke-virtual {p0}, Lxp5;->getDescriptor()Le3e0;

    move-result-object p0

    invoke-static {p1, v0, p0}, Lqmu0;->lIl(IILe3e0;)V

    const/4 p0, 0x0

    throw p0
.end method

.method public constructor <init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;II)V
    .locals 4

    .line 1
    const-wide v0, -0xc712c7a0c56e39L

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    const-wide v2, -0xc712d0a0c56e39L

    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    invoke-static {v0, v1, p2, v2, v3}, Lns;->lll(JLjava/lang/String;J)V

    .line 12
    .line 13
    .line 14
    const-wide v0, -0xc712d8a0c56e39L

    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    invoke-static {v0, v1, p3, p4}, Lw280;->oO(JLjava/lang/String;Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 23
    .line 24
    .line 25
    iput p1, p0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->heroId:I

    .line 26
    .line 27
    iput-object p2, p0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->heroName:Ljava/lang/String;

    .line 28
    .line 29
    iput-object p3, p0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->iconUrl:Ljava/lang/String;

    .line 30
    .line 31
    iput-object p4, p0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->date:Ljava/lang/String;

    .line 32
    .line 33
    iput p5, p0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->areaId:I

    .line 34
    .line 35
    iput p6, p0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->segmentMode:I

    .line 36
    .line 37
    return-void
.end method

.method public static synthetic copy$default(Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;IIILjava/lang/Object;)Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;
    .locals 0

    .line 1
    and-int/lit8 p8, p7, 0x1

    .line 2
    .line 3
    if-eqz p8, :cond_0

    .line 4
    .line 5
    iget p1, p0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->heroId:I

    .line 6
    .line 7
    :cond_0
    and-int/lit8 p8, p7, 0x2

    .line 8
    .line 9
    if-eqz p8, :cond_1

    .line 10
    .line 11
    iget-object p2, p0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->heroName:Ljava/lang/String;

    .line 12
    .line 13
    :cond_1
    and-int/lit8 p8, p7, 0x4

    .line 14
    .line 15
    if-eqz p8, :cond_2

    .line 16
    .line 17
    iget-object p3, p0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->iconUrl:Ljava/lang/String;

    .line 18
    .line 19
    :cond_2
    and-int/lit8 p8, p7, 0x8

    .line 20
    .line 21
    if-eqz p8, :cond_3

    .line 22
    .line 23
    iget-object p4, p0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->date:Ljava/lang/String;

    .line 24
    .line 25
    :cond_3
    and-int/lit8 p8, p7, 0x10

    .line 26
    .line 27
    if-eqz p8, :cond_4

    .line 28
    .line 29
    iget p5, p0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->areaId:I

    .line 30
    .line 31
    :cond_4
    and-int/lit8 p7, p7, 0x20

    .line 32
    .line 33
    if-eqz p7, :cond_5

    .line 34
    .line 35
    iget p6, p0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->segmentMode:I

    .line 36
    .line 37
    :cond_5
    move p7, p5

    .line 38
    move p8, p6

    .line 39
    move-object p5, p3

    .line 40
    move-object p6, p4

    .line 41
    move p3, p1

    .line 42
    move-object p4, p2

    .line 43
    move-object p2, p0

    .line 44
    invoke-virtual/range {p2 .. p8}, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->copy(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;II)Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;

    .line 45
    .line 46
    .line 47
    move-result-object p0

    .line 48
    return-object p0
.end method

.method public static final synthetic write$Self$app(Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;Lvud;Le3e0;)V
    .locals 2
    .annotation runtime Lkotlin/jvm/JvmStatic;
    .end annotation

    .line 1
    const/4 v0, 0x0

    .line 2
    iget v1, p0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->heroId:I

    .line 3
    .line 4
    invoke-interface {p1, v0, v1, p2}, Lvud;->lOO(IILe3e0;)V

    .line 5
    .line 6
    .line 7
    const/4 v0, 0x1

    .line 8
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->heroName:Ljava/lang/String;

    .line 9
    .line 10
    invoke-interface {p1, p2, v0, v1}, Lvud;->lII(Le3e0;ILjava/lang/String;)V

    .line 11
    .line 12
    .line 13
    const/4 v0, 0x2

    .line 14
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->iconUrl:Ljava/lang/String;

    .line 15
    .line 16
    invoke-interface {p1, p2, v0, v1}, Lvud;->lII(Le3e0;ILjava/lang/String;)V

    .line 17
    .line 18
    .line 19
    const/4 v0, 0x3

    .line 20
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->date:Ljava/lang/String;

    .line 21
    .line 22
    invoke-interface {p1, p2, v0, v1}, Lvud;->lII(Le3e0;ILjava/lang/String;)V

    .line 23
    .line 24
    .line 25
    const/4 v0, 0x4

    .line 26
    iget v1, p0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->areaId:I

    .line 27
    .line 28
    invoke-interface {p1, v0, v1, p2}, Lvud;->lOO(IILe3e0;)V

    .line 29
    .line 30
    .line 31
    const/4 v0, 0x5

    .line 32
    iget p0, p0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->segmentMode:I

    .line 33
    .line 34
    invoke-interface {p1, v0, p0, p2}, Lvud;->lOO(IILe3e0;)V

    .line 35
    .line 36
    .line 37
    return-void
.end method


# virtual methods
.method public final component1()I
    .locals 0

    .line 1
    iget p0, p0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->heroId:I

    .line 2
    .line 3
    return p0
.end method

.method public final component2()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->heroName:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public final component3()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->iconUrl:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public final component4()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->date:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public final component5()I
    .locals 0

    .line 1
    iget p0, p0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->areaId:I

    .line 2
    .line 3
    return p0
.end method

.method public final component6()I
    .locals 0

    .line 1
    iget p0, p0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->segmentMode:I

    .line 2
    .line 3
    return p0
.end method

.method public final copy(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;II)Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;
    .locals 4

    .line 1
    const-wide v0, -0xc712dda0c56e39L

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    const-wide v2, -0xc712e6a0c56e39L

    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    invoke-static {v0, v1, p2, v2, v3}, Lns;->lll(JLjava/lang/String;J)V

    .line 12
    .line 13
    .line 14
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    .line 16
    .line 17
    const-wide v0, -0xc712eea0c56e39L

    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 26
    .line 27
    .line 28
    new-instance p0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;

    .line 29
    .line 30
    invoke-direct/range {p0 .. p6}, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;II)V

    .line 31
    .line 32
    .line 33
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, p1, :cond_0

    .line 3
    .line 4
    return v0

    .line 5
    :cond_0
    instance-of v1, p1, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    if-nez v1, :cond_1

    .line 9
    .line 10
    return v2

    .line 11
    :cond_1
    check-cast p1, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;

    .line 12
    .line 13
    iget v1, p0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->heroId:I

    .line 14
    .line 15
    iget v3, p1, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->heroId:I

    .line 16
    .line 17
    if-eq v1, v3, :cond_2

    .line 18
    .line 19
    return v2

    .line 20
    :cond_2
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->heroName:Ljava/lang/String;

    .line 21
    .line 22
    iget-object v3, p1, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->heroName:Ljava/lang/String;

    .line 23
    .line 24
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v1

    .line 28
    if-nez v1, :cond_3

    .line 29
    .line 30
    return v2

    .line 31
    :cond_3
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->iconUrl:Ljava/lang/String;

    .line 32
    .line 33
    iget-object v3, p1, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->iconUrl:Ljava/lang/String;

    .line 34
    .line 35
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 36
    .line 37
    .line 38
    move-result v1

    .line 39
    if-nez v1, :cond_4

    .line 40
    .line 41
    return v2

    .line 42
    :cond_4
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->date:Ljava/lang/String;

    .line 43
    .line 44
    iget-object v3, p1, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->date:Ljava/lang/String;

    .line 45
    .line 46
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 47
    .line 48
    .line 49
    move-result v1

    .line 50
    if-nez v1, :cond_5

    .line 51
    .line 52
    return v2

    .line 53
    :cond_5
    iget v1, p0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->areaId:I

    .line 54
    .line 55
    iget v3, p1, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->areaId:I

    .line 56
    .line 57
    if-eq v1, v3, :cond_6

    .line 58
    .line 59
    return v2

    .line 60
    :cond_6
    iget p0, p0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->segmentMode:I

    .line 61
    .line 62
    iget p1, p1, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->segmentMode:I

    .line 63
    .line 64
    if-eq p0, p1, :cond_7

    .line 65
    .line 66
    return v2

    .line 67
    :cond_7
    return v0
.end method

.method public final getAreaId()I
    .locals 0

    .line 1
    iget p0, p0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->areaId:I

    .line 2
    .line 3
    return p0
.end method

.method public final getDate()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->date:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public final getHeroId()I
    .locals 0

    .line 1
    iget p0, p0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->heroId:I

    .line 2
    .line 3
    return p0
.end method

.method public final getHeroName()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->heroName:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public final getIconUrl()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->iconUrl:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public final getSegmentMode()I
    .locals 0

    .line 1
    iget p0, p0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->segmentMode:I

    .line 2
    .line 3
    return p0
.end method

.method public hashCode()I
    .locals 3

    .line 1
    iget v0, p0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->heroId:I

    .line 2
    .line 3
    invoke-static {v0}, Ljava/lang/Integer;->hashCode(I)I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    const/16 v1, 0x1f

    .line 8
    .line 9
    mul-int/2addr v0, v1

    .line 10
    iget-object v2, p0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->heroName:Ljava/lang/String;

    .line 11
    .line 12
    invoke-static {v0, v1, v2}, Lw280;->I(IILjava/lang/String;)I

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    iget-object v2, p0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->iconUrl:Ljava/lang/String;

    .line 17
    .line 18
    invoke-static {v0, v1, v2}, Lw280;->I(IILjava/lang/String;)I

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    iget-object v2, p0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->date:Ljava/lang/String;

    .line 23
    .line 24
    invoke-static {v0, v1, v2}, Lw280;->I(IILjava/lang/String;)I

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    iget v2, p0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->areaId:I

    .line 29
    .line 30
    invoke-static {v2, v0, v1}, Ljs2;->o(III)I

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    iget p0, p0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->segmentMode:I

    .line 35
    .line 36
    invoke-static {p0}, Ljava/lang/Integer;->hashCode(I)I

    .line 37
    .line 38
    .line 39
    move-result p0

    .line 40
    add-int/2addr p0, v0

    .line 41
    return p0
.end method

.method public toString()Ljava/lang/String;
    .locals 4

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-wide v1, -0xc712f3a0c56e39L

    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    iget v1, p0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->heroId:I

    .line 16
    .line 17
    const-wide v2, -0xc7130aa0c56e39L

    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    invoke-static {v1, v2, v3, v0}, Lcoe;->lIl(IJLjava/lang/StringBuilder;)V

    .line 23
    .line 24
    .line 25
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->heroName:Ljava/lang/String;

    .line 26
    .line 27
    const-wide v2, -0xc71316a0c56e39L

    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    invoke-static {v2, v3, v1, v0}, Lti6;->Oo(JLjava/lang/String;Ljava/lang/StringBuilder;)V

    .line 33
    .line 34
    .line 35
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->iconUrl:Ljava/lang/String;

    .line 36
    .line 37
    const-wide v2, -0xc71321a0c56e39L

    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    invoke-static {v2, v3, v1, v0}, Lti6;->Oo(JLjava/lang/String;Ljava/lang/StringBuilder;)V

    .line 43
    .line 44
    .line 45
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->date:Ljava/lang/String;

    .line 46
    .line 47
    const-wide v2, -0xc71329a0c56e39L

    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    invoke-static {v2, v3, v1, v0}, Lti6;->Oo(JLjava/lang/String;Ljava/lang/StringBuilder;)V

    .line 53
    .line 54
    .line 55
    iget v1, p0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->areaId:I

    .line 56
    .line 57
    const-wide v2, -0xc71333a0c56e39L

    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    invoke-static {v1, v2, v3, v0}, Lcoe;->lIl(IJLjava/lang/StringBuilder;)V

    .line 63
    .line 64
    .line 65
    iget p0, p0, Lcom/chuanyi/voyage/ui/navigation/ArenaHeroRoute;->segmentMode:I

    .line 66
    .line 67
    const/16 v1, 0x29

    .line 68
    .line 69
    invoke-static {v1, p0, v0}, Lzad0;->IO(CILjava/lang/StringBuilder;)Ljava/lang/String;

    .line 70
    .line 71
    .line 72
    move-result-object p0

    .line 73
    return-object p0
.end method
