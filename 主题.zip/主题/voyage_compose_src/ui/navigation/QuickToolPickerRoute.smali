.class public final Lcom/chuanyi/voyage/ui/navigation/QuickToolPickerRoute;
.super Ljava/lang/Object;
.source "S"

# interfaces
.implements Lcom/chuanyi/voyage/ui/navigation/AppRoute;


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000B\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\u0008\u0003\n\u0002\u0010\u0008\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\u0008\u0007\n\u0002\u0010\u000e\n\u0002\u0008\u0004\n\u0002\u0010\u0000\n\u0002\u0008\t\u0008\u0087\u0008\u0018\u0000 #2\u00020\u0001:\u0002$%B\u000f\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u00a2\u0006\u0004\u0008\u0004\u0010\u0005B#\u0008\u0010\u0012\u0006\u0010\u0007\u001a\u00020\u0006\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0008\u0010\t\u001a\u0004\u0018\u00010\u0008\u00a2\u0006\u0004\u0008\u0004\u0010\nJ\'\u0010\u0013\u001a\u00020\u00102\u0006\u0010\u000b\u001a\u00020\u00002\u0006\u0010\r\u001a\u00020\u000c2\u0006\u0010\u000f\u001a\u00020\u000eH\u0001\u00a2\u0006\u0004\u0008\u0011\u0010\u0012J\u0010\u0010\u0014\u001a\u00020\u0002H\u00c6\u0003\u00a2\u0006\u0004\u0008\u0014\u0010\u0015J\u001a\u0010\u0016\u001a\u00020\u00002\u0008\u0008\u0002\u0010\u0003\u001a\u00020\u0002H\u00c6\u0001\u00a2\u0006\u0004\u0008\u0016\u0010\u0017J\u0010\u0010\u0019\u001a\u00020\u0018H\u00d6\u0001\u00a2\u0006\u0004\u0008\u0019\u0010\u001aJ\u0010\u0010\u001b\u001a\u00020\u0006H\u00d6\u0001\u00a2\u0006\u0004\u0008\u001b\u0010\u001cJ\u001a\u0010\u001f\u001a\u00020\u00022\u0008\u0010\u001e\u001a\u0004\u0018\u00010\u001dH\u00d6\u0003\u00a2\u0006\u0004\u0008\u001f\u0010 R\u0017\u0010\u0003\u001a\u00020\u00028\u0006\u00a2\u0006\u000c\n\u0004\u0008\u0003\u0010!\u001a\u0004\u0008\"\u0010\u0015\u00a8\u0006&"
    }
    d2 = {
        "Lcom/chuanyi/voyage/ui/navigation/QuickToolPickerRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/AppRoute;",
        "",
        "pin",
        "<init>",
        "(Z)V",
        "",
        "seen0",
        "Lu3e0;",
        "serializationConstructorMarker",
        "(IZLu3e0;)V",
        "self",
        "Lvud;",
        "output",
        "Le3e0;",
        "serialDesc",
        "",
        "write$Self$app",
        "(Lcom/chuanyi/voyage/ui/navigation/QuickToolPickerRoute;Lvud;Le3e0;)V",
        "write$Self",
        "component1",
        "()Z",
        "copy",
        "(Z)Lcom/chuanyi/voyage/ui/navigation/QuickToolPickerRoute;",
        "",
        "toString",
        "()Ljava/lang/String;",
        "hashCode",
        "()I",
        "",
        "other",
        "equals",
        "(Ljava/lang/Object;)Z",
        "Z",
        "getPin",
        "Companion",
        "jr90",
        "kr90",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation

.annotation runtime Lq3e0;
.end annotation


# static fields
.field public static final $stable:I

.field public static final Companion:Lkr90;


# instance fields
.field private final pin:Z


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, Lkr90;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lcom/chuanyi/voyage/ui/navigation/QuickToolPickerRoute;->Companion:Lkr90;

    .line 7
    .line 8
    return-void
.end method

.method public synthetic constructor <init>(IZLu3e0;)V
    .locals 1

    .line 1
    and-int/lit8 p3, p1, 0x1

    .line 2
    .line 3
    const/4 v0, 0x1

    .line 4
    if-ne v0, p3, :cond_0

    .line 5
    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-boolean p2, p0, Lcom/chuanyi/voyage/ui/navigation/QuickToolPickerRoute;->pin:Z

    .line 10
    .line 11
    return-void

    .line 12
    :cond_0
    sget-object p0, Ljr90;->l:Ljr90;

    .line 13
    .line 14
    invoke-virtual {p0}, Ljr90;->getDescriptor()Le3e0;

    .line 15
    .line 16
    .line 17
    move-result-object p0

    .line 18
    invoke-static {p1, v0, p0}, Lqmu0;->lIl(IILe3e0;)V

    .line 19
    .line 20
    .line 21
    const/4 p0, 0x0

    .line 22
    throw p0
.end method

.method public constructor <init>(Z)V
    .locals 0

    .line 23
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 24
    iput-boolean p1, p0, Lcom/chuanyi/voyage/ui/navigation/QuickToolPickerRoute;->pin:Z

    return-void
.end method

.method public static synthetic copy$default(Lcom/chuanyi/voyage/ui/navigation/QuickToolPickerRoute;ZILjava/lang/Object;)Lcom/chuanyi/voyage/ui/navigation/QuickToolPickerRoute;
    .locals 0

    .line 1
    and-int/lit8 p2, p2, 0x1

    .line 2
    .line 3
    if-eqz p2, :cond_0

    .line 4
    .line 5
    iget-boolean p1, p0, Lcom/chuanyi/voyage/ui/navigation/QuickToolPickerRoute;->pin:Z

    .line 6
    .line 7
    :cond_0
    invoke-virtual {p0, p1}, Lcom/chuanyi/voyage/ui/navigation/QuickToolPickerRoute;->copy(Z)Lcom/chuanyi/voyage/ui/navigation/QuickToolPickerRoute;

    .line 8
    .line 9
    .line 10
    move-result-object p0

    .line 11
    return-object p0
.end method

.method public static final synthetic write$Self$app(Lcom/chuanyi/voyage/ui/navigation/QuickToolPickerRoute;Lvud;Le3e0;)V
    .locals 1
    .annotation runtime Lkotlin/jvm/JvmStatic;
    .end annotation

    .line 1
    const/4 v0, 0x0

    .line 2
    iget-boolean p0, p0, Lcom/chuanyi/voyage/ui/navigation/QuickToolPickerRoute;->pin:Z

    .line 3
    .line 4
    invoke-interface {p1, p2, v0, p0}, Lvud;->llo(Le3e0;IZ)V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final component1()Z
    .locals 0

    .line 1
    iget-boolean p0, p0, Lcom/chuanyi/voyage/ui/navigation/QuickToolPickerRoute;->pin:Z

    .line 2
    .line 3
    return p0
.end method

.method public final copy(Z)Lcom/chuanyi/voyage/ui/navigation/QuickToolPickerRoute;
    .locals 0

    .line 1
    new-instance p0, Lcom/chuanyi/voyage/ui/navigation/QuickToolPickerRoute;

    .line 2
    .line 3
    invoke-direct {p0, p1}, Lcom/chuanyi/voyage/ui/navigation/QuickToolPickerRoute;-><init>(Z)V

    .line 4
    .line 5
    .line 6
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 3

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, p1, :cond_0

    .line 3
    .line 4
    return v0

    .line 5
    :cond_0
    instance-of v1, p1, Lcom/chuanyi/voyage/ui/navigation/QuickToolPickerRoute;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    if-nez v1, :cond_1

    .line 9
    .line 10
    return v2

    .line 11
    :cond_1
    check-cast p1, Lcom/chuanyi/voyage/ui/navigation/QuickToolPickerRoute;

    .line 12
    .line 13
    iget-boolean p0, p0, Lcom/chuanyi/voyage/ui/navigation/QuickToolPickerRoute;->pin:Z

    .line 14
    .line 15
    iget-boolean p1, p1, Lcom/chuanyi/voyage/ui/navigation/QuickToolPickerRoute;->pin:Z

    .line 16
    .line 17
    if-eq p0, p1, :cond_2

    .line 18
    .line 19
    return v2

    .line 20
    :cond_2
    return v0
.end method

.method public final getPin()Z
    .locals 0

    .line 1
    iget-boolean p0, p0, Lcom/chuanyi/voyage/ui/navigation/QuickToolPickerRoute;->pin:Z

    .line 2
    .line 3
    return p0
.end method

.method public hashCode()I
    .locals 0

    .line 1
    iget-boolean p0, p0, Lcom/chuanyi/voyage/ui/navigation/QuickToolPickerRoute;->pin:Z

    .line 2
    .line 3
    invoke-static {p0}, Ljava/lang/Boolean;->hashCode(Z)I

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public toString()Ljava/lang/String;
    .locals 3

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-wide v1, -0xc746e1a0c56e39L

    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    iget-boolean p0, p0, Lcom/chuanyi/voyage/ui/navigation/QuickToolPickerRoute;->pin:Z

    .line 16
    .line 17
    const/16 v1, 0x29

    .line 18
    .line 19
    invoke-static {v0, p0, v1}, Lzad0;->OO(Ljava/lang/StringBuilder;ZC)Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object p0

    .line 23
    return-object p0
.end method
