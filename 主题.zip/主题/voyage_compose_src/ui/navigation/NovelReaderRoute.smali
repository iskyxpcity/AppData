.class public final Lcom/chuanyi/voyage/ui/navigation/NovelReaderRoute;
.super Ljava/lang/Object;
.source "S"

# interfaces
.implements Lcom/chuanyi/voyage/ui/navigation/AppRoute;


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000@\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0008\n\u0002\u0008\u0005\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\u0008\u000c\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\u0008\u000b\u0008\u0087\u0008\u0018\u0000 )2\u00020\u0001:\u0002*+B#\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0008\u0008\u0002\u0010\u0005\u001a\u00020\u0004\u0012\u0008\u0008\u0002\u0010\u0006\u001a\u00020\u0004\u00a2\u0006\u0004\u0008\u0007\u0010\u0008B5\u0008\u0010\u0012\u0006\u0010\t\u001a\u00020\u0004\u0012\u0008\u0010\u0003\u001a\u0004\u0018\u00010\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u0012\u0006\u0010\u0006\u001a\u00020\u0004\u0012\u0008\u0010\u000b\u001a\u0004\u0018\u00010\n\u00a2\u0006\u0004\u0008\u0007\u0010\u000cJ\'\u0010\u0015\u001a\u00020\u00122\u0006\u0010\r\u001a\u00020\u00002\u0006\u0010\u000f\u001a\u00020\u000e2\u0006\u0010\u0011\u001a\u00020\u0010H\u0001\u00a2\u0006\u0004\u0008\u0013\u0010\u0014J\u0010\u0010\u0016\u001a\u00020\u0002H\u00c6\u0003\u00a2\u0006\u0004\u0008\u0016\u0010\u0017J\u0010\u0010\u0018\u001a\u00020\u0004H\u00c6\u0003\u00a2\u0006\u0004\u0008\u0018\u0010\u0019J\u0010\u0010\u001a\u001a\u00020\u0004H\u00c6\u0003\u00a2\u0006\u0004\u0008\u001a\u0010\u0019J.\u0010\u001b\u001a\u00020\u00002\u0008\u0008\u0002\u0010\u0003\u001a\u00020\u00022\u0008\u0008\u0002\u0010\u0005\u001a\u00020\u00042\u0008\u0008\u0002\u0010\u0006\u001a\u00020\u0004H\u00c6\u0001\u00a2\u0006\u0004\u0008\u001b\u0010\u001cJ\u0010\u0010\u001d\u001a\u00020\u0002H\u00d6\u0001\u00a2\u0006\u0004\u0008\u001d\u0010\u0017J\u0010\u0010\u001e\u001a\u00020\u0004H\u00d6\u0001\u00a2\u0006\u0004\u0008\u001e\u0010\u0019J\u001a\u0010\"\u001a\u00020!2\u0008\u0010 \u001a\u0004\u0018\u00010\u001fH\u00d6\u0003\u00a2\u0006\u0004\u0008\"\u0010#R\u0017\u0010\u0003\u001a\u00020\u00028\u0006\u00a2\u0006\u000c\n\u0004\u0008\u0003\u0010$\u001a\u0004\u0008%\u0010\u0017R\u0017\u0010\u0005\u001a\u00020\u00048\u0006\u00a2\u0006\u000c\n\u0004\u0008\u0005\u0010&\u001a\u0004\u0008\'\u0010\u0019R\u0017\u0010\u0006\u001a\u00020\u00048\u0006\u00a2\u0006\u000c\n\u0004\u0008\u0006\u0010&\u001a\u0004\u0008(\u0010\u0019\u00a8\u0006,"
    }
    d2 = {
        "Lcom/chuanyi/voyage/ui/navigation/NovelReaderRoute;",
        "Lcom/chuanyi/voyage/ui/navigation/AppRoute;",
        "",
        "bookUrl",
        "",
        "chapterIndex",
        "chapterPos",
        "<init>",
        "(Ljava/lang/String;II)V",
        "seen0",
        "Lu3e0;",
        "serializationConstructorMarker",
        "(ILjava/lang/String;IILu3e0;)V",
        "self",
        "Lvud;",
        "output",
        "Le3e0;",
        "serialDesc",
        "",
        "write$Self$app",
        "(Lcom/chuanyi/voyage/ui/navigation/NovelReaderRoute;Lvud;Le3e0;)V",
        "write$Self",
        "component1",
        "()Ljava/lang/String;",
        "component2",
        "()I",
        "component3",
        "copy",
        "(Ljava/lang/String;II)Lcom/chuanyi/voyage/ui/navigation/NovelReaderRoute;",
        "toString",
        "hashCode",
        "",
        "other",
        "",
        "equals",
        "(Ljava/lang/Object;)Z",
        "Ljava/lang/String;",
        "getBookUrl",
        "I",
        "getChapterIndex",
        "getChapterPos",
        "Companion",
        "qx20",
        "rx20",
        "app"
    }
    k = 0x1
    mv = {
        0x2,
        0x4,
        0x0
    }
    xi = 0x30
.end annotation

.annotation runtime Lq3e0;
.end annotation


# static fields
.field public static final $stable:I

.field public static final Companion:Lrx20;


# instance fields
.field private final bookUrl:Ljava/lang/String;

.field private final chapterIndex:I

.field private final chapterPos:I


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, Lrx20;

    .line 2
    .line 3
    invoke-direct {v0}, Lrx20;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lcom/chuanyi/voyage/ui/navigation/NovelReaderRoute;->Companion:Lrx20;

    .line 7
    .line 8
    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/String;IILu3e0;)V
    .locals 1

    .line 1
    and-int/lit8 p5, p1, 0x1

    .line 2
    .line 3
    const/4 v0, 0x1

    .line 4
    if-ne v0, p5, :cond_2

    .line 5
    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object p2, p0, Lcom/chuanyi/voyage/ui/navigation/NovelReaderRoute;->bookUrl:Ljava/lang/String;

    .line 10
    .line 11
    and-int/lit8 p2, p1, 0x2

    .line 12
    .line 13
    const/4 p5, -0x1

    .line 14
    if-nez p2, :cond_0

    .line 15
    .line 16
    iput p5, p0, Lcom/chuanyi/voyage/ui/navigation/NovelReaderRoute;->chapterIndex:I

    .line 17
    .line 18
    goto :goto_0

    .line 19
    :cond_0
    iput p3, p0, Lcom/chuanyi/voyage/ui/navigation/NovelReaderRoute;->chapterIndex:I

    .line 20
    .line 21
    :goto_0
    and-int/lit8 p1, p1, 0x4

    .line 22
    .line 23
    if-nez p1, :cond_1

    .line 24
    .line 25
    iput p5, p0, Lcom/chuanyi/voyage/ui/navigation/NovelReaderRoute;->chapterPos:I

    .line 26
    .line 27
    return-void

    .line 28
    :cond_1
    iput p4, p0, Lcom/chuanyi/voyage/ui/navigation/NovelReaderRoute;->chapterPos:I

    .line 29
    .line 30
    return-void

    .line 31
    :cond_2
    sget-object p0, Lqx20;->l:Lqx20;

    .line 32
    .line 33
    invoke-virtual {p0}, Lqx20;->getDescriptor()Le3e0;

    .line 34
    .line 35
    .line 36
    move-result-object p0

    .line 37
    invoke-static {p1, v0, p0}, Lqmu0;->lIl(IILe3e0;)V

    .line 38
    .line 39
    .line 40
    const/4 p0, 0x0

    .line 41
    throw p0
.end method

.method public constructor <init>(Ljava/lang/String;II)V
    .locals 2

    const-wide v0, -0xc73b64a0c56e39L

    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 42
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 43
    iput-object p1, p0, Lcom/chuanyi/voyage/ui/navigation/NovelReaderRoute;->bookUrl:Ljava/lang/String;

    iput p2, p0, Lcom/chuanyi/voyage/ui/navigation/NovelReaderRoute;->chapterIndex:I

    iput p3, p0, Lcom/chuanyi/voyage/ui/navigation/NovelReaderRoute;->chapterPos:I

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;IIILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 1

    and-int/lit8 p5, p4, 0x2

    const/4 v0, -0x1

    if-eqz p5, :cond_0

    move p2, v0

    :cond_0
    and-int/lit8 p4, p4, 0x4

    if-eqz p4, :cond_1

    move p3, v0

    .line 44
    :cond_1
    invoke-direct {p0, p1, p2, p3}, Lcom/chuanyi/voyage/ui/navigation/NovelReaderRoute;-><init>(Ljava/lang/String;II)V

    return-void
.end method

.method public static synthetic copy$default(Lcom/chuanyi/voyage/ui/navigation/NovelReaderRoute;Ljava/lang/String;IIILjava/lang/Object;)Lcom/chuanyi/voyage/ui/navigation/NovelReaderRoute;
    .locals 0

    .line 1
    and-int/lit8 p5, p4, 0x1

    .line 2
    .line 3
    if-eqz p5, :cond_0

    .line 4
    .line 5
    iget-object p1, p0, Lcom/chuanyi/voyage/ui/navigation/NovelReaderRoute;->bookUrl:Ljava/lang/String;

    .line 6
    .line 7
    :cond_0
    and-int/lit8 p5, p4, 0x2

    .line 8
    .line 9
    if-eqz p5, :cond_1

    .line 10
    .line 11
    iget p2, p0, Lcom/chuanyi/voyage/ui/navigation/NovelReaderRoute;->chapterIndex:I

    .line 12
    .line 13
    :cond_1
    and-int/lit8 p4, p4, 0x4

    .line 14
    .line 15
    if-eqz p4, :cond_2

    .line 16
    .line 17
    iget p3, p0, Lcom/chuanyi/voyage/ui/navigation/NovelReaderRoute;->chapterPos:I

    .line 18
    .line 19
    :cond_2
    invoke-virtual {p0, p1, p2, p3}, Lcom/chuanyi/voyage/ui/navigation/NovelReaderRoute;->copy(Ljava/lang/String;II)Lcom/chuanyi/voyage/ui/navigation/NovelReaderRoute;

    .line 20
    .line 21
    .line 22
    move-result-object p0

    .line 23
    return-object p0
.end method

.method public static final synthetic write$Self$app(Lcom/chuanyi/voyage/ui/navigation/NovelReaderRoute;Lvud;Le3e0;)V
    .locals 3
    .annotation runtime Lkotlin/jvm/JvmStatic;
    .end annotation

    .line 1
    const/4 v0, 0x0

    .line 2
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/navigation/NovelReaderRoute;->bookUrl:Ljava/lang/String;

    .line 3
    .line 4
    invoke-interface {p1, p2, v0, v1}, Lvud;->lII(Le3e0;ILjava/lang/String;)V

    .line 5
    .line 6
    .line 7
    invoke-interface {p1, p2}, Lvud;->ll(Le3e0;)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    const/4 v1, -0x1

    .line 12
    if-eqz v0, :cond_0

    .line 13
    .line 14
    goto :goto_0

    .line 15
    :cond_0
    iget v0, p0, Lcom/chuanyi/voyage/ui/navigation/NovelReaderRoute;->chapterIndex:I

    .line 16
    .line 17
    if-eq v0, v1, :cond_1

    .line 18
    .line 19
    :goto_0
    iget v0, p0, Lcom/chuanyi/voyage/ui/navigation/NovelReaderRoute;->chapterIndex:I

    .line 20
    .line 21
    const/4 v2, 0x1

    .line 22
    invoke-interface {p1, v2, v0, p2}, Lvud;->lOO(IILe3e0;)V

    .line 23
    .line 24
    .line 25
    :cond_1
    invoke-interface {p1, p2}, Lvud;->ll(Le3e0;)Z

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    if-eqz v0, :cond_2

    .line 30
    .line 31
    goto :goto_1

    .line 32
    :cond_2
    iget v0, p0, Lcom/chuanyi/voyage/ui/navigation/NovelReaderRoute;->chapterPos:I

    .line 33
    .line 34
    if-eq v0, v1, :cond_3

    .line 35
    .line 36
    :goto_1
    iget p0, p0, Lcom/chuanyi/voyage/ui/navigation/NovelReaderRoute;->chapterPos:I

    .line 37
    .line 38
    const/4 v0, 0x2

    .line 39
    invoke-interface {p1, v0, p0, p2}, Lvud;->lOO(IILe3e0;)V

    .line 40
    .line 41
    .line 42
    :cond_3
    return-void
.end method


# virtual methods
.method public final component1()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/navigation/NovelReaderRoute;->bookUrl:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public final component2()I
    .locals 0

    .line 1
    iget p0, p0, Lcom/chuanyi/voyage/ui/navigation/NovelReaderRoute;->chapterIndex:I

    .line 2
    .line 3
    return p0
.end method

.method public final component3()I
    .locals 0

    .line 1
    iget p0, p0, Lcom/chuanyi/voyage/ui/navigation/NovelReaderRoute;->chapterPos:I

    .line 2
    .line 3
    return p0
.end method

.method public final copy(Ljava/lang/String;II)Lcom/chuanyi/voyage/ui/navigation/NovelReaderRoute;
    .locals 2

    .line 1
    const-wide v0, -0xc73b6ca0c56e39L

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    new-instance p0, Lcom/chuanyi/voyage/ui/navigation/NovelReaderRoute;

    .line 13
    .line 14
    invoke-direct {p0, p1, p2, p3}, Lcom/chuanyi/voyage/ui/navigation/NovelReaderRoute;-><init>(Ljava/lang/String;II)V

    .line 15
    .line 16
    .line 17
    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, p1, :cond_0

    .line 3
    .line 4
    return v0

    .line 5
    :cond_0
    instance-of v1, p1, Lcom/chuanyi/voyage/ui/navigation/NovelReaderRoute;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    if-nez v1, :cond_1

    .line 9
    .line 10
    return v2

    .line 11
    :cond_1
    check-cast p1, Lcom/chuanyi/voyage/ui/navigation/NovelReaderRoute;

    .line 12
    .line 13
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/navigation/NovelReaderRoute;->bookUrl:Ljava/lang/String;

    .line 14
    .line 15
    iget-object v3, p1, Lcom/chuanyi/voyage/ui/navigation/NovelReaderRoute;->bookUrl:Ljava/lang/String;

    .line 16
    .line 17
    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    move-result v1

    .line 21
    if-nez v1, :cond_2

    .line 22
    .line 23
    return v2

    .line 24
    :cond_2
    iget v1, p0, Lcom/chuanyi/voyage/ui/navigation/NovelReaderRoute;->chapterIndex:I

    .line 25
    .line 26
    iget v3, p1, Lcom/chuanyi/voyage/ui/navigation/NovelReaderRoute;->chapterIndex:I

    .line 27
    .line 28
    if-eq v1, v3, :cond_3

    .line 29
    .line 30
    return v2

    .line 31
    :cond_3
    iget p0, p0, Lcom/chuanyi/voyage/ui/navigation/NovelReaderRoute;->chapterPos:I

    .line 32
    .line 33
    iget p1, p1, Lcom/chuanyi/voyage/ui/navigation/NovelReaderRoute;->chapterPos:I

    .line 34
    .line 35
    if-eq p0, p1, :cond_4

    .line 36
    .line 37
    return v2

    .line 38
    :cond_4
    return v0
.end method

.method public final getBookUrl()Ljava/lang/String;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/navigation/NovelReaderRoute;->bookUrl:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public final getChapterIndex()I
    .locals 0

    .line 1
    iget p0, p0, Lcom/chuanyi/voyage/ui/navigation/NovelReaderRoute;->chapterIndex:I

    .line 2
    .line 3
    return p0
.end method

.method public final getChapterPos()I
    .locals 0

    .line 1
    iget p0, p0, Lcom/chuanyi/voyage/ui/navigation/NovelReaderRoute;->chapterPos:I

    .line 2
    .line 3
    return p0
.end method

.method public hashCode()I
    .locals 3

    .line 1
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/navigation/NovelReaderRoute;->bookUrl:Ljava/lang/String;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    const/16 v1, 0x1f

    .line 8
    .line 9
    mul-int/2addr v0, v1

    .line 10
    iget v2, p0, Lcom/chuanyi/voyage/ui/navigation/NovelReaderRoute;->chapterIndex:I

    .line 11
    .line 12
    invoke-static {v2, v0, v1}, Ljs2;->o(III)I

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    iget p0, p0, Lcom/chuanyi/voyage/ui/navigation/NovelReaderRoute;->chapterPos:I

    .line 17
    .line 18
    invoke-static {p0}, Ljava/lang/Integer;->hashCode(I)I

    .line 19
    .line 20
    .line 21
    move-result p0

    .line 22
    add-int/2addr p0, v0

    .line 23
    return p0
.end method

.method public toString()Ljava/lang/String;
    .locals 4

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-wide v1, -0xc73b74a0c56e39L

    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/navigation/NovelReaderRoute;->bookUrl:Ljava/lang/String;

    .line 16
    .line 17
    const-wide v2, -0xc73b8ea0c56e39L

    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    invoke-static {v2, v3, v1, v0}, Lti6;->Oo(JLjava/lang/String;Ljava/lang/StringBuilder;)V

    .line 23
    .line 24
    .line 25
    iget v1, p0, Lcom/chuanyi/voyage/ui/navigation/NovelReaderRoute;->chapterIndex:I

    .line 26
    .line 27
    const-wide v2, -0xc73b9ea0c56e39L

    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    invoke-static {v1, v2, v3, v0}, Lcoe;->lIl(IJLjava/lang/StringBuilder;)V

    .line 33
    .line 34
    .line 35
    iget p0, p0, Lcom/chuanyi/voyage/ui/navigation/NovelReaderRoute;->chapterPos:I

    .line 36
    .line 37
    const/16 v1, 0x29

    .line 38
    .line 39
    invoke-static {v1, p0, v0}, Lzad0;->IO(CILjava/lang/StringBuilder;)Ljava/lang/String;

    .line 40
    .line 41
    .line 42
    move-result-object p0

    .line 43
    return-object p0
.end method
