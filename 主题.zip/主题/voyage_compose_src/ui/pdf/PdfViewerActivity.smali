.class public final Lcom/chuanyi/voyage/ui/pdf/PdfViewerActivity;
.super Lcfd;
.source "S"

# interfaces
.implements Lgmn;


# static fields
.field public static final synthetic ll:I


# instance fields
.field public final I:Ljava/lang/Object;

.field public O:Z

.field public volatile l:Lpm;

.field public final o:Lybg0;


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, Lcfd;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Ljava/lang/Object;

    .line 5
    .line 6
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, Lcom/chuanyi/voyage/ui/pdf/PdfViewerActivity;->I:Ljava/lang/Object;

    .line 10
    .line 11
    const/4 v0, 0x0

    .line 12
    iput-boolean v0, p0, Lcom/chuanyi/voyage/ui/pdf/PdfViewerActivity;->O:Z

    .line 13
    .line 14
    new-instance v0, Lbv4;

    .line 15
    .line 16
    const/4 v1, 0x6

    .line 17
    invoke-direct {v0, p0, v1}, Lbv4;-><init>(Lcfd;B)V

    .line 18
    .line 19
    .line 20
    invoke-virtual {p0, v0}, Lcfd;->addOnContextAvailableListener(Lvz30;)V

    .line 21
    .line 22
    .line 23
    const/4 v0, 0x0

    .line 24
    invoke-static {v0}, Lzbg0;->l(Ljava/lang/Object;)Lybg0;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    iput-object v0, p0, Lcom/chuanyi/voyage/ui/pdf/PdfViewerActivity;->o:Lybg0;

    .line 29
    .line 30
    return-void
.end method


# virtual methods
.method public final I()Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-virtual {p0}, Lcom/chuanyi/voyage/ui/pdf/PdfViewerActivity;->IO()Lpm;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    invoke-virtual {p0}, Lpm;->I()Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    return-object p0
.end method

.method public final II(Landroid/content/Intent;)V
    .locals 7

    .line 1
    const/4 v0, 0x0

    .line 2
    if-eqz p1, :cond_4

    .line 3
    .line 4
    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    move-result-object v1

    .line 8
    const-class v2, Landroid/net/Uri;

    .line 9
    .line 10
    const-wide v3, -0xe0be5aa0c56e39L

    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    if-eqz v1, :cond_1

    .line 16
    .line 17
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    .line 18
    .line 19
    .line 20
    move-result v5

    .line 21
    const v6, -0x45ee9a33

    .line 22
    .line 23
    .line 24
    if-eq v5, v6, :cond_0

    .line 25
    .line 26
    goto :goto_0

    .line 27
    :cond_0
    const-wide v5, -0xe0be3fa0c56e39L

    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    invoke-static {v5, v6}, Li6t0;->lO(J)Ljava/lang/String;

    .line 33
    .line 34
    .line 35
    move-result-object v5

    .line 36
    invoke-virtual {v1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 37
    .line 38
    .line 39
    move-result v1

    .line 40
    if-eqz v1, :cond_1

    .line 41
    .line 42
    invoke-static {v3, v4}, Li6t0;->lO(J)Ljava/lang/String;

    .line 43
    .line 44
    .line 45
    move-result-object v1

    .line 46
    invoke-static {p1, v1, v2}, Landroidx/core/content/IntentCompat;->getParcelableExtra(Landroid/content/Intent;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object v1

    .line 50
    check-cast v1, Landroid/net/Uri;

    .line 51
    .line 52
    if-nez v1, :cond_2

    .line 53
    .line 54
    invoke-virtual {p1}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    .line 55
    .line 56
    .line 57
    move-result-object v1

    .line 58
    goto :goto_1

    .line 59
    :cond_1
    :goto_0
    invoke-virtual {p1}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    .line 60
    .line 61
    .line 62
    move-result-object v1

    .line 63
    if-nez v1, :cond_2

    .line 64
    .line 65
    invoke-static {v3, v4}, Li6t0;->lO(J)Ljava/lang/String;

    .line 66
    .line 67
    .line 68
    move-result-object v1

    .line 69
    invoke-static {p1, v1, v2}, Landroidx/core/content/IntentCompat;->getParcelableExtra(Landroid/content/Intent;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 70
    .line 71
    .line 72
    move-result-object v1

    .line 73
    check-cast v1, Landroid/net/Uri;

    .line 74
    .line 75
    :cond_2
    :goto_1
    if-nez v1, :cond_5

    .line 76
    .line 77
    invoke-virtual {p1}, Landroid/content/Intent;->getClipData()Landroid/content/ClipData;

    .line 78
    .line 79
    .line 80
    move-result-object v1

    .line 81
    if-eqz v1, :cond_4

    .line 82
    .line 83
    invoke-virtual {v1}, Landroid/content/ClipData;->getItemCount()I

    .line 84
    .line 85
    .line 86
    move-result v2

    .line 87
    if-lez v2, :cond_3

    .line 88
    .line 89
    goto :goto_2

    .line 90
    :cond_3
    move-object v1, v0

    .line 91
    :goto_2
    if-eqz v1, :cond_4

    .line 92
    .line 93
    const/4 v2, 0x0

    .line 94
    invoke-virtual {v1, v2}, Landroid/content/ClipData;->getItemAt(I)Landroid/content/ClipData$Item;

    .line 95
    .line 96
    .line 97
    move-result-object v1

    .line 98
    if-eqz v1, :cond_4

    .line 99
    .line 100
    invoke-virtual {v1}, Landroid/content/ClipData$Item;->getUri()Landroid/net/Uri;

    .line 101
    .line 102
    .line 103
    move-result-object v1

    .line 104
    goto :goto_3

    .line 105
    :cond_4
    move-object v1, v0

    .line 106
    :cond_5
    :goto_3
    if-nez v1, :cond_7

    .line 107
    .line 108
    sget-object p0, Lsmj0;->l:Lqmj0;

    .line 109
    .line 110
    const-wide v0, -0xe0be32a0c56e39L    # -2.143499991770646E304

    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 116
    .line 117
    .line 118
    if-eqz p1, :cond_6

    .line 119
    .line 120
    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    .line 121
    .line 122
    .line 123
    :cond_6
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 124
    .line 125
    .line 126
    return-void

    .line 127
    :cond_7
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/pdf/PdfViewerActivity;->o:Lybg0;

    .line 128
    .line 129
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 130
    .line 131
    .line 132
    invoke-virtual {p0, v0, v1}, Lybg0;->Ol(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 133
    .line 134
    .line 135
    return-void
.end method

.method public final IO()Lpm;
    .locals 2

    .line 1
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/pdf/PdfViewerActivity;->l:Lpm;

    .line 2
    .line 3
    if-nez v0, :cond_1

    .line 4
    .line 5
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/pdf/PdfViewerActivity;->I:Ljava/lang/Object;

    .line 6
    .line 7
    monitor-enter v0

    .line 8
    :try_start_0
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/pdf/PdfViewerActivity;->l:Lpm;

    .line 9
    .line 10
    if-nez v1, :cond_0

    .line 11
    .line 12
    new-instance v1, Lpm;

    .line 13
    .line 14
    invoke-direct {v1, p0}, Lpm;-><init>(Landroid/app/Activity;)V

    .line 15
    .line 16
    .line 17
    iput-object v1, p0, Lcom/chuanyi/voyage/ui/pdf/PdfViewerActivity;->l:Lpm;

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :catchall_0
    move-exception p0

    .line 21
    goto :goto_1

    .line 22
    :cond_0
    :goto_0
    monitor-exit v0

    .line 23
    goto :goto_2

    .line 24
    :goto_1
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 25
    throw p0

    .line 26
    :cond_1
    :goto_2
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/pdf/PdfViewerActivity;->l:Lpm;

    .line 27
    .line 28
    return-object p0
.end method

.method public final Io(Landroid/os/Bundle;)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Lcfd;->onCreate(Landroid/os/Bundle;)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Lcom/chuanyi/voyage/ui/pdf/PdfViewerActivity;->IO()Lpm;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    invoke-virtual {p0}, Lpm;->o()V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public final attachBaseContext(Landroid/content/Context;)V
    .locals 2

    .line 1
    const-wide v0, -0xe0be23a0c56e39L

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    invoke-super {p0, p1}, Landroid/content/ContextWrapper;->attachBaseContext(Landroid/content/Context;)V

    .line 13
    .line 14
    .line 15
    sget-object p1, Lh15;->l:Lh15;

    .line 16
    .line 17
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 18
    .line 19
    .line 20
    invoke-static {p0}, Lh15;->I(Landroid/view/ContextThemeWrapper;)V

    .line 21
    .line 22
    .line 23
    return-void
.end method

.method public final getDefaultViewModelProviderFactory()Lq2n0;
    .locals 1

    .line 1
    invoke-super {p0}, Lcfd;->getDefaultViewModelProviderFactory()Lq2n0;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-static {p0, v0}, Lot8;->lIl(Lcfd;Lq2n0;)Ltfp;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    return-object p0
.end method

.method public final onCreate(Landroid/os/Bundle;)V
    .locals 3

    .line 1
    invoke-virtual {p0, p1}, Lcom/chuanyi/voyage/ui/pdf/PdfViewerActivity;->Io(Landroid/os/Bundle;)V

    .line 2
    .line 3
    .line 4
    invoke-static {p0}, Ljgj;->I(Lcfd;)V

    .line 5
    .line 6
    .line 7
    if-nez p1, :cond_0

    .line 8
    .line 9
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 10
    .line 11
    .line 12
    move-result-object p1

    .line 13
    invoke-virtual {p0, p1}, Lcom/chuanyi/voyage/ui/pdf/PdfViewerActivity;->II(Landroid/content/Intent;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    new-instance p1, Ldq60;

    .line 17
    .line 18
    const/4 v0, 0x3

    .line 19
    invoke-direct {p1, p0, v0}, Ldq60;-><init>(Ljava/lang/Object;B)V

    .line 20
    .line 21
    .line 22
    new-instance v0, Lggd;

    .line 23
    .line 24
    const v1, -0x23cb873b

    .line 25
    .line 26
    .line 27
    const/4 v2, 0x1

    .line 28
    invoke-direct {v0, p1, v1, v2}, Lggd;-><init>(Ljava/lang/Object;IZ)V

    .line 29
    .line 30
    .line 31
    invoke-static {p0, v0}, Ldfd;->l(Lcfd;Lggd;)V

    .line 32
    .line 33
    .line 34
    return-void
.end method

.method public final onDestroy()V
    .locals 0

    .line 1
    invoke-super {p0}, Landroid/app/Activity;->onDestroy()V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Lcom/chuanyi/voyage/ui/pdf/PdfViewerActivity;->IO()Lpm;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    invoke-virtual {p0}, Lpm;->l()V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public final onNewIntent(Landroid/content/Intent;)V
    .locals 2

    .line 1
    const-wide v0, -0xe0be2ba0c56e39L

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    invoke-super {p0, p1}, Lcfd;->onNewIntent(Landroid/content/Intent;)V

    .line 13
    .line 14
    .line 15
    invoke-virtual {p0, p1}, Landroid/app/Activity;->setIntent(Landroid/content/Intent;)V

    .line 16
    .line 17
    .line 18
    invoke-virtual {p0, p1}, Lcom/chuanyi/voyage/ui/pdf/PdfViewerActivity;->II(Landroid/content/Intent;)V

    .line 19
    .line 20
    .line 21
    return-void
.end method
