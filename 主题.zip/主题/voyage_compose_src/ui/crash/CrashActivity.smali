.class public final Lcom/chuanyi/voyage/ui/crash/CrashActivity;
.super Lcfd;
.source "S"


# static fields
.field public static final l:Llh8;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    const-wide v0, -0x7f5903a0c56e39L

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    const-wide v0, -0x7f5913a0c56e39L

    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 15
    .line 16
    .line 17
    const-wide v0, -0x7f5926a0c56e39L

    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    const-wide v0, -0x7f593aa0c56e39L    # -1.46163065605413E306

    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 31
    .line 32
    .line 33
    const-wide v0, -0x7f594ca0c56e39L

    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 39
    .line 40
    .line 41
    new-instance v0, Llh8;

    .line 42
    .line 43
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 44
    .line 45
    .line 46
    sput-object v0, Lcom/chuanyi/voyage/ui/crash/CrashActivity;->l:Llh8;

    .line 47
    .line 48
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Lcfd;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public final attachBaseContext(Landroid/content/Context;)V
    .locals 2

    .line 1
    const-wide v0, -0x7f5647a0c56e39L

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    invoke-super {p0, p1}, Landroid/content/ContextWrapper;->attachBaseContext(Landroid/content/Context;)V

    .line 13
    .line 14
    .line 15
    sget-object p1, Lh15;->l:Lh15;

    .line 16
    .line 17
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 18
    .line 19
    .line 20
    invoke-static {p0}, Lh15;->I(Landroid/view/ContextThemeWrapper;)V

    .line 21
    .line 22
    .line 23
    return-void
.end method

.method public final onCreate(Landroid/os/Bundle;)V
    .locals 8

    .line 1
    invoke-super {p0, p1}, Lcfd;->onCreate(Landroid/os/Bundle;)V

    .line 2
    .line 3
    .line 4
    invoke-static {p0}, Ljgj;->I(Lcfd;)V

    .line 5
    .line 6
    .line 7
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 8
    .line 9
    .line 10
    move-result-object p1

    .line 11
    const/4 v0, 0x0

    .line 12
    if-eqz p1, :cond_0

    .line 13
    .line 14
    const-wide v1, -0x7f564fa0c56e39L    # -1.46263117721609E306

    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object v1

    .line 23
    invoke-virtual {p1, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 24
    .line 25
    .line 26
    move-result-object p1

    .line 27
    goto :goto_0

    .line 28
    :cond_0
    move-object p1, v0

    .line 29
    :goto_0
    if-nez p1, :cond_1

    .line 30
    .line 31
    const-wide v1, -0x7f565fa0c56e39L

    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 37
    .line 38
    .line 39
    move-result-object p1

    .line 40
    :cond_1
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 41
    .line 42
    .line 43
    move-result-object v1

    .line 44
    if-eqz v1, :cond_2

    .line 45
    .line 46
    const-wide v2, -0x7f5660a0c56e39L

    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    invoke-static {v2, v3}, Li6t0;->lO(J)Ljava/lang/String;

    .line 52
    .line 53
    .line 54
    move-result-object v2

    .line 55
    invoke-virtual {v1, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 56
    .line 57
    .line 58
    move-result-object v1

    .line 59
    goto :goto_1

    .line 60
    :cond_2
    move-object v1, v0

    .line 61
    :goto_1
    if-nez v1, :cond_3

    .line 62
    .line 63
    const-wide v1, -0x7f5673a0c56e39L

    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 69
    .line 70
    .line 71
    move-result-object v1

    .line 72
    :cond_3
    move-object v3, v1

    .line 73
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 74
    .line 75
    .line 76
    move-result-object v1

    .line 77
    if-eqz v1, :cond_4

    .line 78
    .line 79
    const-wide v4, -0x7f5674a0c56e39L

    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    invoke-static {v4, v5}, Li6t0;->lO(J)Ljava/lang/String;

    .line 85
    .line 86
    .line 87
    move-result-object v2

    .line 88
    invoke-virtual {v1, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 89
    .line 90
    .line 91
    move-result-object v1

    .line 92
    goto :goto_2

    .line 93
    :cond_4
    move-object v1, v0

    .line 94
    :goto_2
    if-nez v1, :cond_5

    .line 95
    .line 96
    const-wide v1, -0x7f5688a0c56e39L

    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 102
    .line 103
    .line 104
    move-result-object v1

    .line 105
    :cond_5
    move-object v4, v1

    .line 106
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 107
    .line 108
    .line 109
    move-result-object v1

    .line 110
    if-eqz v1, :cond_8

    .line 111
    .line 112
    const-wide v5, -0x7f5689a0c56e39L

    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    invoke-static {v5, v6}, Li6t0;->lO(J)Ljava/lang/String;

    .line 118
    .line 119
    .line 120
    move-result-object v2

    .line 121
    invoke-virtual {v1, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 122
    .line 123
    .line 124
    move-result-object v1

    .line 125
    if-eqz v1, :cond_8

    .line 126
    .line 127
    sget-object v2, Lzue;->lo:Lkotlin/enums/EnumEntries;

    .line 128
    .line 129
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 130
    .line 131
    .line 132
    move-result-object v2

    .line 133
    :cond_6
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 134
    .line 135
    .line 136
    move-result v5

    .line 137
    if-eqz v5, :cond_7

    .line 138
    .line 139
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 140
    .line 141
    .line 142
    move-result-object v5

    .line 143
    move-object v6, v5

    .line 144
    check-cast v6, Lzue;

    .line 145
    .line 146
    invoke-virtual {v6}, Ljava/lang/Enum;->name()Ljava/lang/String;

    .line 147
    .line 148
    .line 149
    move-result-object v6

    .line 150
    invoke-static {v6, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 151
    .line 152
    .line 153
    move-result v6

    .line 154
    if-eqz v6, :cond_6

    .line 155
    .line 156
    move-object v0, v5

    .line 157
    :cond_7
    check-cast v0, Lzue;

    .line 158
    .line 159
    :cond_8
    move-object v5, v0

    .line 160
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 161
    .line 162
    .line 163
    move-result-object v0

    .line 164
    const-wide/16 v1, 0x0

    .line 165
    .line 166
    if-eqz v0, :cond_9

    .line 167
    .line 168
    const-wide v6, -0x7f569ba0c56e39L

    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    invoke-static {v6, v7}, Li6t0;->lO(J)Ljava/lang/String;

    .line 174
    .line 175
    .line 176
    move-result-object v6

    .line 177
    invoke-virtual {v0, v6, v1, v2}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    .line 178
    .line 179
    .line 180
    move-result-wide v1

    .line 181
    :cond_9
    move-wide v6, v1

    .line 182
    new-instance v2, Lcue;

    .line 183
    .line 184
    invoke-direct/range {v2 .. v7}, Lcue;-><init>(Ljava/lang/String;Ljava/lang/String;Lzue;J)V

    .line 185
    .line 186
    .line 187
    new-instance v0, Lose;

    .line 188
    .line 189
    const/4 v1, 0x0

    .line 190
    invoke-direct {v0, p1, v2, p0, v1}, Lose;-><init>(Ljava/lang/String;Lcue;Lcom/chuanyi/voyage/ui/crash/CrashActivity;B)V

    .line 191
    .line 192
    .line 193
    new-instance p1, Lggd;

    .line 194
    .line 195
    const v1, -0x6a8172a6

    .line 196
    .line 197
    .line 198
    const/4 v2, 0x1

    .line 199
    invoke-direct {p1, v0, v1, v2}, Lggd;-><init>(Ljava/lang/Object;IZ)V

    .line 200
    .line 201
    .line 202
    invoke-static {p0, p1}, Ldfd;->l(Lcfd;Lggd;)V

    .line 203
    .line 204
    .line 205
    return-void
.end method
