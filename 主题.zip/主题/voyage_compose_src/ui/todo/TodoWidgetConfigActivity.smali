.class public final Lcom/chuanyi/voyage/ui/todo/TodoWidgetConfigActivity;
.super Lcfd;
.source "S"

# interfaces
.implements Lgmn;


# static fields
.field public static final synthetic ll:I


# instance fields
.field public final I:Ljava/lang/Object;

.field public O:Z

.field public volatile l:Lpm;

.field public o:Lazj0;


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, Lcfd;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Ljava/lang/Object;

    .line 5
    .line 6
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, Lcom/chuanyi/voyage/ui/todo/TodoWidgetConfigActivity;->I:Ljava/lang/Object;

    .line 10
    .line 11
    const/4 v0, 0x0

    .line 12
    iput-boolean v0, p0, Lcom/chuanyi/voyage/ui/todo/TodoWidgetConfigActivity;->O:Z

    .line 13
    .line 14
    new-instance v0, Lbv4;

    .line 15
    .line 16
    const/16 v1, 0xa

    .line 17
    .line 18
    invoke-direct {v0, p0, v1}, Lbv4;-><init>(Lcfd;B)V

    .line 19
    .line 20
    .line 21
    invoke-virtual {p0, v0}, Lcfd;->addOnContextAvailableListener(Lvz30;)V

    .line 22
    .line 23
    .line 24
    return-void
.end method


# virtual methods
.method public final I()Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-virtual {p0}, Lcom/chuanyi/voyage/ui/todo/TodoWidgetConfigActivity;->II()Lpm;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    invoke-virtual {p0}, Lpm;->I()Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    return-object p0
.end method

.method public final II()Lpm;
    .locals 2

    .line 1
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/todo/TodoWidgetConfigActivity;->l:Lpm;

    .line 2
    .line 3
    if-nez v0, :cond_1

    .line 4
    .line 5
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/todo/TodoWidgetConfigActivity;->I:Ljava/lang/Object;

    .line 6
    .line 7
    monitor-enter v0

    .line 8
    :try_start_0
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/todo/TodoWidgetConfigActivity;->l:Lpm;

    .line 9
    .line 10
    if-nez v1, :cond_0

    .line 11
    .line 12
    new-instance v1, Lpm;

    .line 13
    .line 14
    invoke-direct {v1, p0}, Lpm;-><init>(Landroid/app/Activity;)V

    .line 15
    .line 16
    .line 17
    iput-object v1, p0, Lcom/chuanyi/voyage/ui/todo/TodoWidgetConfigActivity;->l:Lpm;

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :catchall_0
    move-exception p0

    .line 21
    goto :goto_1

    .line 22
    :cond_0
    :goto_0
    monitor-exit v0

    .line 23
    goto :goto_2

    .line 24
    :goto_1
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 25
    throw p0

    .line 26
    :cond_1
    :goto_2
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/todo/TodoWidgetConfigActivity;->l:Lpm;

    .line 27
    .line 28
    return-object p0
.end method

.method public final IO(Landroid/os/Bundle;)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Lcfd;->onCreate(Landroid/os/Bundle;)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Lcom/chuanyi/voyage/ui/todo/TodoWidgetConfigActivity;->II()Lpm;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    invoke-virtual {p0}, Lpm;->o()V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public final Io(Le4o;Lxce;)Ljava/lang/Object;
    .locals 5

    .line 1
    instance-of v0, p2, Lh2k0;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object v0, p2

    .line 6
    check-cast v0, Lh2k0;

    .line 7
    .line 8
    iget v1, v0, Lh2k0;->O:I

    .line 9
    .line 10
    const/high16 v2, -0x80000000

    .line 11
    .line 12
    and-int v3, v1, v2

    .line 13
    .line 14
    if-eqz v3, :cond_0

    .line 15
    .line 16
    sub-int/2addr v1, v2

    .line 17
    iput v1, v0, Lh2k0;->O:I

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    new-instance v0, Lh2k0;

    .line 21
    .line 22
    invoke-direct {v0, p0, p2}, Lh2k0;-><init>(Lcom/chuanyi/voyage/ui/todo/TodoWidgetConfigActivity;Lxce;)V

    .line 23
    .line 24
    .line 25
    :goto_0
    iget-object p2, v0, Lh2k0;->l:Ljava/lang/Object;

    .line 26
    .line 27
    sget-object v1, Lroe;->l:Lroe;

    .line 28
    .line 29
    iget v2, v0, Lh2k0;->O:I

    .line 30
    .line 31
    const/4 v3, 0x0

    .line 32
    const/4 v4, 0x1

    .line 33
    if-eqz v2, :cond_2

    .line 34
    .line 35
    if-ne v2, v4, :cond_1

    .line 36
    .line 37
    :try_start_0
    invoke-static {p2}, Lcp30;->IoO(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 38
    .line 39
    .line 40
    goto :goto_1

    .line 41
    :catchall_0
    move-exception p0

    .line 42
    goto/16 :goto_4

    .line 43
    .line 44
    :cond_1
    const-wide p0, -0x1126a11a0c56e39L

    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    invoke-static {p0, p1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 50
    .line 51
    .line 52
    move-result-object p0

    .line 53
    invoke-static {p0}, Lvv70;->llI(Ljava/lang/String;)V

    .line 54
    .line 55
    .line 56
    const/4 p0, 0x0

    .line 57
    return-object p0

    .line 58
    :cond_2
    invoke-static {p2}, Lcp30;->IoO(Ljava/lang/Object;)V

    .line 59
    .line 60
    .line 61
    :try_start_1
    sget-object p2, Lhg80;->l:Lhg80;

    .line 62
    .line 63
    iput v4, v0, Lh2k0;->O:I

    .line 64
    .line 65
    instance-of v2, p1, Lx85;

    .line 66
    .line 67
    if-eqz v2, :cond_7

    .line 68
    .line 69
    sget-object v2, Lo4o;->l:Lo4o;

    .line 70
    .line 71
    check-cast p1, Lx85;

    .line 72
    .line 73
    iget p1, p1, Lx85;->l:I

    .line 74
    .line 75
    invoke-static {p1}, Ly8x;->II(I)Ljava/lang/String;

    .line 76
    .line 77
    .line 78
    move-result-object p1

    .line 79
    invoke-virtual {v2, p0, p2, p1, v0}, Lo4o;->O(Landroid/content/Context;Lp4o;Ljava/lang/String;Lxce;)Ljava/lang/Object;

    .line 80
    .line 81
    .line 82
    move-result-object p2

    .line 83
    if-ne p2, v1, :cond_3

    .line 84
    .line 85
    return-object v1

    .line 86
    :cond_3
    :goto_1
    check-cast p2, Lub10;

    .line 87
    .line 88
    new-instance p0, Lo7p0;

    .line 89
    .line 90
    sget-object p1, Lh0k0;->l:Ld0k0;

    .line 91
    .line 92
    sget-object v0, Ln2k0;->I:Leg80;

    .line 93
    .line 94
    invoke-virtual {p2, v0}, Lub10;->O(Leg80;)Ljava/lang/Object;

    .line 95
    .line 96
    .line 97
    move-result-object v0

    .line 98
    check-cast v0, Ljava/lang/String;

    .line 99
    .line 100
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 101
    .line 102
    .line 103
    invoke-static {v0}, Ld0k0;->l(Ljava/lang/String;)Lh0k0;

    .line 104
    .line 105
    .line 106
    move-result-object p1

    .line 107
    if-nez p1, :cond_4

    .line 108
    .line 109
    sget-object p1, Ld0k0;->I:Lf0k0;

    .line 110
    .line 111
    :cond_4
    sget-object v0, Ln2k0;->O:Leg80;

    .line 112
    .line 113
    invoke-virtual {p2, v0}, Lub10;->O(Leg80;)Ljava/lang/Object;

    .line 114
    .line 115
    .line 116
    move-result-object v0

    .line 117
    check-cast v0, Ljava/lang/Boolean;

    .line 118
    .line 119
    if-eqz v0, :cond_5

    .line 120
    .line 121
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 122
    .line 123
    .line 124
    move-result v0

    .line 125
    goto :goto_2

    .line 126
    :cond_5
    move v0, v3

    .line 127
    :goto_2
    sget-object v1, Ln2k0;->o:Leg80;

    .line 128
    .line 129
    invoke-virtual {p2, v1}, Lub10;->O(Leg80;)Ljava/lang/Object;

    .line 130
    .line 131
    .line 132
    move-result-object p2

    .line 133
    check-cast p2, Ljava/lang/Boolean;

    .line 134
    .line 135
    if-eqz p2, :cond_6

    .line 136
    .line 137
    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    .line 138
    .line 139
    .line 140
    move-result p2

    .line 141
    goto :goto_3

    .line 142
    :cond_6
    move p2, v4

    .line 143
    :goto_3
    invoke-direct {p0, p1, v0, p2}, Lo7p0;-><init>(Lh0k0;ZZ)V

    .line 144
    .line 145
    .line 146
    goto :goto_5

    .line 147
    :cond_7
    const-string p0, "The glance ID is not the one of an App Widget"

    .line 148
    .line 149
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 150
    .line 151
    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 152
    .line 153
    .line 154
    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 155
    :goto_4
    new-instance p1, Lvqb0;

    .line 156
    .line 157
    invoke-direct {p1, p0}, Lvqb0;-><init>(Ljava/lang/Throwable;)V

    .line 158
    .line 159
    .line 160
    move-object p0, p1

    .line 161
    :goto_5
    new-instance p1, Lo7p0;

    .line 162
    .line 163
    sget-object p2, Lh0k0;->l:Ld0k0;

    .line 164
    .line 165
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 166
    .line 167
    .line 168
    sget-object p2, Ld0k0;->I:Lf0k0;

    .line 169
    .line 170
    invoke-direct {p1, p2, v3, v4}, Lo7p0;-><init>(Lh0k0;ZZ)V

    .line 171
    .line 172
    .line 173
    instance-of p2, p0, Lvqb0;

    .line 174
    .line 175
    if-eqz p2, :cond_8

    .line 176
    .line 177
    move-object p0, p1

    .line 178
    :cond_8
    return-object p0
.end method

.method public final attachBaseContext(Landroid/content/Context;)V
    .locals 2

    .line 1
    const-wide v0, -0x11269f1a0c56e39L

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    invoke-super {p0, p1}, Landroid/content/ContextWrapper;->attachBaseContext(Landroid/content/Context;)V

    .line 13
    .line 14
    .line 15
    sget-object p1, Lh15;->l:Lh15;

    .line 16
    .line 17
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 18
    .line 19
    .line 20
    invoke-static {p0}, Lh15;->I(Landroid/view/ContextThemeWrapper;)V

    .line 21
    .line 22
    .line 23
    return-void
.end method

.method public final getDefaultViewModelProviderFactory()Lq2n0;
    .locals 1

    .line 1
    invoke-super {p0}, Lcfd;->getDefaultViewModelProviderFactory()Lq2n0;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-static {p0, v0}, Lot8;->lIl(Lcfd;Lq2n0;)Ltfp;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    return-object p0
.end method

.method public final onCreate(Landroid/os/Bundle;)V
    .locals 4

    .line 1
    invoke-virtual {p0, p1}, Lcom/chuanyi/voyage/ui/todo/TodoWidgetConfigActivity;->IO(Landroid/os/Bundle;)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    invoke-virtual {p1}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    const/4 v0, 0x0

    .line 13
    if-eqz p1, :cond_0

    .line 14
    .line 15
    const-wide v1, -0x11269f9a0c56e39L

    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object v1

    .line 24
    invoke-virtual {p1, v1, v0}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    .line 25
    .line 26
    .line 27
    move-result p1

    .line 28
    goto :goto_0

    .line 29
    :cond_0
    move p1, v0

    .line 30
    :goto_0
    new-instance v1, Landroid/content/Intent;

    .line 31
    .line 32
    invoke-direct {v1}, Landroid/content/Intent;-><init>()V

    .line 33
    .line 34
    .line 35
    const-wide v2, -0x1126a05a0c56e39L

    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    invoke-static {v2, v3}, Li6t0;->lO(J)Ljava/lang/String;

    .line 41
    .line 42
    .line 43
    move-result-object v2

    .line 44
    invoke-virtual {v1, v2, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 45
    .line 46
    .line 47
    move-result-object v1

    .line 48
    invoke-virtual {p0, v0, v1}, Landroid/app/Activity;->setResult(ILandroid/content/Intent;)V

    .line 49
    .line 50
    .line 51
    :try_start_0
    new-instance v0, Lz3o;

    .line 52
    .line 53
    invoke-direct {v0, p0}, Lz3o;-><init>(Landroid/content/Context;)V

    .line 54
    .line 55
    .line 56
    iget-object v0, v0, Lz3o;->I:Landroid/appwidget/AppWidgetManager;

    .line 57
    .line 58
    invoke-virtual {v0, p1}, Landroid/appwidget/AppWidgetManager;->getAppWidgetInfo(I)Landroid/appwidget/AppWidgetProviderInfo;

    .line 59
    .line 60
    .line 61
    move-result-object v0

    .line 62
    if-eqz v0, :cond_1

    .line 63
    .line 64
    new-instance v0, Lx85;

    .line 65
    .line 66
    invoke-direct {v0, p1}, Lx85;-><init>(I)V

    .line 67
    .line 68
    .line 69
    goto :goto_1

    .line 70
    :cond_1
    const-string v0, "Invalid AppWidget ID."

    .line 71
    .line 72
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 73
    .line 74
    invoke-direct {v1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 75
    .line 76
    .line 77
    throw v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 78
    :catchall_0
    move-exception v0

    .line 79
    new-instance v1, Lvqb0;

    .line 80
    .line 81
    invoke-direct {v1, v0}, Lvqb0;-><init>(Ljava/lang/Throwable;)V

    .line 82
    .line 83
    .line 84
    move-object v0, v1

    .line 85
    :goto_1
    nop

    .line 86
    instance-of v1, v0, Lvqb0;

    .line 87
    .line 88
    if-eqz v1, :cond_2

    .line 89
    .line 90
    const/4 v0, 0x0

    .line 91
    :cond_2
    check-cast v0, Le4o;

    .line 92
    .line 93
    if-eqz p1, :cond_4

    .line 94
    .line 95
    if-nez v0, :cond_3

    .line 96
    .line 97
    goto :goto_2

    .line 98
    :cond_3
    invoke-static {p0}, Ljgj;->I(Lcfd;)V

    .line 99
    .line 100
    .line 101
    new-instance v1, Lp0e0;

    .line 102
    .line 103
    const/16 v2, 0x15

    .line 104
    .line 105
    invoke-direct {v1, p0, v0, p1, v2}, Lp0e0;-><init>(Ljava/lang/Object;Ljava/lang/Object;IB)V

    .line 106
    .line 107
    .line 108
    new-instance p1, Lggd;

    .line 109
    .line 110
    const v0, -0x45c3cf5d

    .line 111
    .line 112
    .line 113
    const/4 v2, 0x1

    .line 114
    invoke-direct {p1, v1, v0, v2}, Lggd;-><init>(Ljava/lang/Object;IZ)V

    .line 115
    .line 116
    .line 117
    invoke-static {p0, p1}, Ldfd;->l(Lcfd;Lggd;)V

    .line 118
    .line 119
    .line 120
    return-void

    .line 121
    :cond_4
    :goto_2
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    .line 122
    .line 123
    .line 124
    return-void
.end method

.method public final onDestroy()V
    .locals 0

    .line 1
    invoke-super {p0}, Landroid/app/Activity;->onDestroy()V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Lcom/chuanyi/voyage/ui/todo/TodoWidgetConfigActivity;->II()Lpm;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    invoke-virtual {p0}, Lpm;->l()V

    .line 9
    .line 10
    .line 11
    return-void
.end method
