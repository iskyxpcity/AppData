.class public final Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;
.super Lcfd;
.source "S"

# interfaces
.implements Lumo0;
.implements Lgmn;


# static fields
.field public static final f:B


# instance fields
.field public final I:Ljava/lang/Object;

.field public final II:Lkc10;

.field public final IO:Lkc10;

.field public final Il:Lkc10;

.field public final Io:Ldie0;

.field public O:Z

.field public Ol:Landroid/graphics/Bitmap;

.field public Oo:J

.field public volatile l:Lpm;

.field public final lI:Lkc10;

.field public final lO:Lkc10;

.field public ll:Llki;

.field public final lo:Lkc10;

.field public o:Lnno0;

.field public oI:Lkotlin/jvm/functions/Function2;

.field public final oO:Ldn;

.field public ol:Lkotlin/jvm/functions/Function1;

.field public final oo:Ldn;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    const-wide v0, -0x12f8b65a0c56e39L

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    const-wide v0, -0x12f8b70a0c56e39L    # -7.05280366947346E302

    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 15
    .line 16
    .line 17
    const/16 v0, 0x8

    .line 18
    .line 19
    sput-byte v0, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->f:B

    .line 20
    .line 21
    return-void
.end method

.method public constructor <init>()V
    .locals 4

    .line 1
    invoke-direct {p0}, Lcfd;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Ljava/lang/Object;

    .line 5
    .line 6
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->I:Ljava/lang/Object;

    .line 10
    .line 11
    const/4 v0, 0x0

    .line 12
    iput-boolean v0, p0, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->O:Z

    .line 13
    .line 14
    new-instance v1, Lbv4;

    .line 15
    .line 16
    const/16 v2, 0xb

    .line 17
    .line 18
    invoke-direct {v1, p0, v2}, Lbv4;-><init>(Lcfd;B)V

    .line 19
    .line 20
    .line 21
    invoke-virtual {p0, v1}, Lcfd;->addOnContextAvailableListener(Lvz30;)V

    .line 22
    .line 23
    .line 24
    const/4 v1, 0x0

    .line 25
    invoke-static {v1}, Landroidx/compose/runtime/lI;->lI(Ljava/lang/Object;)Lkc10;

    .line 26
    .line 27
    .line 28
    move-result-object v2

    .line 29
    iput-object v2, p0, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->lI:Lkc10;

    .line 30
    .line 31
    invoke-static {v1}, Landroidx/compose/runtime/lI;->lI(Ljava/lang/Object;)Lkc10;

    .line 32
    .line 33
    .line 34
    move-result-object v2

    .line 35
    iput-object v2, p0, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->lO:Lkc10;

    .line 36
    .line 37
    new-instance v2, Lioo0;

    .line 38
    .line 39
    const/16 v3, 0xfff

    .line 40
    .line 41
    invoke-direct {v2, v0, v3}, Lioo0;-><init>(ZI)V

    .line 42
    .line 43
    .line 44
    invoke-static {v2}, Landroidx/compose/runtime/lI;->lI(Ljava/lang/Object;)Lkc10;

    .line 45
    .line 46
    .line 47
    move-result-object v2

    .line 48
    iput-object v2, p0, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->lo:Lkc10;

    .line 49
    .line 50
    invoke-static {v1}, Landroidx/compose/runtime/lI;->lI(Ljava/lang/Object;)Lkc10;

    .line 51
    .line 52
    .line 53
    move-result-object v2

    .line 54
    iput-object v2, p0, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->Il:Lkc10;

    .line 55
    .line 56
    invoke-static {v1}, Landroidx/compose/runtime/lI;->lI(Ljava/lang/Object;)Lkc10;

    .line 57
    .line 58
    .line 59
    move-result-object v2

    .line 60
    iput-object v2, p0, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->II:Lkc10;

    .line 61
    .line 62
    sget-object v2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 63
    .line 64
    invoke-static {v2}, Landroidx/compose/runtime/lI;->lI(Ljava/lang/Object;)Lkc10;

    .line 65
    .line 66
    .line 67
    move-result-object v2

    .line 68
    iput-object v2, p0, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->IO:Lkc10;

    .line 69
    .line 70
    const/4 v2, 0x4

    .line 71
    const/4 v3, 0x5

    .line 72
    invoke-static {v0, v2, v1, v3}, Lw6b0;->I(IILwx9;I)Ldie0;

    .line 73
    .line 74
    .line 75
    move-result-object v1

    .line 76
    iput-object v1, p0, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->Io:Ldie0;

    .line 77
    .line 78
    new-instance v1, Lvm;

    .line 79
    .line 80
    const/4 v2, 0x7

    .line 81
    invoke-direct {v1, v2}, Lvm;-><init>(B)V

    .line 82
    .line 83
    .line 84
    new-instance v2, Lllo0;

    .line 85
    .line 86
    invoke-direct {v2, p0, v0}, Lllo0;-><init>(Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;B)V

    .line 87
    .line 88
    .line 89
    invoke-virtual {p0, v1, v2}, Lcfd;->registerForActivityResult(Lum;Ltm;)Ldn;

    .line 90
    .line 91
    .line 92
    move-result-object v0

    .line 93
    iput-object v0, p0, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->oO:Ldn;

    .line 94
    .line 95
    new-instance v0, Lvm;

    .line 96
    .line 97
    const/16 v1, 0x9

    .line 98
    .line 99
    invoke-direct {v0, v1}, Lvm;-><init>(B)V

    .line 100
    .line 101
    .line 102
    new-instance v1, Lllo0;

    .line 103
    .line 104
    const/4 v2, 0x1

    .line 105
    invoke-direct {v1, p0, v2}, Lllo0;-><init>(Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;B)V

    .line 106
    .line 107
    .line 108
    invoke-virtual {p0, v0, v1}, Lcfd;->registerForActivityResult(Lum;Ltm;)Ldn;

    .line 109
    .line 110
    .line 111
    move-result-object v0

    .line 112
    iput-object v0, p0, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->oo:Ldn;

    .line 113
    .line 114
    return-void
.end method

.method public static oo(Landroid/content/Intent;)Ljava/lang/String;
    .locals 6

    .line 1
    const/4 v0, 0x0

    .line 2
    if-eqz p0, :cond_1

    .line 3
    .line 4
    const-wide v1, -0x12f88e6a0c56e39L

    .line 5
    .line 6
    .line 7
    .line 8
    .line 9
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    invoke-virtual {p0, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    if-eqz p0, :cond_1

    .line 18
    .line 19
    const-wide v1, -0x12f8900a0c56e39L    # -7.05688461045786E302

    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    invoke-static {v1, v2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 25
    .line 26
    .line 27
    move-result-object v1

    .line 28
    const/4 v2, 0x0

    .line 29
    const/4 v3, 0x2

    .line 30
    invoke-static {p0, v1, v2, v3, v0}, Lfgh0;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    .line 31
    .line 32
    .line 33
    move-result v1

    .line 34
    if-nez v1, :cond_0

    .line 35
    .line 36
    const-wide v4, -0x12f8908a0c56e39L    # -7.05683229070165E302

    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    invoke-static {v4, v5}, Li6t0;->lO(J)Ljava/lang/String;

    .line 42
    .line 43
    .line 44
    move-result-object v1

    .line 45
    invoke-static {p0, v1, v2, v3, v0}, Lfgh0;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    .line 46
    .line 47
    .line 48
    move-result v1

    .line 49
    if-eqz v1, :cond_1

    .line 50
    .line 51
    :cond_0
    return-object p0

    .line 52
    :cond_1
    return-object v0
.end method


# virtual methods
.method public final I()Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-virtual {p0}, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->II()Lpm;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    invoke-virtual {p0}, Lpm;->I()Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    return-object p0
.end method

.method public final II()Lpm;
    .locals 2

    .line 1
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->l:Lpm;

    .line 2
    .line 3
    if-nez v0, :cond_1

    .line 4
    .line 5
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->I:Ljava/lang/Object;

    .line 6
    .line 7
    monitor-enter v0

    .line 8
    :try_start_0
    iget-object v1, p0, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->l:Lpm;

    .line 9
    .line 10
    if-nez v1, :cond_0

    .line 11
    .line 12
    new-instance v1, Lpm;

    .line 13
    .line 14
    invoke-direct {v1, p0}, Lpm;-><init>(Landroid/app/Activity;)V

    .line 15
    .line 16
    .line 17
    iput-object v1, p0, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->l:Lpm;

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :catchall_0
    move-exception p0

    .line 21
    goto :goto_1

    .line 22
    :cond_0
    :goto_0
    monitor-exit v0

    .line 23
    goto :goto_2

    .line 24
    :goto_1
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 25
    throw p0

    .line 26
    :cond_1
    :goto_2
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->l:Lpm;

    .line 27
    .line 28
    return-object p0
.end method

.method public final IO()Lrmo0;
    .locals 0

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->lI:Lkc10;

    .line 2
    .line 3
    check-cast p0, Laif0;

    .line 4
    .line 5
    invoke-virtual {p0}, Laif0;->getValue()Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    check-cast p0, Lrmo0;

    .line 10
    .line 11
    return-object p0
.end method

.method public final Io()Lnno0;
    .locals 2

    .line 1
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->o:Lnno0;

    .line 2
    .line 3
    if-eqz p0, :cond_0

    .line 4
    .line 5
    return-object p0

    .line 6
    :cond_0
    const-wide v0, -0x12f87dda0c56e39L    # -7.058787741590009E302

    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 12
    .line 13
    .line 14
    move-result-object p0

    .line 15
    invoke-static {p0}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    const/4 p0, 0x0

    .line 19
    return-object p0
.end method

.method public final OI()V
    .locals 3

    .line 1
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->lO:Lkc10;

    .line 2
    .line 3
    check-cast v0, Laif0;

    .line 4
    .line 5
    invoke-virtual {v0}, Laif0;->getValue()Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    check-cast v0, Ljlo0;

    .line 10
    .line 11
    if-eqz v0, :cond_1

    .line 12
    .line 13
    iget-object v0, v0, Ljlo0;->l:Lplo0;

    .line 14
    .line 15
    if-eqz v0, :cond_1

    .line 16
    .line 17
    iget-object v0, v0, Lplo0;->I:Ljava/lang/String;

    .line 18
    .line 19
    if-nez v0, :cond_0

    .line 20
    .line 21
    goto :goto_0

    .line 22
    :cond_0
    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 23
    .line 24
    iget-object v2, p0, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->IO:Lkc10;

    .line 25
    .line 26
    check-cast v2, Laif0;

    .line 27
    .line 28
    invoke-virtual {v2, v1}, Laif0;->setValue(Ljava/lang/Object;)V

    .line 29
    .line 30
    .line 31
    new-instance v1, Lxko0;

    .line 32
    .line 33
    const/4 v2, 0x2

    .line 34
    invoke-direct {v1, p0, v2}, Lxko0;-><init>(Ljava/lang/Object;B)V

    .line 35
    .line 36
    .line 37
    invoke-static {p0, p0, v0, v1}, Lzm;->lO(Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;Ljava/lang/String;Lxko0;)V

    .line 38
    .line 39
    .line 40
    :cond_1
    :goto_0
    return-void
.end method

.method public final OO(Landroid/os/Bundle;)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Lcfd;->onCreate(Landroid/os/Bundle;)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->II()Lpm;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    invoke-virtual {p0}, Lpm;->o()V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public final Ol(Landroid/content/Intent;Lkotlin/jvm/functions/Function2;)Z
    .locals 3

    .line 1
    const-wide v0, -0x12f889aa0c56e39L

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    const-wide v0, -0x12f88a1a0c56e39L

    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 15
    .line 16
    .line 17
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->oI:Lkotlin/jvm/functions/Function2;

    .line 18
    .line 19
    const/4 v1, 0x0

    .line 20
    if-eqz v0, :cond_0

    .line 21
    .line 22
    const/4 v2, 0x0

    .line 23
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 24
    .line 25
    .line 26
    move-result-object v2

    .line 27
    invoke-interface {v0, v2, v1}, Lkotlin/jvm/functions/Function2;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    :cond_0
    iput-object p2, p0, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->oI:Lkotlin/jvm/functions/Function2;

    .line 31
    .line 32
    :try_start_0
    iget-object p2, p0, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->oo:Ldn;

    .line 33
    .line 34
    invoke-virtual {p2, p1}, Ldn;->l(Ljava/lang/Object;)V

    .line 35
    .line 36
    .line 37
    sget-object p1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 38
    .line 39
    goto :goto_0

    .line 40
    :catchall_0
    move-exception p1

    .line 41
    new-instance p2, Lvqb0;

    .line 42
    .line 43
    invoke-direct {p2, p1}, Lvqb0;-><init>(Ljava/lang/Throwable;)V

    .line 44
    .line 45
    .line 46
    move-object p1, p2

    .line 47
    :goto_0
    invoke-static {p1}, Lxqb0;->l(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 48
    .line 49
    .line 50
    move-result-object p2

    .line 51
    if-eqz p2, :cond_1

    .line 52
    .line 53
    iput-object v1, p0, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->oI:Lkotlin/jvm/functions/Function2;

    .line 54
    .line 55
    :cond_1
    instance-of p0, p1, Lvqb0;

    .line 56
    .line 57
    xor-int/lit8 p0, p0, 0x1

    .line 58
    .line 59
    return p0
.end method

.method public final Oo()V
    .locals 0

    .line 1
    invoke-super {p0}, Landroid/app/Activity;->onDestroy()V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->II()Lpm;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    invoke-virtual {p0}, Lpm;->l()V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public final attachBaseContext(Landroid/content/Context;)V
    .locals 2

    .line 1
    const-wide v0, -0x12f8802a0c56e39L

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    invoke-super {p0, p1}, Landroid/content/ContextWrapper;->attachBaseContext(Landroid/content/Context;)V

    .line 13
    .line 14
    .line 15
    sget-object p1, Lh15;->l:Lh15;

    .line 16
    .line 17
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 18
    .line 19
    .line 20
    invoke-static {p0}, Lh15;->I(Landroid/view/ContextThemeWrapper;)V

    .line 21
    .line 22
    .line 23
    return-void
.end method

.method public final getDefaultViewModelProviderFactory()Lq2n0;
    .locals 1

    .line 1
    invoke-super {p0}, Lcfd;->getDefaultViewModelProviderFactory()Lq2n0;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-static {p0, v0}, Lot8;->lIl(Lcfd;Lq2n0;)Ltfp;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    return-object p0
.end method

.method public final oI(Lzlo0;)V
    .locals 3

    .line 1
    const-wide v0, -0x12f88aaa0c56e39L    # -7.05744704783712E302

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->Il:Lkc10;

    .line 10
    .line 11
    move-object v0, p0

    .line 12
    check-cast v0, Laif0;

    .line 13
    .line 14
    invoke-virtual {v0}, Laif0;->getValue()Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    check-cast v0, Lzlo0;

    .line 19
    .line 20
    if-eqz v0, :cond_6

    .line 21
    .line 22
    instance-of v1, v0, Ltlo0;

    .line 23
    .line 24
    if-eqz v1, :cond_0

    .line 25
    .line 26
    check-cast v0, Ltlo0;

    .line 27
    .line 28
    iget-object v0, v0, Ltlo0;->I:Lr4n0;

    .line 29
    .line 30
    invoke-virtual {v0}, Lr4n0;->invoke()Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    goto :goto_0

    .line 34
    :cond_0
    instance-of v1, v0, Lvlo0;

    .line 35
    .line 36
    if-eqz v1, :cond_1

    .line 37
    .line 38
    check-cast v0, Lvlo0;

    .line 39
    .line 40
    iget-object v0, v0, Lvlo0;->I:Ljmo0;

    .line 41
    .line 42
    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 43
    .line 44
    invoke-virtual {v0, v1}, Ljmo0;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    goto :goto_0

    .line 48
    :cond_1
    instance-of v1, v0, Lylo0;

    .line 49
    .line 50
    const/4 v2, 0x0

    .line 51
    if-eqz v1, :cond_2

    .line 52
    .line 53
    check-cast v0, Lylo0;

    .line 54
    .line 55
    iget-object v0, v0, Lylo0;->O:Lxko0;

    .line 56
    .line 57
    invoke-virtual {v0, v2}, Lxko0;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    goto :goto_0

    .line 61
    :cond_2
    instance-of v1, v0, Lulo0;

    .line 62
    .line 63
    if-eqz v1, :cond_3

    .line 64
    .line 65
    check-cast v0, Lulo0;

    .line 66
    .line 67
    iget-object v0, v0, Lulo0;->I:Ljmo0;

    .line 68
    .line 69
    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 70
    .line 71
    invoke-virtual {v0, v1}, Ljmo0;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 72
    .line 73
    .line 74
    goto :goto_0

    .line 75
    :cond_3
    instance-of v1, v0, Lxlo0;

    .line 76
    .line 77
    if-eqz v1, :cond_4

    .line 78
    .line 79
    check-cast v0, Lxlo0;

    .line 80
    .line 81
    iget-object v0, v0, Lxlo0;->O:Ly7n0;

    .line 82
    .line 83
    invoke-virtual {v0, v2}, Ly7n0;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 84
    .line 85
    .line 86
    goto :goto_0

    .line 87
    :cond_4
    instance-of v1, v0, Lwlo0;

    .line 88
    .line 89
    if-eqz v1, :cond_5

    .line 90
    .line 91
    check-cast v0, Lwlo0;

    .line 92
    .line 93
    iget-object v0, v0, Lwlo0;->I:Lkmo0;

    .line 94
    .line 95
    sget-object v1, Lzmo0;->O:Lzmo0;

    .line 96
    .line 97
    invoke-virtual {v0, v1}, Lkmo0;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 98
    .line 99
    .line 100
    goto :goto_0

    .line 101
    :cond_5
    invoke-static {}, Lauc;->lI()V

    .line 102
    .line 103
    .line 104
    return-void

    .line 105
    :cond_6
    :goto_0
    check-cast p0, Laif0;

    .line 106
    .line 107
    invoke-virtual {p0, p1}, Laif0;->setValue(Ljava/lang/Object;)V

    .line 108
    .line 109
    .line 110
    return-void
.end method

.method public final oO(Ljava/lang/String;)V
    .locals 2

    .line 1
    const-wide v0, -0x12f88b1a0c56e39L

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->Io:Ldie0;

    .line 10
    .line 11
    invoke-virtual {p0, p1}, Ldie0;->o(Ljava/lang/Object;)Z

    .line 12
    .line 13
    .line 14
    return-void
.end method

.method public final ol(Ljava/lang/String;Landroid/os/Bundle;Lxce;)Ljava/lang/Object;
    .locals 11

    .line 1
    instance-of v0, p3, Lnlo0;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object v0, p3

    .line 6
    check-cast v0, Lnlo0;

    .line 7
    .line 8
    iget v1, v0, Lnlo0;->lO:I

    .line 9
    .line 10
    const/high16 v2, -0x80000000

    .line 11
    .line 12
    and-int v3, v1, v2

    .line 13
    .line 14
    if-eqz v3, :cond_0

    .line 15
    .line 16
    sub-int/2addr v1, v2

    .line 17
    iput v1, v0, Lnlo0;->lO:I

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    new-instance v0, Lnlo0;

    .line 21
    .line 22
    invoke-direct {v0, p0, p3}, Lnlo0;-><init>(Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;Lxce;)V

    .line 23
    .line 24
    .line 25
    :goto_0
    iget-object p3, v0, Lnlo0;->ll:Ljava/lang/Object;

    .line 26
    .line 27
    sget-object v1, Lroe;->l:Lroe;

    .line 28
    .line 29
    iget v2, v0, Lnlo0;->lO:I

    .line 30
    .line 31
    const/4 v3, 0x0

    .line 32
    const/4 v4, 0x4

    .line 33
    const/4 v5, 0x3

    .line 34
    const/4 v6, 0x2

    .line 35
    const/4 v7, 0x1

    .line 36
    const/4 v8, 0x0

    .line 37
    if-eqz v2, :cond_5

    .line 38
    .line 39
    if-eq v2, v7, :cond_4

    .line 40
    .line 41
    if-eq v2, v6, :cond_3

    .line 42
    .line 43
    if-eq v2, v5, :cond_2

    .line 44
    .line 45
    if-ne v2, v4, :cond_1

    .line 46
    .line 47
    iget-object p0, v0, Lnlo0;->o:Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;

    .line 48
    .line 49
    check-cast p0, Lrmo0;

    .line 50
    .line 51
    invoke-static {p3}, Lcp30;->IoO(Ljava/lang/Object;)V

    .line 52
    .line 53
    .line 54
    return-object p3

    .line 55
    :cond_1
    const-wide p0, -0x12f883aa0c56e39L

    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    invoke-static {p0, p1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 61
    .line 62
    .line 63
    move-result-object p0

    .line 64
    invoke-static {p0}, Lvv70;->llI(Ljava/lang/String;)V

    .line 65
    .line 66
    .line 67
    return-object v8

    .line 68
    :cond_2
    iget-object p1, v0, Lnlo0;->o:Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;

    .line 69
    .line 70
    check-cast p1, Lrmo0;

    .line 71
    .line 72
    invoke-static {p3}, Lcp30;->IoO(Ljava/lang/Object;)V

    .line 73
    .line 74
    .line 75
    goto/16 :goto_b

    .line 76
    .line 77
    :cond_3
    iget-object p1, v0, Lnlo0;->o:Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;

    .line 78
    .line 79
    iget-object p2, v0, Lnlo0;->O:Ljlo0;

    .line 80
    .line 81
    iget-object v2, v0, Lnlo0;->I:Landroid/os/Bundle;

    .line 82
    .line 83
    iget-object v6, v0, Lnlo0;->l:Ljava/lang/String;

    .line 84
    .line 85
    invoke-static {p3}, Lcp30;->IoO(Ljava/lang/Object;)V

    .line 86
    .line 87
    .line 88
    goto :goto_2

    .line 89
    :cond_4
    iget-object p2, v0, Lnlo0;->I:Landroid/os/Bundle;

    .line 90
    .line 91
    iget-object p1, v0, Lnlo0;->l:Ljava/lang/String;

    .line 92
    .line 93
    invoke-static {p3}, Lcp30;->IoO(Ljava/lang/Object;)V

    .line 94
    .line 95
    .line 96
    goto :goto_1

    .line 97
    :cond_5
    invoke-static {p3}, Lcp30;->IoO(Ljava/lang/Object;)V

    .line 98
    .line 99
    .line 100
    invoke-virtual {p0}, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->Io()Lnno0;

    .line 101
    .line 102
    .line 103
    move-result-object p3

    .line 104
    iput-object p1, v0, Lnlo0;->l:Ljava/lang/String;

    .line 105
    .line 106
    iput-object p2, v0, Lnlo0;->I:Landroid/os/Bundle;

    .line 107
    .line 108
    iput v7, v0, Lnlo0;->lO:I

    .line 109
    .line 110
    invoke-virtual {p3, p1, v0}, Lnno0;->lO(Ljava/lang/String;Lxce;)Ljava/lang/Object;

    .line 111
    .line 112
    .line 113
    move-result-object p3

    .line 114
    if-ne p3, v1, :cond_6

    .line 115
    .line 116
    goto/16 :goto_c

    .line 117
    .line 118
    :cond_6
    :goto_1
    check-cast p3, Ljlo0;

    .line 119
    .line 120
    if-nez p3, :cond_7

    .line 121
    .line 122
    const-wide p1, -0x12f880aa0c56e39L

    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    invoke-static {p1, p2}, Li6t0;->lO(J)Ljava/lang/String;

    .line 128
    .line 129
    .line 130
    move-result-object p1

    .line 131
    invoke-static {p0, p1, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 132
    .line 133
    .line 134
    move-result-object p1

    .line 135
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 136
    .line 137
    .line 138
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    .line 139
    .line 140
    .line 141
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 142
    .line 143
    return-object p0

    .line 144
    :cond_7
    iget-object v2, p0, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->lO:Lkc10;

    .line 145
    .line 146
    check-cast v2, Laif0;

    .line 147
    .line 148
    invoke-virtual {v2, p3}, Laif0;->setValue(Ljava/lang/Object;)V

    .line 149
    .line 150
    .line 151
    invoke-virtual {p0}, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->Io()Lnno0;

    .line 152
    .line 153
    .line 154
    move-result-object v2

    .line 155
    iput-object p1, v0, Lnlo0;->l:Ljava/lang/String;

    .line 156
    .line 157
    iput-object p2, v0, Lnlo0;->I:Landroid/os/Bundle;

    .line 158
    .line 159
    iput-object p3, v0, Lnlo0;->O:Ljlo0;

    .line 160
    .line 161
    iput-object p0, v0, Lnlo0;->o:Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;

    .line 162
    .line 163
    iput v6, v0, Lnlo0;->lO:I

    .line 164
    .line 165
    invoke-virtual {v2, p1, v0}, Lnno0;->ll(Ljava/lang/String;Lxce;)Ljava/lang/Object;

    .line 166
    .line 167
    .line 168
    move-result-object v2

    .line 169
    if-ne v2, v1, :cond_8

    .line 170
    .line 171
    goto/16 :goto_c

    .line 172
    .line 173
    :cond_8
    move-object v6, v2

    .line 174
    move-object v2, p2

    .line 175
    move-object p2, p3

    .line 176
    move-object p3, v6

    .line 177
    move-object v6, p1

    .line 178
    move-object p1, p0

    .line 179
    :goto_2
    check-cast p3, Landroid/graphics/Bitmap;

    .line 180
    .line 181
    iput-object p3, p1, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->Ol:Landroid/graphics/Bitmap;

    .line 182
    .line 183
    new-instance p1, Lrmo0;

    .line 184
    .line 185
    iget-object p2, p2, Ljlo0;->l:Lplo0;

    .line 186
    .line 187
    sget-object p3, Lnno0;->II:Lbxf0;

    .line 188
    .line 189
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 190
    .line 191
    .line 192
    const-wide v9, -0x13e30a2a0c56e39L

    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    invoke-static {v9, v10}, Li6t0;->lO(J)Ljava/lang/String;

    .line 198
    .line 199
    .line 200
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 201
    .line 202
    .line 203
    const-wide v9, -0x13e30a5a0c56e39L

    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    invoke-static {v9, v10}, Li6t0;->lO(J)Ljava/lang/String;

    .line 209
    .line 210
    .line 211
    move-result-object p3

    .line 212
    invoke-virtual {p3, v6}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 213
    .line 214
    .line 215
    move-result-object p3

    .line 216
    invoke-direct {p1, p0, p2, p0, p3}, Lrmo0;-><init>(Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;Lplo0;Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;Ljava/lang/String;)V

    .line 217
    .line 218
    .line 219
    iget-object p3, p0, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->lI:Lkc10;

    .line 220
    .line 221
    check-cast p3, Laif0;

    .line 222
    .line 223
    invoke-virtual {p3, p1}, Laif0;->setValue(Ljava/lang/Object;)V

    .line 224
    .line 225
    .line 226
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 227
    .line 228
    .line 229
    move-result-object p3

    .line 230
    const-wide v9, -0x12f8814a0c56e39L

    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    invoke-static {v9, v10}, Li6t0;->lO(J)Ljava/lang/String;

    .line 236
    .line 237
    .line 238
    move-result-object v7

    .line 239
    invoke-virtual {p3, v7}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 240
    .line 241
    .line 242
    move-result-object p3

    .line 243
    if-nez p3, :cond_9

    .line 244
    .line 245
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 246
    .line 247
    .line 248
    move-result-object p3

    .line 249
    invoke-static {p3}, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->oo(Landroid/content/Intent;)Ljava/lang/String;

    .line 250
    .line 251
    .line 252
    move-result-object p3

    .line 253
    :cond_9
    if-eqz v2, :cond_a

    .line 254
    .line 255
    const-string v7, "webapp.webview"

    .line 256
    .line 257
    invoke-virtual {v2, v7}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    .line 258
    .line 259
    .line 260
    move-result-object v2

    .line 261
    if-eqz v2, :cond_a

    .line 262
    .line 263
    iget-object v7, p1, Lrmo0;->lI:Landroid/webkit/WebView;

    .line 264
    .line 265
    invoke-virtual {v7, v2}, Landroid/webkit/WebView;->restoreState(Landroid/os/Bundle;)Landroid/webkit/WebBackForwardList;

    .line 266
    .line 267
    .line 268
    move-result-object v2

    .line 269
    goto :goto_3

    .line 270
    :cond_a
    move-object v2, v8

    .line 271
    :goto_3
    if-eqz v2, :cond_b

    .line 272
    .line 273
    goto :goto_8

    .line 274
    :cond_b
    iget-object v2, p1, Lrmo0;->II:Landroid/content/SharedPreferences;

    .line 275
    .line 276
    const-string v7, "last_url"

    .line 277
    .line 278
    invoke-interface {v2, v7, v8}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 279
    .line 280
    .line 281
    move-result-object v2

    .line 282
    if-eqz v2, :cond_c

    .line 283
    .line 284
    iget-boolean v7, p2, Lplo0;->llo:Z

    .line 285
    .line 286
    if-eqz v7, :cond_c

    .line 287
    .line 288
    invoke-static {v2}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 289
    .line 290
    .line 291
    move-result-object v7

    .line 292
    invoke-virtual {p1, v7}, Lrmo0;->ol(Landroid/net/Uri;)Z

    .line 293
    .line 294
    .line 295
    move-result v7

    .line 296
    if-eqz v7, :cond_c

    .line 297
    .line 298
    goto :goto_4

    .line 299
    :cond_c
    move-object v2, v8

    .line 300
    :goto_4
    if-eqz p3, :cond_f

    .line 301
    .line 302
    invoke-static {p3}, Ligh0;->isBlank(Ljava/lang/CharSequence;)Z

    .line 303
    .line 304
    .line 305
    move-result v7

    .line 306
    if-nez v7, :cond_d

    .line 307
    .line 308
    goto :goto_5

    .line 309
    :cond_d
    move-object p3, v8

    .line 310
    :goto_5
    if-nez p3, :cond_e

    .line 311
    .line 312
    goto :goto_6

    .line 313
    :cond_e
    move-object v2, p3

    .line 314
    goto :goto_7

    .line 315
    :cond_f
    :goto_6
    if-nez v2, :cond_10

    .line 316
    .line 317
    iget-object v2, p2, Lplo0;->O:Ljava/lang/String;

    .line 318
    .line 319
    :cond_10
    :goto_7
    new-instance p3, Lgmo0;

    .line 320
    .line 321
    invoke-direct {p3, p1, v2, v3}, Lgmo0;-><init>(Lrmo0;Ljava/lang/String;B)V

    .line 322
    .line 323
    .line 324
    invoke-virtual {p1, v2, p3}, Lrmo0;->OI(Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V

    .line 325
    .line 326
    .line 327
    :goto_8
    invoke-virtual {p0}, Lcfd;->getLifecycle()Luvu;

    .line 328
    .line 329
    .line 330
    move-result-object p3

    .line 331
    check-cast p3, Lowu;

    .line 332
    .line 333
    iget-object p3, p3, Lowu;->Il:Ltvu;

    .line 334
    .line 335
    sget-object v2, Ltvu;->o:Ltvu;

    .line 336
    .line 337
    invoke-virtual {p3, v2}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    .line 338
    .line 339
    .line 340
    move-result p3

    .line 341
    if-ltz p3, :cond_12

    .line 342
    .line 343
    iget-object p3, p1, Lrmo0;->lI:Landroid/webkit/WebView;

    .line 344
    .line 345
    invoke-virtual {p3}, Landroid/webkit/WebView;->onResume()V

    .line 346
    .line 347
    .line 348
    iget-object p3, p1, Lrmo0;->lI:Landroid/webkit/WebView;

    .line 349
    .line 350
    invoke-virtual {p3}, Landroid/webkit/WebView;->resumeTimers()V

    .line 351
    .line 352
    .line 353
    iget-object p3, p1, Lrmo0;->ol:Landroid/webkit/WebView;

    .line 354
    .line 355
    if-eqz p3, :cond_11

    .line 356
    .line 357
    invoke-virtual {p3}, Landroid/webkit/WebView;->onResume()V

    .line 358
    .line 359
    .line 360
    :cond_11
    invoke-virtual {p1}, Lrmo0;->lIl()V

    .line 361
    .line 362
    .line 363
    :cond_12
    iget-object p3, p2, Lplo0;->ll:Ljava/lang/Integer;

    .line 364
    .line 365
    iget-object v2, p2, Lplo0;->I:Ljava/lang/String;

    .line 366
    .line 367
    if-eqz p3, :cond_13

    .line 368
    .line 369
    invoke-virtual {p3}, Ljava/lang/Number;->intValue()I

    .line 370
    .line 371
    .line 372
    move-result p3

    .line 373
    new-instance v7, Landroid/app/ActivityManager$TaskDescription;

    .line 374
    .line 375
    iget-object v9, p0, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->Ol:Landroid/graphics/Bitmap;

    .line 376
    .line 377
    const/high16 v10, -0x1000000

    .line 378
    .line 379
    or-int/2addr p3, v10

    .line 380
    invoke-direct {v7, v2, v9, p3}, Landroid/app/ActivityManager$TaskDescription;-><init>(Ljava/lang/String;Landroid/graphics/Bitmap;I)V

    .line 381
    .line 382
    .line 383
    goto :goto_9

    .line 384
    :cond_13
    new-instance v7, Landroid/app/ActivityManager$TaskDescription;

    .line 385
    .line 386
    iget-object p3, p0, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->Ol:Landroid/graphics/Bitmap;

    .line 387
    .line 388
    invoke-direct {v7, v2, p3}, Landroid/app/ActivityManager$TaskDescription;-><init>(Ljava/lang/String;Landroid/graphics/Bitmap;)V

    .line 389
    .line 390
    .line 391
    :goto_9
    invoke-virtual {p0, v7}, Landroid/app/Activity;->setTaskDescription(Landroid/app/ActivityManager$TaskDescription;)V

    .line 392
    .line 393
    .line 394
    iget-boolean p2, p2, Lplo0;->lIl:Z

    .line 395
    .line 396
    if-eqz p2, :cond_14

    .line 397
    .line 398
    invoke-virtual {p0}, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->OI()V

    .line 399
    .line 400
    .line 401
    :cond_14
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 402
    .line 403
    .line 404
    move-result-object p2

    .line 405
    if-eqz p2, :cond_15

    .line 406
    .line 407
    const-wide v9, -0x12f8911a0c56e39L

    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    invoke-static {v9, v10}, Li6t0;->lO(J)Ljava/lang/String;

    .line 413
    .line 414
    .line 415
    move-result-object p3

    .line 416
    invoke-virtual {p2, p3, v3}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    .line 417
    .line 418
    .line 419
    move-result p2

    .line 420
    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 421
    .line 422
    .line 423
    move-result-object p3

    .line 424
    if-lez p2, :cond_15

    .line 425
    .line 426
    goto :goto_a

    .line 427
    :cond_15
    move-object p3, v8

    .line 428
    :goto_a
    if-eqz p3, :cond_16

    .line 429
    .line 430
    invoke-virtual {p3}, Ljava/lang/Number;->intValue()I

    .line 431
    .line 432
    .line 433
    move-result p2

    .line 434
    if-lez p2, :cond_16

    .line 435
    .line 436
    iget-object p1, p1, Lrmo0;->lI:Landroid/webkit/WebView;

    .line 437
    .line 438
    new-instance p3, Ljava/lang/StringBuilder;

    .line 439
    .line 440
    const-string v2, "window.__voyageWebApp&&window.__voyageWebApp.clicked("

    .line 441
    .line 442
    invoke-direct {p3, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 443
    .line 444
    .line 445
    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 446
    .line 447
    .line 448
    const-string p2, ")"

    .line 449
    .line 450
    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 451
    .line 452
    .line 453
    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 454
    .line 455
    .line 456
    move-result-object p2

    .line 457
    invoke-virtual {p1, p2, v8}, Landroid/webkit/WebView;->evaluateJavascript(Ljava/lang/String;Landroid/webkit/ValueCallback;)V

    .line 458
    .line 459
    .line 460
    :cond_16
    invoke-virtual {p0}, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->Io()Lnno0;

    .line 461
    .line 462
    .line 463
    move-result-object p1

    .line 464
    iput-object v8, v0, Lnlo0;->l:Ljava/lang/String;

    .line 465
    .line 466
    iput-object v8, v0, Lnlo0;->I:Landroid/os/Bundle;

    .line 467
    .line 468
    iput-object v8, v0, Lnlo0;->O:Ljlo0;

    .line 469
    .line 470
    iput-object v8, v0, Lnlo0;->o:Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;

    .line 471
    .line 472
    iput v5, v0, Lnlo0;->lO:I

    .line 473
    .line 474
    invoke-virtual {p1, v6, v0}, Lnno0;->lo(Ljava/lang/String;Lxce;)Ljava/lang/Object;

    .line 475
    .line 476
    .line 477
    move-result-object p1

    .line 478
    if-ne p1, v1, :cond_17

    .line 479
    .line 480
    goto :goto_c

    .line 481
    :cond_17
    :goto_b
    sget-object p1, Lymo0;->l:Lymo0;

    .line 482
    .line 483
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 484
    .line 485
    .line 486
    move-result-object p2

    .line 487
    const-wide v2, -0x12f881fa0c56e39L

    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    invoke-static {v2, v3}, Li6t0;->lO(J)Ljava/lang/String;

    .line 493
    .line 494
    .line 495
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 496
    .line 497
    .line 498
    invoke-virtual {p0}, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->Io()Lnno0;

    .line 499
    .line 500
    .line 501
    move-result-object p0

    .line 502
    iput-object v8, v0, Lnlo0;->l:Ljava/lang/String;

    .line 503
    .line 504
    iput-object v8, v0, Lnlo0;->I:Landroid/os/Bundle;

    .line 505
    .line 506
    iput-object v8, v0, Lnlo0;->O:Ljlo0;

    .line 507
    .line 508
    iput-object v8, v0, Lnlo0;->o:Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;

    .line 509
    .line 510
    iput v4, v0, Lnlo0;->lO:I

    .line 511
    .line 512
    invoke-virtual {p1, p2, p0, v0}, Lymo0;->o(Landroid/content/Context;Lnno0;Lxce;)Ljava/lang/Object;

    .line 513
    .line 514
    .line 515
    move-result-object p0

    .line 516
    if-ne p0, v1, :cond_18

    .line 517
    .line 518
    :goto_c
    return-object v1

    .line 519
    :cond_18
    return-object p0
.end method

.method public final onCreate(Landroid/os/Bundle;)V
    .locals 8

    .line 1
    invoke-virtual {p0, p1}, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->OO(Landroid/os/Bundle;)V

    .line 2
    .line 3
    .line 4
    invoke-static {p0}, Ljgj;->I(Lcfd;)V

    .line 5
    .line 6
    .line 7
    sget-object v0, Lymo0;->l:Lymo0;

    .line 8
    .line 9
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14
    .line 15
    .line 16
    const/4 v6, 0x0

    .line 17
    if-eqz v1, :cond_1

    .line 18
    .line 19
    invoke-virtual {v1}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    if-eqz v0, :cond_1

    .line 24
    .line 25
    invoke-virtual {v0}, Landroid/net/Uri;->getScheme()Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object v1

    .line 29
    const-wide v2, -0x13e2f3aa0c56e39L

    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    invoke-static {v2, v3}, Li6t0;->lO(J)Ljava/lang/String;

    .line 35
    .line 36
    .line 37
    move-result-object v2

    .line 38
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 39
    .line 40
    .line 41
    move-result v1

    .line 42
    if-eqz v1, :cond_0

    .line 43
    .line 44
    invoke-virtual {v0}, Landroid/net/Uri;->getHost()Ljava/lang/String;

    .line 45
    .line 46
    .line 47
    move-result-object v1

    .line 48
    const-wide v2, -0x13e2f48a0c56e39L

    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    invoke-static {v2, v3}, Li6t0;->lO(J)Ljava/lang/String;

    .line 54
    .line 55
    .line 56
    move-result-object v2

    .line 57
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 58
    .line 59
    .line 60
    move-result v1

    .line 61
    if-eqz v1, :cond_0

    .line 62
    .line 63
    goto :goto_0

    .line 64
    :cond_0
    move-object v0, v6

    .line 65
    :goto_0
    if-eqz v0, :cond_1

    .line 66
    .line 67
    invoke-virtual {v0}, Landroid/net/Uri;->getLastPathSegment()Ljava/lang/String;

    .line 68
    .line 69
    .line 70
    move-result-object v0

    .line 71
    move-object v4, v0

    .line 72
    goto :goto_1

    .line 73
    :cond_1
    move-object v4, v6

    .line 74
    :goto_1
    if-nez v4, :cond_2

    .line 75
    .line 76
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    .line 77
    .line 78
    .line 79
    return-void

    .line 80
    :cond_2
    invoke-virtual {p0}, Lcfd;->getOnBackPressedDispatcher()Ljz30;

    .line 81
    .line 82
    .line 83
    move-result-object v0

    .line 84
    new-instance v1, Lmlo0;

    .line 85
    .line 86
    invoke-direct {v1, p0}, Lmlo0;-><init>(Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;)V

    .line 87
    .line 88
    .line 89
    invoke-virtual {v0, p0, v1}, Ljz30;->l(Lkwu;Lez30;)V

    .line 90
    .line 91
    .line 92
    invoke-static {p0}, Lavv0;->OO(Lkwu;)Lbwu;

    .line 93
    .line 94
    .line 95
    move-result-object v0

    .line 96
    new-instance v2, Lhqn0;

    .line 97
    .line 98
    const/16 v7, 0x18

    .line 99
    .line 100
    move-object v3, p0

    .line 101
    move-object v5, p1

    .line 102
    invoke-direct/range {v2 .. v7}, Lhqn0;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lvce;B)V

    .line 103
    .line 104
    .line 105
    const/4 p0, 0x3

    .line 106
    invoke-static {v0, v6, v6, v2, p0}, Lw19;->loI(Lqoe;Lhoe;Ltoe;Lkotlin/jvm/functions/Function2;I)Lp9g0;

    .line 107
    .line 108
    .line 109
    new-instance p0, Lklo0;

    .line 110
    .line 111
    const/4 p1, 0x0

    .line 112
    invoke-direct {p0, v3, p1}, Lklo0;-><init>(Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;B)V

    .line 113
    .line 114
    .line 115
    new-instance p1, Lggd;

    .line 116
    .line 117
    const v0, 0x15cbf15c

    .line 118
    .line 119
    .line 120
    const/4 v1, 0x1

    .line 121
    invoke-direct {p1, p0, v0, v1}, Lggd;-><init>(Ljava/lang/Object;IZ)V

    .line 122
    .line 123
    .line 124
    invoke-static {v3, p1}, Ldfd;->l(Lcfd;Lggd;)V

    .line 125
    .line 126
    .line 127
    return-void
.end method

.method public final onDestroy()V
    .locals 5

    .line 1
    invoke-virtual {p0}, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->IO()Lrmo0;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    const/4 v1, 0x0

    .line 6
    if-eqz v0, :cond_3

    .line 7
    .line 8
    iget-boolean v2, v0, Lrmo0;->lOI:Z

    .line 9
    .line 10
    if-eqz v2, :cond_0

    .line 11
    .line 12
    goto :goto_0

    .line 13
    :cond_0
    const/4 v2, 0x1

    .line 14
    iput-boolean v2, v0, Lrmo0;->lOI:Z

    .line 15
    .line 16
    iget-object v2, v0, Lrmo0;->lIo:Lpt;

    .line 17
    .line 18
    if-eqz v2, :cond_1

    .line 19
    .line 20
    :try_start_0
    iget-object v3, v0, Lrmo0;->l:Landroid/app/Activity;

    .line 21
    .line 22
    const-string v4, "connectivity"

    .line 23
    .line 24
    invoke-virtual {v3, v4}, Landroid/app/Activity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    move-result-object v3

    .line 28
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 29
    .line 30
    .line 31
    check-cast v3, Landroid/net/ConnectivityManager;

    .line 32
    .line 33
    invoke-virtual {v3, v2}, Landroid/net/ConnectivityManager;->unregisterNetworkCallback(Landroid/net/ConnectivityManager$NetworkCallback;)V

    .line 34
    .line 35
    .line 36
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 37
    .line 38
    :catchall_0
    :cond_1
    iget-object v2, v0, Lrmo0;->llI:Landroid/webkit/ValueCallback;

    .line 39
    .line 40
    if-eqz v2, :cond_2

    .line 41
    .line 42
    invoke-interface {v2, v1}, Landroid/webkit/ValueCallback;->onReceiveValue(Ljava/lang/Object;)V

    .line 43
    .line 44
    .line 45
    :cond_2
    iput-object v1, v0, Lrmo0;->llI:Landroid/webkit/ValueCallback;

    .line 46
    .line 47
    invoke-virtual {v0}, Lrmo0;->lo()V

    .line 48
    .line 49
    .line 50
    :try_start_1
    iget-object v2, v0, Lrmo0;->lI:Landroid/webkit/WebView;

    .line 51
    .line 52
    invoke-virtual {v2}, Landroid/webkit/WebView;->resumeTimers()V

    .line 53
    .line 54
    .line 55
    iget-object v2, v0, Lrmo0;->lI:Landroid/webkit/WebView;

    .line 56
    .line 57
    invoke-virtual {v2}, Landroid/webkit/WebView;->stopLoading()V

    .line 58
    .line 59
    .line 60
    iget-object v2, v0, Lrmo0;->lI:Landroid/webkit/WebView;

    .line 61
    .line 62
    invoke-virtual {v2, v1}, Landroid/webkit/WebView;->setWebChromeClient(Landroid/webkit/WebChromeClient;)V

    .line 63
    .line 64
    .line 65
    iget-object v2, v0, Lrmo0;->lI:Landroid/webkit/WebView;

    .line 66
    .line 67
    const-string v3, "about:blank"

    .line 68
    .line 69
    invoke-virtual {v2, v3}, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V

    .line 70
    .line 71
    .line 72
    iget-object v2, v0, Lrmo0;->lI:Landroid/webkit/WebView;

    .line 73
    .line 74
    invoke-virtual {v2}, Landroid/webkit/WebView;->destroy()V

    .line 75
    .line 76
    .line 77
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 78
    .line 79
    :catchall_1
    iget-object v0, v0, Lrmo0;->Io:Ljava/util/concurrent/ExecutorService;

    .line 80
    .line 81
    invoke-interface {v0}, Ljava/util/concurrent/ExecutorService;->shutdown()V

    .line 82
    .line 83
    .line 84
    :cond_3
    :goto_0
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->lI:Lkc10;

    .line 85
    .line 86
    check-cast v0, Laif0;

    .line 87
    .line 88
    invoke-virtual {v0, v1}, Laif0;->setValue(Ljava/lang/Object;)V

    .line 89
    .line 90
    .line 91
    invoke-virtual {p0}, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->Oo()V

    .line 92
    .line 93
    .line 94
    return-void
.end method

.method public final onNewIntent(Landroid/content/Intent;)V
    .locals 3

    .line 1
    const-wide v0, -0x12f886aa0c56e39L

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    invoke-super {p0, p1}, Lcfd;->onNewIntent(Landroid/content/Intent;)V

    .line 13
    .line 14
    .line 15
    invoke-virtual {p0, p1}, Landroid/app/Activity;->setIntent(Landroid/content/Intent;)V

    .line 16
    .line 17
    .line 18
    invoke-virtual {p0}, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->IO()Lrmo0;

    .line 19
    .line 20
    .line 21
    move-result-object p0

    .line 22
    if-nez p0, :cond_0

    .line 23
    .line 24
    goto :goto_1

    .line 25
    :cond_0
    const-wide v0, -0x12f8871a0c56e39L

    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    invoke-virtual {p1, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    if-nez v0, :cond_1

    .line 39
    .line 40
    invoke-static {p1}, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->oo(Landroid/content/Intent;)Ljava/lang/String;

    .line 41
    .line 42
    .line 43
    move-result-object v0

    .line 44
    :cond_1
    if-eqz v0, :cond_2

    .line 45
    .line 46
    invoke-virtual {p0, v0}, Lrmo0;->oO(Ljava/lang/String;)V

    .line 47
    .line 48
    .line 49
    :cond_2
    const-wide v0, -0x12f8911a0c56e39L

    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    const/4 v1, 0x0

    .line 59
    invoke-virtual {p1, v0, v1}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    .line 60
    .line 61
    .line 62
    move-result p1

    .line 63
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 64
    .line 65
    .line 66
    move-result-object v0

    .line 67
    const/4 v1, 0x0

    .line 68
    if-lez p1, :cond_3

    .line 69
    .line 70
    goto :goto_0

    .line 71
    :cond_3
    move-object v0, v1

    .line 72
    :goto_0
    if-eqz v0, :cond_4

    .line 73
    .line 74
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 75
    .line 76
    .line 77
    move-result p1

    .line 78
    if-lez p1, :cond_4

    .line 79
    .line 80
    iget-object p0, p0, Lrmo0;->lI:Landroid/webkit/WebView;

    .line 81
    .line 82
    new-instance v0, Ljava/lang/StringBuilder;

    .line 83
    .line 84
    const-string v2, "window.__voyageWebApp&&window.__voyageWebApp.clicked("

    .line 85
    .line 86
    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 87
    .line 88
    .line 89
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 90
    .line 91
    .line 92
    const-string p1, ")"

    .line 93
    .line 94
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 95
    .line 96
    .line 97
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 98
    .line 99
    .line 100
    move-result-object p1

    .line 101
    invoke-virtual {p0, p1, v1}, Landroid/webkit/WebView;->evaluateJavascript(Ljava/lang/String;Landroid/webkit/ValueCallback;)V

    .line 102
    .line 103
    .line 104
    :cond_4
    :goto_1
    return-void
.end method

.method public final onSaveInstanceState(Landroid/os/Bundle;)V
    .locals 2

    .line 1
    const-wide v0, -0x12f887ca0c56e39L    # -7.05774788643533E302

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    invoke-super {p0, p1}, Lcfd;->onSaveInstanceState(Landroid/os/Bundle;)V

    .line 13
    .line 14
    .line 15
    invoke-virtual {p0}, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->IO()Lrmo0;

    .line 16
    .line 17
    .line 18
    move-result-object p0

    .line 19
    if-eqz p0, :cond_0

    .line 20
    .line 21
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    .line 23
    .line 24
    new-instance v0, Landroid/os/Bundle;

    .line 25
    .line 26
    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 27
    .line 28
    .line 29
    :try_start_0
    iget-object p0, p0, Lrmo0;->lI:Landroid/webkit/WebView;

    .line 30
    .line 31
    invoke-virtual {p0, v0}, Landroid/webkit/WebView;->saveState(Landroid/os/Bundle;)Landroid/webkit/WebBackForwardList;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 32
    .line 33
    .line 34
    :catchall_0
    const-string p0, "webapp.webview"

    .line 35
    .line 36
    invoke-virtual {p1, p0, v0}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    .line 37
    .line 38
    .line 39
    :cond_0
    return-void
.end method

.method public final onStart()V
    .locals 4

    .line 1
    invoke-super {p0}, Landroid/app/Activity;->onStart()V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->IO()Lrmo0;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    if-nez v0, :cond_0

    .line 9
    .line 10
    goto :goto_0

    .line 11
    :cond_0
    iget-object v1, v0, Lrmo0;->lI:Landroid/webkit/WebView;

    .line 12
    .line 13
    invoke-virtual {v1}, Landroid/webkit/WebView;->onResume()V

    .line 14
    .line 15
    .line 16
    iget-object v1, v0, Lrmo0;->lI:Landroid/webkit/WebView;

    .line 17
    .line 18
    invoke-virtual {v1}, Landroid/webkit/WebView;->resumeTimers()V

    .line 19
    .line 20
    .line 21
    iget-object v1, v0, Lrmo0;->ol:Landroid/webkit/WebView;

    .line 22
    .line 23
    if-eqz v1, :cond_1

    .line 24
    .line 25
    invoke-virtual {v1}, Landroid/webkit/WebView;->onResume()V

    .line 26
    .line 27
    .line 28
    :cond_1
    invoke-virtual {v0}, Lrmo0;->lIl()V

    .line 29
    .line 30
    .line 31
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->lO:Lkc10;

    .line 32
    .line 33
    check-cast v0, Laif0;

    .line 34
    .line 35
    invoke-virtual {v0}, Laif0;->getValue()Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    check-cast v0, Ljlo0;

    .line 40
    .line 41
    if-eqz v0, :cond_3

    .line 42
    .line 43
    iget-object v0, v0, Ljlo0;->l:Lplo0;

    .line 44
    .line 45
    if-nez v0, :cond_2

    .line 46
    .line 47
    goto :goto_0

    .line 48
    :cond_2
    iget-boolean v0, v0, Lplo0;->lIl:Z

    .line 49
    .line 50
    if-eqz v0, :cond_3

    .line 51
    .line 52
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->IO:Lkc10;

    .line 53
    .line 54
    check-cast v0, Laif0;

    .line 55
    .line 56
    invoke-virtual {v0}, Laif0;->getValue()Ljava/lang/Object;

    .line 57
    .line 58
    .line 59
    move-result-object v0

    .line 60
    check-cast v0, Ljava/lang/Boolean;

    .line 61
    .line 62
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 63
    .line 64
    .line 65
    move-result v0

    .line 66
    if-nez v0, :cond_3

    .line 67
    .line 68
    iget-wide v0, p0, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->Oo:J

    .line 69
    .line 70
    const-wide/16 v2, 0x0

    .line 71
    .line 72
    cmp-long v0, v0, v2

    .line 73
    .line 74
    if-lez v0, :cond_3

    .line 75
    .line 76
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 77
    .line 78
    .line 79
    move-result-wide v0

    .line 80
    iget-wide v2, p0, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->Oo:J

    .line 81
    .line 82
    sub-long/2addr v0, v2

    .line 83
    const-wide/32 v2, 0xea60

    .line 84
    .line 85
    .line 86
    cmp-long v0, v0, v2

    .line 87
    .line 88
    if-lez v0, :cond_3

    .line 89
    .line 90
    invoke-virtual {p0}, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->OI()V

    .line 91
    .line 92
    .line 93
    :cond_3
    :goto_0
    return-void
.end method

.method public final onStop()V
    .locals 2

    .line 1
    invoke-super {p0}, Landroid/app/Activity;->onStop()V

    .line 2
    .line 3
    .line 4
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 5
    .line 6
    .line 7
    move-result-wide v0

    .line 8
    iput-wide v0, p0, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->Oo:J

    .line 9
    .line 10
    invoke-virtual {p0}, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->IO()Lrmo0;

    .line 11
    .line 12
    .line 13
    move-result-object p0

    .line 14
    if-eqz p0, :cond_2

    .line 15
    .line 16
    invoke-static {}, Landroid/webkit/CookieManager;->getInstance()Landroid/webkit/CookieManager;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    invoke-virtual {v0}, Landroid/webkit/CookieManager;->flush()V

    .line 21
    .line 22
    .line 23
    iget-object v0, p0, Lrmo0;->I:Lplo0;

    .line 24
    .line 25
    iget-boolean v0, v0, Lplo0;->lIo:Z

    .line 26
    .line 27
    if-eqz v0, :cond_0

    .line 28
    .line 29
    goto :goto_0

    .line 30
    :cond_0
    iget-object v0, p0, Lrmo0;->lI:Landroid/webkit/WebView;

    .line 31
    .line 32
    invoke-virtual {v0}, Landroid/webkit/WebView;->onPause()V

    .line 33
    .line 34
    .line 35
    iget-object v0, p0, Lrmo0;->ol:Landroid/webkit/WebView;

    .line 36
    .line 37
    if-eqz v0, :cond_1

    .line 38
    .line 39
    invoke-virtual {v0}, Landroid/webkit/WebView;->onPause()V

    .line 40
    .line 41
    .line 42
    :cond_1
    iget-object p0, p0, Lrmo0;->lI:Landroid/webkit/WebView;

    .line 43
    .line 44
    invoke-virtual {p0}, Landroid/webkit/WebView;->pauseTimers()V

    .line 45
    .line 46
    .line 47
    :cond_2
    :goto_0
    return-void
.end method

.method public requestPermissions([Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    .line 1
    const-wide v0, -0x12f8885a0c56e39L

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    const-wide v0, -0x12f8891a0c56e39L

    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    invoke-static {v0, v1}, Li6t0;->lO(J)Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 21
    .line 22
    .line 23
    array-length v0, p1

    .line 24
    sget-object v1, Lnpj;->l:Lnpj;

    .line 25
    .line 26
    if-nez v0, :cond_0

    .line 27
    .line 28
    invoke-interface {p2, v1}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    return-void

    .line 32
    :cond_0
    iget-object v0, p0, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->ol:Lkotlin/jvm/functions/Function1;

    .line 33
    .line 34
    if-eqz v0, :cond_1

    .line 35
    .line 36
    invoke-interface {v0, v1}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    :cond_1
    iput-object p2, p0, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->ol:Lkotlin/jvm/functions/Function1;

    .line 40
    .line 41
    iget-object p0, p0, Lcom/chuanyi/voyage/ui/webapp/WebAppActivity;->oO:Ldn;

    .line 42
    .line 43
    invoke-virtual {p0, p1}, Ldn;->l(Ljava/lang/Object;)V

    .line 44
    .line 45
    .line 46
    return-void
.end method
