package com.example.audioeraserbannerhider;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public final class AudioEraserBannerHider implements IXposedHookLoadPackage {
    private static final String TAG = "AudioEraserBannerHider";
    private static final String TARGET_PACKAGE = "com.android.systemui";
    private static final String TARGET_CLASS = "com.android.systemui.samsung.quicksetting.ui.banner.TopBannerViewModel$1$2";
    private static final String AUDIO_ERASER_CLASS = "com.android.systemui.samsung.quicksetting.ui.banner.AudioEraser";

    @Override public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {
        if (!TARGET_PACKAGE.equals(lpparam.packageName)) return;
        try {
            final Class<?> coroutineClass = Class.forName(TARGET_CLASS, false, lpparam.classLoader);
            XposedBridge.hookAllMethods(coroutineClass, "invokeSuspend", new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam param) {
                    try {
                        Field listField = findField(param.thisObject.getClass(), "L$0");
                        listField.setAccessible(true);
                        Object current = listField.get(param.thisObject);
                        if (!(current instanceof List<?>)) return;
                        List<?> source = (List<?>) current;
                        List<Object> filtered = new ArrayList<>(source.size());
                        int removed = 0;
                        for (Object item : source) {
                            if (item != null && AUDIO_ERASER_CLASS.equals(item.getClass().getName())) removed++;
                            else filtered.add(item);
                        }
                        if (removed > 0) {
                            listField.set(param.thisObject, filtered);
                            XposedBridge.log(TAG + ": filtered " + removed + " AudioEraser banner(s)");
                        }
                    } catch (Throwable t) { XposedBridge.log(TAG + ": list filtering failed: " + t); }
                }
            });
            XposedBridge.log(TAG + ": hook installed in SystemUI");
        } catch (Throwable t) { XposedBridge.log(TAG + ": failed to install hook: " + t); }
    }

    private static Field findField(Class<?> type, String name) throws NoSuchFieldException {
        Class<?> current = type;
        while (current != null) {
            try { return current.getDeclaredField(name); }
            catch (NoSuchFieldException ignored) { current = current.getSuperclass(); }
        }
        throw new NoSuchFieldException(name);
    }
}
