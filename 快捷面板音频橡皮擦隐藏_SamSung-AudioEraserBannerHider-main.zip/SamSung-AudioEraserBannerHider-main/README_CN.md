# Audio Eraser Banner Hider（实验性源码）

用途：在 Samsung SystemUI 发布顶部横幅列表前，仅过滤 `AudioEraser` 对象；不改音频橡皮擦启用状态，不过滤 MicMode、VideoCallEffect、VoIPTranslator 等其他横幅。

## 重要限制
- 这是**源码工程**，不是已经编译和实机验证的 APK。
- 使用 LSPosed 传统 Xposed API（API 82）。LSPosed 2.x 通常兼容传统模块，但需在你的实际环境验证。
- Hook 根据你提供的 One UI 8.5 SystemUI Smali 类名和字段 `L$0` 编写。系统更新后类名/字段可能变化。
- LSPosed 模块需作为 APK 安装并在 LSPosed 中启用；KernelSU 本身不能代替 Java Hook 框架。
- 未在设备上验证，可能出现 Hook 不生效。若 SystemUI 异常，先在 LSPosed 中禁用此模块并重启设备。

## 编译
1. 用 Android Studio 打开本目录。
2. 等待 Gradle 同步；若依赖下载失败，检查网络和仓库配置。
3. 选择 Build > Build APK(s)。
4. APK 通常输出到 `app/build/outputs/apk/debug/app-debug.apk`。

## 安装与启用
1. 安装 APK。
2. 在 LSPosed 管理器的“模块”页启用 Audio Eraser Banner Hider。
3. 进入模块作用域，勾选 `System UI` / `com.android.systemui`（若显示该项）。
4. 重启设备，或确保 SystemUI 进程重新启动。
5. 播放音频测试：音频橡皮擦横幅应不再显示；其他顶部横幅应照常显示。

## 回滚
在 LSPosed 管理器中禁用模块并重启设备。

## 工作原理
Hook `TopBannerViewModel$1$2.invokeSuspend()` 的执行前阶段，从协程实例的 `L$0` 读取即将发布的 List，将类型名完全等于 `com.android.systemui.samsung.quicksetting.ui.banner.AudioEraser` 的元素过滤后写回 `L$0`。
